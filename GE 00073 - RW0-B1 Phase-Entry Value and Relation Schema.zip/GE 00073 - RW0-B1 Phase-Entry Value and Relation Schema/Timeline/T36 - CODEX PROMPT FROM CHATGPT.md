TITLE

Coordinator RW0-B1 — audited-byte commit, feature-branch push, and pull-request
gate

ENGAGEMENT TYPE

Commit and publication gate for the independently accepted RW0-B1 candidate.

Use the existing write-enabled RW0-B1 implementation conversation. Do not use
the independent-audit conversation.

This prompt explicitly authorizes only:

1. read-only local and remote preflight;
2. regeneration of the accepted working-tree provenance;
3. staging exactly the 17 audited paths;
4. exact staged-blob comparison;
5. one isolated final node collection and one complete pytest suite on frozen
   staged bytes;
6. one Git commit with the exact subject below;
7. one plain push to the existing feature-branch name;
8. creation of one non-draft pull request with the exact title and body below;
9. read-only local/remote/PR verification and external evidence retention.

This prompt does NOT authorize:

- implementation repair;
- source, documentation, or test editing;
- formatting;
- dependency installation;
- migration execution outside tests;
- direct push to `trunk_dev`;
- force push;
- amend, rebase, cherry-pick, reset, or alternate-history operation;
- a second commit or second push;
- review, self-approval, thread resolution, auto-merge, PR merge, branch deletion,
  tag, release, deployment, remote worker/model invocation, or supporting-repo
  mutation.

If any byte change is required, stop. Changed bytes require implementation
closeout and a fresh independent audit.

REPOSITORY

/Users/ds/Repositories/Governed Execution Coordinator/

ACCEPTED AUDIT

Safely read and retain:

`/private/tmp/gec-rw0-b1-audit5-ll6lr5xg/audit-report.md`

Require it to contain exactly:

- verdict:
  `ACCEPT`
- acceptance token:
  `COORDINATOR_RW0_B1_FOURTH_AUDIT_REPAIR_ACCEPTED_READY_FOR_COMMIT_AND_PR_GATE`
- no Critical, High, Medium, or Low patch defect;
- opening and closing provenance equality;
- candidate collection:
  4,566 nodes;
- independent complete suite:
  4,566 collected and 4,566 passed;
- no skip or warning;
- no repository mutation, repair, staging, commit, push, PR, remote contact,
  worker/model invocation, or supporting-repository mutation.

The report must bind or identify the exact accepted manifest, per-file
inventory, tracked-diff identity, node-list identity, and audit validation
records. If it does not, stop with:

`COMMIT_GATE_AUDIT_EVIDENCE_INSUFFICIENT`

ACCEPTED IMPLEMENTATION TARGET

Safely read and retain:

- implementation report:
  `/private/tmp/gec-rw0-b1-repair4.ljh_96ne/repair-report.md`
- accepted canonical manifest:
  `/private/tmp/gec-rw0-b1-repair4.ljh_96ne/final-provenance-1.manifest.json`
- implementation evidence root:
  `/private/tmp/gec-rw0-b1-repair4.ljh_96ne`

Require the accepted audit report to identify or byte-bind the same manifest.
Do not substitute an earlier RW0-B1 manifest.

PATH SAFETY

For every external evidence path:

- `/`, `/private`, and `/private/tmp` are trusted fixed system ancestors and may
  be root-owned;
- `/` and `/private` must be real directories;
- `/private/tmp` must be a real root-owned sticky temporary directory;
- the named implementation/audit roots and every descendant used here must be
  operator-owned, non-symlink, and a supported regular file/directory type;
- create one new operator-owned, non-symlink, mode-0700 commit-gate evidence
  root under `/private/tmp`;
- retain key evidence files mode 0400;
- never retain credentials, tokens, private values, raw WorkSpec/plan bytes,
  prompts, transcripts, endpoints, host identities, or raw database content.

OPENING REPOSITORY IDENTITY

Before remote contact, require exactly:

- root:
  `/Users/ds/Repositories/Governed Execution Coordinator/`
- branch:
  `codex/rw0-b1-pure-phase-values-v1`
- HEAD:
  `bf68a5232bff1b412c9414c076d82cab18c8e0aa`
- HEAD tree:
  `8fc05f5626bdbb01808df1698c9c2245ab06f1cb`
- sole parent:
  `1a894c5527c610ab40d8e5ae5e530a762c6e60bf`
- subject:
  `docs: freeze RW0-A phase-entry contract (#2)`
- upstream:
  `origin/trunk_dev`
- ahead/behind:
  `0/0`
- worktrees:
  `1`
- dirty paths:
  exactly 17
- tracked modifications:
  exactly 11
- untracked paths:
  exactly 6
- staged:
  0
- unmerged:
  0
- every candidate path:
  regular working-tree mode 0644
- no deleted, renamed, copied, symlinked, Git-mode-changed, or extra path;
- no Git operation, Git lock, or repository-local test/build/database/cache
  residue;
- `git diff --check` clean.

The exact accepted path set is:

- `.docs/rw0-b1-pure-phase-values.md`
- `src/ge_nwp_coordinator/_rw0_phase_entry_semantic_values.py`
- `tests/test_rw0_b1_phase_values.py`
- `tests/test_rw0_b1_relations.py`
- `tests/test_rw0_b1_vectors.py`
- `tests/test_rw0_b1_boundaries.py`
- `tests/test_c2a_nonimplementation.py`
- `tests/test_runtime_non_authority.py`
- `.docs/rw0-remote-worker-contact-phase-entry.md`
- `.docs/authority-boundaries.md`
- `.docs/autonomous-software-development-operating-model.md`
- `.docs/durable-state-model.md`
- `.docs/worker-execution-boundary.md`
- `tests/test_rw0_remote_contact_phase_entry_contract.py`
- `tests/test_architecture_contracts.py`
- `tests/test_remote_worker_pre_execution_planning_contract.py`
- `tests/test_c2b2_development_row_value_boundaries.py`

Stop on any mismatch. Do not restore, edit, or normalize the candidate.

EXACT PROVENANCE RECIPE

Verify the exact source bytes:

- size:
  3,945 bytes
- SHA-256:
  `db21f2b67ba73a03a98c1d309323e5cabc014a10248ef96d5e25cc52081460bc`

Safely classify the fixed recipe output path. Preserve a safe pre-existing
file's bytes, owner, mode, and timestamps before the first run; restore and
verify it after each provenance phase.

Run the exact recipe twice before remote contact and before staging.

Require:

- return code 0;
- empty stderr;
- byte-identical complete stdout;
- byte-identical canonical manifests;
- exact equality to the accepted canonical manifest;
- exact path classifications, modes, sizes, and SHA-256 values;
- exact accepted tracked textual-diff identity;
- exact branch, HEAD, and upstream.

On any mismatch, return:

`COMMIT_GATE_PROVENANCE_MISMATCH`

and stop.

Exact recipe:

```python
from __future__ import annotations

import hashlib
import json
import os
import stat
import subprocess
from pathlib import Path

RECIPE_ID = "governed-execution.audit-patch-manifest.v1"
OUTPUT_PATH = Path("/tmp/ge-coordinator-b3a-audit-manifest-v1.json")


def git_bytes(*args: str) -> bytes:
    env = os.environ.copy()
    env["LC_ALL"] = "C"
    env["LANG"] = "C"
    result = subprocess.run(
        ["git", *args],
        check=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        env=env,
    )
    return result.stdout


def git_text(*args: str) -> str:
    return git_bytes(*args).decode("utf-8", "strict").strip()


def nul_paths(data: bytes) -> list[str]:
    return [
        item.decode("utf-8", "strict")
        for item in data.split(b"\0")
        if item
    ]


head = git_text("rev-parse", "HEAD")
branch = git_text("branch", "--show-current")
upstream = git_text("rev-parse", "--abbrev-ref", "--symbolic-full-name", "@{u}")

tracked = set(
    nul_paths(git_bytes("diff", "--name-only", "--no-renames", "-z", "HEAD", "--"))
)
added = set(
    nul_paths(
        git_bytes(
            "diff",
            "--name-only",
            "--no-renames",
            "--diff-filter=A",
            "-z",
            "HEAD",
            "--",
        )
    )
)
deleted = set(
    nul_paths(
        git_bytes(
            "diff",
            "--name-only",
            "--no-renames",
            "--diff-filter=D",
            "-z",
            "HEAD",
            "--",
        )
    )
)
untracked = set(
    nul_paths(git_bytes("ls-files", "--others", "--exclude-standard", "-z"))
)

if tracked & untracked:
    raise SystemExit("tracked/untracked path overlap")

entries: list[dict[str, object]] = []
for relative_path in sorted(tracked | untracked):
    if relative_path in untracked:
        kind = "untracked"
    elif relative_path in deleted:
        kind = "tracked_deleted"
    elif relative_path in added:
        kind = "tracked_added"
    else:
        kind = "tracked_modified"

    entry: dict[str, object] = {
        "kind": kind,
        "path": relative_path,
    }

    if kind == "tracked_deleted":
        entry.update(
            {
                "file_type": "missing",
                "mode": None,
                "sha256": None,
                "size": None,
            }
        )
    else:
        path = Path(relative_path)
        metadata = path.lstat()
        mode = f"{stat.S_IMODE(metadata.st_mode):04o}"
        if stat.S_ISREG(metadata.st_mode):
            payload = path.read_bytes()
            file_type = "regular"
        elif stat.S_ISLNK(metadata.st_mode):
            payload = os.readlink(path).encode("utf-8")
            file_type = "symlink"
        else:
            raise SystemExit(f"unsupported file type: {relative_path}")

        entry.update(
            {
                "file_type": file_type,
                "mode": mode,
                "sha256": hashlib.sha256(payload).hexdigest(),
                "size": len(payload),
            }
        )

    entries.append(entry)

diff_bytes = git_bytes(
    "diff",
    "--full-index",
    "--binary",
    "--no-ext-diff",
    "--no-textconv",
    "--no-renames",
    "HEAD",
    "--",
)
textual_diff_sha256 = hashlib.sha256(diff_bytes).hexdigest()

manifest = {
    "branch": branch,
    "files": entries,
    "head": head,
    "recipe_id": RECIPE_ID,
    "textual_diff_sha256": textual_diff_sha256,
    "upstream": upstream,
}

canonical = (
    json.dumps(
        manifest,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")
    + b"\n"
)
manifest_sha256 = hashlib.sha256(canonical).hexdigest()
OUTPUT_PATH.write_bytes(canonical)

print(f"recipe_id={RECIPE_ID}")
print(f"textual_diff_sha256={textual_diff_sha256}")
print(f"manifest_sha256={manifest_sha256}")
print(f"file_count={len(entries)}")
print(canonical.decode("utf-8"), end="")
```

REMOTE PREFLIGHT — READ ONLY

After local provenance succeeds:

1. Verify `origin` resolves to the GitHub repository
   `evo-agi/Governed-Execution-Coordinator`.
2. Verify authenticated GitHub identity and record it without retaining
   credentials.
3. Fetch or query read-only remote refs needed for exact comparison.
4. Require remote `trunk_dev` to remain exactly:
   `bf68a5232bff1b412c9414c076d82cab18c8e0aa`.
5. Require no remote branch named:
   `codex/rw0-b1-pure-phase-values-v1`.
6. Require no open or closed pull request whose head is that branch.
7. Inspect the currently effective `trunk_dev` rulesets and repository merge
   settings. Record:
   - PR requirement;
   - allowed merge methods;
   - review and thread requirements;
   - required status checks;
   - bypass actors and current-user bypass mode;
   - auto-merge setting;
   - branch-deletion setting.
8. Do not change any rule, setting, reviewer, label, milestone, project, or
   repository configuration.
9. Require no current-user ruleset bypass and do not request admin/bypass
   behavior.
10. Require squash merge to be permitted for the later separate merge gate.
    This prompt does not merge.

If remote `trunk_dev` differs, the feature branch or PR already exists, the
repository slug differs, or a safe ordinary feature-branch push/PR cannot be
performed, stop before staging.

STAGING

Create an explicit NUL-terminated path list from the accepted manifest; do not
stage via `git add .`, globbing, or an inferred directory.

Stage exactly the 17 accepted paths.

Require after staging:

- index status:
  exactly 11 `M` plus 6 `A`;
- zero `D`, rename, copy, unmerged, or non-stage-0 entry;
- every staged Git mode:
  `100644`;
- zero unstaged tracked changes;
- zero remaining untracked paths;
- no extra staged path;
- working-tree bytes remain equal to the accepted manifest;
- no Git operation or lock.

For every manifest entry:

- obtain the staged blob;
- compare staged blob size and SHA-256 to the accepted working-tree manifest;
- require exact equality;
- retain a deterministic staged-comparison record.

Also retain the cached full-index binary diff and its SHA-256.

On staging or staged-blob mismatch:

- do not edit;
- unstage exactly the 17 manifest paths to restore the accepted opening index;
- verify the 17 accepted working-tree bytes remain unchanged;
- stop with `COMMIT_GATE_STAGED_BLOB_MISMATCH`.

FINAL VALIDATION ON FROZEN STAGED BYTES

No repository mutation may occur between staged comparison and commit except
the commit itself.

Use serial isolated validation under a new external commit-gate root.

For every child:

- capture and restore actual caller umask;
- require equal caller/child numerical umask;
- use:
  - `env -u PYTHONTRACEMALLOC -u PYTHONWARNINGS`;
  - `LC_ALL=C`, `LANG=C`;
  - `PYTHONDONTWRITEBYTECODE=1`;
  - distinct external `PYTHONPYCACHEPREFIX`, `TMPDIR`, `--basetemp`, JUnit;
  - `PYTEST_DISABLE_PLUGIN_AUTOLOAD=1`;
  - `PYTEST_ADDOPTS=''`;
  - `PYTHONHASHSEED=0`;
  - `python3 -B -m pytest -p no:cacheprovider -W error`;
  - serial execution.

Before and after every validation child require:

- staged comparison still exact;
- working-tree bytes still exact;
- status remains 11 staged M + 6 staged A and nothing else;
- no repository residue, operation, or lock.

Run candidate collection exactly once:

```text
python3 -B -m pytest -p no:cacheprovider -W error   --basetemp=<external> --collect-only -q .
```

Require:

- exactly 4,566 unique ordered node IDs;
- exact equality to the accepted-audit node-list identity;
- no collection error, warning, duplicate, skip, xfail, or collection control.

Then run the complete suite exactly once:

```text
python3 -B -m pytest -p no:cacheprovider -W error   --basetemp=<external> --junitxml=<external> -q .
```

Require:

- 4,566 collected;
- 4,566 passed;
- zero failures, errors, skips, xfails, warnings;
- return code 0;
- empty stderr;
- no duplicate, ambiguous, parse-error, or unmapped JUnit case;
- exact staged and working bytes unchanged.

Do not run a second complete-suite attempt.

If collection or validation fails:

- do not repair;
- do not commit;
- preserve evidence;
- unstage exactly the 17 paths;
- verify accepted working bytes remain unchanged;
- report `COMMIT_GATE_VALIDATION_FAILED`.

PRE-COMMIT REMOTE RECHECK

Immediately after validation and before commit:

- re-query remote `trunk_dev`;
- require it still equals
  `bf68a5232bff1b412c9414c076d82cab18c8e0aa`;
- require remote feature branch still absent;
- require no matching PR.

If any differs, do not commit. Unstage the exact 17 paths, preserve accepted
working bytes, and stop.

COMMIT

Create exactly one commit.

Exact subject:

`feat: implement RW0-B1 pure phase-entry semantics`

Exact body:

empty

Requirements:

- sole parent:
  `bf68a5232bff1b412c9414c076d82cab18c8e0aa`;
- exactly 17 paths:
  11 `M`, 6 `A`, 0 `D`;
- all modes `100644`;
- no extra path;
- no amend;
- no second commit;
- no signing requirement; record the actual signature status honestly.

After commit:

1. compare every committed blob size and SHA-256 to the accepted manifest;
2. require exact equality;
3. require committed tree path/status/mode set equals the staged set;
4. require clean worktree/index/untracked/unmerged state;
5. require no operation, lock, or repository residue;
6. retain deterministic committed-comparison evidence.

If committed bytes differ, do not amend, reset, or create a corrective commit.
Stop with `COMMIT_GATE_COMMITTED_BLOB_MISMATCH`.

PRE-PUSH REMOTE RECHECK

Immediately before push:

- require remote `trunk_dev` still equals the audited base;
- require the remote feature branch remains absent;
- require no matching PR.

If the base advanced after the local commit, do not rebase or push. Report the
local commit and stop for a new baseline/audit decision.

PUSH

Execute exactly once:

```text
git push -u origin HEAD:refs/heads/codex/rw0-b1-pure-phase-values-v1
```

Requirements:

- no force option;
- no direct `trunk_dev` update;
- no tags;
- no branch deletion;
- no second push;
- remote feature ref must equal the local commit;
- remote `trunk_dev` must remain the audited base.

If push fails, do not retry automatically. Retain the local commit and evidence
and report the exact failure.

PRE-PR RECHECK

Before PR creation:

- require remote feature ref equals the local commit;
- require remote `trunk_dev` still equals the audited base;
- require no existing PR for the head branch.

If `trunk_dev` advanced after push, do not create the PR. Do not rebase or force
push. Report the pushed branch for a later rebaseline decision.

PULL REQUEST

Create exactly one non-draft PR.

Repository:

`evo-agi/Governed-Execution-Coordinator`

Base:

`trunk_dev`

Head:

`codex/rw0-b1-pure-phase-values-v1`

Exact title:

`feat: implement RW0-B1 pure phase-entry semantics`

Exact body is the following 926-byte UTF-8 text, SHA-256
`c2bac359a1fafea39c3bac7bcb8aa6f4e79e14ab8f6700bb6ff592c4b8738ba2`:

-------------------- BEGIN EXACT PR BODY --------------------

## Summary

- add private RW0-B1 phase-entry value schemas and pure relations over supplied C2A, C2B3D, and Section 41 evidence
- enforce bounded construction, canonical identity, authority, custody, retrieval, host-qualification, and terminal-shape checks
- update current-status documentation and static import/public-boundary inventories

## Validation

- fresh independent audit: `ACCEPT`
- complete suite: `4,566/4,566`
- exact audited working-tree manifest reproduced before publication
- staged and committed blobs must match the audited manifest byte-for-byte

## Non-claims

- no authority issuance or source authentication
- no custody transport, remote contact, worker/process/model invocation, persistence, latch implementation, ES or Bridge handoff, Git effect, or autonomous runtime
- no public package export, public `StateStore`/`WriterSession` surface, dependency, migration, or application-generation change
--------------------- END EXACT PR BODY ---------------------

Do not:

- request reviewers;
- submit a review;
- self-approve;
- resolve threads;
- enable auto-merge;
- merge the PR;
- delete the branch;
- add labels, milestones, assignees, projects, or comments.

FINAL VERIFICATION

Verify and report:

Local:

- branch remains `codex/rw0-b1-pure-phase-values-v1`;
- local HEAD equals the created commit;
- upstream is
  `origin/codex/rw0-b1-pure-phase-values-v1`;
- ahead/behind `0/0`;
- worktree/index/untracked/unmerged clean;
- one worktree;
- no operation, lock, or residue.

Remote:

- `trunk_dev` remains
  `bf68a5232bff1b412c9414c076d82cab18c8e0aa`;
- feature ref equals the created commit;
- no force or alternate-history effect occurred.

PR:

- OPEN;
- non-draft;
- exact base and head branch names and OIDs;
- exact title and body;
- one commit;
- exactly 17 changed files;
- merged false;
- merge commit absent;
- auto-merge absent;
- record actual mergeability, review decision, status/check state, comments,
  threads, and effective ruleset without altering them.

Boundaries:

- all committed blobs equal the accepted manifest;
- no dependency, migration, application-generation, package export, public API,
  StateStore, WriterSession, process, worker, model/provider, Bridge, ES,
  network, Git-effect implementation, or supporting-repository widening;
- B1 remains private pure semantics over supplied evidence and grants no
  authority or contact capability.

EVIDENCE

Retain a deterministic mode-0400 evidence index under the mode-0700 commit-gate
root, including safe identities for:

- accepted audit report;
- accepted implementation report and manifest;
- opening two-run provenance;
- remote preflight and ruleset/settings;
- staged path list and staged comparison;
- cached binary diff;
- collection and full-suite outputs/JUnit/results;
- pre-commit/pre-push/pre-PR remote checks;
- commit identity/tree/parent/subject/signature/path status;
- committed comparison;
- push result;
- PR body;
- PR creation and final state;
- final local/remote/ruleset guards.

Do not include the index itself in its indexed entries. Remove only transient
commit-gate caches and test scratch after retaining terminal evidence.

CLOSEOUT

Return exactly:

`COORDINATOR_RW0_B1_PURE_PHASE_VALUES_COMMITTED_PUSHED_AND_PR_OPENED`

only if the commit, push, PR creation, and every final verification succeed.

Report:

1. accepted audit and manifest identities;
2. opening local identity/topology;
3. remote preflight and ruleset/settings;
4. two-run provenance;
5. exact staged status and blob equality;
6. node collection and full-suite result;
7. commit ID, tree, parent, subject/body, author/committer, time, signature, and
   exact path status;
8. committed blob comparison;
9. push command/result and remote refs;
10. PR number/URL/state/title/body/base/head/OIDs/mergeability/review/checks;
11. final local and remote state;
12. evidence-root and evidence-index identity;
13. assumptions, limitations, and any non-blocking observations.

Required final statements:

IMPLEMENTATION_REPAIR_NOT_PERFORMED
INDEPENDENT_AUDIT_NOT_REPEATED
DIRECT_TRUNK_PUSH_NOT_PERFORMED
BYPASS_NOT_USED
FORCE_PUSH_NOT_PERFORMED
AMEND_NOT_PERFORMED
SECOND_COMMIT_NOT_PERFORMED
SECOND_PUSH_NOT_PERFORMED
SECOND_PR_NOT_CREATED
PR_MERGE_NOT_PERFORMED
AUTO_MERGE_NOT_ENABLED
REVIEW_NOT_SELF_APPROVED
FEATURE_BRANCH_NOT_DELETED
TAG_NOT_CREATED
RELEASE_NOT_CREATED
DEPLOYMENT_NOT_PERFORMED

STOP CONDITIONS

Stop without repair or publication if:

- audit report or manifest is unavailable, unsafe, incomplete, or inconsistent;
- opening repository identity/topology differs;
- provenance differs;
- remote base differs;
- feature branch or PR already exists;
- rules require or invite a bypass/admin operation;
- staged or committed bytes differ from the accepted manifest;
- a path/mode/status outside 11 M + 6 A appears;
- node identity differs;
- final validation is not exact-green;
- validation changes repository bytes;
- a second full-suite attempt would be required;
- commit parent, subject, body, or scope differs;
- push requires force or retry;
- PR would target a different base/head or use different title/body;
- any implementation repair, rebase, merge, or policy change appears necessary.
