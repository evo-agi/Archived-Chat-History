TITLE

Coordinator RW0-B1 — repair fourth independent-audit findings and prepare fresh
re-audit

ENGAGEMENT TYPE

Bounded parent-only repair in the existing RW0-B1 implementation conversation.

Return to the write-enabled implementation conversation that produced the
current candidate. Do not continue in the latest independent-audit conversation.

Do not create or resume subagents. You are the sole repository writer.

This engagement authorizes mutation only in the exact four-path maximum
allowlist below, isolated local validation, external repair evidence, and exact
new patch provenance.

This engagement does not authorize staging, commit, push, PR creation, merge,
tag, release, deployment, remote contact, dependency installation, migration,
supporting-repository mutation, or independent audit.

REPOSITORY

/Users/ds/Repositories/Governed Execution Coordinator/

AUDIT VERDICT TO REPAIR

The latest fresh independent audit returned `BLOCK` with exactly two repairable
Medium findings:

1. RW0-B1-01 — construction work-bound violation.

   The common closed-mapping validation scans all caller-supplied keys before
   creating or applying the documented per-value construction budget. A
   1,000-key exact dict therefore consumes a full unbounded key scan before
   returning `unknown_field`, although the smallest affected value has a 34-unit
   `2V` construction/reconstruction bound.

2. RW0-B1-02 — noncausal K8 privacy test.

   The eight selection-key IPv4-shaped cases change both the K8 entry and the
   corresponding L34 coordinate. L34 is validated first, so those cases can
   continue returning `privacy_forbidden_material` even if the K8 privacy check
   is removed. K8-only and L34-only cases must be separated and independently
   resealed.

No relation, authority, canonical identity, privacy policy, class inventory, or
architecture defect was otherwise identified. Do not reopen the B1/B2 split or
change relation semantics.

EXPECTED OPENING STATE

Before any mutation, require exactly:

- physical root:
  /Users/ds/Repositories/Governed Execution Coordinator/
- branch:
  codex/rw0-b1-pure-phase-values-v1
- HEAD:
  bf68a5232bff1b412c9414c076d82cab18c8e0aa
- HEAD tree:
  8fc05f5626bdbb01808df1698c9c2245ab06f1cb
- sole parent:
  1a894c5527c610ab40d8e5ae5e530a762c6e60bf
- subject:
  docs: freeze RW0-A phase-entry contract (#2)
- upstream:
  origin/trunk_dev
- ahead/behind:
  0/0
- worktrees:
  1
- dirty paths:
  exactly 17
- tracked modifications:
  exactly 11
- untracked paths:
  exactly 6
- staged/unmerged:
  0/0
- every candidate path:
  regular mode 0644
- no deletion, rename, copy, symlink, Git-recorded mode change, Git operation,
  Git lock, or repository residue.

PINNED OPENING TARGET

Safely inspect and bind all of:

1. Implementation repair report:

   `/private/tmp/gec-rw0-b1-repair3.ehHPGy/repair-report.md`

2. Implementation final manifest:

   `/private/tmp/gec-rw0-b1-repair3.ehHPGy/final-provenance-1.manifest.json`

3. Latest independent-audit final-manifest copy:

   `/private/tmp/gec-rw0-b1-audit4-2_037ak1/final-manifest.json`

Every path component must be lstat-checked, operator-owned, non-symlink, and
safely readable. Copy immutable audit inputs mode-0400 into the new repair
evidence root.

Require:

- both manifest files are byte-identical;
- the implementation report records and binds that exact manifest identity;
- recipe ID is:
  `governed-execution.audit-patch-manifest.v1`;
- manifest branch, HEAD, upstream, 17 paths, kinds, modes, sizes, and SHA-256
  values equal the live repository exactly;
- report-bound final node count is exactly 4,545;
- report-bound full suite is exactly 4,545/4,545;
- the report's final node-list identity is safely readable and matches the live
  opening collection required below.

Run the exact unchanged provenance recipe appended below twice before editing.
Require both runs to be byte-identical and exactly equal to the two pinned
manifest files.

On any mismatch, stop without mutation and report the exact mismatch. Do not
reconstruct or approximate a target.

Create one new external operator-owned, non-symlink, mode-0700 repair evidence
root beneath `/private/tmp`.

ENGINEERING DISPOSITION

This is a narrow common-constructor and test-oracle repair.

The following remain frozen:

- all eight class names;
- every ordered `_FIELDS` tuple;
- every schema ID and digest domain;
- all enum and error-reason inventories;
- all relation names, signatures, semantics, reasons, and budgets;
- all per-value `2V` budget literals;
- canonical JSON and digest bytes for every existing valid mapping;
- exact C2A, Section 41, L34, K8, row, decision, and stop contracts;
- the B1/B2/C/D/E/ES ownership split;
- package exports, production consumers, public APIs, dependencies, migrations,
  and runtime behavior.

No budget literal change is authorized.

EXACT REPAIR ALLOWLIST

Only these four existing candidate paths may change relative to the pinned
17-path opening target:

1. `.docs/rw0-b1-pure-phase-values.md`
2. `src/ge_nwp_coordinator/_rw0_phase_entry_semantic_values.py`
3. `tests/test_rw0_b1_phase_values.py`
4. `tests/test_rw0_b1_boundaries.py`

The other thirteen candidate entries must remain byte-identical to the opening
target. Every path outside the complete 17-path candidate must remain
byte-identical to HEAD.

The final topology remains exactly:

- 17 dirty paths;
- 11 tracked modifications;
- 6 untracked files;
- 0 staged;
- 0 unmerged;
- all regular mode 0644;
- no Git-recorded add/delete/rename/copy/mode change.

Stop if a fifth repair path is required.

REPAIR 1 — BOUNDED CLOSED-MAPPING PREFLIGHT

The common construction path must enforce the documented `2V` work bound from
the first operation over caller mapping structure.

Required behavior:

1. Exact input type remains built-in `dict`.

2. Before iterating, materializing, sorting, copying, set-converting, or
   otherwise traversing caller-supplied keys, perform an O(1) cardinality
   preflight using `len(payload)` against the exact allowed field count.

3. If `len(payload) > len(fields)`, fail immediately with:

   - reason:
     `unknown_field`;
   - a constant content-free field label;
   - no supplied key or value in message, repr, str, or exception chain.

   Because a built-in dict has unique keys and every valid mapping has exactly
   the closed field count, an oversize mapping necessarily contains an unknown
   key.

4. For mappings whose cardinality is no larger than the field count:

   - scan at most that fixed field count;
   - preserve exact `unknown_field` before `missing_field` precedence;
   - reject non-exact key types under the existing content-free type rule;
   - do not sort caller keys merely to validate closure;
   - do not construct an unbounded intermediate set/list from caller keys.

5. Create or thread the existing construction work budget early enough that the
   bounded closure-validation pass and defensive reconstruction together honor
   the existing `2V` contract.

   The implementation may either:

   - charge the mapping container and each bounded key occurrence directly to
     the existing shared construction budget; or
   - use the O(1) oversize guard plus a mechanically fixed-at-field-count key
     pass whose work is included in the documented validation half of `2V`.

   It must not leave any unbounded caller-key traversal outside the bound.

6. Every existing maximum valid value must remain accepted under its unchanged
   budget. Every existing one-over, cycle, alias, exact-type, privacy, and
   canonical-vector case must retain its current result.

7. The common helper must cover all eight classes. Do not add per-class ad hoc
   key-scan implementations.

8. Do not change error ordering for valid-cardinality unknown/missing mixtures:

   - unknown plus missing -> `unknown_field`;
   - missing only -> `missing_field`.

9. Do not use timing thresholds as the governing proof of boundedness.

GOVERNING DOCUMENT CLARIFICATION

Update only the detailed B1 governing document to make explicit that:

- exact dict cardinality is checked before caller-key iteration;
- oversize closed mappings fail content-free `unknown_field`;
- the remaining key scan is bounded by the class's fixed field count;
- closure validation and defensive reconstruction satisfy the existing `2V`
  construction bound;
- no budget literal, schema identity, or valid canonical byte changes.

Do not alter any field inventory or relation description.

REPAIR 2 — CAUSAL K8 AND L34 PRIVACY ORACLES

The exact K8 coordinate names are a literal test-owned inventory:

```text
program_ref
semantic_attempt_ref
candidate_ref
effect_intent_ref
author_command_ref
attempt_fence_ref
effect_fence_ref
delivery_attempt_ref
```

Replace the combined K8+L34 IPv4 mutants with two causally independent families.

A. K8-only family

For each of the eight coordinates:

1. Start from one literal valid `RW0PhaseEntryBasisV1` mapping.
2. Leave the complete L34 mapping byte-for-byte unchanged and valid.
3. Replace only the corresponding K8 ref value with `192.0.2.1`.
4. Recompute only the outer B1 `basis_digest` required by that changed mapping.
5. Require exactly:
   `privacy_forbidden_material`.
6. Require content-free text and no chained supplied value.
7. Do not accept `relation_mismatch`, malformed-ref fallback, or an L34-origin
   privacy failure as satisfying the test.

These cases must reach and prove the K8 ref privacy path itself.

B. L34-only family

For each corresponding L34 safe-ref coordinate:

1. Start from the same literal valid basis mapping.
2. Leave the complete K8 list byte-for-byte unchanged and valid.
3. Replace only the L34 ref value with `192.0.2.1`.
4. Recompute the exact L34 self-digest and then the outer B1 `basis_digest`.
5. Require exactly:
   `privacy_forbidden_material`.
6. Require content-free text and no chained supplied value.

These cases prove the nested L34 path independently.

C. Controls

Preserve:

- all representative alternate IPv4-shaped rejections;
- accepted dotted opaque refs;
- exact existing valid canonical vectors;
- literal, test-owned field inventories.

Add a direct assertion that each mutant family changes only its named surface
plus required self-digest resealing. Do not derive expected coordinate names
from production `_FIELDS` or K8/L34 constants.

A regression that disables only K8 IPv4 rejection must make the K8-only family
fail even while every L34-only case continues to reject. The test design must
make that causal property evident through exact reason and unchanged-surface
assertions; do not add a candidate-digest or any new identity.

TEST-FIRST AND CAUSAL EVIDENCE

Before changing production source or documentation:

1. Add the construction-bound tests and corrected privacy tests within the two
   authorized test files.

2. Run one isolated pre-repair diagnostic gate exactly once.

3. Require and record:

   - the construction-order/static causal test fails against the opening source;
   - existing source may already pass the new K8-only and L34-only runtime cases;
     that is expected because RW0-B1-02 is a test-causality defect;
   - no syntax, fixture, collection, or unrelated failure;
   - exact argv, environment, caller/child umask, stdout, stderr, JUnit,
     repository fingerprint, and selected node IDs.

4. Do not describe already-green corrected privacy cases as a causal red.

5. Do not rerun the pre-repair diagnostic.

Then repair source and documentation.

REQUIRED CONSTRUCTION TESTS

At minimum add:

1. Common helper source/AST ordering oracle

   Independently parse the production source and prove that the common
   closed-mapping path performs an O(1) cardinality guard before its first
   caller-key traversal, materialization, sort, copy, or set conversion.

   The expected structural rule must be test-owned, not imported from a
   production constant.

2. Oversize mapping matrix

   For all eight classes, use a valid mapping plus enough exact built-in string
   keys to exceed the exact class field count substantially, including a
   1,000-key case for the smallest class.

   Require:

   - `unknown_field`;
   - constant content-free field label;
   - no supplied key/value leakage or chain;
   - no `cumulative_work_exhausted` substitution.

3. Exact-cardinality mixed closure

   For representative smallest and largest classes:

   - replace one required field with one unknown field while preserving total
     cardinality;
   - require `unknown_field`, not `missing_field`.

4. Missing-only control

   Remove exactly one required key and require `missing_field`.

5. Maximum-valid and one-over budget controls

   Reconfirm actual constructors—not only a standalone budget helper—at every
   existing maximum and one-over boundary.

6. No per-class bypass

   Prove all eight `from_mapping` methods route through the one common bounded
   closed-mapping implementation.

Do not use wall-clock performance assertions as acceptance criteria.

VALIDATION ISOLATION

Use the same strict isolated posture as the accepted implementation chain.

For every pytest child:

- save and restore actual caller umask;
- require equal caller/child numerical umask;
- use:
  - `env -u PYTHONTRACEMALLOC -u PYTHONWARNINGS`;
  - `LC_ALL=C`, `LANG=C`;
  - `PYTHONDONTWRITEBYTECODE=1`;
  - distinct external `PYTHONPYCACHEPREFIX`, `TMPDIR`, `--basetemp`, JUnit;
  - `PYTEST_DISABLE_PLUGIN_AUTOLOAD=1`;
  - `PYTEST_ADDOPTS=''`;
  - `PYTHONHASHSEED=0`;
  - `python3 -B -m pytest -p no:cacheprovider -W error`;
  - serial execution.

Before and after every final green run require exact candidate bytes, modes,
path set, branch/HEAD/upstream, zero staged/unmerged, no operation/lock, and no
repository residue.

OPENING NODE COLLECTION

Before editing, collect the complete ordered candidate node list exactly once.

Require:

- exactly 4,545 nodes;
- exact equality to the implementation-report-bound final node list and hash;
- no duplicate or collection warning.

Stop on mismatch.

FINAL VALIDATION ORDER

After source/doc repair and cleanup:

1. Collect the complete final ordered node list exactly once.

   Require:

   - opening minus final is empty;
   - every opening node retains exact order;
   - additions belong only to:
     - `tests/test_rw0_b1_phase_values.py`
     - `tests/test_rw0_b1_boundaries.py`;
   - no duplicate, skip, xfail, warning, collection hook, renamed, collapsed, or
     reparameterized node.

2. Run the exact new construction and privacy causal tests.

3. Run individually:

- `tests/test_rw0_b1_phase_values.py`
- `tests/test_rw0_b1_boundaries.py`

4. Run all four B1 files together:

- `tests/test_rw0_b1_phase_values.py`
- `tests/test_rw0_b1_relations.py`
- `tests/test_rw0_b1_vectors.py`
- `tests/test_rw0_b1_boundaries.py`

5. Run source/public/static boundaries:

- `tests/test_c2a_nonimplementation.py`
- `tests/test_runtime_non_authority.py`
- `tests/test_c2b2_development_row_value_boundaries.py`
- `tests/test_b2a_writer_session_contract.py`

6. Run C2A compatibility:

- `tests/test_worker_execution_semantic_values.py`
- `tests/test_worker_execution_semantic_vectors.py`
- `tests/test_worker_execution_semantic_relations.py`
- `tests/test_worker_execution_semantic_boundaries.py`
- `tests/test_c2a_relations.py`
- `tests/test_c2a_first_slice_semantic_protocol_contract.py`

7. Run RW0/current-status/docs:

- `tests/test_rw0_remote_contact_phase_entry_contract.py`
- `tests/test_architecture_contracts.py`
- `tests/test_remote_worker_pre_execution_planning_contract.py`
- `tests/test_autonomous_software_development_operating_model.py`

8. Run exact path, mode, status, import, public-surface, protected-byte,
   `git diff --check`, operation/lock, and repository-residue guards.

9. Run the complete suite against frozen repair bytes.

Full-suite policy:

- run repair attempt 001 exactly once;
- if it fails only because of this repair and every correction remains inside
  the exact four-path allowlist, repair and run attempt 002 exactly once;
- never run attempt 003;
- if a fifth path, budget-literal change, schema change, or architecture
  correction is required, stop.

For every final green run require:

- return code 0;
- exact collected/passed accounting;
- zero failures/errors/skips/xfailed/warnings;
- empty stderr;
- no duplicate, ambiguous, parse-error, or unmapped JUnit case;
- equal caller/child umask;
- unchanged frozen bytes.

PROTECTED SURFACES

Relative to the pinned 17-path opening target:

- only the four repair-authorized entries may change;
- the other thirteen candidate entries remain byte-identical.

Relative to HEAD, everything outside the complete 17-path candidate remains
byte-identical, especially:

- all C2A source, schemas, enums, relations, vectors, and safe-ref grammar;
- C2B3D and Section 41 source/contracts;
- row-value providers;
- SQLite, migrations, catalog, application generation;
- package root, StateStore, WriterSession, public protocols;
- dependencies, scripts, config, fixtures;
- AGENTS.md and README.md;
- supporting repositories.

No production consumer beyond the private B1 module may appear.

ARTIFACT HYGIENE

Remove only repair-created transient caches, pycache, basetemps, temporary
archives/files, and repository residue after preserving terminal evidence.

Do not modify or delete prior implementation or audit evidence.

Do not run `compileall` or `py_compile` against repository paths.

FINAL PROVENANCE

After final validation and cleanup, run the exact unchanged provenance recipe
below twice.

Require:

- return code 0;
- empty stderr;
- byte-identical complete stdout;
- byte-identical canonical manifests;
- exact branch/HEAD/upstream;
- exactly 17 entries;
- exactly 11 tracked modifications and 6 untracked;
- safe regular file types and expected modes;
- stable tracked textual-diff SHA-256.

Because the detailed B1 doc, source, and direct B1 tests are untracked candidate
files, do not infer their equality from the tracked textual-diff hash. Compare
canonical manifest entries and per-file hashes.

Compare final with the pinned opening target and prove:

- only repair-authorized entries changed;
- all other candidate entries are exact;
- no path became newly dirty or ceased being dirty.

EXACT PROVENANCE RECIPE

```python
from __future__ import annotations

import hashlib
import json
import os
import stat
import subprocess
from pathlib import Path

RECIPE_ID = "governed-execution.audit-patch-manifest.v1"
OUTPUT_PATH = Path("/tmp/ge-coordinator-b3a-audit-manifest-v1.json")


def git_bytes(*args: str) -> bytes:
    env = os.environ.copy()
    env["LC_ALL"] = "C"
    env["LANG"] = "C"
    result = subprocess.run(
        ["git", *args],
        check=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        env=env,
    )
    return result.stdout


def git_text(*args: str) -> str:
    return git_bytes(*args).decode("utf-8", "strict").strip()


def nul_paths(data: bytes) -> list[str]:
    return [
        item.decode("utf-8", "strict")
        for item in data.split(b"\0")
        if item
    ]


head = git_text("rev-parse", "HEAD")
branch = git_text("branch", "--show-current")
upstream = git_text("rev-parse", "--abbrev-ref", "--symbolic-full-name", "@{u}")

tracked = set(
    nul_paths(git_bytes("diff", "--name-only", "--no-renames", "-z", "HEAD", "--"))
)
added = set(
    nul_paths(
        git_bytes(
            "diff",
            "--name-only",
            "--no-renames",
            "--diff-filter=A",
            "-z",
            "HEAD",
            "--",
        )
    )
)
deleted = set(
    nul_paths(
        git_bytes(
            "diff",
            "--name-only",
            "--no-renames",
            "--diff-filter=D",
            "-z",
            "HEAD",
            "--",
        )
    )
)
untracked = set(
    nul_paths(git_bytes("ls-files", "--others", "--exclude-standard", "-z"))
)

if tracked & untracked:
    raise SystemExit("tracked/untracked path overlap")

entries: list[dict[str, object]] = []
for relative_path in sorted(tracked | untracked):
    if relative_path in untracked:
        kind = "untracked"
    elif relative_path in deleted:
        kind = "tracked_deleted"
    elif relative_path in added:
        kind = "tracked_added"
    else:
        kind = "tracked_modified"

    entry: dict[str, object] = {
        "kind": kind,
        "path": relative_path,
    }

    if kind == "tracked_deleted":
        entry.update(
            {
                "file_type": "missing",
                "mode": None,
                "sha256": None,
                "size": None,
            }
        )
    else:
        path = Path(relative_path)
        metadata = path.lstat()
        mode = f"{stat.S_IMODE(metadata.st_mode):04o}"
        if stat.S_ISREG(metadata.st_mode):
            payload = path.read_bytes()
            file_type = "regular"
        elif stat.S_ISLNK(metadata.st_mode):
            payload = os.readlink(path).encode("utf-8")
            file_type = "symlink"
        else:
            raise SystemExit(f"unsupported file type: {relative_path}")

        entry.update(
            {
                "file_type": file_type,
                "mode": mode,
                "sha256": hashlib.sha256(payload).hexdigest(),
                "size": len(payload),
            }
        )

    entries.append(entry)

diff_bytes = git_bytes(
    "diff",
    "--full-index",
    "--binary",
    "--no-ext-diff",
    "--no-textconv",
    "--no-renames",
    "HEAD",
    "--",
)
textual_diff_sha256 = hashlib.sha256(diff_bytes).hexdigest()

manifest = {
    "branch": branch,
    "files": entries,
    "head": head,
    "recipe_id": RECIPE_ID,
    "textual_diff_sha256": textual_diff_sha256,
    "upstream": upstream,
}

canonical = (
    json.dumps(
        manifest,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")
    + b"\n"
)
manifest_sha256 = hashlib.sha256(canonical).hexdigest()
OUTPUT_PATH.write_bytes(canonical)

print(f"recipe_id={RECIPE_ID}")
print(f"textual_diff_sha256={textual_diff_sha256}")
print(f"manifest_sha256={manifest_sha256}")
print(f"file_count={len(entries)}")
print(canonical.decode("utf-8"), end="")
```

CLOSEOUT

Return exactly:

COORDINATOR_RW0_B1_FOURTH_AUDIT_FINDINGS_REPAIRED_READY_FOR_FRESH_REAUDIT

only when both findings are mechanically closed, every final gate is
exact-green, artifact hygiene is complete, and repeated provenance is stable.

Report:

1. exact opening repository identity/topology and target reproduction;
2. both audit-finding dispositions;
3. exact repair delta with before/after size/SHA-256;
4. pre-repair diagnostic command/results/evidence and honest red/green
   classification;
5. exact bounded closed-mapping algorithm and `2V` accounting;
6. oversize, exact-cardinality unknown/missing, maximum, and one-over results;
7. literal K8-only and L34-only privacy matrices and resealing proof;
8. proof that no class/schema/domain/relation/budget/canonical vector changed;
9. opening/final node counts, hashes, additions, and order comparison;
10. every focused/full-suite command/result/evidence hash;
11. failed attempts and whether full-suite attempt 002 was needed;
12. protected/public/import/dependency/migration comparisons;
13. artifact hygiene;
14. recipe identity, two-run output identity, tracked diff, final manifest
    size/hash/count/path;
15. assumptions, limitations, unresolved later seams, skipped validation, and
    inspection boundary;
16. separate provenance, validation, and implementation confidence.

Required final statements:

INDEPENDENT_AUDIT_NOT_PERFORMED
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED
REMOTE_CONTACT_NOT_PERFORMED
WORKER_OR_MODEL_NOT_INVOKED
SUPPORTING_REPOSITORIES_NOT_MODIFIED
DEPENDENCIES_NOT_CHANGED
MIGRATIONS_NOT_CHANGED
PUBLIC_API_NOT_WIDENED
PRIOR_AUDIT_EVIDENCE_PRESERVED

STOP CONDITIONS

Stop without further mutation if:

- opening provenance or opening node identity differs;
- the implementation report does not bind the pinned target;
- a fifth repair path is required;
- a class, ordered field list, schema ID, digest domain, relation signature,
  enum, error reason, budget literal, role decomposition, or B1/B2/C/D/E/ES
  ownership split must change;
- maximum valid mappings cannot fit the existing `2V` budgets after bounding
  closure validation;
- causal K8 privacy requires changing L34, K8, C2A, or identity schemas;
- a new production consumer or public surface is required;
- private/bearer material would enter B1;
- a digest would become authenticity or permission;
- SQLite, migration, durable state, filesystem, process, network, provider,
  model, Bridge, ES, worker, adapter, dependency, script, configuration, or
  public API work is required;
- tests must be weakened, skipped, xfailed, or gratuitously renamed;
- full-suite attempt 002 is not exact-green;
- final provenance is unstable or residue remains.
