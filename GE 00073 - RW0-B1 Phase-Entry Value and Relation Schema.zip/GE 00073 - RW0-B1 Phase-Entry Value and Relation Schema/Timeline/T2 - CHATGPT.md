## Verdict

**`RW0_B_RECONNAISSANCE_PARTIAL` is the correct result. Do not authorize implementation from this packet.**

The reconnaissance achieved the important architectural work:

- it established a clean **B1 → B2 dependency split**;
- preserved C2A/C2A1 as the immutable semantic foundation;
- separated authority observations from Coordinator evaluation;
- separated custody availability from capability issuance, redemption, and consumption;
- separated host readiness from effect-bound qualification;
- kept terminal-outcome semantics distinct from C2B decisions and persistence;
- assigned persistence to RW0-C and process mechanics to RW0-D.

That is substantial progress. The remaining gap is narrower: B1 still lacks exact class names, ordered fields, constructor types, digest domains, canonical forms, bounds, error reasons, and pure relation signatures. Under the project’s operating protocol, unresolved authority or identity decisions must be closed before implementation begins. 

## The decisive correction

Codex treated two categories as one remaining blocker:

1. **B1 semantic schemas**
2. **B2 wire framing and numeric limits**

They should no longer be coupled.

RW0-B’s governing tranche definition already separates pure value work from later persistence and execution: it calls for private deterministic source and tests, prohibits SQLite/process/network/model effects, and leaves persistence and execution for later tranches. 

Therefore:

```text
B1 exact schemas
    can be frozen now

B2 framing/header/result/cap choices
    remain deferred
    and must not keep B1 PARTIAL
```

The suggested `NWPF` header and `64 KiB / 256 KiB / eight observations / depth eight` limits are **recommendations only**. They are not accepted architecture and must not appear in a B1 implementation.

## Accepted B1 direction

The next pass should freeze these exact role families:

1. Phase-entry basis.
2. External authority-verification observation.
3. Subordinate-authorization proposal.
4. Custody-availability observation.
5. Retrieval-capability event observation.
6. Remote-host readiness observation.
7. Effect-bound host-qualification evaluation.
8. RW0 terminal-outcome value.

Several non-collapse decisions are already fixed:

- selected-plan identity is reused from Section 41 rather than recreated;
- K8, complete L34, the current selection-head postimage, C2A attempt/effect/command/fence/candidate identities, and the initial delivery remain authoritative inputs;
- B1 creates no second attempt, plan, effect, command, candidate, or delivery identity;
- source invocation, delivery, observation, and Coordinator outcome remain distinct. 

The current/target ledger also clearly leaves durable phase-entry state, observation ingest, acceptance-latch representation, and migration 0004 or its successor for RW0-C—not B1. 

## Decisions imposed on the focused freeze

The new prompt makes several parent-level judgments rather than asking Codex to reopen the split:

- one private B1 module:
  `src/ge_nwp_coordinator/_rw0_phase_entry_semantic_values.py`;
- no generic shared helper module yet;
- no widening of `WorkerObservationV1`, source kinds, observation kinds, routes, effect classes, C2A schema IDs, or golden vectors;
- no authoritative recovery-probe value in B1;
- C2A-compatible canonical JSON with exact Unicode code points and no silent normalization;
- exact built-in type enforcement, including rejecting `bool` for integer fields;
- no raw WorkSpec, selected-plan bytes, bearer, credentials, host identity, endpoint, path, prompt, transcript, stdout, or stderr;
- one cumulative graph-construction budget covering aliases, cycles, and compact shared-DAG expansion;
- exact B1 bounds must be derived from existing equivalent repository limits rather than invented;
- B2 frame sizes, process limits, transport, and Codex mechanics are explicitly out of scope.

The project’s broader planning convention supports this treatment: a freeze should state precisely what is and is not claimed before implementation widens by inertia, without itself promoting target prose or evidence into runtime authority. 

## Next action

Continue in the **same read-only Codex conversation** with:

:chatgpt-content-reference{index="3"}

The useful completion verdict is:

```text
RW0_B1_SCHEMA_FREEZE_READY
```

`READY` requires exact:

- Python class names;
- schema IDs and digest domains;
- ordered field lists;
- constructor and stored types;
- enum domains;
- scalar, cardinality, and graph-work bounds;
- canonical object and byte rules;
- safe projections;
- content-free error algebra;
- pure relation function signatures;
- module order and imports;
- maximum implementation path allowlist;
- tests, validation, provenance, audit perspectives, and stop conditions.

The prompt explicitly prevents B2’s wire caps or Codex runtime choices from causing another `PARTIAL`.

## Expected lifecycle after the freeze

```text
RW0-B1 exact schema freeze READY
→ parent-only B1 implementation
→ focused and full validation
→ exact provenance
→ fresh independent audit
→ audited-byte commit/PR/merge
→ separate RW0-B2 framing and capability freeze
```

B2 should not begin until B1’s exact values and relations are independently accepted, because B2 must frame and carry those semantics rather than invent them.

### Sources

- Codex RW0-B reconnaissance response supplied in this turn.
- RW0 tranche split and B1/B2 ceiling. 
- K8/L34 identity and non-collapse rules. 
- Current-versus-target ownership of persistence and execution. 
- Reconnaissance synthesis gate. 

**Confidence:** 99% that the B1/B2 split is correct; 98% that B1 can now be frozen independently of wire limits; 95% that the proposed eight-role B1 inventory is minimal without collapsing authority, custody, readiness, or terminal semantics.
