TITLE

Coordinator RW0-B1 — repair second independent re-audit findings and prepare
fresh re-audit

ENGAGEMENT TYPE

Bounded parent-only repair in the existing RW0-B1 implementation conversation.

Return to the write-enabled implementation conversation that produced the
current candidate. Do not continue in the independent re-audit conversation.

Do not create or resume subagents. You are the sole repository writer.

This engagement authorizes mutation only in the exact four-path repair allowlist
below, isolated local validation, external repair evidence, and exact new patch
provenance.

This engagement does not authorize staging, commit, push, PR creation, merge,
tag, release, deployment, remote contact, dependency installation, migration,
supporting-repository mutation, or independent audit.

REPOSITORY

/Users/ds/Repositories/Governed Execution Coordinator/

AUDIT VERDICT TO REPAIR

The fresh independent re-audit returned `BLOCK` with these confirmed findings:

1. High — host qualification can bind an authority observation to another
   attempt because the authority attempt-fence pair is not tied to the current
   effect fence and phase basis.
2. High — subordinate narrowing accepts a current effect fence from another
   semantic attempt.
3. High — verified-parent containment remains incomplete:
   - direct authority validation accepts applicable fences expiring after the
     verified grant;
   - narrowing accepts an attempt fence whose allowed-effect set is broader
     than the verified parent set;
   - the governing per-function wording does not state the complete effect-set
     containment rule consistently.
4. Medium — retrieval's shared traversal budget omits 36 occurrences. The
   implementation tells the narrowing helper that those occurrences were
   already charged, but the retrieval caller did not charge them. The frozen
   formula and literal are therefore undercounted.
5. Medium — causal tests omit specified qualification result/precedence cases,
   and the duplicate-event-ref mutant also violates self-predecessor, so it does
   not isolate event-ref uniqueness.

No fundamental design rejection was found. Do not reopen the B1/B2 split, add a
new class or field, change a relation signature, or add runtime/durable behavior.

EXPECTED OPENING STATE

Before any mutation, require exactly:

- physical root:
  /Users/ds/Repositories/Governed Execution Coordinator/
- branch:
  codex/rw0-b1-pure-phase-values-v1
- HEAD:
  bf68a5232bff1b412c9414c076d82cab18c8e0aa
- HEAD tree:
  8fc05f5626bdbb01808df1698c9c2245ab06f1cb
- sole parent:
  1a894c5527c610ab40d8e5ae5e530a762c6e60bf
- subject:
  docs: freeze RW0-A phase-entry contract (#2)
- upstream:
  origin/trunk_dev
- ahead/behind:
  0/0
- worktrees:
  1
- dirty paths:
  exactly 17
- tracked modifications:
  exactly 11
- untracked paths:
  exactly 6
- staged/unmerged:
  0/0
- all candidate paths:
  regular mode 0644
- no deletion, rename, copy, symlink, Git-recorded mode change, Git operation,
  Git lock, or repository residue.

Require live bytes to match exactly:

`/private/tmp/gec-rw0-b1-repair.Xm5t6e/final-provenance-1.manifest.json`

with:

- size:
  3,687 bytes
- SHA-256:
  e1c7d5133599d4d6229eb5bf818d04471937882430c47b089cbe22b03d12e0ab
- tracked textual-diff SHA-256:
  b402f11454c9f519ce5822d420fcba71312b3add653b86c3ea1eac7dd55a0689

Safely retain the second re-audit records without modifying them:

- `/private/tmp/gec-rw0-b1-reaudit-bb6sgyd9/audit-report.txt`
- `/private/tmp/gec-rw0-b1-reaudit-bb6sgyd9/terminal-evidence.json`

Create a new external operator-owned, non-symlink, mode-0700 repair evidence
root beneath `/private/tmp`.

Run the exact provenance recipe below twice before editing and require exact
equality to the pinned 17-path opening target. Stop on any mismatch.

ENGINEERING DISPOSITION

This is a bounded contract-and-implementation correction, not an architecture
refreeze.

The governing B1 relation contract is amended in exactly two ways:

A. COMPLETE VERIFIED-PARENT CONTAINMENT

The external authority observation's verified parent claim is the structural
upper bound for all supplied current authority values.

For every relation with the relevant supplied objects:

1. Parent identity
   - observation parent-grant ref/digest equals the attempt fence's existing
     parent-standing-grant pair;
   - it equals the author/current effect fence parent-standing-grant pair where
     those objects are supplied;
   - proposal parent pair equals the observation parent pair.

2. Attempt lineage
   - the supplied attempt fence ref/digest and semantic-attempt identity equal
     the exact attempt fence and semantic attempt in the phase basis/L34;
   - a current effect fence's semantic-attempt identity equals the phase-basis
     semantic attempt;
   - the current effect fence's originating attempt-fence ref/digest equals the
     supplied attempt fence pair and the phase-basis L34 attempt-fence pair;
   - the authority observation and subordinate proposal attempt-fence pairs
     equal that same pair;
   - derive exact owning field names and validations from current C2A source;
     do not invent aliases or new fields.

3. Effect identity
   - observation effect-fence ref/digest equals the exact supplied current
     effect-fence pair;
   - observation `effect_class` equals the current effect fence's effect class;
   - proposal effect-fence ref/digest and effect class equal the current effect
     fence when the proposal relation is evaluated;
   - author-fence identity remains tied to L34 under the existing author-effect
     relation; a later current fence remains permitted only within the same
     semantic attempt and originating attempt fence.

4. Effect-set containment
   - the attempt fence's complete allowed-effect set is a subset of the
     observation's verified parent `allowed_effect_classes` set;
   - each applicable author/current effect-fence effect class is a member of the
     verified parent set;
   - each applicable effect-fence effect class is a member of the attempt
     fence's allowed-effect set under the existing C2A relation;
   - proposal effect class is a member of both the verified parent set and the
     supplied attempt-fence set;
   - this is structural checking of an external verifier claim, not independent
     authentication of the grant or family.

5. Ceiling containment
   - every applicable attempt/author/current fence ceiling is componentwise <=
     the observation's verified parent ceilings;
   - proposal ceilings remain <= parent, attempt fence, and current effect
     fence;
   - strict proposal reduction is still measured only from the verified parent.

6. Expiry containment
   - attempt fence, author effect fence, and current effect fence expiry are each
     <= the observation's verified parent grant expiry whenever supplied;
   - proposal expiry remains <= parent, attempt fence, and current effect fence;
   - currentness still requires `now` strictly before every applicable expiry.

7. Stop/head containment
   - current stop is clear;
   - all supplied stop coordinates match the phase basis;
   - observation current effect-head and delivery-head digests equal the phase
     basis;
   - active or drifted stop/head facts cannot pass retrieval or qualification.

The complete rule MUST be enforced consistently by authority validation,
subordinate narrowing, retrieval composition, and host qualification to the
extent each existing signature supplies the necessary object.

Host qualification does not receive an `AttemptFenceV1` object and therefore
MUST NOT claim to revalidate attempt-fence ceilings, expiry, or effect-set
contents. It MUST still bind:

- authority attempt-fence ref/digest to the phase-basis L34 pair;
- current effect-fence semantic attempt and originating attempt-fence pair to
  the same phase-basis pair;
- authority effect-fence pair/effect class to the supplied current effect fence;
- current effect class membership in the authority parent allowed set;
- current effect-fence ceilings and expiry within the claimed parent;
- current heads, path, and clear stop.

A mismatch in these identity predicates computes
`blocked / phase_or_effect_mismatch`; excluded effect or otherwise structurally
invalid parent containment computes `blocked / authority_not_verified` after
higher-precedence phase/stop/denial/expiry cases.

B. RETRIEVAL RELATION BUDGET

The retrieval relation's exact governed limit becomes **374**, not 338.

Correct formula:

```text
87 basis
+ 17 custody
+ 62 authority observation
+ 46 proposal
+ 3×38 retrieval events
+ 1 sequence container
+ 2 fence leaves
+ 1 caller-supplied time
+ 8 current-path occurrences
+ 30 external ceiling-member occurrences
+ 6 external effect-set occurrences
= 374
```

This is the only budget-literal change authorized.

The retrieval caller and its narrowing helper must use one shared budget. The
30 ceiling-member and 6 effect-set occurrences are charged exactly once before
or inside the helper. Do not tell a helper that they were already charged when
they were not; do not double-charge them; do not reset the budget.

EXACT REPAIR ALLOWLIST

Only these four existing candidate paths may change relative to the pinned
17-path opening target:

1. `.docs/rw0-b1-pure-phase-values.md`
2. `src/ge_nwp_coordinator/_rw0_phase_entry_semantic_values.py`
3. `tests/test_rw0_b1_phase_values.py`
4. `tests/test_rw0_b1_relations.py`

The other thirteen candidate entries must remain byte-identical to the opening
target. Every path outside the complete 17-path candidate must remain
byte-identical to HEAD.

Final topology remains exactly:

- 17 dirty paths;
- 11 tracked modifications;
- 6 untracked;
- 0 staged;
- 0 unmerged;
- all regular mode 0644;
- no Git-recorded add/delete/rename/copy/mode change.

Stop if a fifth repair path is required.

SOURCE REPAIR REQUIREMENTS

Use private internal single-pass helpers where needed so the same containment
and lineage rules are not inconsistently reimplemented.

1. `validate_authority_observation`

Require complete verified-parent containment for the supplied attempt fence,
author effect fence, and current effect fence, including parent pair,
semantic-attempt/origin attempt-fence lineage, allowed-effect containment,
ceiling containment, expiry containment, current heads, path, and clear/current
stop.

Eliminate any remaining semantic shortcut based on Python object identity.

2. `validate_subordinate_narrowing`

Require:

- complete current attempt/effect lineage to the phase basis;
- complete verified-parent containment for the attempt and current effect
  fences;
- proposal containment under parent and both fences;
- strict reduction from the verified parent only.

A current effect fence from another semantic attempt or originating attempt
fence fails `per_fence_basis_mismatch` or the current existing content-free
relation reason that most exactly represents the failed predicate. Do not add a
new error reason.

3. `validate_retrieval_event_sequence`

Preserve the F1–F7 repairs. In one shared 374-unit budget invocation, establish:

- current subordinate narrowing;
- live exact custody;
- exact authority/proposal/custody/phase/attempt/effect/fence/head/stop/path
  bindings;
- legal unique-ref immutable-expiry sequence.

Charge the 36 previously omitted external occurrences exactly once.

4. `validate_host_qualification`

Bind the authority observation's attempt-fence pair to the phase-basis L34
attempt pair and to the supplied current effect fence's originating attempt
pair. Bind semantic attempt, current effect-fence identity/class, parent,
allowed-effect membership, current-fence ceilings/expiry, heads, path, and clear
stop before permitting `qualified`.

Compute the existing closed result/reason precedence; do not add reasons or
change fields/signatures.

GOVERNING DOCUMENT REPAIR

Update only `.docs/rw0-b1-pure-phase-values.md` to:

- state the complete verified-parent containment rule above consistently for
  authority, narrowing, retrieval, and qualification;
- make explicit that host qualification rechecks only predicates available from
  its current signature and does not authenticate or reconstruct the absent
  attempt-fence object;
- change only the retrieval budget formula/literal from 338 to 374;
- preserve every class, field, schema, digest domain, other budget, privacy rule,
  consumer boundary, and nonclaim.

TEST-FIRST CAUSAL REPAIR GATE

Before changing production source or the governing document:

1. Add exact causal tests to the two authorized test files.
2. Run one isolated selected red gate.
3. Require failures caused by the current false acceptances, budget undercount,
   missing matrix coverage, or non-isolated uniqueness mutant—not syntax,
   invalid fixture setup, collection weakening, or unrelated failure.
4. Retain exact argv, environment, umask, stdout, stderr, JUnit, repository
   fingerprint, and selected node IDs.
5. Do not rerun the red gate.

Then repair source and governing documentation.

REQUIRED CAUSAL TESTS

A. Host qualification attempt lineage

Add at least:

1. A self-digest-valid authority observation with a changed attempt-fence
   ref/digest, while all unrelated fields remain valid. A supplied
   `qualified/qualified` result must fail; the matching
   `blocked/phase_or_effect_mismatch` value must pass.
2. A current effect fence whose semantic attempt or originating attempt-fence
   pair differs from the phase basis. Isolate each predicate where practical.
3. A current effect class excluded from the authority allowed set.
4. A current effect fence ceiling or expiry above/after the claimed parent.

B. Narrowing attempt lineage and parent containment

Add isolated mutants for:

1. current effect fence from another semantic attempt;
2. current effect fence originating from another attempt-fence pair;
3. attempt-fence allowed-effect set broader than the verified parent set;
4. attempt, author, or current effect fence expiry after the verified grant;
5. applicable fence ceiling above parent;
6. proposal equal to parent;
7. one valid case with an attempt allowed set strictly narrower than the parent;
8. equal and unequal valid role-specific authorization-basis pairs remain
   accepted when all lineage/containment rules hold.

C. Retrieval budget

Pin the exact literal **374** and formula independently of production constants.
Exercise the actual retrieval relation:

- largest valid traversal at 374 passes;
- one additional charged occurrence fails
  `cumulative_work_exhausted`;
- the 30 ceiling-member and 6 effect-set occurrences are not free;
- helper composition neither resets nor double-charges the budget;
- shared-DAG aliases still charge per occurrence.

D. Complete qualification result and precedence coverage

Create a test-owned table that exercises every exact result/reason state:

- `qualified/qualified`
- `blocked/readiness_unready`
- `blocked/readiness_expired`
- `blocked/authority_not_verified`
- `blocked/authority_denied_or_revoked`
- `blocked/authority_expired`
- `blocked/phase_or_effect_mismatch`
- `blocked/worker_artifact_mismatch`
- `blocked/worker_protocol_mismatch`
- `blocked/platform_or_architecture_mismatch`
- `blocked/profile_mismatch`
- `blocked/global_stop_active`
- `unknown/unknown`

Also exercise `readiness_unknown` as the exact blocked reason frozen by the
current qualification matrix. Do not omit it merely because `unknown/unknown`
exists for authority uncertainty.

For every precedence row, add isolated one-predicate cases. Add pairwise
collisions for every adjacent precedence step that can coexist in one fixture,
including at minimum:

- phase mismatch over active stop;
- active stop over denied/revoked;
- denied/revoked over expired authority;
- expired authority over unknown authority;
- unknown authority over incompatible/unverified family;
- family invalid over readiness expiry;
- readiness expiry over readiness unready;
- readiness unready over artifact mismatch;
- readiness unknown over artifact mismatch;
- artifact mismatch over protocol mismatch;
- protocol mismatch over platform/architecture mismatch;
- platform/architecture mismatch over other profile mismatch.

The expected pair must come from a literal test-owned table, not production
constants.

E. Isolated event-ref uniqueness

Replace or supplement the non-isolated duplicate mutant with:

```text
issued event ref A
-> redeemed event ref B, predecessor A
-> consumed event ref A, predecessor B
```

All other fields, sequence numbers, times, immutable expiry, and predecessor
pairs remain valid. This must fail solely because event ref A is repeated.

Keep a separate unique-ref self-predecessor mutant, for example a later event
with unique ref C and predecessor ref C, so uniqueness and self-predecessor are
causally independent.

Do not weaken, skip, xfail, rename gratuitously, or reduce existing tests.

VALIDATION ISOLATION

Use one new external operator-owned, non-symlink, mode-0700 repair root under
`/private/tmp`.

For every pytest child:

- save actual caller umask;
- restore it before launch;
- record and require equal caller/child numerical umask;
- use:
  - `env -u PYTHONTRACEMALLOC -u PYTHONWARNINGS`;
  - `LC_ALL=C`, `LANG=C`;
  - `PYTHONDONTWRITEBYTECODE=1`;
  - distinct external `PYTHONPYCACHEPREFIX`, `TMPDIR`, `--basetemp`, JUnit;
  - `PYTEST_DISABLE_PLUGIN_AUTOLOAD=1`;
  - `PYTEST_ADDOPTS=''`;
  - `PYTHONHASHSEED=0`;
  - `python3 -B -m pytest -p no:cacheprovider -W error`;
  - serial execution.

Before and after every final green run require exact candidate bytes, modes,
path set, branch/HEAD/upstream, zero staged/unmerged, no operation/lock, and no
repository residue.

OPENING REPAIR NODE COLLECTION

Before editing, collect the complete ordered candidate node list exactly once.
The reported opening count is 4,393; require the live result and hash to match:

- count:
  4,393
- SHA-256:
  97b1f9a90e1f458ebd6d0802dc4fc82b70e8a7f8b4d427eb04d9ad4fac06ded7

Stop on mismatch.

FINAL VALIDATION ORDER

After source/doc repair and cleanup:

1. Collect the complete final ordered node list exactly once.

   Require:

   - opening minus final is empty;
   - every opening node retains exact order;
   - additions belong only to:
     - `tests/test_rw0_b1_phase_values.py`
     - `tests/test_rw0_b1_relations.py`;
   - no duplicate, skip, xfail, warning, collection hook, renamed, collapsed, or
     reparameterized node.

2. Run the exact new causal tests.

3. Run individually:

- `tests/test_rw0_b1_phase_values.py`
- `tests/test_rw0_b1_relations.py`

4. Run all four B1 files together:

- `tests/test_rw0_b1_phase_values.py`
- `tests/test_rw0_b1_relations.py`
- `tests/test_rw0_b1_vectors.py`
- `tests/test_rw0_b1_boundaries.py`

5. Run source/public/static boundaries:

- `tests/test_c2a_nonimplementation.py`
- `tests/test_runtime_non_authority.py`
- `tests/test_c2b2_development_row_value_boundaries.py`
- `tests/test_b2a_writer_session_contract.py`

6. Run C2A compatibility:

- `tests/test_worker_execution_semantic_values.py`
- `tests/test_worker_execution_semantic_vectors.py`
- `tests/test_worker_execution_semantic_relations.py`
- `tests/test_worker_execution_semantic_boundaries.py`
- `tests/test_c2a_relations.py`
- `tests/test_c2a_first_slice_semantic_protocol_contract.py`

7. Run RW0/current-status/docs:

- `tests/test_rw0_remote_contact_phase_entry_contract.py`
- `tests/test_architecture_contracts.py`
- `tests/test_remote_worker_pre_execution_planning_contract.py`
- `tests/test_autonomous_software_development_operating_model.py`

8. Run exact path, mode, status, import, public-surface, protected-byte,
   `git diff --check`, operation/lock, and residue guards.

9. Run the complete suite against frozen repair bytes.

Full-suite policy:

- run repair attempt 001 exactly once;
- if it fails only because of this repair and every correction remains inside
  the exact four-path repair allowlist, repair and run repair attempt 002
  exactly once;
- never run repair attempt 003;
- if a fifth path, schema/signature change, or architecture correction is
  required, stop.

For every final green run require:

- return code 0;
- exact collected/passed accounting;
- zero failures/errors/skips/xfailed/warnings;
- empty stderr;
- no duplicate, ambiguous, parse-error, or unmapped JUnit case;
- equal caller/child umask;
- unchanged frozen bytes.

PROTECTED SURFACES

Relative to the pinned 17-path opening target:

- only the four repair-authorized entries may change;
- the other thirteen candidate entries remain byte-identical.

Relative to HEAD, everything outside the complete 17-path candidate remains
byte-identical, especially:

- C2A source, schemas, enums, relations, vectors, and path grammar;
- C2B3D and Section 41 source/contracts;
- row-value providers;
- SQLite, migrations, catalog, application generation;
- package root, StateStore, WriterSession, public protocols;
- dependencies, scripts, config, fixtures;
- AGENTS.md and README.md;
- supporting repositories.

No production consumer beyond the private B1 module may appear.

ARTIFACT HYGIENE

Remove only repair-created transient caches, pycache, basetemps, temporary
archives/files, and repository residue after preserving terminal evidence.

Do not modify or delete prior implementation/audit evidence.

Do not run `compileall` or `py_compile` against repository paths.

FINAL PROVENANCE

After final validation and cleanup, run the exact unchanged provenance recipe
below twice.

Require:

- return code 0;
- empty stderr;
- byte-identical complete stdout;
- byte-identical canonical manifests;
- exact branch/HEAD/upstream;
- exactly 17 entries;
- exactly 11 tracked modifications and 6 untracked;
- safe regular file types and expected modes;
- stable tracked textual-diff SHA-256.

Compare final with the pinned opening target and prove:

- only the four repair-authorized entries changed;
- all other candidate entries are exact;
- no path became newly dirty or ceased being dirty.

EXACT PROVENANCE RECIPE

```python
from __future__ import annotations

import hashlib
import json
import os
import stat
import subprocess
from pathlib import Path

RECIPE_ID = "governed-execution.audit-patch-manifest.v1"
OUTPUT_PATH = Path("/tmp/ge-coordinator-b3a-audit-manifest-v1.json")


def git_bytes(*args: str) -> bytes:
    env = os.environ.copy()
    env["LC_ALL"] = "C"
    env["LANG"] = "C"
    result = subprocess.run(
        ["git", *args],
        check=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        env=env,
    )
    return result.stdout


def git_text(*args: str) -> str:
    return git_bytes(*args).decode("utf-8", "strict").strip()


def nul_paths(data: bytes) -> list[str]:
    return [
        item.decode("utf-8", "strict")
        for item in data.split(b"\0")
        if item
    ]


head = git_text("rev-parse", "HEAD")
branch = git_text("branch", "--show-current")
upstream = git_text("rev-parse", "--abbrev-ref", "--symbolic-full-name", "@{u}")

tracked = set(
    nul_paths(git_bytes("diff", "--name-only", "--no-renames", "-z", "HEAD", "--"))
)
added = set(
    nul_paths(
        git_bytes(
            "diff",
            "--name-only",
            "--no-renames",
            "--diff-filter=A",
            "-z",
            "HEAD",
            "--",
        )
    )
)
deleted = set(
    nul_paths(
        git_bytes(
            "diff",
            "--name-only",
            "--no-renames",
            "--diff-filter=D",
            "-z",
            "HEAD",
            "--",
        )
    )
)
untracked = set(
    nul_paths(git_bytes("ls-files", "--others", "--exclude-standard", "-z"))
)

if tracked & untracked:
    raise SystemExit("tracked/untracked path overlap")

entries: list[dict[str, object]] = []
for relative_path in sorted(tracked | untracked):
    if relative_path in untracked:
        kind = "untracked"
    elif relative_path in deleted:
        kind = "tracked_deleted"
    elif relative_path in added:
        kind = "tracked_added"
    else:
        kind = "tracked_modified"

    entry: dict[str, object] = {
        "kind": kind,
        "path": relative_path,
    }

    if kind == "tracked_deleted":
        entry.update(
            {
                "file_type": "missing",
                "mode": None,
                "sha256": None,
                "size": None,
            }
        )
    else:
        path = Path(relative_path)
        metadata = path.lstat()
        mode = f"{stat.S_IMODE(metadata.st_mode):04o}"
        if stat.S_ISREG(metadata.st_mode):
            payload = path.read_bytes()
            file_type = "regular"
        elif stat.S_ISLNK(metadata.st_mode):
            payload = os.readlink(path).encode("utf-8")
            file_type = "symlink"
        else:
            raise SystemExit(f"unsupported file type: {relative_path}")

        entry.update(
            {
                "file_type": file_type,
                "mode": mode,
                "sha256": hashlib.sha256(payload).hexdigest(),
                "size": len(payload),
            }
        )

    entries.append(entry)

diff_bytes = git_bytes(
    "diff",
    "--full-index",
    "--binary",
    "--no-ext-diff",
    "--no-textconv",
    "--no-renames",
    "HEAD",
    "--",
)
textual_diff_sha256 = hashlib.sha256(diff_bytes).hexdigest()

manifest = {
    "branch": branch,
    "files": entries,
    "head": head,
    "recipe_id": RECIPE_ID,
    "textual_diff_sha256": textual_diff_sha256,
    "upstream": upstream,
}

canonical = (
    json.dumps(
        manifest,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")
    + b"\n"
)
manifest_sha256 = hashlib.sha256(canonical).hexdigest()
OUTPUT_PATH.write_bytes(canonical)

print(f"recipe_id={RECIPE_ID}")
print(f"textual_diff_sha256={textual_diff_sha256}")
print(f"manifest_sha256={manifest_sha256}")
print(f"file_count={len(entries)}")
print(canonical.decode("utf-8"), end="")
```

CLOSEOUT

Return exactly:

COORDINATOR_RW0_B1_SECOND_REAUDIT_FINDINGS_REPAIRED_READY_FOR_FRESH_REAUDIT

only when all five re-audit findings are mechanically closed, every final gate
is exact-green, artifact hygiene is complete, and repeated provenance is stable.

Report:

1. opening repository identity/topology and pinned target reproduction;
2. finding disposition for all five re-audit findings;
3. exact four-path repair delta with before/after size/SHA-256;
4. causal-red command/results/evidence;
5. exact semantic-attempt and attempt-fence lineage binding;
6. complete verified-parent effect-set/ceiling/expiry containment;
7. host-qualification attempt/effect binding and result precedence;
8. corrected retrieval budget formula/literal and single-charge proof;
9. complete qualification matrix/precedence tests;
10. isolated duplicate-event and self-predecessor mutants;
11. opening/final node counts, hashes, additions, and order comparison;
12. every focused/full-suite command/result/evidence hash;
13. failed attempts and whether repair attempt 002 was needed;
14. protected/public/import/dependency/migration comparisons;
15. artifact hygiene;
16. recipe identity, two-run output identity, tracked diff, final manifest
    size/hash/count/path;
17. assumptions, limitations, unresolved later seams, skipped validation, and
    inspection boundary;
18. separate provenance, validation, and implementation confidence.

Required final statements:

INDEPENDENT_AUDIT_NOT_PERFORMED
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED
REMOTE_CONTACT_NOT_PERFORMED
WORKER_OR_MODEL_NOT_INVOKED
SUPPORTING_REPOSITORIES_NOT_MODIFIED
DEPENDENCIES_NOT_CHANGED
MIGRATIONS_NOT_CHANGED
PUBLIC_API_NOT_WIDENED
PRIOR_AUDIT_EVIDENCE_PRESERVED

STOP CONDITIONS

Stop without further mutation if:

- opening provenance or opening node identity differs;
- a fifth repair path is required;
- a class, ordered field list, schema ID, digest domain, relation signature,
  role decomposition, or B1/B2/C/D/E/ES ownership split must change;
- any budget literal other than retrieval 338 -> 374 must change;
- the corrected 374 budget is mechanically insufficient under faithful
  single-pass charging;
- a new scenario-profile class or production consumer is required;
- private/bearer material would enter B1;
- a digest would become authenticity or permission;
- existing C2A, C2B3D, Section 41, row, decision, or global-stop contracts must
  change;
- SQLite, migration, durable state, filesystem, process, network, provider,
  model, Bridge, ES, worker, adapter, dependency, script, configuration, or
  public API work is required;
- tests must be weakened, skipped, xfailed, or gratuitously renamed;
- repair full-suite attempt 002 is not exact-green;
- final provenance is unstable or residue remains.
