TITLE

Coordinator RW0-B1 — correction to third-audit repair prompt:
candidate lineage is ref-only

ENGAGEMENT TYPE

Bounded continuation in the existing write-enabled RW0-B1 implementation
conversation.

This correction supersedes only the candidate-lineage wording and test
requirements in the previously issued:

`Coordinator RW0-B1 — repair third independent-audit findings and prepare
fresh re-audit`

All other scope, authority, privacy, validation, provenance, isolation,
allowlist, stop-condition, non-goal, closeout, and reporting requirements from
that prompt remain in force.

Do not create or resume subagents. You remain the sole repository writer.

CURRENT STOPPED STATE

The preceding attempt stopped before repository mutation.

It reports that:

- opening provenance matched the pinned 17-path target;
- the opening ordered collection matched exactly 4,403 nodes;
- all 17 candidate files remain unchanged;
- no repair tests were run;
- no final provenance was run.

Treat those already retained opening-provenance and opening-node records as
satisfying the prior prompt's opening gates. Do not repeat an exact-once opening
node collection or recreate opening provenance merely because of this prompt
correction.

Before editing, perform only a read-only immediate guard confirming that the
live branch, HEAD, upstream, 17-path topology, staged/unmerged state, modes, and
per-file bytes still equal the already verified pinned opening target:

`/private/tmp/gec-rw0-b1-repair2.ZlVzXM/final-provenance-1.manifest.json`

Required manifest identity:

- size: 3,687 bytes
- SHA-256:
  `40537149d30595bac5eedb0d4077b85d2b145d94ee2b6ec68a35c70fee347c9a`

Stop on any mismatch. Do not restore, revert, or restart from HEAD.

AUTHORITATIVE FIELD CORRECTION

The prior repair prompt incorrectly required a `candidate_digest` relation and a
`candidate_digest`-only mutant.

That requirement is withdrawn.

The frozen owning schemas expose:

- `candidate_ref` as the candidate lineage coordinate relevant here;
- no `candidate_digest` field on `EffectFenceV1`;
- no `candidate_digest` field in `CanonicalC2B3DLineage`.

Therefore:

1. Do not add `candidate_digest` anywhere.
2. Do not infer, synthesize, derive, alias, or persist a candidate digest.
3. Do not change any class, `_FIELDS` tuple, schema ID, digest domain, relation
   signature, K8/L34 inventory, C2A field, or B1 field.
4. Do not add a `candidate_digest` test fixture, mutant, comparison, document
   claim, error path, or compatibility rule.
5. Any previous wording saying:
   - “candidate ref/digest pair”;
   - “candidate digest”;
   - “candidate and command pairs” where that implies a candidate digest;
   is superseded by the exact ref-only rule below.

CORRECTED STABLE LINEAGE RULE

Inspect and use the exact live owning field names.

For the current effect fence:

- bind its exact `candidate_ref` to the phase-basis L34 `candidate_ref`;
- bind the actual originating/author-command ref and digest fields exposed by
  `EffectFenceV1` to the corresponding actual L34 author-command ref and digest
  fields;
- preserve semantic-attempt and originating-attempt-fence binding;
- preserve the owning C2A effect relation;
- preserve current-effect ceiling/expiry containment inside the attempt fence
  and verified parent;
- preserve current parent, effect-class, head, stop, path, and authority checks.

No candidate digest participates in this relation.

Apply the corrected rule to:

- `validate_subordinate_narrowing`;
- `validate_retrieval_event_sequence` through narrowing composition;
- `validate_host_qualification`.

Failure behavior remains:

- narrowing/retrieval candidate-ref or command-lineage drift:
  `relation_mismatch`;
- semantic-attempt or originating-attempt-fence drift:
  `per_fence_basis_mismatch`;
- host-qualification candidate-ref or command-lineage drift:
  `blocked / phase_or_effect_mismatch`.

Preserve a valid later current effect with:

- a different current effect intent/ref where the owning C2A relation permits;
- the same semantic attempt;
- the same originating attempt-fence pair;
- the same `candidate_ref`;
- the same actual author/originating-command ref and digest lineage.

CORRECTED CAUSAL TEST INVENTORY

Replace the prior four-item candidate/command mutant list with exactly:

1. `candidate_ref` only;
2. originating/author-command ref only;
3. originating/author-command digest only.

For each isolated, self-digest-valid current-effect-fence mutant:

- hold all unrelated fields fixed;
- rebind observation/proposal identities only when necessary to isolate the
  lineage predicate;
- require `validate_subordinate_narrowing` to reject;
- require `validate_retrieval_event_sequence` to reject through composed
  narrowing;
- require host qualification not to accept `qualified/qualified`;
- require the matching
  `blocked / phase_or_effect_mismatch`
  qualification value to pass.

Do not create a candidate-digest mutant.

Also retain the positive later-current-effect case with:

- a different permitted effect intent/ref;
- exact stable L34 semantic attempt;
- exact originating attempt-fence pair;
- exact `candidate_ref`;
- exact actual author/originating-command ref and digest lineage.

CONTINUE THE ORIGINAL REPAIR

After the immediate opening guard:

1. Add the corrected tests-first causal cases, including the current-fence
   ceiling/expiry and IPv4-shaped privacy cases from the original prompt.
2. Run the selected causal-red gate exactly once.
3. Retain its required command, environment, umask, stdout, stderr, JUnit,
   fingerprint, and node evidence.
4. Repair only the exact four authorized paths:
   - `.docs/rw0-b1-pure-phase-values.md`
   - `src/ge_nwp_coordinator/_rw0_phase_entry_semantic_values.py`
   - `tests/test_rw0_b1_phase_values.py`
   - `tests/test_rw0_b1_relations.py`
5. Perform the original focused, boundary, C2A, RW0/documentation, collection,
   full-suite, guard, hygiene, and repeated-provenance gates unchanged.
6. Preserve the exact 17-path candidate boundary:
   - 11 tracked modifications;
   - 6 untracked files;
   - 0 staged;
   - 0 unmerged.
7. Do not change a fifth path.
8. Do not stage, commit, push, create a PR, merge, tag, release, deploy, contact
   a remote, invoke a worker/model, or modify a supporting repository.

DOCUMENTATION WORDING

Where the governing B1 document describes the stable current-fence lineage,
state exactly that:

- candidate lineage is the exact L34 `candidate_ref`;
- command lineage uses the actual owning ref/digest fields;
- no candidate digest exists or is introduced;
- B1 validates supplied identities only and grants no authority.

Do not add a compatibility alias or explanatory pseudo-field named
`candidate_digest`.

STOP CONDITIONS

In addition to every stop condition in the original repair prompt, stop if:

- implementation appears to require a candidate digest;
- live source does not expose the expected `candidate_ref`;
- the owning command fields differ materially from the inspected ref/digest
  relation;
- satisfying the audit requires changing EffectFenceV1, L34, K8, C2A, or any
  frozen schema.

CLOSEOUT

The successful closeout token remains exactly:

`COORDINATOR_RW0_B1_THIRD_AUDIT_FINDINGS_REPAIRED_READY_FOR_FRESH_REAUDIT`

In the final report explicitly record:

- that the original candidate-digest requirement was a prompt defect;
- that no candidate-digest field was added;
- the exact live candidate and command fields used;
- the corrected three-mutant lineage matrix;
- all other repair, validation, provenance, and non-effect evidence required by
  the original prompt.

Required final statements remain unchanged:

INDEPENDENT_AUDIT_NOT_PERFORMED
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED
REMOTE_CONTACT_NOT_PERFORMED
WORKER_OR_MODEL_NOT_INVOKED
SUPPORTING_REPOSITORIES_NOT_MODIFIED
DEPENDENCIES_NOT_CHANGED
MIGRATIONS_NOT_CHANGED
PUBLIC_API_NOT_WIDENED
PRIOR_AUDIT_EVIDENCE_PRESERVED
