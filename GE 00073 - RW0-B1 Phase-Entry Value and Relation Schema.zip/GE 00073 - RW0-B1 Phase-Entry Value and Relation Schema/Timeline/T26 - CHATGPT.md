Codex stopped correctly. **The `candidate_digest` requirement was a prompt defect.**

The frozen identity carries `candidate_ref`; it does not define a parallel `candidate_digest` coordinate. The exact RW0 entry identity likewise names `candidate_ref` and `author_command_ref`, without widening K8/L34.  Adding a missing digest field would violate the reconciled freeze, whose purpose is private, pure relations over supplied evidence—not a new identity schema. 

No repository recovery is necessary:

- opening provenance passed;
- the 4,403-node opening collection passed;
- all 17 candidate paths remain unchanged;
- no test-first red run was consumed;
- no repair mutation occurred.

The corrected rule is:

```text
candidate lineage:
  current_effect_fence.candidate_ref
  ==
  phase-basis L34 candidate_ref

command lineage:
  actual owning command ref/digest fields
  ==
  corresponding L34 author-command ref/digest fields
```

There is **no** candidate-digest comparison, fixture, mutant, compatibility alias, or schema addition.

Send this correction to the **same RW0-B1 implementation conversation**:

:chatgpt-content-reference{index="2"}

It explicitly:

- supersedes only the erroneous candidate-digest portions of the prior repair prompt;
- reuses the already completed opening provenance and node gates instead of rerunning exact-once collection;
- replaces the invalid four-case lineage matrix with:
  1. `candidate_ref` only;
  2. command ref only;
  3. command digest only;
- preserves all current-fence bounds, IPv4-shaped privacy, validation, four-path scope, provenance, and stop conditions;
- requires Codex to report the exact live field names it used;
- forbids adding or synthesizing `candidate_digest`.

The successful closeout token remains:

```text
COORDINATOR_RW0_B1_THIRD_AUDIT_FINDINGS_REPAIRED_READY_FOR_FRESH_REAUDIT
```

### Sources

- Reconciled RW0-B1 packet and non-authority boundary. 
- Exact RW0 K8 identity showing `candidate_ref` and `author_command_ref`. 
- Codex stopped-state report supplied in this turn.

**Confidence:** 100% that the `candidate_digest` requirement must be removed; 99% that no repository mutation or schema revision is needed to resume the bounded repair.
