## Next step: RW0-B reconnaissance

RW0-A is merged and the fresh snapshot is now the authoritative Coordinator baseline. The next critical-path action is **not implementation**. RW0-B still contains several architecture-defining decisions that the merged contract explicitly leaves open:

- verifier and grant-verification representation;
- custody and one-use capability semantics;
- host readiness versus effect-bound qualification;
- exact process framing and terminal-result grammar;
- numeric byte, frame, output, and resource ceilings;
- the Codex capability interface without choosing CLI versus App Server;
- the boundary between pure values in RW0-B, durable representation in RW0-C, and process mechanics in RW0-D.

The merged tranche map defines RW0-B as private no-I/O values and strict semantic/wire boundaries, with no SQLite, filesystem, process, network, or model effects. It separately reserves persistence for RW0-C and the offline process proof for RW0-D. `.docs/rw0-remote-worker-contact-phase-entry.md:390-425`

The existing C2A1 layer is already a tightly frozen, private semantic contract: one standard-library-only module, nine immutable value classes, six pure relation validators, no public export, and no I/O or executable authority. `src/ge_nwp_coordinator/_worker_execution_semantic_values.py:1-16,21-108` `.docs/c2a1-pure-semantic-values.md:322-363`

That makes the default design hypothesis:

```text
preserve C2A1 byte-compatible
→ compose its existing identities and records
→ add a separate private RW0-B value layer
→ split semantic values from framing/capability mechanics if needed
```

The prompt does not force that conclusion. It requires Codex to compare extending C2A1 against one or two new private modules and to reject unsafe module ownership explicitly.

It also addresses a subtle regression hazard: older contract tests deliberately reject names such as `WorkSpecCustodyReceiptV1` and `VerifiedAuthorityResultV1` inside historical C2B3 narrowing owners. The reconnaissance must determine whether those are historical non-selections or current global prohibitions; it may not weaken those assertions merely to reuse a convenient name. `tests/test_architecture_contracts.py:1847-1883` `tests/test_c2b0_durable_state_contract.py:17862-17903`

Start a **new read-only Codex conversation** with:

:chatgpt-content-reference{index="0"}

The prompt directs four bounded explorers to cover:

1. authority, custody, privacy, readiness, qualification, and terminal-outcome semantics;
2. existing C2A1 source identities, imports, consumers, tests, and private-module placement;
3. framing, terminal-result, resource ceilings, exit/error precedence, and the Codex capability seam;
4. validation, hostile-input limits, nonimplementation boundaries, provenance, audit, and artifact hygiene.

The expected useful verdict is:

```text
RW0_B_RECONNAISSANCE_READY
```

That verdict must include a closed minimum value inventory, exact exclusions, a one-tranche-versus-split decision, and precise implementation file and test allowlists. A `PARTIAL` or `BLOCKED` result should return the unresolved architecture decisions rather than improvising source work.

My provisional expectation is that the safe decomposition will be:

```text
RW0-B1
  phase-entry and selected-plan bindings
  authority-verification and subordinate-binding projections
  custody and capability observations
  host readiness and qualification
  terminal-outcome pure semantics

RW0-B2
  strict frame and terminal-result values
  bounded byte/resource grammar
  exit/error/cancellation precedence
  Codex-specific capability declaration/observation/qualification
```

That is a hypothesis for reconnaissance, not yet a frozen architecture decision.

### Sources

- :chatgpt-content-reference{index="1"}
- RW0 tranche map and deferred decisions: `.docs/rw0-remote-worker-contact-phase-entry.md:390-425`
- Process/framing gates: `.docs/c2a-first-slice-semantic-protocol-contract.md:1337-1354`
- Deferred wire and runtime mechanics: `.docs/c2a-first-slice-semantic-protocol-contract.md:1432-1484`
- Current pure no-I/O boundary: `.docs/c2a1-pure-semantic-values.md:322-363`
- Exact current private value implementation: `src/ge_nwp_coordinator/_worker_execution_semantic_values.py:1-16,21-108`
- Production-file and public-surface guards: `tests/test_runtime_non_authority.py:22-118`
- Exact C2A1 source and export inventory: `tests/test_c2a_nonimplementation.py:471-581`
- RW0-A tests preserving RW0-B’s open decisions: `tests/test_rw0_remote_contact_phase_entry_contract.py:929-1085`

**Confidence:** 99% that read-only RW0-B reconnaissance is the correct next action; 93% that RW0-B should ultimately split into semantic and framing/capability implementation tranches.
