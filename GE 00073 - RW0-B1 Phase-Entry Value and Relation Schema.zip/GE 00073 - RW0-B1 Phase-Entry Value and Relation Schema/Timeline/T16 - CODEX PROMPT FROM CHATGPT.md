TITLE

Coordinator RW0-B1 — fresh independent re-audit after first-audit repair

ENGAGEMENT TYPE

Fresh read-only independent re-audit of the repaired, uncommitted RW0-B1
candidate.

Use a NEW Codex conversation. Do not continue in either the implementation
conversation or the first independent-audit conversation.

The audit must not edit, format, chmod, clean repository files, stage, commit,
push, create or modify a PR, merge, tag, release, deploy, install dependencies,
run non-test migrations, contact a remote service, invoke a worker/model, or
modify any supporting repository.

Audit-created files, test caches, archives, counterexample databases, and
evidence must stay outside the repository. Remove only audit-created transient
external artifacts after preserving terminal audit evidence.

Do not treat the implementation report, green suite, packet size, manifest
hash, or final node count as correctness proof. Reproduce exact provenance
before correctness inspection.

REPOSITORY

/Users/ds/Repositories/Governed Execution Coordinator/

EXPECTED LIVE TARGET

Require exactly at opening and closeout:

- branch:
  codex/rw0-b1-pure-phase-values-v1
- HEAD:
  bf68a5232bff1b412c9414c076d82cab18c8e0aa
- HEAD tree:
  8fc05f5626bdbb01808df1698c9c2245ab06f1cb
- sole parent:
  1a894c5527c610ab40d8e5ae5e530a762c6e60bf
- HEAD subject:
  docs: freeze RW0-A phase-entry contract (#2)
- upstream:
  origin/trunk_dev
- ahead/behind:
  0/0
- worktrees:
  1
- dirty paths:
  exactly 17
- tracked modifications:
  exactly 11
- untracked paths:
  exactly 6
- staged/unmerged:
  0/0
- every candidate path:
  regular mode 0644
- no deletion, rename, copy, symlink, Git-recorded mode change, Git operation,
  Git lock, or repository-local test/build/database/cache residue.

The exact 17-path set remains:

1. `.docs/rw0-b1-pure-phase-values.md`
2. `src/ge_nwp_coordinator/_rw0_phase_entry_semantic_values.py`
3. `tests/test_rw0_b1_phase_values.py`
4. `tests/test_rw0_b1_relations.py`
5. `tests/test_rw0_b1_vectors.py`
6. `tests/test_rw0_b1_boundaries.py`
7. `tests/test_c2a_nonimplementation.py`
8. `tests/test_runtime_non_authority.py`
9. `.docs/rw0-remote-worker-contact-phase-entry.md`
10. `.docs/authority-boundaries.md`
11. `.docs/autonomous-software-development-operating-model.md`
12. `.docs/durable-state-model.md`
13. `.docs/worker-execution-boundary.md`
14. `tests/test_rw0_remote_contact_phase_entry_contract.py`
15. `tests/test_architecture_contracts.py`
16. `tests/test_remote_worker_pre_execution_planning_contract.py`
17. `tests/test_c2b2_development_row_value_boundaries.py`

No production consumer beyond the new private B1 module is permitted.

PINNED FINAL REPAIR TARGET

Safely read, classify, and copy mode-0400 into the audit root:

`/private/tmp/gec-rw0-b1-repair.Xm5t6e/final-provenance-1.manifest.json`

Required identity:

- size:
  3,687 bytes
- SHA-256:
  e1c7d5133599d4d6229eb5bf818d04471937882430c47b089cbe22b03d12e0ab
- recipe ID:
  governed-execution.audit-patch-manifest.v1
- branch/HEAD/upstream/path set/classifications/modes/sizes/per-file hashes:
  exact live equality
- tracked textual-diff SHA-256:
  b402f11454c9f519ce5822d420fcba71312b3add653b86c3ea1eac7dd55a0689

The target and every path component must be safely lstat-checked, operator-owned,
non-symlink, regular, and readable. Stop on unsafe path, unsupported file type,
malformed canonical JSON, size/hash mismatch, or live mismatch.

PRE-REPAIR TARGET AND FIRST AUDIT

Safely retain and compare:

1. Pre-repair candidate target:

   `/private/tmp/gec-rw0-b1-continuation.qbmvj7qo/final-provenance-1.manifest.json`

   - size:
     3,685 bytes
   - SHA-256:
     5e2ccb1fffb6af4db4e242041a8ef56b511b7b30149b80c0a2cb121bb82aeeb5
   - tracked textual-diff SHA-256:
     28864c904c2f9a09ac6d0d38a61d7aade901cdc4077406702a8019d66883d883

2. First-audit terminal record:

   `/private/tmp/gec-rw0-b1-audit-if52pwsc/terminal-evidence.json`

   - SHA-256:
     620b1bccf951690f8a112c6866eff8192977d4b464f61836c4d32d9f70e6de47

3. Repair terminal record:

   `/private/tmp/gec-rw0-b1-repair.Xm5t6e/terminal-evidence.json`

Verify all safe retained identities reported by those records. Do not modify any
implementation or audit evidence.

Require final-versus-pre-repair manifest comparison to show:

- the same 17 paths, classifications, types, and modes;
- only the eight repair-authorized entries changed;
- the other nine candidate entries are byte-identical.

The eight allowed repair entries were:

1. `.docs/rw0-b1-pure-phase-values.md`
2. `.docs/rw0-remote-worker-contact-phase-entry.md`
3. `src/ge_nwp_coordinator/_rw0_phase_entry_semantic_values.py`
4. `tests/test_rw0_b1_phase_values.py`
5. `tests/test_rw0_b1_relations.py`
6. `tests/test_rw0_b1_vectors.py`
7. `tests/test_rw0_b1_boundaries.py`
8. `tests/test_rw0_remote_contact_phase_entry_contract.py`

FIRST-AUDIT FINDINGS TO RE-AUDIT

The first audit returned `BLOCK` with:

F1 — High — strict narrowing:
A proposal equal to its verified parent was accepted by counting reduction only
against an over-broad fence. The repair must require both fences to fit the
verified parent and strict reduction from that parent.

F2 — High — current authority binding:
Authority/narrowing accepted mismatched fence stop versions, a different current
effect-head digest, and an object-identity shortcut that bypassed the author
effect relation. The repair must bind the author fence semantically, bind
current heads and clear/current stop, and remove object-identity semantics.

F3 — High — downstream composition:
Retrieval accepted a wrong-effect proposal; host qualification accepted
`qualified` when the effect was excluded; narrowing/retrieval accepted active
stop. The repair must enforce current narrowing, live custody, current
authority, effect membership, head/stop compatibility, and supplied-profile
relations within the existing signatures and budgets.

F4 — Medium — canonical identity:
The unbounded exact-integer grammar encountered Python's environment-dependent
integer-to-string conversion limit. The repair selected explicit B1 canonical
compatibility `0..2^63-1` for every integer leaf entering a B1 identity,
including nested L34 and Ceilings leaves, before JSON conversion.

F5 — High — causal tests:
Field/vector fixtures derived from production; two required relations were not
called; relation budgets were not exercised. The repair must use literal
independent oracles, directly exercise all thirteen relations, and causally test
actual shared relation budgets, cycles, and aliases.

F6 — Low — owner status contradiction:
The RW0 owner said B1 was implemented while still calling C2B3D plus Section 41
the unqualified complete implemented boundary. The repair must qualify that as
the durable and executable boundary.

F7 — first-audit observation resolved by engineering decision:
Retrieval allowed repeated event refs and later expiry extension. The repair
must require unique event refs, one immutable expiry per sequence, exact
terminality, no self-predecessor, issued/redeemed/consumed before expiry,
expired at/after expiry, and no later event or retry after a terminal event.

IMPLEMENTATION-REPORTED REPAIR CLAIMS

Treat these as claims to verify, never proof:

- F1–F7 are implemented.
- Only the eight authorized paths changed from the pre-repair target.
- Final topology remains 17 / 11 tracked / 6 untracked / 0 staged / 0 unmerged.
- All other candidate paths are byte-identical.
- Every path outside the 17-path candidate remains at HEAD.
- Final collection:
  4,393 nodes.
- Final node-list SHA-256:
  97b1f9a90e1f458ebd6d0802dc4fc82b70e8a7f8b4d427eb04d9ad4fac06ded7
- Repair-opening node set:
  4,331 nodes,
  SHA-256
  bb466266b494111c037bfc229ce48f89714910bcf935b40117183d3b0ffcd07e
- Exactly 62 repair additions in the five authorized test files.
- All 4,331 repair-opening nodes remain in order.
- Full repair suite attempt 001:
  4,393 collected / 4,393 passed.
- No repair suite attempt 002 was needed.
- Dependencies, migrations, and public API remain unchanged.

PROCESS LIMITATIONS — REQUIRED TREATMENT

The implementation conversation withheld its requested success token because:

1. the causal-red run did not retain a repository fingerprint after test edits;
2. some F5 tests were added after that red run;
3. two exploratory test processes overlapped;
4. all required final validation runs were later serial, isolated, fingerprinted,
   and exact-green.

These are disclosed evidence/process limitations.

Audit treatment:

- Do NOT classify the absent red fingerprint, late-added F5 tests, or exploratory
  overlap as an automatic candidate defect.
- Give the causal-red evidence no correctness credit beyond its exact retained
  bytes and reported child outcome.
- Independently reproduce every F1–F7 pre-repair counterexample against the
  final implementation's negative tests and relation behavior.
- Independently inspect whether every final F5 test is causal.
- Determine whether overlapping exploratory processes wrote, shared, collided,
  or made any retained final result ambiguous. If final isolated evidence,
  repository fingerprints, and frozen bytes establish clean final validation,
  classify the overlap as an implementation-process observation. If it caused
  evidence ambiguity or candidate mutation, block.
- Run every independent audit test serially.
- Do not request another implementation turn solely to recreate a tests-first
  red chronology. Independent causal reproduction may supersede that evidence
  limitation.

RETAINED REPAIR EVIDENCE TO VERIFY

Audit the complete safe root:

`/private/tmp/gec-rw0-b1-repair.Xm5t6e`

At minimum verify:

- opening provenance;
- causal-red metadata, stdout, stderr, JUnit, argv/environment/umask where
  retained;
- path delta/integrity record;
- opening/final node lists and comparison;
- every final focused metadata/result/JUnit record;
- full repair suite attempt 001;
- final guards;
- final provenance pair;
- terminal evidence.

Reported causal-red evidence:

- 12 selected nodes;
- 11 failed, 1 passed;
- stdout:
  22,234 bytes,
  SHA-256
  ea37415d27a5902dab9471972a78ed6b2d172cc4b2171c0e3d0ab175e586119f
- JUnit:
  25,246 bytes,
  SHA-256
  0410c71f402d053589032216838ef00deaf99bb91bb1cecba5a7e83f2eef2f7a

Reported full repair suite:

- exact command family:
  `python3 -B -m pytest -p no:cacheprovider -W error
   --basetemp=<external> --junitxml=<external> -q .`
- 4,393 collected;
- 4,393 passed;
- zero failed/errors/skipped/xfailed/warnings;
- empty stderr;
- caller and child umask `0022`;
- stdout:
  5,081 bytes,
  SHA-256
  0f277e4dc3fef6a172f39d560a44a075ee912a9bcc07d1f7c58353e3c27893c0
- JUnit:
  944,908 bytes,
  SHA-256
  775e6b9a0b6b36b95154abbf770493fdd3df6574341579ef9afdc9f1613dff94

GOVERNING FREEZE PACKET

The exact accepted reconciled design packet is appended verbatim.

Packet identity:

- bytes:
  40,515
- SHA-256:
  2820b4505e9b4e6eb411fcf76597c0455b3b30dd155bd23f607d6957efa47e23

The repair authorizes only the F1–F7 contract corrections above. It does not
authorize a new class, field, schema ID, digest domain, relation signature,
role decomposition, production consumer, public surface, persistence, runtime,
or B2/C/D/E/ES ownership change.

EXACT PROVENANCE RECIPE

Verify the exact source before use:

- size:
  3,945 bytes
- SHA-256:
  db21f2b67ba73a03a98c1d309323e5cabc014a10248ef96d5e25cc52081460bc

Safely classify the fixed output path. Preserve a safe pre-existing file's
bytes, owner, mode, and timestamps; restore and verify it after every provenance
phase. Stop rather than traverse or overwrite an unsafe path.

Run the exact recipe twice at audit opening. Require:

- rc 0;
- empty stderr;
- byte-identical complete stdout;
- byte-identical canonical manifests;
- exact equality to the pinned final repair target;
- exact live repository identity and topology.

On any mismatch, return exactly:

`AUDIT_PROVENANCE_MISMATCH`

and stop before correctness inspection.

Exact recipe:

```python
from __future__ import annotations

import hashlib
import json
import os
import stat
import subprocess
from pathlib import Path

RECIPE_ID = "governed-execution.audit-patch-manifest.v1"
OUTPUT_PATH = Path("/tmp/ge-coordinator-b3a-audit-manifest-v1.json")


def git_bytes(*args: str) -> bytes:
    env = os.environ.copy()
    env["LC_ALL"] = "C"
    env["LANG"] = "C"
    result = subprocess.run(
        ["git", *args],
        check=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        env=env,
    )
    return result.stdout


def git_text(*args: str) -> str:
    return git_bytes(*args).decode("utf-8", "strict").strip()


def nul_paths(data: bytes) -> list[str]:
    return [
        item.decode("utf-8", "strict")
        for item in data.split(b"\0")
        if item
    ]


head = git_text("rev-parse", "HEAD")
branch = git_text("branch", "--show-current")
upstream = git_text("rev-parse", "--abbrev-ref", "--symbolic-full-name", "@{u}")

tracked = set(
    nul_paths(git_bytes("diff", "--name-only", "--no-renames", "-z", "HEAD", "--"))
)
added = set(
    nul_paths(
        git_bytes(
            "diff",
            "--name-only",
            "--no-renames",
            "--diff-filter=A",
            "-z",
            "HEAD",
            "--",
        )
    )
)
deleted = set(
    nul_paths(
        git_bytes(
            "diff",
            "--name-only",
            "--no-renames",
            "--diff-filter=D",
            "-z",
            "HEAD",
            "--",
        )
    )
)
untracked = set(
    nul_paths(git_bytes("ls-files", "--others", "--exclude-standard", "-z"))
)

if tracked & untracked:
    raise SystemExit("tracked/untracked path overlap")

entries: list[dict[str, object]] = []
for relative_path in sorted(tracked | untracked):
    if relative_path in untracked:
        kind = "untracked"
    elif relative_path in deleted:
        kind = "tracked_deleted"
    elif relative_path in added:
        kind = "tracked_added"
    else:
        kind = "tracked_modified"

    entry: dict[str, object] = {
        "kind": kind,
        "path": relative_path,
    }

    if kind == "tracked_deleted":
        entry.update(
            {
                "file_type": "missing",
                "mode": None,
                "sha256": None,
                "size": None,
            }
        )
    else:
        path = Path(relative_path)
        metadata = path.lstat()
        mode = f"{stat.S_IMODE(metadata.st_mode):04o}"
        if stat.S_ISREG(metadata.st_mode):
            payload = path.read_bytes()
            file_type = "regular"
        elif stat.S_ISLNK(metadata.st_mode):
            payload = os.readlink(path).encode("utf-8")
            file_type = "symlink"
        else:
            raise SystemExit(f"unsupported file type: {relative_path}")

        entry.update(
            {
                "file_type": file_type,
                "mode": mode,
                "sha256": hashlib.sha256(payload).hexdigest(),
                "size": len(payload),
            }
        )

    entries.append(entry)

diff_bytes = git_bytes(
    "diff",
    "--full-index",
    "--binary",
    "--no-ext-diff",
    "--no-textconv",
    "--no-renames",
    "HEAD",
    "--",
)
textual_diff_sha256 = hashlib.sha256(diff_bytes).hexdigest()

manifest = {
    "branch": branch,
    "files": entries,
    "head": head,
    "recipe_id": RECIPE_ID,
    "textual_diff_sha256": textual_diff_sha256,
    "upstream": upstream,
}

canonical = (
    json.dumps(
        manifest,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")
    + b"\n"
)
manifest_sha256 = hashlib.sha256(canonical).hexdigest()
OUTPUT_PATH.write_bytes(canonical)

print(f"recipe_id={RECIPE_ID}")
print(f"textual_diff_sha256={textual_diff_sha256}")
print(f"manifest_sha256={manifest_sha256}")
print(f"file_count={len(entries)}")
print(canonical.decode("utf-8"), end="")
```

AUDIT ROOT AND POSTURE

Create one external operator-owned, non-symlink, mode-0700 audit root under
`/private/tmp`. Retained audit evidence files must be mode 0400. Do not retain
credentials, private values, raw WorkSpec/plan bytes, bearer material,
transcripts, stdout/stderr containing private data, or raw database content.

After provenance succeeds, start exactly four bounded read-only audit tasks.
Make at most one retry for a task that fails to start. No nested delegation.
Subagents do not run pytest and do not mutate anything. Every task receives the
same exact final target identity and governing packet.

1. CONTRACT, AUTHORITY, PRIVACY, AND DOCUMENTATION

Inspect:

- governing B1 doc;
- source ownership/nonclaim docstring;
- RW0 owner current-status correction;
- four normalized cross-references;
- C2A/C2A1;
- C2B3D;
- Section 41;
- development-decision/global-stop contracts;
- first-audit F1–F7 ownership implications.

Try to falsify:

- external observation becoming executable authority;
- family compatibility inferred from digests;
- strict narrowing being measured against a fence instead of the parent;
- path-scope digest becoming path policy;
- availability becoming retrieval or consumption;
- readiness becoming qualification or authenticity;
- terminal value becoming a C2B decision, durable terminal fact, evidence-set
  proof, latch atomicity proof, reconciliation-completeness proof, or absence
  proof;
- B1 status overclaiming persistence/contact/runtime/autonomy;
- stale current-status wording remaining in a live owner.

2. VALUE IDENTITY, CANONICALIZATION, TYPE SAFETY, PRIVACY, AND BOUNDS

Inspect all eight values and helpers for:

- exact class order, schema IDs, digest domains, `_FIELDS`, and final digest;
- literal fields versus production-derived tests;
- exact built-in types/subclass/`bool` rejection;
- optional-pair symmetry;
- unknown-before-missing;
- immutable defensive copies;
- subclassing/pickle disablement;
- content-free repr/str/errors and suppressed foreign chains;
- compact sorted JSON, exact Unicode code points, no normalization;
- independent digest reproduction;
- exact `0..2^63-1` B1 canonical compatibility for every integer leaf:
  direct, nested L34, and nested Ceilings;
- deterministic huge-integer rejection before JSON conversion;
- no global interpreter-limit mutation;
- exact per-value and per-relation budgets;
- occurrence-before-descent, cycle detection, and charged shared-DAG aliases;
- privacy sentinels and no I/O/import side effects.

Independently probe maximum, one-over, 4,301-digit integer, hostile subclasses,
cycles, compact DAGs, aliasing, Unicode collisions, digest substitution,
pickling, and exception leakage.

3. RELATION CORRECTNESS, COMPOSITION, AND NON-COLLAPSE

Inspect and externally exercise all thirteen relations.

Required F1–F3/F7 counterexamples:

- proposal equal to parent while a fence is broader;
- fence ceiling or expiry broader/later than parent;
- basis/claims at stop version 8 with fences at 7;
- active stop matching everywhere;
- observation current effect-head or delivery-head mismatch;
- later fence supplied as both author/current fence;
- one-field author-fence drift;
- wrong-effect proposal at retrieval;
- allowed-effect set excluding qualified effect;
- denied/revoked/unknown/incompatible/stale authority through retrieval and
  qualification;
- stale/unavailable custody through retrieval;
- duplicate event refs;
- self-predecessor;
- expiry extension by a later event;
- issued/redeemed/consumed at expiry or after;
- expired before expiry;
- later event after terminal revoked/failed/unknown/expired;
- illegal prefix, predecessor, sequence, time, or correlation drift.

Also cover:

- complete K8/L34/selection/head/stop relation;
- equal and unequal valid per-fence bases;
- family claim remains external;
- strict and non-strict narrowing;
- both custody subjects;
- every qualification precedence/result/reason pair;
- all five terminal rows and forbidden optional pairs;
- no evidence completeness/latch atomicity/reconciliation completeness/absence
  inference;
- one-field ref/digest/head/stop/family/ceiling/profile/branch mutants;
- shared relation budget across called helpers, with no reset or free alias.

4. TEST ADEQUACY, PUBLIC/IMPORT BOUNDARY, PROCESS EVIDENCE, AND ARTIFACTS

Inspect:

- all four B1 test files;
- RW0 owner contract test;
- source/public inventories;
- row-value consumer inventory;
- current-status structural tests;
- opening/final node evidence;
- final focused/full-suite evidence;
- process limitations;
- final manifest, diff, and artifact hygiene.

Required checks:

- every class `_FIELDS`, schema ID, domain, enum, and count has a literal
  test-owned oracle;
- same-count rename/reorder mutants fail;
- canonical vectors do not use production constants/helpers as expected oracle;
- all thirteen relations are directly invoked positively and negatively;
- every real relation budget is exercised at largest valid, one-over, cycle,
  and shared-DAG alias;
- helper composition does not reset budgets;
- all F1–F7 deterministic mutants are checked in and causal;
- current-status owner has a causal stale-wording mutant;
- row-provider allowlist remains exactly the actual three direct imports;
- no dynamic/hidden import or public/package consumer exists;
- no test-name/decorator/parameterization/skip/xfail/warning-filter/collection
  weakening;
- late-added F5 tests are evaluated on final causality, not credited merely
  because they exist;
- causal-red evidence limitations are reported honestly;
- exploratory overlap did not affect final repository bytes, evidence paths,
  or final serial results.

PARENT RESPONSIBILITIES

The parent must:

- wait for all four tasks;
- preserve disagreements and minority findings;
- inspect every material claim directly;
- run independent external counterexamples;
- inspect complete diffs for the eight repair entries;
- verify exact equality of the other nine candidate entries;
- inspect source/docs/tests/imports/config/schema/migrations/artifacts relevant
  to the slice;
- not infer correctness from hashes or green tests;
- not repair any finding.

DIRECT AUDIT CHECKS

1. Exact target comparison

Create one clean external `git archive HEAD`, safely extract with no links or
unsafe paths, and compare:

- all 17 candidate entries;
- every protected path outside the candidate;
- package exports/dependencies;
- migration catalog/application generation;
- all production importers.

2. AST/import/public-surface comparison

Verify:

- one new private production module only;
- empty `__all__`;
- no package-root export;
- no public StateStore/WriterSession/protocol method;
- no filesystem, SQLite, subprocess, network, environment, logging, provider,
  model, Bridge, ES, worker, service, queue, or scheduler behavior;
- exactly the three legitimate direct row-provider imports;
- no new production consumer;
- no test collection-control weakening.

3. Independent vectors

For every class, construct at least one literal valid mapping and compute
canonical bytes/digest independently of production constants/helpers. Mutate
every field class and the self-digest. Explicitly test all integer boundaries.

4. Independent budget accounting

Recompute every implemented value/relation budget from final field inventories
and actual traversal. Exercise largest-valid, one-over, cycle, repeated alias,
and composed-helper paths. Any undercount, uncharged alias, or reset is
blocking.

5. Relation mutant matrix

Create a bounded external matrix for every relation, source status, currentness
boundary, equal-time expiry, basis pairing, strictness, custody subject,
retrieval sequence, qualification precedence, and terminal row.

6. Documentation liveness

Use a fence-aware structural scanner to prove:

- one B1 detailed owner;
- one bounded RW0 current-status successor;
- exactly four live normalized cross-references;
- hidden duplicates do not count;
- visible duplicates, fencing, relocation, same-title reparenting, marker/body
  splits, and leading/trailing contradictory prose reject;
- current prose distinguishes pure B1 implementation from the durable and
  executable C2B3D-plus-Section-41 boundary.

INDEPENDENT VALIDATION

Only after provenance and source/probe inspection are green enough to justify
pytest, run serial isolated validation.

For every child:

- save actual caller umask;
- create audit paths securely;
- restore caller umask before launch;
- require equal caller/child numerical umask;
- use:
  - `env -u PYTHONTRACEMALLOC -u PYTHONWARNINGS`;
  - `LC_ALL=C`, `LANG=C`;
  - `PYTHONDONTWRITEBYTECODE=1`;
  - distinct external `PYTHONPYCACHEPREFIX`, `TMPDIR`, `--basetemp`, JUnit;
  - `PYTEST_DISABLE_PLUGIN_AUTOLOAD=1`;
  - `PYTEST_ADDOPTS=''`;
  - `PYTHONHASHSEED=0`;
  - `python3 -B -m pytest -p no:cacheprovider -W error`;
  - serial execution.

Run:

A. Direct B1 and owner:

- `tests/test_rw0_b1_phase_values.py`
- `tests/test_rw0_b1_relations.py`
- `tests/test_rw0_b1_vectors.py`
- `tests/test_rw0_b1_boundaries.py`
- `tests/test_rw0_remote_contact_phase_entry_contract.py`

B. Import/public/static boundary:

- `tests/test_c2a_nonimplementation.py`
- `tests/test_runtime_non_authority.py`
- `tests/test_c2b2_development_row_value_boundaries.py`
- `tests/test_b2a_writer_session_contract.py`

C. C2A compatibility:

- `tests/test_worker_execution_semantic_values.py`
- `tests/test_worker_execution_semantic_vectors.py`
- `tests/test_worker_execution_semantic_relations.py`
- `tests/test_worker_execution_semantic_boundaries.py`
- `tests/test_c2a_relations.py`
- `tests/test_c2a_first_slice_semantic_protocol_contract.py`

D. RW0/current-status/docs:

- `tests/test_rw0_remote_contact_phase_entry_contract.py`
- `tests/test_architecture_contracts.py`
- `tests/test_remote_worker_pre_execution_planning_contract.py`
- `tests/test_autonomous_software_development_operating_model.py`

E. Complete candidate and clean HEAD collection exactly once each.

Require:

- candidate:
  4,393 nodes;
- HEAD:
  4,284 nodes;
- intersection:
  4,284;
- candidate-only:
  109;
- HEAD-only:
  0;
- candidate node-list SHA-256:
  97b1f9a90e1f458ebd6d0802dc4fc82b70e8a7f8b4d427eb04d9ad4fac06ded7;
- HEAD node-list SHA-256:
  7fb16833d1fcf8916f62ad17b0238b87b8cda8bb03432039771290bc713d12e8;
- every candidate-only node belongs to the four B1 test files or the RW0 owner
  test file;
- exact HEAD order preserved after removing 109 additions;
- no duplicate, removed, renamed, skipped, xfailed, collapsed, reparameterized,
  or collection-controlled node.

F. Full suite

If and only if source/docs/tests/probes are green, run exactly once:

`python3 -B -m pytest -p no:cacheprovider -W error --basetemp=<external> --junitxml=<external> -q .`

Require:

- 4,393 collected;
- 4,393 passed;
- zero failure/error/skip/xfail/warning;
- rc 0;
- empty stderr;
- no duplicate, ambiguous, parse-error, or unmapped JUnit case;
- equal caller/child umask;
- unchanged repository bytes.

Green validation never overrides a deterministic semantic or oracle
counterexample.

CLOSING PROVENANCE

After removing only audit-created transient artifacts, run the exact recipe
twice again.

Require exact equality with the opening final-repair target:

- branch/HEAD/upstream;
- all 17 paths/classifications/modes/sizes/SHA-256;
- tracked diff;
- canonical bytes and manifest hash;
- no repository mutation or residue.

If closing provenance differs, return:

`AUDIT_PROVENANCE_MISMATCH`

FINDING FORMAT

For each material item:

```text
ID:
Type:
Severity: critical | high | medium | low | observation
Current contract or strategic target:
Path and line:
Evidence:
Counterexample or test:
Impact:
Required correction:
Uncertainty:
Patch defect, pre-existing issue, process limitation, or report-only observation:
```

BLOCKING CLASSIFICATION

Treat as blocking:

- authority or identity collapse;
- digest treated as authenticity/permission;
- private/bearer material exposure;
- existing C2A/Section41/C2B3D/decision/global-stop contract violation;
- canonical identity/type-safety defect;
- environment-dependent integer encoding;
- graph-budget bypass;
- relation accepting contradictory current state;
- narrowing not strict to verified parent;
- retrieval/qualification bypassing current prerequisites;
- terminal semantics overclaiming C-owned proof;
- public/package/runtime/I/O widening;
- materially non-causal final tests;
- provenance or target mismatch.

Do not block solely because:

- tests-first red evidence is incomplete when independent final-byte causal
  reproduction is complete;
- exploratory implementation tests overlapped, if final serial validation and
  exact frozen provenance are independently clean;
- B2/C/D/E/ES mechanics remain unimplemented and current docs preserve that
  boundary.

VERDICT

Return exactly one:

- `ACCEPT`
- `BLOCK`
- `REJECT`
- `AUDIT_PROVENANCE_MISMATCH`

Use:

- `ACCEPT` only when no Critical, High, Medium, or Low patch defect remains;
- `BLOCK` for repairable defects;
- `REJECT` for a fundamental target/design failure requiring a new architecture
  freeze;
- `AUDIT_PROVENANCE_MISMATCH` for any target mismatch before or after
  correctness inspection.

On ACCEPT include exactly:

`COORDINATOR_RW0_B1_FIRST_AUDIT_REPAIR_ACCEPTED_READY_FOR_COMMIT_AND_PR_GATE`

Required final statements:

REPOSITORY_MUTATION_NOT_PERFORMED
REPAIR_NOT_PERFORMED
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED
REMOTE_CONTACT_NOT_PERFORMED
WORKER_OR_MODEL_NOT_INVOKED
SUPPORTING_REPOSITORIES_NOT_MODIFIED

APPENDIX A — EXACT ACCEPTED RW0-B1 RECONCILED FREEZE PACKET

The following 40,515-byte text, SHA-256 `2820b4505e9b4e6eb411fcf76597c0455b3b30dd155bd23f607d6957efa47e23`, is the exact
governing packet. The authorized repair overlay is limited to F1–F7 above.

-------------------- BEGIN EXACT PACKET --------------------

# RW0-B1 replacement implementation packet

**Verdict: `RW0_B1_SCHEMA_FREEZE_RECONCILED_READY`**

This packet replaces the preceding B1 schema inventory. It freezes private, pure values and relations over **supplied** evidence. It grants no permission and implements no contact or durable state. No subagent was needed for this finite reconciliation.

The required baseline matched at opening and closing: `trunk_dev`; HEAD `bf68a5232bff1b412c9414c076d82cab18c8e0aa`; tree `8fc05f5626bdbb01808df1698c9c2245ab06f1cb`; sole parent `1a894c5527c610ab40d8e5ae5e530a762c6e60bf`; subject `docs: freeze RW0-A phase-entry contract (#2)`; upstream `origin/trunk_dev` at `0/0`; one worktree; clean status; no Git operation, lock, or residue. No fetch was made.

## Shared value contract

All eight classes live in one private module. Each has `from_mapping(payload: dict[str, object])`, a fixed ordered `_FIELDS` tuple, immutable slots, disabled subclassing and pickling, and content-free `repr`/`str`. Every listed field is required, including nullable fields. Input mappings and collection members must have exact built-in types; mutable inputs are defensively copied. Unknown keys fail before missing keys. B1 has no JSON decoder, so duplicate object keys cannot reach `from_mapping`; any later decoder must reject them before construction.

The field notation below is exact:

| Mark | External type; stored type and validation |
| --- | --- |
| `R` | exact `str`; C2A safe ref, 1–96 ASCII characters with its existing pattern and forbidden prefixes |
| `H` | exact `str`; 64 lowercase hex characters |
| `T` | exact `str`; validated UTC second, `YYYY-MM-DDTHH:MM:SSZ` |
| `N` | exact `int`, nonnegative, **no new B1 upper bound**; use the owning C2A, row, or global-stop validator for copied fields |
| `S41N` | exact `int`, `0…2^63−1`, for the Section 41 selection revision |
| `BL` | exact `int`, positive; `selected_plan: 1…65,536` from the existing artifact binding, or `work_spec: 1…2^63−1` as an explicit **new B1 compatibility limit** for future 64-bit durable representation |
| `Q` | exact `int`, `0…2`, for the three-position retrieval sequence |
| `C` | exact `dict`; stored as defensively reconstructed exact `CeilingsV1`, using all 15 C2A field-specific nonnegative rules |
| `E` | exact `list[str]`; stored as sorted unique tuple of 1–5 existing C2A effect-class members |
| `L34` | exact `dict`; stored as reconstructed exact `CanonicalC2B3DLineage` |
| `K8` | exact list of eight exact two-item string lists; stored as the existing ordered tuple of eight `(field name, safe ref)` pairs |
| `R?`, `H?` | exact `None` or stated scalar; each nullable ref/digest pair is jointly present or jointly absent |

These distinctions follow [C2A’s validators and canonicalization](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/_worker_execution_semantic_values.py:295>), [Section 41’s K8/L34](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/_development_pre_execution_plan_disposition_contracts.py:48>), and the existing [artifact byte limit](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/_cognitive_proposal_row_values.py:768>). In particular, C2A ceilings and several row/global-stop integers do **not** have a blanket `2^63−1` bound.

For each class, `schema_id` is the fixed literal below; its digest domain is **that literal plus `.identity`**. The last field is its sole self-digest and is omitted from `identity_mapping()`. `to_mapping()` returns fresh safe built-ins in `_FIELDS` order. Canonical identity bytes are compact UTF-8 JSON with sorted object keys, `ensure_ascii=False`, `allow_nan=False`, and no Unicode normalization. The digest is `SHA256(domain UTF-8 || NUL || canonical identity bytes)`. This preserves [C2A’s byte rule](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/_worker_execution_semantic_values.py:431>); Section 41’s Unicode-normalizing helper must not encode B1 identities.

### Eight exact classes and ordered fields

**1. `RW0PhaseEntryBasisV1`**  
Schema: `governed-execution.nwp-rw0-phase-entry-basis.v1`  
Owner: Coordinator. Posture: inert no-contact input; no claim receipt or launch authority.

```text
schema_id:literal, basis_ref:R, c2b3d_lineage:L34, selection_key:K8,
selected_proposal_ref:R, selected_proposal_digest:H,
selected_artifact_ref:R, selected_artifact_digest:H,
selected_artifact_binding_digest:H, selected_plan_safe_projection_digest:H,
disposition_ref:R, disposition_digest:H,
disposition:"selected_for_dispatch_gates",
selection_head_revision:S41N, selection_head_digest:H,
current_effect_head_revision:N, current_effect_head_state:EffectHeadState,
current_effect_head_digest:H,
current_delivery_head_revision:N, current_delivery_head_state:DeliveryHeadState,
current_delivery_head_digest:H,
global_stop_ref:R, global_stop_version:N, global_stop_state:"clear"|"active",
path_scope_digest:H, basis_digest:H
```

`EffectHeadState` is exactly `ready_for_delivery|delivery_pending|delivery_outcome_unknown|observed|cancellation_effect_established|terminal`; `DeliveryHeadState` is exactly `planned|submitted|outcome_unknown|acknowledged|rejected|completed`, reused from the [existing row contract](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/_development_effect_row_values.py:162>). L34 owns the complete program/work/WorkSpec and execution lineage; K8 must be derived from it. `selection_head_digest` binds the existing head postimage, with no second selected-plan identity.

**2. `RW0AuthorityVerificationObservationV1`**  
Schema: `governed-execution.nwp-rw0-authority-verification-observation.v1`  
Owner: external verifier. Posture: safe, unauthenticated-by-B1 source claim.

```text
schema_id:literal, observation_ref:R, source_ref:R,
evidence_ref:R, evidence_digest:H,
phase_basis_ref:R, phase_basis_digest:H,
parent_grant_ref:R, parent_grant_digest:H,
grant_family_ref:R, grant_family_digest:H,
attempt_basis_ref:R, attempt_basis_digest:H,
effect_basis_ref:R, effect_basis_digest:H,
attempt_fence_ref:R, attempt_fence_digest:H,
effect_fence_ref:R, effect_fence_digest:H,
audience_ref:R, repository_ref:R,
base_git_object_format:"sha1", base_git_oid:40 lowercase hex,
path_scope_digest:H, allowed_effect_classes:E,
effect_class:one existing deliverable C2A effect class,
parent_ceilings:C,
status:"verified"|"denied"|"unknown",
family_status:"compatible"|"incompatible"|"unknown",
revocation_status:"unrevoked"|"revoked"|"unknown",
grant_expires_at:T, observed_at:T, observation_expires_at:T,
current_effect_head_digest:H, current_delivery_head_digest:H,
global_stop_ref:R, global_stop_version:N,
global_stop_state:"clear"|"active", observation_digest:H
```

Its two authorization-basis pairs are role-specific; their values need neither equal nor differ. `family_status=compatible` is the verifier’s claim, not a family fact computed from fence digests.

**3. `RW0SubordinateAuthorizationProposalV1`**  
Schema: `governed-execution.nwp-rw0-subordinate-authorization-proposal.v1`  
Owner: Coordinator. Posture: inert narrower proposal, never an issued grant or bearer.

```text
schema_id:literal, proposal_ref:R,
phase_basis_ref:R, phase_basis_digest:H,
verification_ref:R, verification_digest:H,
parent_grant_ref:R, parent_grant_digest:H,
grant_family_ref:R, grant_family_digest:H,
attempt_basis_ref:R, attempt_basis_digest:H,
effect_basis_ref:R, effect_basis_digest:H,
attempt_fence_ref:R, attempt_fence_digest:H,
effect_fence_ref:R, effect_fence_digest:H,
audience_ref:R, repository_ref:R,
base_git_object_format:"sha1", base_git_oid:40 lowercase hex,
path_scope_digest:H,
effect_class:one existing deliverable C2A effect class,
ceilings:C, expires_at:T,
global_stop_ref:R, global_stop_version:N, proposal_digest:H
```

The **observation and proposal alone** carry the family pair. Existing fences carry their parent pair and their respective authorization pair, but no family fields ([attempt and effect fence fields](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/_worker_execution_semantic_values.py:955>)).

**4. `RW0CustodyAvailabilityObservationV1`**  
Schema: `governed-execution.nwp-rw0-custody-availability-observation.v1`  
Owner: physical custodian. Posture: safe availability and asserted-byte claim.

```text
schema_id:literal, observation_ref:R, source_ref:R,
evidence_ref:R, evidence_digest:H,
phase_basis_ref:R, phase_basis_digest:H,
subject_kind:"work_spec"|"selected_plan",
subject_ref:R, subject_semantic_digest:H,
content_sha256:H, byte_length:BL,
availability:"available"|"unavailable"|"unknown",
observed_at:T, expires_at:T, observation_digest:H
```

`subject_semantic_digest` and raw-byte `content_sha256` are distinct. The selected-plan length must also equal the existing artifact-binding canonical byte length when that row is supplied. No value contains the bytes.

**5. `RW0RetrievalCapabilityEventObservationV1`**  
Schema: `governed-execution.nwp-rw0-retrieval-capability-event-observation.v1`  
Owner: issuer/custodian. Posture: source event with non-bearer correlation only.

```text
schema_id:literal, event_ref:R, source_ref:R,
evidence_ref:R, evidence_digest:H,
phase_basis_ref:R, phase_basis_digest:H,
safe_correlation_ref:R,
subject_kind:"work_spec"|"selected_plan",
subject_ref:R, subject_semantic_digest:H,
content_sha256:H, byte_length:BL,
semantic_attempt_ref:R,
attempt_fence_ref:R, attempt_fence_digest:H,
effect_intent_ref:R, effect_fence_ref:R, effect_fence_digest:H,
audience_ref:R, repository_ref:R,
base_git_object_format:"sha1", base_git_oid:40 lowercase hex,
path_scope_digest:H,
authority_observation_ref:R, authority_observation_digest:H,
subordinate_proposal_ref:R, subordinate_proposal_digest:H,
custody_observation_ref:R, custody_observation_digest:H,
event_kind:"issued"|"redeemed"|"consumed"|"expired"|"revoked"|"failed"|"unknown",
predecessor_event_ref:R?, predecessor_event_digest:H?,
sequence_number:Q, occurred_at:T, expires_at:T, event_digest:H
```

The three added pairs close the previous gap between retrieval, current verification, narrower proposal, and availability. They are safe correlations, never the capability itself.

**6. `RW0RemoteHostReadinessObservationV1`**  
Schema: `governed-execution.nwp-rw0-remote-host-readiness-observation.v1`  
Owner: host-owning source. Posture: safe profile claim, not identity or permission.

```text
schema_id:literal, observation_ref:R, source_ref:R,
evidence_ref:R, evidence_digest:H, safe_host_correlation_ref:R,
status:"ready"|"unready"|"unknown", platform:"linux",
platform_profile_ref:R, platform_profile_digest:H,
architecture_profile_ref:R, architecture_profile_digest:H,
worker_artifact_ref:R, worker_artifact_digest:H,
worker_protocol_ref:R, worker_protocol_digest:H,
execution_identity_profile_ref:R, execution_identity_profile_digest:H,
process_profile_ref:R, process_profile_digest:H,
isolation_profile_ref:R, isolation_profile_digest:H,
resource_profile_ref:R, resource_profile_digest:H,
cancellation_profile_ref:R, cancellation_profile_digest:H,
credential_handoff_profile_ref:R, credential_handoff_profile_digest:H,
capsule_store_profile_ref:R, capsule_store_profile_digest:H,
validation_tool_profile_ref:R, validation_tool_profile_digest:H,
review_tool_profile_ref:R, review_tool_profile_digest:H,
cleanup_profile_ref:R, cleanup_profile_digest:H,
observed_at:T, expires_at:T, observation_digest:H
```

Every capability dimension has an exact safe ref/digest pair. The resource profile is a source assertion whose physical limits and enforcement belong to RW0-D/E. There is **no `CeilingsV1` host capacity field** and no invented architecture enum.

**7. `RW0EffectHostQualificationV1`**  
Schema: `governed-execution.nwp-rw0-effect-host-qualification.v1`  
Owner: Coordinator. Posture: deterministic evaluation of one supplied readiness claim for one effect.

```text
schema_id:literal, qualification_ref:R,
phase_basis_ref:R, phase_basis_digest:H,
effect_intent_ref:R, effect_fence_ref:R, effect_fence_digest:H,
verification_ref:R, verification_digest:H,
readiness_ref:R, readiness_digest:H,
required_scenario_profile_ref:R, required_scenario_profile_digest:H,
required_platform_profile_ref:R, required_platform_profile_digest:H,
required_architecture_profile_ref:R, required_architecture_profile_digest:H,
required_worker_artifact_ref:R, required_worker_artifact_digest:H,
required_worker_protocol_ref:R, required_worker_protocol_digest:H,
required_execution_identity_profile_ref:R, required_execution_identity_profile_digest:H,
required_process_profile_ref:R, required_process_profile_digest:H,
required_isolation_profile_ref:R, required_isolation_profile_digest:H,
required_resource_profile_ref:R, required_resource_profile_digest:H,
required_cancellation_profile_ref:R, required_cancellation_profile_digest:H,
required_credential_handoff_profile_ref:R, required_credential_handoff_profile_digest:H,
required_capsule_store_profile_ref:R, required_capsule_store_profile_digest:H,
required_validation_tool_profile_ref:R, required_validation_tool_profile_digest:H,
required_review_tool_profile_ref:R, required_review_tool_profile_digest:H,
required_cleanup_profile_ref:R, required_cleanup_profile_digest:H,
result:"qualified"|"blocked"|"unknown",
reason:QualificationReason,
evaluated_at:T, qualification_digest:H
```

`QualificationReason` is **exactly**:

```text
qualified, readiness_unready, readiness_unknown, readiness_expired,
authority_not_verified, authority_denied_or_revoked, authority_expired,
phase_or_effect_mismatch, worker_artifact_mismatch,
worker_protocol_mismatch, platform_or_architecture_mismatch,
profile_mismatch, global_stop_active, unknown
```

The constructor enforces this closed matrix:

| Result | Permitted reason |
| --- | --- |
| `qualified` | `qualified` only |
| `unknown` | `unknown` only |
| `blocked` | the other twelve reasons only |

The relation computes one result/reason using this precedence: phase/effect mismatch; active global stop; denied/revoked authority; expired authority; unknown authority/revocation (`unknown`); incompatible or unverified family claim; expired readiness; unready readiness; unknown readiness; worker artifact; worker protocol; platform/architecture; other profile; then qualified. Equal-time expiry is expired. The result remains a check over supplied claims and does not authenticate the host.

**8. `RW0TerminalOutcomeV1`**  
Schema: `governed-execution.nwp-rw0-terminal-outcome-value.v1`  
Owner: Coordinator. Posture: proposed pure value, distinct from RW0-C’s future durable terminal fact.

```text
schema_id:literal, outcome_value_ref:R,
phase_basis_ref:R, phase_basis_digest:H,
branch:"normal"|"active_cancel_reconciled"|
  "active_cancel_unresolved"|"pre_effect_cancel_basis_unusable",
outcome:"accept"|"repair"|"replan"|"terminal_reject"|"block"|"cancel",
decision_ref:R, decision_digest:H,
decision_kind:"accept"|"repair"|"replan"|"terminal_reject"|"block"|"cancel",
program_head_revision:N, program_head_digest:H,
work_item_head_revision:N, work_item_head_digest:H,
selection_head_revision:S41N, selection_head_digest:H,
effect_head_revision:N, effect_head_digest:H,
delivery_head_revision:N, delivery_head_digest:H,
global_stop_ref:R, global_stop_version:N,
global_stop_state:"clear"|"active",
evidence_set_ref:R, evidence_set_digest:H,
latch_postimage_ref:R?, latch_postimage_digest:H?,
reconciliation_ref:R?, reconciliation_digest:H?,
mismatch_ref:R?, mismatch_digest:H?,
outcome_value_digest:H
```

The evidence-set pair binds a later C-owned set. B1 defines no evidence-member graph, completeness test, readback, or absence proof. Branch shape is closed:

| Branch | Decision → outcome | Required pair | Forbidden pairs |
| --- | --- | --- | --- |
| `normal` accept | `accept → accept` | latch postimage | reconciliation, mismatch |
| `normal` other | same-kind `repair`, `replan`, `terminal_reject`, or `block` | none | all three |
| `active_cancel_reconciled` | `cancel → cancel` | reconciliation | latch, mismatch |
| `active_cancel_unresolved` | `cancel → block` | reconciliation | latch, mismatch |
| `pre_effect_cancel_basis_unusable` | `cancel → block` | mismatch | latch, reconciliation |

A required reconciliation pair does **not** prove reconciliation complete or unresolved; a mismatch pair does **not** prove no effect/request exists; a latch pair does **not** prove atomic consumption. RW0-C owns those proofs and the durable representation, as [RW0-A specifies](</Users/ds/Repositories/Governed Execution Coordinator/.docs/rw0-remote-worker-contact-phase-entry.md:335>).

### Path-scope correlation

B1 owns **no path list or path policy**. Its four `path_scope_digest` fields use the explicit binding domain:

```text
governed-execution.nwp-rw0-current-path-scope-binding.v1.identity
```

The digest is `SHA256(domain UTF-8 || NUL || canonical JSON array of the exact supplied, validated C2A path tuple)`. Relations recompute it from the supplied `WorkSpecV1` and applicable C2A fence path ceilings, after their owning validators establish consistency. This digest is correlation only; it neither replaces WorkSpec/fence path identity nor grants permission.

Current C2A admits one exact three-path set ([C2A path validator](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/_worker_execution_semantic_values.py:370>)). That is a **current compatibility edge**. RW0-A calls the old ES path fixture stale-able and requires fresh selection before RW0-E ([RW0-A scenario](</Users/ds/Repositories/Governed Execution Coordinator/.docs/rw0-remote-worker-contact-phase-entry.md:51>)). A different future path scope needs a separately governed C2A decision; B1 must not silently widen or canonize the fixture. This B1 slice requires exact current path binding, while strict subordinate narrowing comes from effect-set reduction, a lower ceiling, or earlier expiry.

## Exact pure relations

Each function is keyword-only, returns `None` on its stated positive structural relation, and otherwise raises the content-free B1 error below. Exact supplied C2A/Section 41 values are validated by their owners. B1 compares safe identities and recomputes its **own** digests and path binding; it cannot authenticate source claims. `now_utc:T` is a caller-supplied comparison value, not proof of clock authority.

| Function; arguments in order | Exact positive relation and failure |
| --- | --- |
| `validate_phase_entry_basis(basis, lineage, selection_result, selection_head, selected_proposal, selected_artifact, work_spec, attempt_fence, author_effect_fence, author_command, author_delivery, effect_head, delivery_head, global_stop)` | Types are respectively the B1 basis; `CanonicalC2B3DLineage`; Section 41 result/head/proposal/artifact row values; `WorkSpecV1`, `AttemptFenceV1`, `EffectFenceV1`, `WorkerCommandV1`, `DeliveryEnvelopeV1`; effect/delivery-head row values; `GlobalStopCurrentRecordEnvelope`. Require exact L34/K8, selected disposition and head postimage, existing C2A authoring/delivery relations, current heads/stop, and recomputed path binding. Drift fails `relation_mismatch`, `path_scope_binding_mismatch`, or `current_head_or_global_stop_mismatch`. |
| `validate_authority_observation(basis, observation, attempt_fence, author_effect_fence, current_effect_fence, author_command, capsule_manifest: CandidateCapsuleManifestV1\|None, cancellation_target: EffectFenceV1\|None, now_utc)` | Require `verified`, `compatible`, `unrevoked`; `observed_at ≤ now < observation_expires_at`, `now < grant_expires_at`, and `now` before both applicable fence expiries; exact parent, fence, audience, repository, base, effect, ceilings, heads/stop, and path binding. Use the existing C2A effect relation for a later current effect. Denial/revocation, expiry, scope, head, and path failures retain distinct reasons. This validates a verifier **claim**. |
| `validate_per_fence_basis(observation, proposal, attempt_fence, current_effect_fence)` | Each observation and proposal authorization pair equals its **corresponding** persisted fence pair and each fence ref/digest. Failure: `per_fence_basis_mismatch`. No cross-pair equality or inequality rule. |
| `validate_external_common_family_claim(observation, proposal, attempt_fence, current_effect_fence)` | Observation says `family_status=compatible`; observation/proposal family pairs agree; their parent pairs agree with both fences’ **existing parent-standing-grant** pairs; each role-specific basis pair agrees with its fence. Failure: `common_family_unverified` or `per_fence_basis_mismatch`. **Neither fence is said to store a family pair.** This function cannot independently prove ancestry. |
| `validate_subordinate_narrowing(basis, observation, proposal, attempt_fence, current_effect_fence, now_utc)` | Require the preceding exact basis/family/current authority conditions; same phase, audience, repository, base, stop, parent and path binding; proposed single effect within the observed effect set; every proposal ceiling ≤ parent and both applicable fence ceilings; proposal expiry ≤ parent and both fences. Require at least one *strict* effect-set, ceiling, or expiry reduction. Failure: `scope_or_ceiling_mismatch`, `common_family_unverified`, `per_fence_basis_mismatch`, or freshness/authority reason. |
| `validate_custody_binding(basis, availability, subject, now_utc)` | `subject` is exactly one `WorkSpecV1` or `DevelopmentPrivateProposalArtifactBindingRowValue`, selected by `subject_kind`. Exact semantic ref/digest and phase binding; selected-plan byte length also equals the artifact row’s canonical byte length; observation is `available` and `observed_at ≤ now < expires_at`. `content_sha256` remains a custodian assertion until physical byte verification. Failure: `custody_subject_mismatch` or `observation_stale_or_expired`. |
| `validate_retrieval_event_sequence(basis, availability, observation, proposal, events, attempt_fence, current_effect_fence, now_utc)` | `events` is an exact tuple of 1–3 exact event values. Every event binds the three observation/proposal/custody pairs, subject semantic and asserted-byte pairs, attempt/effect/fences, audience/repository/base/path digest, and one non-bearer correlation. Sequence numbers start at zero and are contiguous; predecessor pairs and nondecreasing times match. Permitted prefixes are `issued` or `issued→redeemed`; successful consumption is only `issued→redeemed→consumed`. `expired|revoked|failed|unknown` may terminate an issued or redeemed prefix; a singleton terminal failure/unknown is diagnostic only. Issuance/redemption/consumption require live custody, verification, proposal, grant, and fence windows; an `expired` event may be recorded at or after its expiry. Unknown, failure, expiry, or revocation never permits reuse. Failure: `retrieval_transition_invalid`, `custody_subject_mismatch`, path, or freshness reason. |
| `validate_host_qualification(basis, authority, readiness, qualification, current_effect_fence, now_utc)` | One exact readiness claim and one exact authority observation; phase/effect/fence/current stop exact; readiness fresh; all required safe profile **pairs** equal; `platform=linux`; recomputed current fence path binding equals the authority/basis binding. The closed precedence above determines the claimed `result/reason`. Failure: `qualification_reason_mismatch`, `readiness_profile_mismatch`, or freshness/path reason. No physical-capacity comparison is made. |
| `validate_terminal_outcome_binding(basis, outcome, decision, program_head, work_head, selection_head, effect_head, delivery_head, global_stop)` | Supplied types are the B1 basis/outcome, `DevelopmentDecisionRowValue`, the five existing head row values, and `GlobalStopCurrentRecordEnvelope`. Require exact phase pair, earlier decision ref/digest/kind, current head revisions/digests and stop; dispatch to the appropriate shape validator below. Failure: `terminal_branch_mismatch` or `current_head_or_global_stop_mismatch`. The evidence-set pair is bound, not expanded. |
| `validate_normal_outcome_shape(outcome, decision)` | Only the two `normal` rows in the branch table; same-kind prior non-cancel decision and required/forbidden optional pairs. |
| `validate_reconciled_cancel_outcome_shape(outcome, decision)` | Only `cancel→cancel` with reconciliation pair; no assertion of completeness. |
| `validate_unresolved_cancel_outcome_shape(outcome, decision)` | Only `cancel→block` with reconciliation pair; no assertion that reconciliation is actually unresolved. |
| `validate_unusable_cancel_basis_outcome_shape(outcome, decision)` | Only `cancel→block` with mismatch pair; no assertion of effect/request absence. |

The four shape validators fail `terminal_branch_mismatch`. They compare a supplied existing decision; they do not create one. RW0-C must prove the evidence set, latch transaction, cancellation reconciliation, and presence or absence of effects/requests by guarded readback. The [existing decision row](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/_development_decision_row_values.py:35>) has no latch-postimage field.

### Work budgets

A *B1 traversal unit* is one value or collection-container occurrence, or one field/member occurrence, charged **before** descent. An active-object set rejects cycles; aliases in a shared DAG are charged again at every occurrence. Exact external C2A/Section 41/row arguments are one B1 leaf apiece and are separately reconstructed by their owning bounded validators. A relation uses **one shared B1 budget for its entire invocation**, including called B1 shape checks. No aggregate B1 schema or unsupported whole-graph construction budget is introduced.

`V = 1 + field count + maximum B1-owned nested occurrences`; constructor/reconstruction budget is `2V` for validation and defensive copy:

| Value | Field count | Nested addition | `V` | Per-value construction/reconstruction |
| --- | ---: | ---: | ---: | ---: |
| Phase basis | 26 | L34 `35` + K8 `25` | 87 | **174** |
| Authority observation | 39 | Ceilings `16` + effect set `6` | 62 | **124** |
| Subordinate proposal | 29 | Ceilings `16` | 46 | **92** |
| Custody observation | 16 | 0 | 17 | **34** |
| Retrieval event | 37 | 0 | 38 | **76** |
| Host readiness | 39 | 0 | 40 | **80** |
| Host qualification | 45 | 0 | 46 | **92** |
| Terminal value | 31 | 0 | 32 | **64** |

The fixed maximum nested additions use L34’s 34 fields, K8’s eight pair occurrences, C2A’s 15 ceiling fields, and the five-member effect set. Profile ref/digest fields and the terminal evidence-set pair are scalar; they add no hidden collection.

Per-relation B1 traversal maxima, derived from the argument inventories above, are:

| Relation | Exact formula | Limit |
| --- | --- | ---: |
| Phase basis | `87 + 13 external leaves + 4 current-path occurrences` | **104** |
| Authority observation | `87 + 62 + 6 external leaves + 1 time + 4 path + 30 external ceiling members + 6 external effect-set occurrences` | **196** |
| Per-fence basis | `62 + 46 + 2 external leaves` | **110** |
| External common-family claim | `62 + 46 + 2 external leaves` | **110** |
| Subordinate narrowing | `87 + 62 + 46 + 2 external leaves + 1 time + 8 two-path tuples + 30 external ceiling members + 6 effect-set occurrences` | **242** |
| Custody binding | `87 + 17 + 1 subject leaf + 1 time` | **106** |
| Retrieval sequence | `87 + 17 + 62 + 46 + 3×38 events + 1 sequence container + 2 fence leaves + 1 time + 8 two-path tuples` | **338** |
| Host qualification | `87 + 62 + 40 + 46 + 1 fence leaf + 1 time + 4 path` | **241** |
| Terminal binding, including one dispatched shape check | `87 + 32 + 7 head/decision/stop leaves + (32 + 1 decision leaf)` | **159** |
| Each standalone branch-shape check | `32 + 1 decision leaf` | **33** |

The four-path/two-path terms describe traversal of **currently validated C2A tuples**, not a B1 fixture-path grammar. If C2A changes that cardinality, B1 budgets require a separate review. Tests pin every literal and formula, largest-valid inputs, one-over-limit inputs, cycles, and compact shared-DAG expansion. Called B1 helpers share the caller budget; they do not reset it.

### Content-free error algebra

`RW0PhaseValueError` is sealed; its `reason` is one of the following exact strings. Messages contain only the reason and a fixed field label, never a supplied value, private material, or chained foreign exception:

```text
invalid_field_type, missing_field, unknown_field, duplicate_field,
invalid_enum, malformed_ref, malformed_digest,
invalid_timestamp_window, invalid_length_or_cardinality,
graph_cycle, cumulative_work_exhausted, relation_mismatch,
observation_stale_or_expired, authority_denied_or_revoked,
per_fence_basis_mismatch, common_family_unverified,
scope_or_ceiling_mismatch, path_scope_binding_mismatch,
current_head_or_global_stop_mismatch, custody_subject_mismatch,
retrieval_transition_invalid, readiness_profile_mismatch,
qualification_reason_mismatch, terminal_branch_mismatch,
privacy_forbidden_material
```

`duplicate_field` is reserved for a future duplicate-aware decoder; none is added in B1. Invalid qualification enum/matrix maps to `invalid_enum`/`qualification_reason_mismatch`. Unknown, denied, revoked, stale, expired, mismatched, or ambiguous source facts fail the relevant progression relation. No valid digest is treated as authenticity or permission.

## Reuse, consumers, and exclusions

B1 **stores** one reconstructed `CanonicalC2B3DLineage` and K8 in its basis, and `CeilingsV1` only in the authority observation and subordinate proposal. It stores safe ref/digest projections of the existing WorkSpec, selected proposal/artifact, disposition, selection head, attempt, candidate, effect, command, fences, delivery, current heads, and stop. It merely **validates supplied** `WorkSpecV1`, `AttemptFenceV1`, `EffectFenceV1`, `WorkerCommandV1`, `DeliveryEnvelopeV1`, later `CandidateCapsuleManifestV1` and its `CapsuleEntryV1` values, `WorkerObservationV1` where its closed grammar applies, Section 41 rows, and the C2B decision/head rows. No existing identity is reissued; no C2A source, observation, or effect enum changes.

B1’s permitted production consumers in this tranche are **none**; direct tests import the private module. Separately governed RW0-C and later B2/D code may become consumers. Package root, StateStore, WriterSession, Bridge, ES, adapters, workers, model/provider clients, and public APIs are prohibited consumers in B1.

B2 retains framing, terminal-result wire grammar, process/stderr/transport limits, and Codex CLI-versus-App-Server selection. RW0-C retains SQLite rows, receipts, evidence-member graph, writer operations, readback/recovery, latch representation and atomicity, and durable terminal fact. RW0-D retains physical custody and bearer handling, subprocess/supervisor/worker, capsule and offline proof; RW0-E retains live-host proof. ES retains its route admission/runtime/reliable-submit authority. External standing policy, verifier, host owner, and custodian retain their own facts and authenticity. B1 imports no I/O or runtime component.

The module is [src/ge_nwp_coordinator/_rw0_phase_entry_semantic_values.py](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/_rw0_phase_entry_semantic_values.py>): docstring; standard-library `datetime`, `hashlib`, `json`, `re`, `typing`; exact private C2A, Section 41, and row-value imports; empty `__all__: tuple[str, ...] = ()`; schema/domain/field/reason constants; one local sealed error and bounded canonical/clone helpers; eight values in the order above; then relations. Use the existing immutable slotted-value idiom. One new production module has no duplicated security-critical algorithm requiring a shared helper. Existing C2A source, schemas, domains, vectors, and enums remain byte-identical.

## Future touched surface and checks

The **exact maximum implementation allowlist** is these sixteen paths:

```text
/Users/ds/Repositories/Governed Execution Coordinator/.docs/rw0-b1-pure-phase-values.md
/Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/_rw0_phase_entry_semantic_values.py
/Users/ds/Repositories/Governed Execution Coordinator/tests/test_rw0_b1_phase_values.py
/Users/ds/Repositories/Governed Execution Coordinator/tests/test_rw0_b1_relations.py
/Users/ds/Repositories/Governed Execution Coordinator/tests/test_rw0_b1_vectors.py
/Users/ds/Repositories/Governed Execution Coordinator/tests/test_rw0_b1_boundaries.py
/Users/ds/Repositories/Governed Execution Coordinator/tests/test_c2a_nonimplementation.py
/Users/ds/Repositories/Governed Execution Coordinator/tests/test_runtime_non_authority.py
/Users/ds/Repositories/Governed Execution Coordinator/.docs/rw0-remote-worker-contact-phase-entry.md
/Users/ds/Repositories/Governed Execution Coordinator/.docs/authority-boundaries.md
/Users/ds/Repositories/Governed Execution Coordinator/.docs/autonomous-software-development-operating-model.md
/Users/ds/Repositories/Governed Execution Coordinator/.docs/durable-state-model.md
/Users/ds/Repositories/Governed Execution Coordinator/.docs/worker-execution-boundary.md
/Users/ds/Repositories/Governed Execution Coordinator/tests/test_rw0_remote_contact_phase_entry_contract.py
/Users/ds/Repositories/Governed Execution Coordinator/tests/test_architecture_contracts.py
/Users/ds/Repositories/Governed Execution Coordinator/tests/test_remote_worker_pre_execution_planning_contract.py
```

The RW0 owner’s current-status paragraph must acknowledge B1 while retaining its strategic-target and no-runtime boundary. In all four cross-references, replace the stale current-implementation sentence with the **same normalized text**:

> A private no-I/O RW0-B1 semantic value and relation layer is now implemented. No phase-entry persistence, verifier authenticity, custody, transport, process, worker, terminal-outcome runtime, latch, Git, ES route, service, scheduler, queue, or autonomous loop is implemented. The durable and executable boundary remains private C2B3D planned author delivery plus Section 41 pre-execution selection.

Preserve their complete four-document map, headings, markers, adjacency, and hostile-mutation checks. The old sentence is pinned twice in the [direct RW0 test](</Users/ds/Repositories/Governed Execution Coordinator/tests/test_rw0_remote_contact_phase_entry_contract.py:369>); [architecture](</Users/ds/Repositories/Governed Execution Coordinator/tests/test_architecture_contracts.py:287>) and [Section 41 cross-reference tests](</Users/ds/Repositories/Governed Execution Coordinator/tests/test_remote_worker_pre_execution_planning_contract.py:4510>) also own the normalized map and should assert the corrected status. The two [source inventory](</Users/ds/Repositories/Governed Execution Coordinator/tests/test_c2a_nonimplementation.py:22>) and [public-boundary inventory](</Users/ds/Repositories/Governed Execution Coordinator/tests/test_runtime_non_authority.py:22>) tests must account for the single new private module.

Everything outside the allowlist remains byte-identical. Especially protected are [C2A source](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/_worker_execution_semantic_values.py>), [C2A governing contract](</Users/ds/Repositories/Governed Execution Coordinator/.docs/c2a-first-slice-semantic-protocol-contract.md>), [C2A vector support](</Users/ds/Repositories/Governed Execution Coordinator/tests/c2a_contract_support.py>), [Section 41 selection source](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/_development_pre_execution_plan_disposition_contracts.py>), migrations `0001_initial.sql`, `0002_development_program_and_effect_state.sql`, `0003_cognitive_proposal_and_selection_state.sql`, application generation, [package root](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/__init__.py>), [StateStore](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/state_store.py>), [WriterSession](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/sqlite_writer_session.py>), schema files, and [pyproject.toml](</Users/ds/Repositories/Governed Execution Coordinator/pyproject.toml>). No AGENTS.md, README, SQL, migration, package export, fixture, script, configuration, or supporting-repository change is authorized by this packet.

### Future validation procedure — not run here

Collect node IDs **before** implementation and again afterward. Require `before − after = ∅`, `after − before` to equal exactly the nodes in the four new B1 test files, and the count increase to equal that set’s size. Do not invent a count before collection. Keep all test and cache artifacts outside the repository:

```sh
mkdir -p /tmp/rw0-b1-tmp /tmp/rw0-b1-cache
export PYTHONDONTWRITEBYTECODE=1 PYTEST_DISABLE_PLUGIN_AUTOLOAD=1
export TMPDIR=/tmp/rw0-b1-tmp XDG_CACHE_HOME=/tmp/rw0-b1-cache
python -m pytest -p no:cacheprovider --basetemp=/tmp/rw0-b1-collect-before --collect-only -q tests > /tmp/rw0-b1-before.nodes

# After implementation:
python -m pytest -p no:cacheprovider --basetemp=/tmp/rw0-b1-collect-after --collect-only -q tests > /tmp/rw0-b1-after.nodes
python -m pytest -p no:cacheprovider --basetemp=/tmp/rw0-b1-values -q tests/test_rw0_b1_phase_values.py
python -m pytest -p no:cacheprovider --basetemp=/tmp/rw0-b1-relations -q tests/test_rw0_b1_relations.py
python -m pytest -p no:cacheprovider --basetemp=/tmp/rw0-b1-vectors -q tests/test_rw0_b1_vectors.py
python -m pytest -p no:cacheprovider --basetemp=/tmp/rw0-b1-boundaries -q tests/test_rw0_b1_boundaries.py
python -m pytest -p no:cacheprovider --basetemp=/tmp/rw0-b1-inventories -q tests/test_c2a_nonimplementation.py tests/test_runtime_non_authority.py
python -m pytest -p no:cacheprovider --basetemp=/tmp/rw0-b1-c2a -q tests/test_worker_execution_semantic_values.py tests/test_worker_execution_semantic_vectors.py tests/test_worker_execution_semantic_relations.py tests/test_worker_execution_semantic_boundaries.py tests/test_c2a_relations.py
python -m pytest -p no:cacheprovider --basetemp=/tmp/rw0-b1-docs -q tests/test_rw0_remote_contact_phase_entry_contract.py tests/test_architecture_contracts.py tests/test_remote_worker_pre_execution_planning_contract.py
python -m pytest -p no:cacheprovider --basetemp=/tmp/rw0-b1-full -q tests
git diff --check
git status --porcelain=v1 --untracked-files=all
```

The four new files must cover literal independently calculated identity vectors, path binding from supplied C2A values, equal and unequal valid fence-basis pairs, source-claim limits, strict narrowing, retrieval triple binding and every legal/illegal transition, the finite qualification matrix and precedence, all five terminal rows, exact types/subclasses/`bool`, optional-pair symmetry, privacy and error chains, each budget’s largest valid and one-over case, cycles, shared-DAG occurrence charging, no-I/O AST/imports, and no public/package-root export. Use causal one-field mutants. Compare protected-file hashes, the sixteen-path diff, node delta, temporary-artifact locations, and final Git status. Obtain fresh independent audits of authority/privacy, identity/non-collapse, relation/budget correctness, test adequacy, public boundary/artifact hygiene, and provenance.

Reject these alternatives explicitly: family fields on existing fences; a digest-derived ancestry proof; host `CeilingsV1` capacity; a B1-owned three-path fixture grammar; retrieval events without the proposal or custody pair; a generic terminal evidence-member list or B1 absence/atomicity proof; one unenforceable whole-graph budget; regex-open qualification reasons; blanket C2A integer caps; a second selected-plan or execution identity; and a source or path outside the allowlist. Stop implementation if any such change is needed, if private/bearer material enters a value, if authenticity is inferred from a digest, if C2A identities/vectors/enums must change, or if B2, SQLite, I/O, runtime, ES, Bridge, or public API work becomes necessary.

REPOSITORY_MUTATION_NOT_PERFORMED  
TESTS_NOT_RUN  
STAGING_NOT_PERFORMED  
COMMIT_NOT_PERFORMED  
PUSH_NOT_PERFORMED  
PR_NOT_CREATED  
REMOTE_CONTACT_NOT_PERFORMED  
WORKER_OR_MODEL_NOT_INVOKED  
SUPPORTING_REPOSITORIES_NOT_MODIFIED

--------------------- END EXACT PACKET ---------------------
