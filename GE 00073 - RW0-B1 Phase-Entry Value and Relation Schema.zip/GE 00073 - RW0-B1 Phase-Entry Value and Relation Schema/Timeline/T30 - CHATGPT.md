## Verdict

**The audit’s `BLOCK` is valid. Return to the existing RW0-B1 implementation conversation for a narrowly bounded repair. Do not start another design/reconnaissance pass, and do not stage or commit.**

These are two different defects:

- **RW0-B1-01 is an implementation defect.** The constructor claims bounded `2V` work, but the common mapping helper can scan arbitrarily many caller keys before that bound exists.
- **RW0-B1-02 is a test-causality defect.** The underlying K8 privacy behavior may already be correct, but the checked-in test cannot prove it because L34 rejects first.

Neither finding reopens B1’s role. It remains a private, pure value-and-relation layer over supplied evidence; it grants no permission and implements no contact or durable state. 

## Engineering decisions

### 1. Bound the key scan without changing any budget literal

The repair must happen in the shared closed-mapping path used by all eight classes.

The correct sequence is:

1. Require an exact built-in `dict`.
2. Use `len(payload)` before any key iteration, sorting, set conversion, copying, or materialization.
3. When the mapping contains more entries than the class has fields, immediately raise content-free `unknown_field`.
4. Otherwise scan no more than the fixed field count.
5. Preserve:
   - unknown-before-missing precedence;
   - exact key-type checking;
   - the existing `2V` construction limit;
   - every valid canonical identity and digest.

The shared contract already requires exact built-in inputs and unknown keys to fail before missing keys.  The budget contract defines construction as bounded validation plus defensive reconstruction, charges occurrences before descent, and requires aliases not to become free. 

A superficial fix that still iterates all 1,000 keys and only later consults a budget is not acceptable.

### 2. Separate K8 privacy from L34 privacy

The corrected test structure is:

```text
K8-only mutant:
  change one selection_key ref
  leave L34 unchanged
  reseal only the outer basis digest
  require privacy_forbidden_material

L34-only mutant:
  leave K8 unchanged
  change one L34 ref
  reseal L34 and then the outer basis digest
  require privacy_forbidden_material
```

The literal K8 coordinate inventory is:

```text
program_ref
semantic_attempt_ref
candidate_ref
effect_intent_ref
author_command_ref
attempt_fence_ref
effect_fence_ref
delivery_attempt_ref
```

The K8-only cases are decisive: if K8 privacy validation is bypassed, they must no longer receive `privacy_forbidden_material` from an earlier L34 failure.

This is a test repair, not a reason to change K8, L34, field order, digest domains, or relation semantics.

## Repair scope

Only these four paths may change:

```text
.docs/rw0-b1-pure-phase-values.md
src/ge_nwp_coordinator/_rw0_phase_entry_semantic_values.py
tests/test_rw0_b1_phase_values.py
tests/test_rw0_b1_boundaries.py
```

The candidate must remain:

```text
17 dirty paths
11 tracked modifications
6 untracked files
0 staged
0 unmerged
```

The other thirteen candidate paths remain byte-identical. No budget literal, schema, enum, error reason, relation, public surface, dependency, migration, or production consumer may change.

The repair prompt also distinguishes the expected pre-repair evidence correctly:

- the construction-order test should fail against the opening source;
- the corrected K8-only and L34-only runtime tests may already pass, because their finding concerns causality rather than a known source false acceptance;
- the report must not mislabel those already-green privacy cases as causal red evidence.

## Next action

Send this prompt to the **existing write-enabled RW0-B1 implementation conversation**:

:chatgpt-content-reference{index="3"}

The successful closeout token is:

```text
COORDINATOR_RW0_B1_FOURTH_AUDIT_FINDINGS_REPAIRED_READY_FOR_FRESH_REAUDIT
```

After any byte change, the candidate needs new validation, repeated provenance, and another fresh read-only audit before a commit gate. That is the defined repair lifecycle.  Provenance must again bind the implementation and auditor to the same tracked and untracked bytes; it does not itself establish correctness. 

### Sources

- Reconciled RW0-B1 contract and non-authority boundary. 
- Exact construction and relation work-budget contract. 
- Independent-audit-to-repair lifecycle. 
- Provenance closeout and audit requirements. 
- Codex audit response supplied in this turn.

**Confidence:** 99% that both findings are real; 98% that the four-path repair is sufficient; 97% that no architecture or schema refreeze is needed.
