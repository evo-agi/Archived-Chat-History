This was a **stale-prompt mismatch**, not repository drift.

The current **17-path state is the intended baseline**:

```text
17 dirty paths
11 tracked modifications
6 untracked files
0 staged
0 unmerged
```

`tests/test_c2b2_development_row_value_boundaries.py` is not an unexpected path. It became the accepted seventeenth path during the earlier implementation-scope expansion, where it recorded the B1 module’s exact private row-value-provider imports. In this repair it must remain **present and byte-identical**, but it is not one of the four paths authorized for further editing.

Do **not** restore the candidate to 16 paths. That would discard accepted candidate bytes and invalidate the current provenance chain. The stop occurred before mutation, so no repository recovery is needed.

I inspected the prompt artifact generated in the previous turn: it already specified `17 / 11 / 6`. The Codex response therefore acted on an older 16-path condition—whether from a stale prompt copy or earlier conversation context. The replacement below now begins with an explicit supersession notice forbidding that interpretation.

Send this complete replacement to the **same RW0-B1 implementation conversation**:

:chatgpt-content-reference{index="2"}

It explicitly states:

```text
- all earlier 16-path conditions are stale;
- preserve the row-value-boundary test;
- do not revert, restore, or restart from HEAD;
- reproduce the pinned 17-path manifest before editing;
- only the four stated repair paths may change;
- the other thirteen candidate entries remain byte-identical.
```

The expected successful closeout remains:

```text
COORDINATOR_RW0_B1_SECOND_REAUDIT_FINDINGS_REPAIRED_READY_FOR_FRESH_REAUDIT
```

The underlying B1 scope remains unchanged: private pure values and relations over supplied evidence, with no permission, contact, or durable-state implementation.  The repair lifecycle also requires returning to the write-enabled implementation conversation, producing new validation and provenance, and then conducting another fresh independent audit. 

**Confidence:** 100% that the 17-path state is the correct intended baseline; 99% that this explicit supersession will remove the stale-opening ambiguity.
