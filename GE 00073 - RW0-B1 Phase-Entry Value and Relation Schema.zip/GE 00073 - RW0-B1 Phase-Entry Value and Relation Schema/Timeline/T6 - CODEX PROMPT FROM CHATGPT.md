TITLE

Coordinator RW0-B1 — implement private pure phase-entry semantic values and
relations

ENGAGEMENT TYPE

Parent-only workspace-write implementation of the immediately preceding
read-only packet:

RW0_B1_SCHEMA_FREEZE_RECONCILED_READY

This is one bounded implementation tranche in the Coordinator repository.
The preceding replacement packet is the governing schema and relation freeze,
subject only to the finite implementation clarifications in this prompt.

Do not create or resume subagents. You are the sole repository writer.

This engagement authorizes:

- creating one local feature branch from the exact baseline;
- editing or creating only the exact sixteen allowlisted paths below;
- running isolated local validation;
- creating external implementation evidence and exact patch provenance.

This engagement does not authorize:

- staging, commit, push, PR creation, merge, tag, release, or deployment;
- remote contact or fetch;
- changes to supporting repositories;
- installation or dependency changes;
- SQLite, migration, filesystem, subprocess, network, provider/model, Bridge,
  ES, worker, adapter, service, queue, scheduler, or public API behavior;
- an independent audit.

REPOSITORY

/Users/ds/Repositories/Governed Execution Coordinator/

OPENING BASELINE

Require exactly before branch creation or mutation:

- physical root:
  /Users/ds/Repositories/Governed Execution Coordinator/
- branch:
  trunk_dev
- HEAD:
  bf68a5232bff1b412c9414c076d82cab18c8e0aa
- tree:
  8fc05f5626bdbb01808df1698c9c2245ab06f1cb
- sole parent:
  1a894c5527c610ab40d8e5ae5e530a762c6e60bf
- subject:
  docs: freeze RW0-A phase-entry contract (#2)
- upstream:
  origin/trunk_dev
- ahead/behind:
  0/0
- worktrees:
  1
- worktree/index/untracked/unmerged:
  clean
- no Git operation or lock
- no repository residue

Do not fetch. Stop without mutation on any mismatch.

FEATURE BRANCH

Require that no local branch named:

codex/rw0-b1-pure-phase-values-v1

already exists.

Create exactly that local branch from the baseline and set its upstream to the
existing local remote-tracking ref `origin/trunk_dev` without contacting the
remote.

After branch creation require:

- branch:
  codex/rw0-b1-pure-phase-values-v1
- HEAD remains the exact baseline commit;
- upstream:
  origin/trunk_dev
- ahead/behind:
  0/0
- clean state.

OBJECTIVE

Implement the reconciled RW0-B1 packet exactly:

- one new private standard-library-only no-I/O module;
- eight immutable closed-world value classes;
- content-free bounded construction and relation validation;
- exact canonical identity bytes and domain-separated SHA-256 digests;
- pure relations over supplied C2A, C2B3D, Section 41, row, head, decision,
  and global-stop values;
- no source observation promoted into authority;
- no new selected-plan, WorkSpec, attempt, candidate, effect, command, fence,
  delivery, or durable-terminal identity;
- bounded current-status documentation that says B1 pure semantics are current
  while persistence and all executable/runtime capability remain absent.

CURRENT VERSUS TARGET

Current baseline remains:

- C2A/C2A1 private pure values and six relations;
- private C2B2 values/readers;
- private VS1B genesis;
- private C2B3D inert author-effect establishment and planned initial delivery;
- private Section 41 pre-execution selection;
- application generation 2, migration tip 0003;
- no phase-entry persistence, external-verifier authenticity, custody runtime,
  host qualification runtime, transport, worker, terminal-outcome runtime,
  latch, Git, ES route, service, queue, scheduler, or autonomous loop.

RW0-B1 adds only private pure semantic values and relations. It is not a
runtime, permission issuer, persistence surface, wire protocol, or public API.

GOVERNING RECONCILED PACKET

Implement the exact eight classes, ordered fields, schema IDs, digest domains,
types, enums, optional-pair rules, path-scope binding, relation names, branch
rules, work-budget literals/formulas, error algebra, module ordering, status
wording, tests, exclusions, and protected surfaces from the immediately
preceding `RW0_B1_SCHEMA_FREEZE_RECONCILED_READY` response.

Do not silently redesign that packet. If source inspection proves an exact
frozen field, type, bound, relation, or budget impossible without widening the
contract, stop and report the conflict before improvising.

FINITE IMPLEMENTATION CLARIFICATIONS

These clarify ambiguities without reopening the freeze.

1. Qualification result/reason mapping

Use this exact precedence and pair:

- phase/effect/fence mismatch
  -> `blocked / phase_or_effect_mismatch`
- active global stop
  -> `blocked / global_stop_active`
- authority status `denied` or revocation status `revoked`
  -> `blocked / authority_denied_or_revoked`
- expired authority/grant/observation window
  -> `blocked / authority_expired`
- authority status `unknown` or revocation status `unknown`
  -> `unknown / unknown`
- family status `incompatible` or `unknown`, or common-family claim not
  structurally established
  -> `blocked / authority_not_verified`
- expired readiness
  -> `blocked / readiness_expired`
- readiness status `unready`
  -> `blocked / readiness_unready`
- readiness status `unknown`
  -> `blocked / readiness_unknown`
- worker artifact mismatch
  -> `blocked / worker_artifact_mismatch`
- worker protocol mismatch
  -> `blocked / worker_protocol_mismatch`
- platform or architecture profile mismatch
  -> `blocked / platform_or_architecture_mismatch`
- any remaining required profile-pair mismatch
  -> `blocked / profile_mismatch`
- otherwise
  -> `qualified / qualified`

The constructor matrix remains:

- `qualified` permits only `qualified`;
- `unknown` permits only `unknown`;
- `blocked` permits exactly the twelve blocking reasons from the packet.

2. Scenario profile pair

`required_scenario_profile_ref/digest` is a Coordinator-owned evaluation-context
binding. It is included in qualification identity and later durable correlation,
but is not a host-authored readiness claim and has no readiness counterpart in
B1. Do not infer or authenticate scenario content from the digest. If an exact
scenario-profile value class is required to make qualification correct, stop;
that would reopen the schema freeze.

3. Constructor error mapping

Use these exact mappings where the packet did not spell out the constructor
case:

- wrong external type or subclass: `invalid_field_type`;
- missing key: `missing_field`;
- unknown key: `unknown_field`;
- wrong fixed literal or finite enum: `invalid_enum`;
- safe-ref syntax failure: `malformed_ref`;
- SHA/base-object syntax failure: `malformed_digest`;
- syntactically valid but incorrect self-digest: `relation_mismatch`;
- timestamp syntax, ordering, or window failure:
  `invalid_timestamp_window`;
- negative/out-of-range integer, collection count, or optional-pair asymmetry:
  `invalid_length_or_cardinality`;
- cycle: `graph_cycle`;
- work limit: `cumulative_work_exhausted`;
- forbidden private/bearer shape or known private-material input:
  `privacy_forbidden_material`.

Do not add an unreviewed new error reason.

4. Work-budget implementation

Use the exact per-value and per-relation literals and formulas in the packet.
Implement internal traversal so called helpers share one budget and do not
re-traverse an argument without charging it.

In the formulas, the wording `8 two-path tuples` means eight traversal
occurrences from two current three-member C2A path tuples, each charged as one
container plus three members. It does not mean eight distinct path tuples.

If a faithful single-pass implementation of the frozen final fields requires a
larger budget than a frozen literal, stop and report the exact undercount; do not
silently change the contract.

EXACT MAXIMUM TOUCHED-FILE ALLOWLIST

Exactly these sixteen paths may differ from HEAD:

1. `.docs/rw0-b1-pure-phase-values.md` — new governing owner
2. `src/ge_nwp_coordinator/_rw0_phase_entry_semantic_values.py` — new private source
3. `tests/test_rw0_b1_phase_values.py` — new
4. `tests/test_rw0_b1_relations.py` — new
5. `tests/test_rw0_b1_vectors.py` — new
6. `tests/test_rw0_b1_boundaries.py` — new
7. `tests/test_c2a_nonimplementation.py`
8. `tests/test_runtime_non_authority.py`
9. `.docs/rw0-remote-worker-contact-phase-entry.md`
10. `.docs/authority-boundaries.md`
11. `.docs/autonomous-software-development-operating-model.md`
12. `.docs/durable-state-model.md`
13. `.docs/worker-execution-boundary.md`
14. `tests/test_rw0_remote_contact_phase_entry_contract.py`
15. `tests/test_architecture_contracts.py`
16. `tests/test_remote_worker_pre_execution_planning_contract.py`

Expected classifications at closeout:

- six new untracked regular files:
  - governing doc;
  - private source;
  - four direct test files;
- ten tracked modifications;
- no staged or unmerged path;
- all regular mode `0644` unless an opening tracked file already has a more
  restrictive safe working-tree mode, which must remain unchanged;
- no addition/deletion/rename/copy/mode change in Git.

Stop if any seventeenth path must change.

EXPLICITLY PROTECTED

Require byte identity with HEAD for everything outside the allowlist,
particularly:

- `src/ge_nwp_coordinator/_worker_execution_semantic_values.py`;
- `.docs/c2a-first-slice-semantic-protocol-contract.md`;
- `.docs/c2a1-pure-semantic-values.md`;
- `tests/c2a_contract_support.py`;
- existing C2A vector identities and all source/observation/effect enums;
- `src/ge_nwp_coordinator/_development_pre_execution_plan_disposition_contracts.py`;
- Section 41 row/semantic/runtime modules;
- migrations 0001, 0002, and 0003;
- migration catalog and application generation;
- `src/ge_nwp_coordinator/__init__.py`;
- `state_store.py` and public `WriterSession` surfaces;
- schemas, fixtures, scripts, config, `pyproject.toml`, `.gitignore`;
- AGENTS.md and README.md;
- all supporting repositories.

SOURCE REQUIREMENTS

The new module must:

- have empty `__all__: tuple[str, ...] = ()`;
- use only the standard library and exact private pure Coordinator modules
  named by the packet;
- contain no filesystem, SQLite, subprocess, socket/network, provider/model,
  Bridge, ES, environment, clock-read, random, UUID, logging, or public-package
  integration;
- expose no package-root symbol;
- retain no caller-owned mutable collection;
- disable subclassing and pickling;
- use content-free `repr` and `str`;
- suppress foreign exception chains;
- use exact built-in external type checks;
- reject `bool` and integer subclasses for integer fields;
- preserve exact Unicode code points with no normalization;
- have no JSON decoder in B1;
- never treat a digest as authenticity or permission.

GOVERNING DOCUMENT AND STATUS WORDING

Create `.docs/rw0-b1-pure-phase-values.md` as the sole detailed B1 owner. It
must state exact current implementation, nonclaims, schemas, fields, domains,
bounds, relations, privacy, consumer boundary, B2/C/D/E/ES ownership, validation
expectations, and stop conditions.

Update the RW0 owner only through a bounded current-status successor/section.
Do not rewrite the accepted RW0-A target or historical bytes.

In each of the four bounded cross-references, use normalized-identical current
status with this exact meaning:

> A private no-I/O RW0-B1 semantic value and relation layer is now implemented. No phase-entry persistence, verifier authenticity, custody, transport, process, worker, terminal-outcome runtime, latch, Git, ES route, service, scheduler, queue, or autonomous loop is implemented. The durable and executable boundary remains private C2B3D planned author delivery plus Section 41 pre-execution selection.

Preserve unique visible owners, marker ranges, adjacency, normalized-body
identity, fence-aware parsing, historical-relocation rejection, hidden-duplicate
controls, and all existing hostile Markdown causality.

TEST-FIRST CAUSAL GATE

Implement the governing doc and four new test files before creating the new
production source. Run one isolated direct red gate over the four new files.
The expected result is collection/import or missing-contract failure caused by
the absent B1 module/classes/relations—not a syntax error, collection-control
weakening, or unrelated failure.

Retain stdout, stderr, exact argv, environment, JUnit when produced, and the
repository fingerprint. Do not count this red run as final validation.

Then create the source and complete the bounded status/inventory edits.

TEST REQUIREMENTS

The four new test files must independently and causally cover at least:

- exact `_FIELDS`, schema IDs, digest domains, and class order;
- literal independently calculated canonical identity bytes and digests;
- no Unicode normalization;
- exact built-in types and hostile subclasses;
- `bool` rejection for every integer family;
- every enum and result/reason pair;
- unknown-before-missing precedence;
- nullable-pair symmetry;
- mutable-input defensive copying;
- disabled subclassing and pickling;
- content-free `repr`, `str`, errors, and exception chains;
- every per-value budget, largest valid, one over, cycle, and shared-DAG alias;
- every per-relation budget and shared budget through called helpers;
- exact K8/L34/Section 41 binding;
- C2A WorkSpec/fence/command/delivery reuse and no identity replacement;
- path-scope binding from supplied current C2A tuples, including one-field
  mismatches and the compatibility-edge treatment;
- equal and unequal valid attempt/effect authorization-basis pairs;
- external common-family claim limits;
- strict and non-strict subordinate narrowing;
- custody subject kinds, semantic/physical digest distinction, freshness, and
  selected-artifact byte length;
- retrieval triple binding, all legal prefixes/terminal transitions, every
  illegal transition, predecessor/sequence/time rules, and no retry implication;
- readiness profile pairs, qualification precedence, and the exact finite
  result/reason matrix;
- terminal binding and all five exact branch rows, with no B1 proof of latch
  atomicity, reconciliation completeness, evidence completeness, or absence;
- no-I/O AST/import boundary;
- no production importer in B1;
- empty private exports and unchanged package root;
- privacy sentinels for raw WorkSpec/plan bytes, bearer/credentials, host
  identity/endpoints/paths, prompts/transcripts/JSONL/stdout/stderr, trust
  material, provider/session metadata, and IM bundle bodies;
- causal one-field ref/digest/head/stop/family/ceiling/profile/branch mutants.

Do not weaken, rename gratuitously, skip, xfail, or reparameterize existing tests
to obtain green results.

VALIDATION EVIDENCE ROOT

Create one external operator-owned, non-symlink, mode-0700 root beneath:

/private/tmp

using a prefix such as:

gec-rw0-b1-implementation.

For every pytest child:

- save the caller's actual umask;
- use secure evidence-root creation;
- restore the caller umask before launching pytest;
- record and require equal caller/child numerical umask;
- use:
  - `env -u PYTHONTRACEMALLOC -u PYTHONWARNINGS`;
  - `LC_ALL=C`;
  - `LANG=C`;
  - `PYTHONDONTWRITEBYTECODE=1`;
  - distinct external `PYTHONPYCACHEPREFIX`;
  - distinct external `TMPDIR`;
  - `PYTEST_DISABLE_PLUGIN_AUTOLOAD=1`;
  - `PYTEST_ADDOPTS=''`;
  - `PYTHONHASHSEED=0`;
  - `python3 -B -m pytest`;
  - `-p no:cacheprovider`;
  - `-W error`;
  - distinct external `--basetemp`;
  - distinct external `--junitxml`;
  - serial execution.

Before and after every final green run require:

- branch/HEAD/upstream unchanged;
- exact dirty path subset within the allowlist;
- no staged/unmerged path;
- no repository-local cache, bytecode, pytest cache, database, journal,
  WAL/SHM, build, archive, generated manifest, or OS metadata;
- no Git operation or lock.

OPENING NODE COLLECTION

After branch creation and before repository edits, collect the complete ordered
node list exactly once under the isolated posture. Retain literal node IDs and
SHA-256. Do not assume a count from chat history.

FINAL VALIDATION ORDER

After implementation and cleanup:

1. Collect the complete final ordered node list exactly once.

   Require:

   - opening minus final is empty;
   - final minus opening contains exactly nodes from the four new B1 test files;
   - removing those additions reproduces opening order exactly;
   - no duplicate node, skip, xfail, collection hook, or collection warning.

2. Direct B1 values:

   `tests/test_rw0_b1_phase_values.py`

3. Direct B1 relations:

   `tests/test_rw0_b1_relations.py`

4. Independent vectors:

   `tests/test_rw0_b1_vectors.py`

5. Boundary/security tests:

   `tests/test_rw0_b1_boundaries.py`

6. Source/public inventories:

   `tests/test_c2a_nonimplementation.py`
   `tests/test_runtime_non_authority.py`

7. C2A compatibility regression:

   `tests/test_worker_execution_semantic_values.py`
   `tests/test_worker_execution_semantic_vectors.py`
   `tests/test_worker_execution_semantic_relations.py`
   `tests/test_worker_execution_semantic_boundaries.py`
   `tests/test_c2a_relations.py`
   `tests/test_c2a_first_slice_semantic_protocol_contract.py`

8. RW0/current-status and structural documentation regression:

   `tests/test_rw0_remote_contact_phase_entry_contract.py`
   `tests/test_architecture_contracts.py`
   `tests/test_remote_worker_pre_execution_planning_contract.py`
   `tests/test_autonomous_software_development_operating_model.py`

9. Run `git diff --check` and exact path/mode/status/residue guards.

10. Run the complete suite against final bytes:

    `python3 -B -m pytest -p no:cacheprovider -W error --basetemp=<external> --junitxml=<external> -q .`

    Run final attempt 001 once. If it fails, repair only when every required
    byte change remains within the exact allowlist and the failure is caused by
    this patch. Then run one final attempt 002. If an outside path, contract
    reset, C2A change, B2 mechanic, or unrelated mutation is required, stop and
    preserve the candidate. Do not run a third full-suite attempt.

For every final green pytest result require:

- return code 0;
- exact collected/passed accounting;
- zero failed, errors, skipped, xfailed, or warnings;
- empty stderr;
- no JUnit parse error, duplicate case, ambiguous case, or unmapped case;
- equal caller/child umask;
- unchanged candidate bytes before/after.

ARTIFACT HYGIENE

Remove only implementation-created transient external caches, pycache,
basetemps, temporary files, and repository-local residue after preserving final
stdout/stderr/JUnit/result records. Do not remove pre-existing material.

Do not run `compileall` or `py_compile` against repository paths.

FINAL PROVENANCE

After final validation and cleanup, use the exact unchanged recipe below.

Recipe source requirements:

- size: 3,945 bytes
- SHA-256:
  db21f2b67ba73a03a98c1d309323e5cabc014a10248ef96d5e25cc52081460bc

Safely classify the fixed external output path before use. Preserve any safe
pre-existing file's exact bytes and metadata externally, run the exact recipe,
copy each generated canonical manifest into the implementation evidence root,
and restore the pre-existing fixed-path file exactly. Stop rather than traverse
or overwrite an unsafe path.

Run the recipe exactly twice after final cleanup. Require:

- return code 0;
- empty stderr;
- byte-identical complete stdout;
- byte-identical canonical manifest;
- exact branch/HEAD/upstream identity;
- exactly the final allowlisted changed path set;
- regular safe file types and expected modes;
- stable tracked textual-diff SHA-256.

EXACT PROVENANCE RECIPE

```python
from __future__ import annotations

import hashlib
import json
import os
import stat
import subprocess
from pathlib import Path

RECIPE_ID = "governed-execution.audit-patch-manifest.v1"
OUTPUT_PATH = Path("/tmp/ge-coordinator-b3a-audit-manifest-v1.json")


def git_bytes(*args: str) -> bytes:
    env = os.environ.copy()
    env["LC_ALL"] = "C"
    env["LANG"] = "C"
    result = subprocess.run(
        ["git", *args],
        check=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        env=env,
    )
    return result.stdout


def git_text(*args: str) -> str:
    return git_bytes(*args).decode("utf-8", "strict").strip()


def nul_paths(data: bytes) -> list[str]:
    return [
        item.decode("utf-8", "strict")
        for item in data.split(b"\0")
        if item
    ]


head = git_text("rev-parse", "HEAD")
branch = git_text("branch", "--show-current")
upstream = git_text("rev-parse", "--abbrev-ref", "--symbolic-full-name", "@{u}")

tracked = set(
    nul_paths(git_bytes("diff", "--name-only", "--no-renames", "-z", "HEAD", "--"))
)
added = set(
    nul_paths(
        git_bytes(
            "diff",
            "--name-only",
            "--no-renames",
            "--diff-filter=A",
            "-z",
            "HEAD",
            "--",
        )
    )
)
deleted = set(
    nul_paths(
        git_bytes(
            "diff",
            "--name-only",
            "--no-renames",
            "--diff-filter=D",
            "-z",
            "HEAD",
            "--",
        )
    )
)
untracked = set(
    nul_paths(git_bytes("ls-files", "--others", "--exclude-standard", "-z"))
)

if tracked & untracked:
    raise SystemExit("tracked/untracked path overlap")

entries: list[dict[str, object]] = []
for relative_path in sorted(tracked | untracked):
    if relative_path in untracked:
        kind = "untracked"
    elif relative_path in deleted:
        kind = "tracked_deleted"
    elif relative_path in added:
        kind = "tracked_added"
    else:
        kind = "tracked_modified"

    entry: dict[str, object] = {
        "kind": kind,
        "path": relative_path,
    }

    if kind == "tracked_deleted":
        entry.update(
            {
                "file_type": "missing",
                "mode": None,
                "sha256": None,
                "size": None,
            }
        )
    else:
        path = Path(relative_path)
        metadata = path.lstat()
        mode = f"{stat.S_IMODE(metadata.st_mode):04o}"
        if stat.S_ISREG(metadata.st_mode):
            payload = path.read_bytes()
            file_type = "regular"
        elif stat.S_ISLNK(metadata.st_mode):
            payload = os.readlink(path).encode("utf-8")
            file_type = "symlink"
        else:
            raise SystemExit(f"unsupported file type: {relative_path}")

        entry.update(
            {
                "file_type": file_type,
                "mode": mode,
                "sha256": hashlib.sha256(payload).hexdigest(),
                "size": len(payload),
            }
        )

    entries.append(entry)

diff_bytes = git_bytes(
    "diff",
    "--full-index",
    "--binary",
    "--no-ext-diff",
    "--no-textconv",
    "--no-renames",
    "HEAD",
    "--",
)
textual_diff_sha256 = hashlib.sha256(diff_bytes).hexdigest()

manifest = {
    "branch": branch,
    "files": entries,
    "head": head,
    "recipe_id": RECIPE_ID,
    "textual_diff_sha256": textual_diff_sha256,
    "upstream": upstream,
}

canonical = (
    json.dumps(
        manifest,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")
    + b"\n"
)
manifest_sha256 = hashlib.sha256(canonical).hexdigest()
OUTPUT_PATH.write_bytes(canonical)

print(f"recipe_id={RECIPE_ID}")
print(f"textual_diff_sha256={textual_diff_sha256}")
print(f"manifest_sha256={manifest_sha256}")
print(f"file_count={len(entries)}")
print(canonical.decode("utf-8"), end="")
```

IMPLEMENTATION CLOSEOUT REPORT

Return exactly:

COORDINATOR_RW0_B1_PURE_PHASE_VALUES_IMPLEMENTED_READY_FOR_INDEPENDENT_AUDIT

only when implementation, final validation, cleanup, guards, and repeated
provenance are complete.

Report:

1. Opening and final repository identity.
2. Feature-branch creation and upstream.
3. Exact touched paths, classifications, modes, sizes, and SHA-256.
4. Material reconciled-packet decisions implemented.
5. The finite implementation clarifications above and their exact realization.
6. Direct red evidence.
7. Opening/final node counts, hashes, literal additions, and order comparison.
8. Every validation command, exact result, elapsed time, stdout/stderr/JUnit
   sizes and hashes, warnings/skips, and before/after byte identity.
9. Failed/repaired validation attempts and whether attempt 002 was needed.
10. Protected-file and public-boundary comparisons.
11. Artifact/residue hygiene.
12. Authority, privacy, protocol, dependency, and cross-repository widening:
    explicitly none or exact exceptions.
13. Exact recipe source identity, two-run output identity, tracked-diff hash,
    canonical-manifest size/hash, file count, and safe manifest path.
14. Complete canonical manifest or a safe exact external reference.
15. Assumptions, unresolved seams, skipped validation, and where inspection
    stopped.
16. Separate confidence estimates for provenance, validation, and
    implementation.

Required final statements:

INDEPENDENT_AUDIT_NOT_PERFORMED
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED
REMOTE_CONTACT_NOT_PERFORMED
WORKER_OR_MODEL_NOT_INVOKED
SUPPORTING_REPOSITORIES_NOT_MODIFIED
DEPENDENCIES_NOT_CHANGED
MIGRATIONS_NOT_CHANGED
PUBLIC_API_NOT_WIDENED

STOP CONDITIONS

Stop without staging, commit, push, or scope widening if:

- baseline or branch preconditions fail;
- a path outside the allowlist must change;
- an existing C2A schema, field, enum, effect/source/observation kind, digest
  domain, vector, path grammar, or relation must change;
- private or bearer material would enter a B1 value, canonical bytes, error,
  projection, fixture, or report;
- authenticity or permission would be inferred from a digest;
- a second selected plan, WorkSpec, attempt, candidate, effect, command, fence,
  delivery, or source-observation identity is needed;
- qualification requires a new scenario-profile class;
- a frozen field inventory, relation, budget, or error rule is mechanically
  inconsistent;
- SQLite, migration, durable state, filesystem, subprocess, network,
  provider/model, Bridge, ES, worker, adapter, public API, dependency, script,
  or configuration work is required;
- B2 framing/terminal-result/Codex mechanics are required;
- an existing test must be weakened, skipped, xfailed, or gratuitously renamed;
- final validation cannot be made exact-green within the allowlist;
- provenance is unstable or repository residue remains.
