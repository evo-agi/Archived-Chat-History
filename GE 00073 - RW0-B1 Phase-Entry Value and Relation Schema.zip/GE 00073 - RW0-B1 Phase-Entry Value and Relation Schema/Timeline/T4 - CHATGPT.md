## Verdict

**Do not authorize RW0-B1 implementation yet.** Codex’s `RW0_B1_SCHEMA_FREEZE_READY` verdict is too strong.

The packet is materially better than the earlier reconnaissance: the B1/B2 split is correct, the eight semantic roles are broadly sensible, the private-module direction is sound, and the C2A non-collapse/privacy posture is mostly right. But several proposed rules either contradict the merged contracts or cannot be mechanically implemented as written.

I classify the actual state as:

```text
RW0_B1_SCHEMA_FREEZE_PARTIAL
```

The project protocol says not to begin mutation while a required authority or identity decision remains unresolved. 

## Blocking issues

### 1. The grant-family relation claims fields the existing fences do not contain

The proposed `validate_common_parent_family(...)` says the observation, proposal, attempt fence, and effect fence all bind one `grant_family_ref/digest`.

But the existing C2A values contain:

```text
AttemptFenceV1:
  parent_standing_grant_ref/digest
  attempt_authorization_ref/digest

EffectFenceV1:
  parent_standing_grant_ref/digest
  effect_authorization_ref/digest
```

They contain no grant-family pair. See:

```text
src/ge_nwp_coordinator/_worker_execution_semantic_values.py:915-970
src/ge_nwp_coordinator/_worker_execution_semantic_values.py:1182-1245
```

B1 can require:

- exact parent-grant equality across the existing fences;
- exact equality between each persisted authorization pair and the corresponding observation/proposal binding;
- exact family-pair equality between the external observation and Coordinator proposal;
- a source-authored `family_status=compatible`.

It cannot independently prove that the existing fences themselves encode that family. That would convert an external verifier assertion into a derived Coordinator fact.

### 2. `CeilingsV1` is not a host-capacity schema

The draft places `CeilingsV1` in both host readiness and host qualification as `capacity_ceilings`.

That value includes:

```text
max_deployments
max_local_commits
max_merges
max_pull_requests
max_pushes
max_model_input_tokens
max_model_output_tokens
```

alongside CPU, memory, wall time, and candidate-byte limits. These are effect-policy ceilings, not physical host capabilities. The exact current inventory is at:

```text
src/ge_nwp_coordinator/_worker_execution_semantic_values.py:92-108
```

A host cannot meaningfully assert “capacity” for pull requests or semantic Git-effect counts. Reusing this class would collapse external readiness evidence into Coordinator policy.

The fix is to remove `CeilingsV1` from the readiness and qualification values. Host suitability should bind safe capability-profile refs/digests; effect ceilings remain in the authority/fence relation. Numeric host mechanics remain RW0-D/E.

### 3. The draft promotes a stale proof fixture into B1’s permanent path grammar

The packet defines `P` as exactly the three current ES fixture paths and uses it in authority, subordinate authorization, and retrieval values.

That is inconsistent with merged RW0-A, which explicitly labels the earlier ES commit and path set as stale-able proof evidence rather than a durable Coordinator contract:

```text
.docs/rw0-remote-worker-contact-phase-entry.md:427-436
```

Existing C2A currently represents those three paths, so the first implementation may be compatibility-limited to that scope. But B1 must not independently freeze those paths as its own universal grammar.

A safer contract is:

```text
path_scope_digest
```

recomputed from the exact path tuple in the supplied current C2A WorkSpec/fences. The B1 digest is only a correlation binding; it neither replaces the C2A path identity nor makes the fixture permanent.

### 4. Retrieval events are not bound to the subordinate proposal

`RW0RetrievalCapabilityEventObservationV1` binds the authority-verification observation but omits:

- the exact subordinate-authorization proposal;
- the exact custody-availability observation.

That would allow a capability issuance/redemption/consumption claim to be structurally valid without being bound to the narrower Coordinator proposal and the availability fact for the subject being retrieved.

Both pairs need to be explicit:

```text
authority_verification_ref/digest
subordinate_authorization_proposal_ref/digest
custody_availability_observation_ref/digest
```

### 5. The terminal-outcome evidence contract is still open

The proposed terminal value contains:

```text
evidence_bindings: 0–32 role/ref/digest triples
```

but does not freeze exact required and forbidden roles or multiplicities per terminal branch. As written, an `accept` value could structurally contain no validation, review, capsule, worker, or authority evidence.

It also claims that the pre-effect-cancel relation can prove:

```text
no effect
no request
```

B1 has no durable readback from which to prove absence. RW0-C owns that proof.

The cleanest correction is:

```text
evidence_set_ref
evidence_set_digest
```

B1 then validates only:

- phase and current-head identity;
- exact earlier C2B decision pair and kind;
- branch/outcome compatibility;
- stop binding;
- applicable latch, reconciliation, or mismatch pair.

RW0-C later owns the evidence graph, completeness, ambiguity, and proof of presence or absence. This preserves the merged contract’s distinction between pure terminal semantics and durable terminal representation. The current target deliberately leaves rows, receipts, graphs, migrations, and latch representation to RW0-C. 

### 6. The global `1,436` construction budget cannot operate as described

The eight classes are independently constructed. There is no complete B1 aggregate constructor through which one shared construction budget could flow.

Therefore this claim is not mechanically implementable:

```text
one private budget is passed through construction/reconstruction
of the complete graph
```

The factor-of-two formula also mixes construction, validation, relation traversal, maximum collections, and hypothetical graph aggregation without an owning call boundary.

The freeze should instead define:

- an exact per-value reconstruction budget for each class;
- an exact per-relation traversal budget derived from that relation’s argument graph;
- one shared budget per relation invocation;
- occurrence charging before descent;
- active-object cycle rejection;
- no free expansion of repeated shared-DAG aliases.

No aggregate schema should be invented merely to justify a global number.

### 7. The qualification reason is not closed-world

The packet gives qualification an arbitrary regex-shaped `reason_code`. That conflicts with its own requirement for finite reason domains.

It needs an exact result/reason matrix, such as:

```text
qualified → qualified

unknown → unknown

blocked →
  readiness_unready
  readiness_expired
  authority_not_verified
  authority_denied_or_revoked
  authority_expired
  phase_or_effect_mismatch
  worker_artifact_mismatch
  worker_protocol_mismatch
  platform_or_architecture_mismatch
  profile_mismatch
  global_stop_active
```

The exact final list may differ, but it must be finite and mechanically tied to the result.

The blanket integer rule also needs correction. Existing C2A uses field-specific validation and generally accepts exact non-negative integers rather than a universal signed-64-bit ceiling. If B1 intentionally imposes a new limit for canonical-work safety or later persistence compatibility, it must be labeled and justified as a **new B1 compatibility bound**, not attributed to C2A.

### 8. The implementation allowlist is too narrow for honest current-status documentation

Four current cross-references literally state:

```text
Current implementation stops at private C2B3D planned author delivery
plus Section 41 pre-execution selection
```

That statement appears in the live four-document map and is directly pinned by the RW0 contract tests:

```text
.docs/authority-boundaries.md:416
.docs/autonomous-software-development-operating-model.md:586
.docs/durable-state-model.md:543
.docs/worker-execution-boundary.md:471
tests/test_rw0_remote_contact_phase_entry_contract.py:386
```

Once B1 source exists, the **durable and executable** boundary still stops at C2B3D/Section 41, but the complete implemented source boundary does not.

The implementation scope therefore needs room for a bounded normalized update across those four documents and their complete-map tests. Otherwise B1 would immediately introduce current-status drift.

A truthful replacement should say, in substance:

```text
A private no-I/O RW0-B1 semantic value/relation layer is implemented.

No phase-entry persistence, verifier authenticity, custody, transport,
process, worker, terminal-outcome runtime, latch, Git, ES route,
service, scheduler, queue, or autonomous loop is implemented.

The durable/executable boundary remains C2B3D plus Section 41.
```

## What remains accepted

These parts should survive the correction unchanged:

- B1 and B2 remain separate ordered tranches.
- One private B1 source module remains the right default.
- Existing C2A schemas, enums, domains, vectors, and source/observation kinds remain byte-identical.
- The eight high-level B1 roles remain a good minimum inventory.
- Selected-plan, K8, L34, WorkSpec, attempt, candidate, effect, command, fences, and initial delivery are reused, not recreated.
- External observations, Coordinator evaluations, and durable facts remain distinct.
- No SQLite, filesystem, subprocess, network, model, ES, Bridge, or public API behavior belongs in B1.
- B1 continues to be private, immutable, deterministic, standard-library-only, and no-I/O.

The merged target explicitly defines RW0-B as pure deterministic source/tests with persistence and execution remaining later.  Its identity model also requires K8 plus the exact L34/head postimage without collapsing authority, delivery, observation, decision, or latch identities. 

## Next action

Continue in the **same read-only Codex conversation** with:

:chatgpt-content-reference{index="3"}

The intended successful verdict is:

```text
RW0_B1_SCHEMA_FREEZE_RECONCILED_READY
```

That response must replace the complete packet, not merely append errata.

Only after that corrected freeze should the same Codex conversation transition to parent-only workspace-write implementation. The project protocol requires the read-only parent to return a reconciled, exact implementation plan and stop before mutation; implementation follows in a separate write-enabled turn, and independent audit follows in a fresh conversation. 

### Sources

- Codex RW0-B1 schema-freeze packet supplied in this turn.
- Merged Coordinator snapshot: :chatgpt-content-reference{index="4"}
- RW0-B tranche ceiling and sequencing. 
- RW0 identity and non-collapse matrix. 
- Reconnaissance-to-implementation protocol. 
- Provenance versus implementation confidence. 

**Confidence:** 99% that implementation should remain blocked; 98% that the eight listed corrections are finite and sufficient to produce an implementation-ready B1 freeze; 96% that the underlying eight-role decomposition remains the right minimum after correction.
