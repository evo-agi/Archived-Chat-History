## Verdict

**The second re-audit’s `BLOCK` is valid. Return to the existing RW0-B1 implementation conversation for one more bounded repair. Do not stage, commit, or reopen the B1/B2 architecture.**

The findings expose incomplete cross-relation composition, not a flaw in the eight-value design. B1 remains a private pure layer over supplied evidence; it grants no permission and implements no contact or durable state. 

## Engineering decisions

| Finding | Disposition |
|---|---|
| Host qualification can bind another attempt | Accept. Qualification must bind the authority observation’s attempt-fence pair to both the phase-basis L34 pair and the current effect fence’s originating attempt-fence pair. |
| Narrowing accepts another attempt’s effect fence | Accept. The current effect fence’s semantic attempt and originating attempt-fence pair must match the supplied attempt fence and phase basis. |
| Parent containment remains incomplete | Accept and resolve the wording conflict explicitly. The verified parent observation is the upper bound for applicable fence effect sets, ceilings, and expiry. |
| Retrieval budget undercounts 36 occurrences | Accept. The governed retrieval budget changes from **338 to 374**; no other budget changes. |
| Qualification and retrieval tests are incomplete | Accept. Add complete reason/precedence coverage and separate duplicate-ref from self-predecessor mutants. |

### Verified-parent containment

The governing relation text already requires current authority, matching parent/fence facts, proposal containment, and strict reduction, but it did not state the whole containment relation consistently across authority, narrowing, retrieval, and qualification. 

The repaired rule is:

- the attempt fence’s allowed-effect set must be a subset of the verified parent set;
- applicable author/current effect classes must be members of both the parent and attempt-fence sets;
- applicable fence ceilings must be componentwise no greater than the verified parent ceilings;
- applicable fence expiries must not outlive the verified parent grant;
- the proposal must remain inside the parent and applicable fences;
- strict proposal narrowing is measured against the **verified parent**, not against a broader fence;
- all supplied semantic-attempt, originating-attempt-fence, current-head, and stop bindings must agree.

This still validates only the structure and freshness of an external verifier claim. It does not authenticate the grant or derive permission from digests.

Host qualification does not receive an `AttemptFenceV1` object, so it must not pretend to revalidate fields it cannot see. It can and must bind the authority’s attempt-fence pair to the phase basis and current effect fence, enforce current-effect membership and current-fence containment, and return the existing closed blocked reason when those facts disagree.

### Retrieval budget

The frozen relation formula omitted the same 30 ceiling-member and six effect-set occurrences that the narrowing helper treated as already charged. The original packet requires one shared budget across the complete relation invocation and prohibits helper resets or free aliases. 

The corrected formula is:

```text
87 basis
+ 17 custody
+ 62 authority observation
+ 46 proposal
+ 3×38 retrieval events
+ 1 sequence container
+ 2 fence leaves
+ 1 time
+ 8 path occurrences
+ 30 ceiling-member occurrences
+ 6 effect-set occurrences
= 374
```

Exactly one side of the helper boundary must charge those 36 occurrences. They cannot be omitted or charged twice.

### Test causality

The repair must add:

- a changed attempt-fence pair in authority while qualification still claims `qualified`;
- a current effect fence from another semantic attempt;
- a current effect fence originating from another attempt fence;
- attempt-fence allowed effects broader than the verified parent;
- fence expiry and ceiling outside the verified parent;
- every qualification result/reason case and adjacent precedence collisions;
- a duplicate event-ref sequence that otherwise has valid predecessor relations:
  `A → B → A`;
- a separate self-predecessor mutant using unique event refs;
- real retrieval-relation budget tests at 374, one over, and shared-DAG/helper composition.

## Repair scope

Only four candidate paths may change:

```text
.docs/rw0-b1-pure-phase-values.md
src/ge_nwp_coordinator/_rw0_phase_entry_semantic_values.py
tests/test_rw0_b1_phase_values.py
tests/test_rw0_b1_relations.py
```

The final candidate must remain exactly:

```text
17 dirty paths
11 tracked modifications
6 untracked files
0 staged
0 unmerged
```

No class, field, schema ID, digest domain, relation signature, error reason, production consumer, public surface, or later-tranche ownership may change.

After repair, the workflow remains:

```text
tests-first causal red
→ bounded source/document repair
→ focused validation
→ node comparison
→ full suite, at most two attempts
→ repeated exact provenance
→ fresh independent re-audit
```

Changed bytes require a new audit before any commit gate. 

## Next action

Send this prompt to the **existing RW0-B1 implementation Codex conversation**:

:chatgpt-content-reference{index="2"}

The successful closeout token is:

```text
COORDINATOR_RW0_B1_SECOND_REAUDIT_FINDINGS_REPAIRED_READY_FOR_FRESH_REAUDIT
```

Do not continue in the re-audit conversation and do not reuse an earlier repair prompt.

### Sources

- Reconciled B1 non-authority boundary. 
- Exact pure-relation contract. 
- Work-budget ownership and original formulas. 
- Repair and fresh-audit lifecycle. 
- Codex second independent re-audit response supplied in this turn.

**Confidence:** 99% that the five findings are real candidate defects; 98% that the verified-parent rule and 374-unit retrieval budget above resolve the contract ambiguity; 96% that the four-path repair ceiling is sufficient without an architecture refreeze.
