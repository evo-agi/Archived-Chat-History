## Verdict

**The audit’s `BLOCK` is valid. Return to the original implementation conversation for a bounded repair; do not stage, commit, or start another architecture reconnaissance.**

This is not a rejection of RW0-B1’s design. The candidate still implements the intended private, pure layer over supplied evidence, with no permission, contact, or durable-state effect.  The findings identify relation false positives, a canonicalization/spec mismatch, weak causal tests, and one status contradiction. They can be corrected without changing the eight classes, field lists, schema IDs, digest domains, relation signatures, or B1/B2/C/D/E ownership split.

## Finding disposition

| Finding | Engineering decision |
|---|---|
| **F1 — strict narrowing** | Accept. Strictness must be measured against the externally verified parent, not against a broader or internally inconsistent fence. Both supplied fences must first fit within the parent. |
| **F2 — current authority binding** | Accept. Bind the exact author fence to L34, eliminate object-identity shortcuts, require current head digests, and bind fence stop versions to the current phase stop. |
| **F3 — downstream composition** | Accept. Retrieval must enforce the supplied narrowing and custody prerequisites. Qualification must enforce every current-authority predicate available through its existing arguments, including allowed-effect membership and clear/current stop. |
| **F4 — unbounded integers** | Accept with a bounded contract correction. Every integer leaf serialized into a B1 identity will be limited to `0..2^63−1`, including nested L34 and `CeilingsV1` integers. This is B1 canonical/durable compatibility—not a runtime, transport, allocation, or C2A-wide limit. |
| **F5 — test causality** | Accept. Literal field inventories, independent vectors, direct execution of all thirteen relations, and actual shared-budget counterexamples are required. |
| **F6 — current-status contradiction** | Accept. The owner must distinguish the newly implemented pure semantic layer from the unchanged durable/executable boundary. |
| **F7 — retrieval ambiguity** | Resolve now: event refs are unique; one safe correlation has one immutable expiry; issued/redeemed/consumed occur strictly before it; `expired` occurs at or after it; revoked/failed/unknown are terminal and permit no later event or retry. |

The authority fixes preserve the governing distinction: B1 may compare identities, currentness, and supplied verifier claims, but cannot authenticate those claims or manufacture authority. 

The terminal relation remains structural only. Evidence completeness, latch atomicity, reconciliation completeness, and proof of effect/request absence remain RW0-C responsibilities. 

## Repair scope

The repair is limited to eight existing candidate paths:

```text
.docs/rw0-b1-pure-phase-values.md
.docs/rw0-remote-worker-contact-phase-entry.md
src/ge_nwp_coordinator/_rw0_phase_entry_semantic_values.py
tests/test_rw0_b1_phase_values.py
tests/test_rw0_b1_relations.py
tests/test_rw0_b1_vectors.py
tests/test_rw0_b1_boundaries.py
tests/test_rw0_remote_contact_phase_entry_contract.py
```

The repository must remain a 17-path candidate:

```text
11 tracked modifications
6 untracked files
0 staged
0 unmerged
```

No new production consumer, public export, row provider, migration, configuration, dependency, or runtime surface is authorized. The accepted design permits no production consumer in B1 and reserves framing, persistence, physical custody, execution, and live-host behavior for later tranches. 

## Validation strategy

The repair prompt requires:

1. Reproduce the exact 17-path opening manifest.
2. Add causal tests for F1–F7 before source or documentation repair.
3. Preserve one expected red run.
4. Repair source and docs inside the eight-path ceiling.
5. Directly exercise every relation—not merely assert that functions exist.
6. Test actual relation budgets, including cycles and shared-DAG aliases.
7. Run focused B1, C2A, static-boundary, and RW0 documentation regressions.
8. Run the complete suite with at most two repair attempts.
9. Produce a new stable 17-path provenance manifest.
10. Stop for a **fresh independent re-audit**.

This follows the project lifecycle: audit findings return to a parent-only repair turn; changed bytes require new validation, provenance, and another fresh read-only audit. 

## Next action

Send this prompt to the **original RW0-B1 implementation Codex conversation**, not the audit conversation:

:chatgpt-content-reference{index="2"}

The successful closeout token is:

```text
COORDINATOR_RW0_B1_FIRST_AUDIT_FINDINGS_REPAIRED_READY_FOR_FRESH_REAUDIT
```

Do not reuse the prior implementation or audit prompts.

### Sources

- Reconciled RW0-B1 governing packet. 
- Pure-relation authority and terminal-proof boundaries. 
- Frozen work-budget model. 
- Consumer and later-tranche boundaries. 
- Repair and fresh-audit operating protocol. 
- Codex independent-audit response supplied in this turn.

**Confidence:** 99% that F1–F6 are real candidate defects; 97% that the F7 rules above are the correct one-use capability semantics; 96% that the eight-path repair ceiling is sufficient without an architecture refreeze.
