Here is Codex's response:

# RW0-B1 pure schema freeze

**Verdict:&#x20;****`RW0_B1_SCHEMA_FREEZE_READY`**

This is an implementation packet, not an implementation. B1 defines private semantic values and pure checks over supplied facts. External sources still own the authority, custody, and host facts they assert; RW0-C owns guarded persistence and the acceptance latch. The [RW0-A contract (line 106)](</Users/ds/Repositories/Governed Execution Coordinator/.docs/rw0-remote-worker-contact-phase-entry.md:106>) and the existing [C2A values (line 21)](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/_worker_execution_semantic_values.py:21>) govern those boundaries.

## Baseline and governing choices

The required baseline matched **at opening and closing**: `trunk_dev`, HEAD `bf68a5232bff1b412c9414c076d82cab18c8e0aa`, tree `8fc05f5626bdbb01808df1698c9c2245ab06f1cb`, sole parent `1a894c5527c610ab40d8e5ae5e530a762c6e60bf`, subject `docs: freeze RW0-A phase-entry contract (#2)`, upstream `origin/trunk_dev` at `0/0`, one worktree, clean index/worktree, and no Git lock, operation, or residue. No fetch was made.

The eight values below have **new B1 value identities only**. They do not replace the existing selected plan, WorkSpec, attempt, candidate, effect, command, fence, or delivery identities. In particular, the terminal *value* ref and digest are not the future durable terminal fact ref, row, or receipt. This resolves RW0-A’s explicit deferral of durable terminal representation ([RW0-A terminal contract (line 335)](</Users/ds/Repositories/Governed Execution Coordinator/.docs/rw0-remote-worker-contact-phase-entry.md:335>)).

### Common schema rules

`from_mapping` takes an **exact built-in&#x20;****`dict`**. Every listed key is required, including nullable keys. No other key is accepted. It checks unknown keys before missing keys. A mapping cannot represent duplicate keys; any future JSON decoder must reject duplicate object keys before calling `from_mapping`. B1 defines no wire decoder.

The type notation in the field inventories is exact:

| CodeExternal value in `from_mapping`Stored value and bound |                                                  |                                                                                                                               |
| ---------------------------------------------------------- | ------------------------------------------------ | ----------------------------------------------------------------------------------------------------------------------------- |
| `R`                                                        | exact `str`                                      | C2A safe ref: 1–96 ASCII characters, `[A-Za-z0-9][A-Za-z0-9.-]*`, excluding C2A’s forbidden prefixes                          |
| `H`                                                        | exact `str`                                      | 64 lowercase hexadecimal SHA-256 characters                                                                                   |
| `T`                                                        | exact `str`                                      | valid 20-character `YYYY-MM-DDTHH:MM:SSZ` UTC second                                                                          |
| `I`                                                        | exact `int`                                      | `0…2^63−1`; `bool` and integer subclasses fail                                                                                |
| `P`                                                        | exact `list[str]`                                | exact immutable tuple `(".docs/system_overview/hybrid_integration_architecture_adr.md", "PLANS.md", "docs_contract_test.go")` |
| `E`                                                        | exact `list[str]`                                | sorted, unique immutable tuple of 1–5 members of C2A’s existing five effect classes                                           |
| `C`                                                        | exact `dict`                                     | defensively reconstructed exact `CeilingsV1`, all 15 existing fields, each `I`                                                |
| `L34`                                                      | exact `dict`                                     | defensively reconstructed exact `CanonicalC2B3DLineage`, its existing 34 ordered fields and rules                             |
| `K8`                                                       | exact `list` of eight exact two-item `list[str]` | immutable tuple of the existing eight ordered `(name, R)` pairs                                                               |
| `?`                                                        | exact `None` or the stated type                  | stored `None` or the immutable stated type; each nullable ref/digest pair is jointly present or jointly absent                |

Enum fields use exact built-in strings; their members are stated below. `schema_id` is a fixed literal, not caller-selected. All eight classes are final, slotted, immutable, non-pickleable, and have constant content-free `repr`/`str`. Each exposes a fresh safe `to_mapping()` in declared field order, an `identity_mapping()` omitting **only its own final digest field**, canonical identity bytes, and `computed_digest()`. Nested mappings and arrays are fresh copies.

Canonical identity bytes are `json.dumps(identity_mapping, ensure_ascii=False, allow_nan=False, sort_keys=True, separators=(",", ":")).encode("utf-8", "strict")`. No NFC/NFKC conversion occurs. The stored digest equals lowercase SHA-256 of `digest_domain.encode("utf-8") + b"\x00" + canonical_identity_bytes`. Thus constructor order is fixed for projection, while canonical object keys sort lexically; K8, paths, and evidence-array order remains semantic. This follows C2A’s [canonical rule (line 431)](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/_worker_execution_semantic_values.py:431>). No B1 constructor accepts raw bytes, arbitrary text, a bearer, a hostname, or a physical path.

### Exact class inventory

For each row, the digest domain is the stated schema ID followed by `.identity`. The final field in each inventory is the sole self-digest. “Source claim” means B1 can check shape and relations but cannot authenticate authorship.

| Class and exact schema IDAuthor and postureConsumers                                                                |                                                 |                                             |
| ------------------------------------------------------------------------------------------------------------------- | ----------------------------------------------- | ------------------------------------------- |
| `RW0PhaseEntryBasisV1` — `governed-execution.nwp-rw0-phase-entry-basis.v1`                                          | Coordinator; inert no-contact semantic input    | B1 relations; later guarded RW0-C           |
| `RW0AuthorityVerificationObservationV1` — `governed-execution.nwp-rw0-authority-verification-observation.v1`        | External verifier; safe source claim            | B1 authority relations; later RW0-C/D gates |
| `RW0SubordinateAuthorizationProposalV1` — `governed-execution.nwp-rw0-subordinate-authorization-proposal.v1`        | Coordinator; inert narrowing proposal           | B1 relations; later RW0-C                   |
| `RW0CustodyAvailabilityObservationV1` — `governed-execution.nwp-rw0-custody-availability-observation.v1`            | Custodian; availability and byte-identity claim | B1 custody relation; later RW0-C/D          |
| `RW0RetrievalCapabilityEventObservationV1` — `governed-execution.nwp-rw0-retrieval-capability-event-observation.v1` | Issuer or custodian; event claim, no bearer     | B1 sequence relation; later RW0-C/D         |
| `RW0RemoteHostReadinessObservationV1` — `governed-execution.nwp-rw0-remote-host-readiness-observation.v1`           | Host owner; safe profile claim                  | B1 qualification relation; later RW0-C/D/E  |
| `RW0EffectHostQualificationV1` — `governed-execution.nwp-rw0-effect-host-qualification.v1`                          | Coordinator; deterministic evaluation           | B1 relation; later RW0-C/D gate             |
| `RW0TerminalOutcomeV1` — `governed-execution.nwp-rw0-terminal-outcome-value.v1`                                     | Coordinator; proposed pure terminal value       | B1 branch relations; later RW0-C            |

**1.&#x20;****`RW0PhaseEntryBasisV1`**, fields in order:
```
schema_id: literal
basis_ref:R
c2b3d_lineage:L34
selection_key:K8
selected_proposal_ref:R
selected_proposal_digest:H
selected_artifact_ref:R
selected_artifact_digest:H
selected_artifact_binding_digest:H
selected_plan_safe_projection_digest:H
disposition_ref:R
disposition_digest:H
disposition: "selected_for_dispatch_gates"
selection_head_revision:I
selection_head_digest:H
current_effect_head_revision:I
current_effect_head_state: one of ready_for_delivery, delivery_pending,
  delivery_outcome_unknown, observed, cancellation_effect_established, terminal
current_effect_head_digest:H
current_delivery_head_revision:I
current_delivery_head_state: one of planned, submitted, outcome_unknown,
  acknowledged, rejected, completed
current_delivery_head_digest:H
global_stop_ref:R
global_stop_version:I
global_stop_state: "clear" | "active"
basis_digest:H
```

`selection_head_digest` is the digest of the supplied current selection-head **postimage**; there is no second postimage identity. L34 supplies the exact program/version/work/WorkSpec, attempt, candidate, effect, command, fence, and delivery bindings. K8 must equal its derivation from L34. The head state domains are the existing [effect and delivery state domains (line 162)](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/_development_effect_row_values.py:162>).

**2.&#x20;****`RW0AuthorityVerificationObservationV1`**, fields in order:
```
schema_id: literal
observation_ref:R
source_ref:R
evidence_ref:R
evidence_digest:H
phase_basis_ref:R
phase_basis_digest:H
parent_grant_ref:R
parent_grant_digest:H
grant_family_ref:R
grant_family_digest:H
attempt_basis_ref:R
attempt_basis_digest:H
effect_basis_ref:R
effect_basis_digest:H
attempt_fence_ref:R
attempt_fence_digest:H
effect_fence_ref:R
effect_fence_digest:H
audience_ref:R
repository_ref:R
base_git_object_format: "sha1"
base_git_oid: exact str of 40 lowercase hexadecimal characters
path_scope:P
allowed_effect_classes:E
effect_class: one existing deliverable C2A effect class
parent_ceilings:C
status: "verified" | "denied" | "unknown"
family_status: "compatible" | "incompatible" | "unknown"
revocation_status: "unrevoked" | "revoked" | "unknown"
grant_expires_at:T
observed_at:T
observation_expires_at:T
current_effect_head_digest:H
current_delivery_head_digest:H
global_stop_ref:R
global_stop_version:I
global_stop_state: "clear" | "active"
observation_digest:H
```

The source asserts the parent, both role-specific basis pairs, family compatibility, and current scope. The two basis pairs **may be equal or different**; neither relationship between them is a validity rule. Each pair must match its own persisted fence. A `verified` string or valid observation digest does not authenticate the verifier or grant.

**3.&#x20;****`RW0SubordinateAuthorizationProposalV1`**, fields in order:
```
schema_id: literal
proposal_ref:R
phase_basis_ref:R
phase_basis_digest:H
verification_ref:R
verification_digest:H
parent_grant_ref:R
parent_grant_digest:H
grant_family_ref:R
grant_family_digest:H
attempt_basis_ref:R
attempt_basis_digest:H
effect_basis_ref:R
effect_basis_digest:H
attempt_fence_ref:R
attempt_fence_digest:H
effect_fence_ref:R
effect_fence_digest:H
audience_ref:R
repository_ref:R
base_git_object_format: "sha1"
base_git_oid: exact str of 40 lowercase hexadecimal characters
path_scope:P
effect_class: one existing deliverable C2A effect class
ceilings:C
expires_at:T
global_stop_ref:R
global_stop_version:I
proposal_digest:H
```

The proposal’s ref/digest are its own inert value identity. It is not an issued grant, credential, fence replacement, or permission.

**4.&#x20;****`RW0CustodyAvailabilityObservationV1`**, fields in order:
```
schema_id: literal
observation_ref:R
source_ref:R
evidence_ref:R
evidence_digest:H
phase_basis_ref:R
phase_basis_digest:H
subject_kind: "work_spec" | "selected_plan"
subject_ref:R
subject_semantic_digest:H
content_sha256:H
byte_length:I
availability: "available" | "unavailable" | "unknown"
observed_at:T
expires_at:T
observation_digest:H
```

The semantic digest and asserted raw-byte `content_sha256` are separate. A C2A WorkSpec digest or Section 41 artifact digest is domain-separated and need not equal SHA-256 of raw custody bytes. Availability proves neither retrieval nor consumption.

**5.&#x20;****`RW0RetrievalCapabilityEventObservationV1`**, fields in order:
```
schema_id: literal
event_ref:R
source_ref:R
evidence_ref:R
evidence_digest:H
phase_basis_ref:R
phase_basis_digest:H
safe_correlation_ref:R
subject_kind: "work_spec" | "selected_plan"
subject_ref:R
subject_semantic_digest:H
content_sha256:H
byte_length:I
semantic_attempt_ref:R
attempt_fence_ref:R
attempt_fence_digest:H
effect_intent_ref:R
effect_fence_ref:R
effect_fence_digest:H
audience_ref:R
repository_ref:R
base_git_object_format: "sha1"
base_git_oid: exact str of 40 lowercase hexadecimal characters
path_scope:P
verification_ref:R
verification_digest:H
event_kind: "issued" | "redeemed" | "consumed" | "expired" | "revoked" |
  "failed" | "unknown"
predecessor_event_ref:R?
predecessor_event_digest:H?
sequence_number:I
occurred_at:T
expires_at:T
event_digest:H
```

The correlation is non-bearer. The first event has sequence 0 and two null predecessor fields. A legal one-use sequence has at most three events: `issued`, optionally `redeemed`, then at most one terminal `consumed|expired|revoked|failed|unknown`. A source may report a singleton `unknown`; it never licenses a retry or implies non-consumption. Later definitive reconciliation belongs to RW0-C.

**6.&#x20;****`RW0RemoteHostReadinessObservationV1`**, fields in order:
```
schema_id: literal
observation_ref:R
source_ref:R
evidence_ref:R
evidence_digest:H
safe_host_correlation_ref:R
status: "ready" | "unready" | "unknown"
platform: "linux"
architecture:R
worker_artifact_ref:R
worker_artifact_digest:H
worker_protocol_ref:R
execution_identity_profile_ref:R
process_profile_ref:R
isolation_profile_ref:R
resource_profile_ref:R
cancellation_profile_ref:R
credential_handoff_profile_ref:R
capsule_store_profile_ref:R
validation_tool_profile_ref:R
review_tool_profile_ref:R
capacity_ceilings:C
cleanup_profile_ref:R
observed_at:T
expires_at:T
observation_digest:H
```

`architecture` is an exact safe profile identifier compared with the required identifier. B1 does **not** invent an `x86_64|aarch64` restriction: RW0-A requires matching architecture, not that two-member domain. The process/resource profile refs carry requirements such as disk, output, isolation, and cancellation whose numeric runtime limits are owned later. `capacity_ceilings` covers the existing 15 C2A ceiling dimensions; it does not claim to encode every physical resource limit.

**7.&#x20;****`RW0EffectHostQualificationV1`**, fields in order:
```
schema_id: literal
qualification_ref:R
phase_basis_ref:R
phase_basis_digest:H
effect_intent_ref:R
effect_fence_ref:R
effect_fence_digest:H
verification_ref:R
verification_digest:H
readiness_ref:R
readiness_digest:H
required_scenario_profile_ref:R
required_scenario_profile_digest:H
required_worker_artifact_ref:R
required_worker_artifact_digest:H
required_worker_protocol_ref:R
required_architecture:R
required_execution_identity_profile_ref:R
required_process_profile_ref:R
required_isolation_profile_ref:R
required_resource_profile_ref:R
required_cancellation_profile_ref:R
required_credential_handoff_profile_ref:R
required_capsule_store_profile_ref:R
required_validation_tool_profile_ref:R
required_review_tool_profile_ref:R
required_cleanup_profile_ref:R
required_capacity_ceilings:C
result: "qualified" | "blocked" | "unknown"
reason_code: exact str matching [a-z][a-z0-9_.-]{0,95}
evaluated_at:T
qualification_digest:H
```

Exactly one readiness ref/digest is bound. Qualification compares supplied profiles for one effect/fence; it does not identify or authenticate a host and does not launch one.

**8.&#x20;****`RW0TerminalOutcomeV1`**, fields in order:
```
schema_id: literal
outcome_value_ref:R
phase_basis_ref:R
phase_basis_digest:H
branch: "normal" | "active_cancel_reconciled" |
  "active_cancel_unresolved" | "pre_effect_cancel_basis_unusable"
outcome: "accept" | "repair" | "replan" | "terminal_reject" | "block" | "cancel"
decision_ref:R
decision_digest:H
decision_kind: "accept" | "repair" | "replan" | "terminal_reject" | "block" | "cancel"
program_head_revision:I
program_head_digest:H
work_item_head_revision:I
work_item_head_digest:H
selection_head_revision:I
selection_head_digest:H
effect_head_revision:I
effect_head_digest:H
delivery_head_revision:I
delivery_head_digest:H
global_stop_ref:R
global_stop_version:I
global_stop_state: "clear" | "active"
evidence_bindings: exact list of 0–32 exact [role:R, ref:R, digest:H] lists
latch_postimage_ref:R?
latch_postimage_digest:H?
reconciliation_ref:R?
reconciliation_digest:H?
mismatch_ref:R?
mismatch_digest:H?
outcome_value_digest:H
```

Evidence roles are the closed set `authority, custody, retrieval, host, delivery, worker, capsule, validation, review, model, reconciliation, mismatch`. The stored tuple is sorted by `(role, ref)`, with that pair unique; multiple distinct worker observations remain representable. The 32 ceiling reuses C2A’s evidence-ref limit. The optional pairs are present only in their applicable branches. These head digests are supplied current-state bindings, not a claim that B1 read authoritative state.

### Bounds, privacy, and error algebra

One complete B1 graph comprises one each of basis, authority observation, proposal, readiness, qualification, and terminal value; at most **two** custody observations (one per subject); and at most **three retrieval events per subject**. Its cumulative construction/reconstruction allowance is **1,436 occurrence-work units**, computed from the frozen field tuples:
```
2 × [
  Σ(1 + field_count of each of the eight classes)       = 238
  + (1 + 34) L34                                         = 35
  + (1 + 8×3) K8                                         = 25
  + 4×(1 + 15) Ceilings                                  = 64
  + 8×(1 + 3) path tuples                                = 32
  + (1 + 5) allowed-effect tuple                         = 6
  + (1 + 32×4) evidence triples                          = 129
  + (1 + 16) second custody value                        = 17
  + 5×(1 + 33) additional retrieval events               = 170
  + 2 retrieval-sequence tuple containers                = 2
] = 1,436
```

The factor two covers validation plus defensive reconstruction. Charge **every occurrence before descent**, including repeated references to a shared acyclic object; keep an active-object-ID set to reject cycles. A seen-object cache must not make shared-DAG expansion free. A single private budget is passed through construction/reconstruction of the complete graph. Existing supplied C2A and Section 41 objects remain subject to their own validators and budgets. The literal 1,436 and its formula are both pinned in tests; attacker-controlled sizes never define the allowance.

Only the named safe fields may enter canonical bytes or projections. Raw WorkSpec/plan bytes, bearer material, signatures, trust roots, credentials, host details, paths, prompts, transcripts, provider metadata, stdout/stderr, and support-bundle bodies have no field. A safe-ref *syntax* cannot prove a source did not disguise private data as an opaque identifier; source ownership and later ingest gates must enforce that semantic privacy condition. B1 rejects known private-material keys and input types and never echoes offending values.

`RW0PhaseValueError` is sealed and carries only a finite `reason` and a constant field label; it suppresses foreign exception chains. The exact reasons are:
```
invalid_field_type, missing_field, unknown_field, duplicate_field,
invalid_enum, malformed_ref, malformed_digest, invalid_timestamp_window,
invalid_length_or_cardinality, graph_cycle, cumulative_work_exhausted,
relation_mismatch, observation_stale_or_expired, authority_denied_or_revoked,
per_fence_basis_mismatch, common_family_unverified,
scope_or_ceiling_mismatch, current_head_or_global_stop_mismatch,
custody_subject_mismatch, retrieval_transition_invalid,
readiness_profile_mismatch, terminal_branch_mismatch,
privacy_forbidden_material
```

`duplicate_field` is reserved for a future duplicate-aware decoder; `from_mapping(dict)` cannot receive duplicates. Type, missing/unknown, enum, scalar, cardinality, self-digest, and graph errors arise during construction. Each relation below uses its named specific reason where applicable, otherwise `relation_mismatch`; no error contains supplied content.

## Exact pure relation inventory

All signatures are keyword-only, return `None` on a satisfied positive relation, and raise `RW0PhaseValueError` otherwise. `now_utc` is `T` supplied by the caller, not an authoritative clock reading. Every relation charges the shared B1 graph budget before traversing B1 values, compares both ref **and** digest, and revalidates supplied exact object types. It recomputes B1 self-digests and delegates existing digest validation to existing C2A/Section 41 validators; it does not manufacture source authenticity.

| Function and ordered argumentsPositive rule; fail-closed reason                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               |                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              |
| ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `validate_phase_entry_basis(basis: RW0PhaseEntryBasisV1, lineage: CanonicalC2B3DLineage, selection_result: PreExecutionPlanDispositionResultProjectionV1, selection_head: DevelopmentPreExecutionSelectionHeadRowValue, selected_proposal: DevelopmentModelProposalRowValue, selected_artifact: DevelopmentPrivateProposalArtifactBindingRowValue, work_spec: WorkSpecV1, attempt_fence: AttemptFenceV1, author_effect_fence: EffectFenceV1, author_command: WorkerCommandV1, author_delivery: DeliveryEnvelopeV1, effect_head: DevelopmentEffectHeadRowValue, delivery_head: DevelopmentDeliveryHeadRowValue, global_stop: GlobalStopCurrentRecordEnvelope)` | Exact L34 and derived K8; selected proposal, artifact, disposition and current selection-head postimage; WorkSpec safe binding; existing C2A authoring/delivery relations; effect/delivery heads and stop. Drift: `relation_mismatch` or `current_head_or_global_stop_mismatch`. No second selected-plan identity is derived.                                                                                                                                                                                                                                                                                                |
| `validate_authority_observation(basis, observation, attempt_fence, author_effect_fence, current_effect_fence, author_command, capsule_manifest: CandidateCapsuleManifestV1\|None, cancellation_target: EffectFenceV1\|None, now_utc)`                                                                                                                                                                                                                                                                                                                                                                                                                         | `verified`, `compatible`, `unrevoked`; source attribution present; `observed_at ≤ now < observation_expires_at`, `now < grant_expires_at`, and `now` before both applicable fence expiries; exact parent, current heads/stop, audience/repository/base/path/effect/scope and pointwise ceilings. Call the existing C2A effect relation when the current fence differs from the author fence. Denied/revoked: `authority_denied_or_revoked`; stale: `observation_stale_or_expired`; scope: `scope_or_ceiling_mismatch`; heads/stop: `current_head_or_global_stop_mismatch`.                                                   |
| `validate_per_fence_basis(observation, proposal, attempt_fence, current_effect_fence)`                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        | Attempt pair equals the persisted attempt-fence pair; effect pair equals the persisted **current** effect-fence pair; proposal repeats each exact pair and each fence ref/digest. Failure: `per_fence_basis_mismatch`. Do not require the two pairs to equal or differ.                                                                                                                                                                                                                                                                                                                                                      |
| `validate_common_parent_family(observation, proposal, attempt_fence, current_effect_fence)`                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   | The source observation claims `compatible`, and all four records bind the same parent ref/digest and asserted family ref/digest, while each role-specific basis remains exact. Failure: `common_family_unverified` or `per_fence_basis_mismatch`. This checks a supplied verifier claim; it cannot authenticate ancestry independently.                                                                                                                                                                                                                                                                                      |
| `validate_subordinate_narrowing(basis, observation, proposal, attempt_fence, current_effect_fence, now_utc)`                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  | Invoke the preceding authority/basis/family checks. Proposal audience, repository, base, three-path scope, stop, effect and parent bind exactly. Its single effect is within `allowed_effect_classes`; every ceiling is ≤ the verified parent and applicable fences; expiry is ≤ grant and both fences. **At least one** of effect-set reduction, a strictly smaller ceiling, or earlier expiry is required. Failure: `scope_or_ceiling_mismatch`, `per_fence_basis_mismatch`, `common_family_unverified`, or freshness/authority reasons. A parent already this narrow yields failure, not fabricated narrowing.            |
| `validate_custody_binding(basis, availability, subject_kind: str, subject_ref: str, subject_semantic_digest: str, content_sha256: str, byte_length: int, now_utc)`                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            | One exact `work_spec` or `selected_plan` subject; semantic pair equals respectively L34 WorkSpec or selected artifact; separately asserted byte pair matches the supplied physical-custody evidence; source claim is `available` and live. Failure: `custody_subject_mismatch` or `observation_stale_or_expired`. No bytes are read.                                                                                                                                                                                                                                                                                         |
| `validate_retrieval_event_sequence(basis, availability, observation, events: tuple[RW0RetrievalCapabilityEventObservationV1, ...], now_utc)`                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  | Exact built-in tuple of 1–3 events for one subject/correlation; exact semantic and byte subject, attempt/fences/effect/audience/repository/base/path and verification binding; sequence numbers contiguous from zero, predecessor ref/digest exact, times nondecreasing and before expiry. Legal transitions are the stated one-use grammar. Terminal `unknown`/`failed` never proves non-consumption or permits retry. Failure: `retrieval_transition_invalid`, `custody_subject_mismatch`, or freshness.                                                                                                                   |
| `validate_host_qualification(basis, observation, readiness, qualification, current_effect_fence, now_utc)`                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    | One exact live readiness observation and authority observation; all worker, protocol, Linux/architecture, identity, process, isolation, resource, cancellation, credential, capsule, tool, capacity and cleanup profile bindings equal the qualification’s required bindings; capacity ceilings dominate required and applicable effect ceilings; effect/fence/phase identities exact. A `qualified` result is consistent only when all checks pass. `blocked` and `unknown` remain representable evaluations but do not pass the progression gate. Failure: `readiness_profile_mismatch` or `observation_stale_or_expired`. |
| `validate_terminal_outcome(basis, outcome, decision: DevelopmentDecisionRowValue, program_head: DevelopmentProgramHeadRowValue, work_head: DevelopmentWorkItemHeadRowValue, selection_head: DevelopmentPreExecutionSelectionHeadRowValue, effect_head: DevelopmentEffectHeadRowValue, delivery_head: DevelopmentDeliveryHeadRowValue, global_stop: GlobalStopCurrentRecordEnvelope, committed_latch_postimage: tuple[str, str]\|None, reconciliation: tuple[str, str]\|None, mismatch: tuple[str, str]\|None)`                                                                                                                                                | Exact earlier decision ref/digest/kind and phase lineage; all supplied current head revisions/digests and stop match; evidence ref/digest bindings have no contradiction. Dispatch to the four branch checks below. Failure: `terminal_branch_mismatch` or `current_head_or_global_stop_mismatch`. The latch tuple is a C-supplied **already committed** safe postimage; B1 can compare it but cannot prove transaction atomicity.                                                                                                                                                                                           |
| `validate_normal_terminal_branch(outcome, decision, committed_latch_postimage)`                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               | `normal` allows only `accept,repair,replan,terminal_reject,block`, with exactly one same-kind prior C2B decision. `accept` requires exact accepted decision and matching non-null consumed-latch postimage; all other outcomes require null latch fields. Reconciliation/mismatch fields are null. Failure: `terminal_branch_mismatch`.                                                                                                                                                                                                                                                                                      |
| `validate_active_cancel_reconciled_branch(outcome, decision, reconciliation)`                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 | Earlier decision is `cancel`; outcome is `cancel`; non-null reconciliation pair denotes complete post-teardown reconciliation; no second cancel/block decision or latch field. Failure: `terminal_branch_mismatch`.                                                                                                                                                                                                                                                                                                                                                                                                          |
| `validate_active_cancel_unresolved_branch(outcome, decision, reconciliation)`                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 | Earlier decision is `cancel`; outcome is `block`; non-null unresolved reconciliation pair; no C2B block decision or latch field. Failure: `terminal_branch_mismatch`.                                                                                                                                                                                                                                                                                                                                                                                                                                                        |
| `validate_pre_effect_cancel_basis_unusable_branch(outcome, decision, mismatch)`                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               | Earlier decision is the unusable `cancel`; outcome is `block`; non-null current-head/stop/verification mismatch pair; no cancellation effect/request and no replacement C2B decision. Failure: `terminal_branch_mismatch`. The no-effect/no-request fact must be supplied and proved by RW0-C readback; B1 cannot infer it from absent fields.                                                                                                                                                                                                                                                                               |

The branch split follows [RW0-A’s decision and cancel rules (line 81)](</Users/ds/Repositories/Governed Execution Coordinator/.docs/rw0-remote-worker-contact-phase-entry.md:81>). Cancellation request, acknowledgement, signal, exit, teardown, and reconciliation remain distinct facts ([RW0-A timeline (line 250)](</Users/ds/Repositories/Governed Execution Coordinator/.docs/rw0-remote-worker-contact-phase-entry.md:250>)). No relation authorizes physical contact.

## Reuse and ownership ledger

- **Stored existing object:** the phase basis stores a defensively reconstructed `CanonicalC2B3DLineage` and K8 value. The authority observation, proposal, readiness, and qualification store reconstructed `CeilingsV1` values. B1 creates no competing L34, K8, plan, or ceiling grammar. Section 41 remains their source ([K8/L34 (line 48)](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/_development_pre_execution_plan_disposition_contracts.py:48>)).
- **Stored safe bindings only:** WorkSpec ref/digest/safe-projection digest, selected proposal and artifact bindings, disposition and selection head, attempt/candidate/effect/command/fence/delivery identities, current heads and stop are taken from existing C2A, C2B3D, and Section 41 identities. `WorkSpecV1`’s raw objective/requirements/exclusions are never stored in B1.
- **Validated supplied objects only:** `WorkSpecV1`, `AttemptFenceV1`, `EffectFenceV1`, `WorkerCommandV1`, `DeliveryEnvelopeV1`, and later `CandidateCapsuleManifestV1` are inputs to their existing C2A relations. `CapsuleEntryV1` is validated only through its supplied manifest. `WorkerObservationV1` remains its closed source-observation grammar; terminal evidence binds its safe ref/digest where applicable, without widening source or observation enums.
- **Decision/latch:** the existing `DevelopmentDecisionRowValue` supplies the decision kind/ref/digest and target bindings ([decision fields (line 35)](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/_development_decision_row_values.py:35>)). It has no latch-postimage field. B1 compares a C-supplied safe committed postimage; RW0-C must prove that `accept` consumed it atomically and must choose its durable representation.
- **Semantic versus bytes:** WorkSpec and selected-artifact semantic digests bind their existing contracts. Custodian `content_sha256` and `byte_length` are independent physical-byte assertions. Neither digest alone proves authenticity, availability, permission, or consumption.

## Module, files, and exclusions

Implement B1 in one new private module, [the proposed source path](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/_rw0_phase_entry_semantic_values.py>). Its order is: docstring; `datetime`, `hashlib`, `json`, `re`, `typing`; precise private C2A/Section 41 and row-value imports; empty `__all__: tuple[str, ...] = ()`; frozen constants/field tuples; sealed error; local bounded clone/canonical helpers; eight values in the order above; then pure relations. Use the existing controlled slotted immutable-value idiom, not a `NamedTuple` or a dataclass that could retain nested mutable inputs. Imports flow **from B1 to** existing pure contracts only. No existing production module imports B1 in this tranche; tests import it directly. One module needs one local canonical/budget implementation, so no generic helper module is warranted. The existing C2A source and golden bytes remain unchanged.

The **maximum future implementation touched-file allowlist** is exactly:
```
/Users/ds/Repositories/Governed Execution Coordinator/.docs/rw0-b1-pure-phase-values.md
/Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/_rw0_phase_entry_semantic_values.py
/Users/ds/Repositories/Governed Execution Coordinator/tests/test_rw0_b1_phase_values.py
/Users/ds/Repositories/Governed Execution Coordinator/tests/test_rw0_b1_relations.py
/Users/ds/Repositories/Governed Execution Coordinator/tests/test_rw0_b1_vectors.py
/Users/ds/Repositories/Governed Execution Coordinator/tests/test_rw0_b1_boundaries.py
/Users/ds/Repositories/Governed Execution Coordinator/tests/test_c2a_nonimplementation.py
/Users/ds/Repositories/Governed Execution Coordinator/tests/test_runtime_non_authority.py
/Users/ds/Repositories/Governed Execution Coordinator/.docs/rw0-remote-worker-contact-phase-entry.md
/Users/ds/Repositories/Governed Execution Coordinator/tests/test_rw0_remote_contact_phase_entry_contract.py
```

The last two permit only a bounded RW0-A status/successor clarification and its direct contract assertion. RW0-A currently says C2B3D and Section 41 are the complete implemented boundary ([status paragraph (line 19)](</Users/ds/Repositories/Governed Execution Coordinator/.docs/rw0-remote-worker-contact-phase-entry.md:19>)); that sentence needs qualification when B1 source exists. The four broader cross-reference documents’ “current implementation stops” wording is interpreted as the current **durable/runtime** boundary, which B1 does not advance. Their shared text is test-pinned ([RW0-A cross-reference test (line 369)](</Users/ds/Repositories/Governed Execution Coordinator/tests/test_rw0_remote_contact_phase_entry_contract.py:369>)); broad status normalization is outside this allowlist. If implementation proves those words to be a literal invariant about all pure source, stop and surface the allowlist conflict.

Protected byte-identical material includes [C2A source](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/_worker_execution_semantic_values.py>), [C2A governing contract](</Users/ds/Repositories/Governed Execution Coordinator/.docs/c2a-first-slice-semantic-protocol-contract.md>), [C2A golden-vector tests](</Users/ds/Repositories/Governed Execution Coordinator/tests/test_c2a1_pure_semantic_values.py>), [Section 41 implementation](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/_development_pre_execution_plan_disposition_contracts.py>), migrations 0001–0003 and application generation, [package root](</Users/ds/Repositories/Governed Execution Coordinator/src/ge_nwp_coordinator/__init__.py>), StateStore/WriterSession public surfaces, and [pyproject.toml](</Users/ds/Repositories/Governed Execution Coordinator/pyproject.toml>). Existing C2A schemas, digest domains, source/observation/effect enums, and vectors do not change. The two exact source-inventory tests require only the new private file added to their inventories ([C2A inventory (line 22)](</Users/ds/Repositories/Governed Execution Coordinator/tests/test_c2a_nonimplementation.py:22>), [runtime inventory (line 22)](</Users/ds/Repositories/Governed Execution Coordinator/tests/test_runtime_non_authority.py:22>)).

B1 excludes B2 framing, wire grammar/caps, stderr and Codex mechanism; RW0-C rows, receipts, guarded reads/writes, recovery, latch and durable outcome; RW0-D custodian/bearer transport, supervisor, worker, capsule and offline proof; RW0-E live host; ES admission/runtime/reliable submit; and external issuance, verification, revocation, host ownership, and custody. It adds no SQLite, filesystem, subprocess, network, model/provider, Bridge, ES call, public API, migration, or effect.

## Future validation and independent audit

No tests were run in this engagement. The implementation tranche should first collect pre-change node IDs, then collect post-change IDs with isolated temporary/cache locations and bytecode disabled. Require `before − after = ∅`; require `after − before` to be **exactly** the nodes in the four new B1 test files; require the count increase to equal that new-node count. Do not predeclare a count.

Run these future commands from the repository root, using a distinct external `--basetemp` for each invocation:
```
export PYTHONDONTWRITEBYTECODE=1 PYTEST_DISABLE_PLUGIN_AUTOLOAD=1
export TMPDIR=/tmp/rw0-b1-tmp XDG_CACHE_HOME=/tmp/rw0-b1-cache
python -m pytest -p no:cacheprovider --basetemp=/tmp/rw0-b1-collect-before --collect-only -q tests > /tmp/rw0-b1-before.nodes

# After implementation:
python -m pytest -p no:cacheprovider --basetemp=/tmp/rw0-b1-collect-after --collect-only -q tests > /tmp/rw0-b1-after.nodes
python -m pytest -p no:cacheprovider --basetemp=/tmp/rw0-b1-values -q tests/test_rw0_b1_phase_values.py
python -m pytest -p no:cacheprovider --basetemp=/tmp/rw0-b1-vectors -q tests/test_rw0_b1_vectors.py
python -m pytest -p no:cacheprovider --basetemp=/tmp/rw0-b1-relations -q tests/test_rw0_b1_relations.py
python -m pytest -p no:cacheprovider --basetemp=/tmp/rw0-b1-boundaries -q tests/test_rw0_b1_boundaries.py
python -m pytest -p no:cacheprovider --basetemp=/tmp/rw0-b1-inventories -q tests/test_c2a_nonimplementation.py tests/test_runtime_non_authority.py
python -m pytest -p no:cacheprovider --basetemp=/tmp/rw0-b1-c2a -q tests/test_c2a1_pure_semantic_values.py
python -m pytest -p no:cacheprovider --basetemp=/tmp/rw0-b1-rw0a -q tests/test_rw0_remote_contact_phase_entry_contract.py
python -m pytest -p no:cacheprovider --basetemp=/tmp/rw0-b1-full -q tests
git diff --check
git status --porcelain=v1 --untracked-files=all
```

The new tests must pin literal canonical vectors and digest domains independently of the implementation; each field’s maximum and one-over-limit; `bool` and hostile subclasses; unknown/missing keys; optional-pair symmetry; every enum; no normalization; source/Coordinator non-collapse; both equal and unequal *valid* per-fence basis pairs; strict versus non-strict narrowing; all retrieval transitions; stale windows; all four terminal branches; content-free error text/chains; shared-DAG and cycle exhaustion; the 1,436 budget; no-I/O AST/import inventory; empty exports; and package/public-surface stability. Include causal mutants that change one ref, one digest, one head, one stop version, one family assertion, one ceiling, or one branch fact while holding all other fields fixed.

Obtain six independent read-only reviews after implementation: authority/privacy; semantic identity and non-collapse; relations and hostile graph bounds; test adequacy and causal mutants; public boundary/artifact hygiene; and provenance. Compare protected-file hashes with the baseline, the exact touched-file allowlist, collected-node delta, Git diff, and clean external artifact locations.

**Implementation must stop** if it needs to change an existing C2A schema/vector/enum/domain; place private or bearer material in B1; treat a digest as authenticity or permission; invent a second selected plan or existing execution identity; require I/O/public/runtime code or B2 mechanics; exceed the allowlist; weaken an unjustified bound; combine source observation with Coordinator authority; or collapse readiness into qualification, availability into consumption, or the terminal value into a C2B decision.

REPOSITORY\_MUTATION\_NOT\_PERFORMED\
TESTS\_NOT\_RUN\
STAGING\_NOT\_PERFORMED\
COMMIT\_NOT\_PERFORMED\
PUSH\_NOT\_PERFORMED\
PR\_NOT\_CREATED\
REMOTE\_CONTACT\_NOT\_PERFORMED\
WORKER\_OR\_MODEL\_NOT\_INVOKED\
SUPPORTING\_REPOSITORIES\_NOT\_MODIFIED
