## Engineering review

### 1. Observable result and capability contribution

RW0-B1 will make one concrete capability current: **the Coordinator can locally construct, canonicalize, digest, and purely cross-check eight private phase-entry semantic value families without I/O or authority effects**. That capability will be observable through the new private module, literal canonical vectors, hostile-input tests, relation matrices, import inventories, and current-status documentation. It will not contact anything or persist anything. The reconciled packet itself correctly defines the slice as pure values and relations over supplied evidence, with no permission, contact, or durable state. 

Its downstream contribution is:

- **RW0-B2** receives stable semantic objects and identities to frame; B2 should not invent phase, authority, custody, readiness, or terminal semantics while designing bytes.
- **RW0-C** receives safe value shapes and relation inputs that it may later persist, reconcile, and bind to guarded receipts, evidence graphs, latch state, and terminal facts.
- **RW0-D** receives deterministic, already-separated semantic inputs for an offline custody, supervisor, worker, capsule, validation, review, and Codex proof.
- **RW0-E** receives readiness, effect-bound qualification, authority, custody, and phase correlations for one later live-host proof.

This result is non-disposable because every later implementation must share the same distinctions between identity, evidence, permission, readiness, qualification, availability, retrieval, C2B decision, and RW0 terminal outcome. Without B1, RW0-C or RW0-D would have to invent those distinctions inside durable-state or process code, hardening temporary runtime mechanics into semantic authority.

Still outside B1:

- source authenticity and trust-root verification;
- executable subordinate authorization;
- WorkSpec or selected-plan retrieval;
- physical custody and bearer handling;
- transport and framing;
- host contact;
- process, supervisor, worker, or Codex execution;
- capsule storage;
- terminal-outcome persistence;
- acceptance-latch representation or atomicity proof;
- ES admission or reliable submission;
- Git, publication, scheduling, service, queue, or autonomy.

### 2. Action-specific prerequisites

| Dependency | Later action blocked | Status and owner | Required before B1? |
|---|---|---|---|
| K8, full L34, selected proposal/artifact/disposition, selection-head postimage, current effect/delivery heads and global stop | Creating a valid phase-entry basis; consequently every later gate | Established by current C2B3D and Section 41 contracts | **The relation must be implemented now.** A live production selection family is not required to implement B1. |
| External authority observation versus subordinate proposal | WorkSpec retrieval and every effect launch | Parent authority and verifier evidence are externally owned; the proposal is Coordinator-authored but inert | **Schemas and pure relations now.** Authentic evidence, trust roots, revocation transport, and executable permission remain open. |
| Custody availability versus retrieval events | Out-of-band byte handoff and any process using the private inputs | Custodian/issuer facts are missing future evidence | **Semantic separation now.** Physical bytes, bearer issuance, and redemption mechanics remain RW0-D/E. |
| Host readiness versus effect-bound qualification | Contacting or launching on a remote host | Readiness is host-owned evidence; qualification is a Coordinator evaluation | **Value and relation shapes now.** Authenticity, host mechanism, and enforcement remain RW0-D/E. |
| Terminal outcome versus C2B decision and latch | Closing RW0, permitting a later phase, and eventually acceptance | Existing C2B grammar owns the decision; RW0-C will own durable outcome and latch proof | **Structural semantics now.** Persistence, evidence completeness, latch atomicity, and absence proofs remain RW0-C. |
| Current C2A path scope | Retrieval and launch for the selected work | Current C2A owns the path tuple; it is a compatibility edge, not permanent RW0 grammar | **Digest correlation now.** Any future path-set widening requires a separate C2A decision. |
| Scalar and collection bounds | Safe construction and later durable compatibility | Most ref/hash/time/artifact limits derive from current owners; retrieval cardinality and WorkSpec byte length are new B1 policy | **Must be frozen for B1.** The WorkSpec `2^63−1` limit is representational, not a transport or allocation allowance. |
| Traversal and graph-work budgets | Hostile constructor/relation inputs | Newly selected B1 engineering limits | **Must be implemented now.** A mechanical undercount is an ordinary freeze correction, not permission to widen silently. |

The important timing distinction is that B1 must encode the prerequisite **relationships**, but it does not need the later real-world evidence. Constructors should represent denied, unknown, unavailable, unready, failed, revoked, and diagnostic states; only the appropriate progression relation rejects them.

### 3. Owning-contract conflict review

**C2A and C2A1 — resolved for B1.**  
The design leaves existing schema IDs, ordered fields, digest domains, path tuple, source kinds, observation kinds, effect classes, relations, and golden vectors unchanged. B1 composes supplied C2A objects and preserves C2A canonical Unicode behavior rather than importing Section 41 normalization. The exact-type and canonicalization rules in the freeze are consistent with that ownership. 

**Section 41 selection — resolved for B1.**  
K8, L34, proposal/artifact/disposition, and selection-head identity remain Section 41-owned. B1 creates a phase-basis identity that binds them; it does not create a second selected plan or selection head.

**C2B3D author-effect establishment — resolved for B1.**  
The existing author attempt, candidate, author effect, command, fences, and planned delivery remain exact inputs. B1 neither relaunches nor replaces them. Later current-effect semantics remain distinct.

**Current development-decision grammar — resolved for B1.**  
The B1 terminal value is not a `development_decision`. The exact five structural branch rows preserve the existing pre-effect `cancel` decision and same-kind non-cancel decisions. RW0-C remains responsible for proving the durable evidence relation and latch postimage.

**RW0-A authority, custody, cancellation, outcome, and acceptance semantics — resolved for B1.**  
The reconciled relations correctly limit B1 to supplied-claim shape, identity, freshness, narrowing, branch structure, and deterministic evaluation. B1 does not claim source authentication, permission, effect/request absence, reconciliation completeness, or latch atomicity. The relation inventory explicitly assigns those later proofs to RW0-C or external owners. 

**Explicitly deferred without blocking B1:**

- verifier deployment and trust;
- physical scenario-profile content;
- custodian and capability mechanics;
- host authenticity and sandboxing;
- evidence-set membership and completeness;
- durable terminal and latch representation;
- framing and practical payload limits;
- process and Codex mechanics.

**No remaining owning-contract contradiction blocks implementation.**

The most mechanically fragile portion is the exact traversal-budget arithmetic. The replacement prompt preserves it as frozen policy but requires Codex to stop rather than adjust a number if the final field graph cannot be implemented within it. The budgets are engineering safeguards, not current C2A authority. 

### 4. Prospective forecasts

The original pre-execution forecast remains recorded unchanged:

> **98%** that RW0-B1 was ready for the bounded implementation turn; **96%** that the remaining risk was implementation/test correctness rather than an unresolved operating-model or authority decision.

This review does not retrospectively revise those figures.

Additional falsifiable forecasts:

1. **The likeliest implementation blocker is mechanical rather than architectural:** one relation budget, exact nested reconstruction count, or exact imported owner API will not match the frozen formula on the first implementation attempt. Evidence would be a largest-valid fixture exhausting early or a required field traversal exceeding its literal budget.

2. **The sixteen-path allowlist is likely sufficient.** The most likely pressure for expansion is a stale current-status assertion in another living owner or source-inventory test—not a need for another production module. A required seventeenth production, schema, configuration, or package path would falsify this forecast and trigger replanning.

3. **Independent audit is likely to concentrate on four classes of counterexample:** digest-as-permission collapse, invalid source claims accidentally becoming progression-eligible, path-scope digest becoming an alternate path authority, and terminal-shape tests overclaiming evidence completeness or latch atomicity.

Architectural replanning—not an ordinary repair—would be required if implementation needs:

- a new or changed C2A schema, enum, digest domain, path grammar, or golden vector;
- a concrete scenario-profile value class;
- a durable evidence graph or absence proof in B1;
- a production consumer during B1;
- framing, filesystem, process, network, provider, ES, or public API behavior.

### 5. Engineering disposition

**Retain the reconciled design; revise the implementation handoff before execution.**

The replacement prompt:

- explicitly supersedes the unexecuted draft;
- is self-contained rather than depending on the preceding Codex response;
- freezes all eight schemas, relations, budgets, errors, and touched paths;
- distinguishes representability from progression eligibility;
- distinguishes representational integer bounds from practical runtime caps;
- states what later tranche consumes each result;
- prevents later evidence prerequisites from being pulled into early constructors;
- preserves the exact baseline, sixteen-path ceiling, validation, provenance, audit separation, and stop conditions.

:chatgpt-content-reference{index="2"}

---

## BEGIN COMPLETE REPLACEMENT CODEX PROMPT

````text
TITLE

Coordinator RW0-B1 — implement private pure phase-entry semantic values and
relations

SUPERSESSION

This prompt completely supersedes the previously issued draft titled:

Coordinator RW0-B1 — implement private pure phase-entry semantic values and
relations

The previous draft has not been executed and MUST NOT be used, merged, quoted
as authority, or combined with this prompt. Use only this complete replacement.

ENGAGEMENT TYPE

Parent-only workspace-write implementation of the reconciled RW0-B1 design.

This is one bounded implementation tranche in the Coordinator repository.
Do not create or resume subagents. You are the sole repository writer.

This engagement authorizes:

- creating one local feature branch from the exact baseline;
- editing or creating only the exact sixteen allowlisted paths below;
- running isolated local validation;
- creating external implementation evidence and exact patch provenance.

This engagement does not authorize:

- staging, commit, push, PR creation, merge, tag, release, or deployment;
- remote contact or fetch;
- changes to supporting repositories;
- installation or dependency changes;
- SQLite, migration, filesystem, subprocess, network, provider/model, Bridge,
  ES, worker, adapter, service, queue, scheduler, or public API behavior;
- an independent audit.

REPOSITORY

/Users/ds/Repositories/Governed Execution Coordinator/

OPENING BASELINE

Require exactly before branch creation or mutation:

- physical root:
  /Users/ds/Repositories/Governed Execution Coordinator/
- branch:
  trunk_dev
- HEAD:
  bf68a5232bff1b412c9414c076d82cab18c8e0aa
- tree:
  8fc05f5626bdbb01808df1698c9c2245ab06f1cb
- sole parent:
  1a894c5527c610ab40d8e5ae5e530a762c6e60bf
- subject:
  docs: freeze RW0-A phase-entry contract (#2)
- upstream:
  origin/trunk_dev
- ahead/behind:
  0/0
- worktrees:
  1
- worktree/index/untracked/unmerged:
  clean
- no Git operation or lock
- no repository residue

Do not fetch. Stop without mutation on any mismatch.

FEATURE BRANCH

Require that no local branch named:

codex/rw0-b1-pure-phase-values-v1

already exists.

Create exactly that local branch from the baseline and set its upstream to the
existing local remote-tracking ref `origin/trunk_dev` without contacting the
remote.

After branch creation require:

- branch:
  codex/rw0-b1-pure-phase-values-v1
- HEAD remains the exact baseline commit;
- upstream:
  origin/trunk_dev
- ahead/behind:
  0/0
- clean state.

OBJECTIVE AND OBSERVABLE RESULT

Implement one private, local, deterministic, standard-library-only, no-I/O
semantic layer whose observable result is exactly:

- one private module importable only by direct tests in this tranche;
- eight immutable closed-world value classes;
- deterministic canonical identity bytes and domain-separated SHA-256 digests;
- pure relation validators over supplied C2A, C2B3D, Section 41, head, decision,
  and global-stop values;
- content-free failure reasons;
- finite per-value and per-relation traversal budgets;
- exact current-status documentation and contract tests saying that B1 pure
  semantics are implemented while persistence and executable/runtime
  capability remain absent.

The result is a reusable semantic foundation:

- RW0-B2 may frame and transport these semantic identities and values, but B1
  defines no wire decoder, frame, terminal-result wire grammar, or process cap;
- RW0-C may later persist selected safe B1 projections and prove guarded
  readback, evidence completeness, terminal facts, and latch behavior, but B1
  defines no row, table, receipt, graph, writer operation, or recovery protocol;
- RW0-D may later consume validated B1 values as offline process/custody/worker
  proof inputs, but B1 performs no custody, bearer redemption, process launch,
  worker action, Codex invocation, capsule operation, or validation/review/model
  execution;
- RW0-E may later consume authority, readiness, qualification, and custody
  correlations in one live-host proof, but B1 authenticates none of those
  external facts and contacts no host;
- ES retains ES-route admission, reliable submit, lifecycle, cancellation,
  runtime identity, and retained-result authority.

Do not describe B1 as worker contact, executable authorization, physical
custody, terminal-outcome persistence, latch implementation, route admission,
or operating autonomy.

CURRENT VERSUS TARGET

Current baseline remains:

- C2A/C2A1 private pure semantic values and relations;
- private C2B2 values/readers;
- private VS1B genesis;
- private C2B3D inert author-effect establishment and planned initial delivery;
- private Section 41 pre-execution selection;
- application generation 2, migration tip 0003;
- no phase-entry persistence, verifier authenticity, custody runtime, host
  qualification runtime, transport, worker, terminal-outcome runtime, latch,
  Git, ES route, service, queue, scheduler, or autonomous loop.

RW0-B1 adds only private semantic representability and pure validation over
supplied facts. It is not a runtime, permission issuer, persistence surface,
wire protocol, capability registry, or public API.

ACTION-SPECIFIC PREREQUISITE POSTURE

Implement the following ownership distinctions exactly. Do not pull a later
effect's evidence prerequisite into an earlier constructor merely because it
matters to the complete RW0 phase.

1. Section 41 lineage

   - Exact K8, full L34, selected proposal/artifact/disposition, selection-head
     postimage, C2A WorkSpec/attempt/effect/command/fence/delivery identity,
     current heads, and global stop are current owning-contract inputs.
   - They block a valid phase-entry basis and therefore any later contact gate.
   - Their schema relation MUST be implemented in B1.
   - A live production K8 family is not required to implement or unit-test B1;
     tests use exact pure fixtures.

2. Authority observation and subordinate proposal

   - External standing policy/verifier owns parent-grant and family claims.
   - Coordinator owns only an inert narrower proposal.
   - Actual source authenticity, trust root, revocation transport, and
     executable permission are missing later evidence/mechanics and may remain
     open through B1.
   - Constructors MUST represent `verified`, `denied`, and `unknown`; the
     progression relation passes only the exact current verified case.

3. Custody and retrieval

   - Custodian/issuer owns availability and event claims.
   - Availability, issuance, redemption, consumption, expiry, revocation,
     failure, and unknown remain separate facts.
   - Physical bytes, bearer possession, and source authenticity remain RW0-D/E
     or external-custodian concerns.
   - Constructors MUST represent unavailable/unknown and diagnostic terminal
     events; no such representation implies permission or retry.

4. Readiness and qualification

   - Host owner authors readiness.
   - Coordinator computes one pure effect-bound qualification over supplied
     claims.
   - Host authenticity and physical enforcement remain later work.
   - The qualification relation validates the claimed result/reason pair for
     all closed outcomes; it does not itself launch or persist anything.

5. Terminal outcome and C2B decisions/latch

   - Existing C2B decision grammar remains unchanged.
   - B1 terminal values are structurally distinct from C2B decisions and from
     RW0-C's future durable terminal fact.
   - B1 binds supplied decision/head/stop/evidence-set and branch-specific safe
     pairs only.
   - RW0-C later proves evidence completeness, latch atomicity, reconciliation
     completeness or ambiguity, and presence/absence through guarded readback.
   - B1 MUST NOT claim those proofs.

6. Path scope

   - Current C2A path validation is an active compatibility edge.
   - B1 owns no path list or permanent RW0 path grammar.
   - B1 computes only the frozen path-scope binding digest from the exact
     supplied validated C2A tuple.

7. Bounds

   - Safe refs, hashes, timestamps, existing C2A ceilings, Section 41 revision,
     and selected-artifact byte length derive from their owners.
   - Retrieval sequence cardinality, WorkSpec asserted byte-length maximum,
     and all B1 traversal budgets are newly selected B1 policy.
   - The WorkSpec `2^63−1` byte-length bound is representational/durable-
     compatibility only; it is not an admissible transport or allocation cap.
   - Practical wire/process/output limits remain B2/D.
   - If a frozen traversal formula undercounts the exact final schema, stop and
     report the mechanical contradiction; do not silently increase it.

COMMON VALUE CONTRACT

All eight classes live in:

src/ge_nwp_coordinator/_rw0_phase_entry_semantic_values.py

Each class:

- has `from_mapping(payload: dict[str, object])` accepting an exact built-in
  `dict` only;
- has a fixed ordered `_FIELDS` tuple;
- uses immutable slots;
- disables subclassing and pickling;
- has constant content-free `repr` and `str`;
- requires every listed key, including nullable keys;
- rejects unknown keys before missing keys;
- checks exact built-in member types and rejects hostile subclasses;
- defensively reconstructs mutable nested inputs;
- exposes `to_mapping()` with fresh safe built-ins in `_FIELDS` order;
- exposes `identity_mapping()` omitting only its own final digest field;
- exposes canonical identity bytes and `computed_digest()`;
- contains no decoder. A later decoder must reject duplicate object keys before
  calling `from_mapping`.

Type notation:

- `R`: exact `str`; C2A safe-ref grammar, 1–96 ASCII characters with existing
  pattern and forbidden prefixes.
- `H`: exact `str`; 64 lowercase hexadecimal characters.
- `T`: exact `str`; UTC second `YYYY-MM-DDTHH:MM:SSZ`.
- `N`: exact nonnegative `int`; no blanket new upper bound. `bool` and integer
  subclasses fail. Copied values are checked by their owning validators.
- `S41N`: exact `int`, `0..2^63-1`, for Section 41 selection revision.
- `BL`: exact positive `int`; selected plan `1..65_536` from the artifact owner;
  WorkSpec `1..2^63-1` as the explicit new B1 representational compatibility
  limit.
- `Q`: exact `int`, `0..2`, for the three-position retrieval sequence.
- `C`: exact `dict`, defensively reconstructed exact `CeilingsV1` with all 15
  existing field-specific rules.
- `E`: exact `list[str]`, stored as sorted unique tuple of 1–5 existing C2A
  effect classes.
- `L34`: exact `dict`, defensively reconstructed exact
  `CanonicalC2B3DLineage`.
- `K8`: exact list of eight exact two-item string lists, stored as the existing
  ordered tuple of eight `(field_name, safe_ref)` pairs.
- `R?`/`H?`: exact `None` or stated scalar; every nullable ref/digest pair is
  jointly present or jointly absent.

Canonical identity bytes:

`json.dumps(identity_mapping, ensure_ascii=False, allow_nan=False,
             sort_keys=True, separators=(",", ":")).encode("utf-8", "strict")`

No NFC/NFKC or other Unicode normalization occurs.

Each class's schema ID is fixed. Its digest domain is exactly the schema ID plus
`.identity`. The stored digest is:

`SHA256(domain_utf8 + b"\x00" + canonical_identity_bytes)`

The final field of each class is its sole self-digest.

EXACT CLASS INVENTORY

1. `RW0PhaseEntryBasisV1`

Schema:
`governed-execution.nwp-rw0-phase-entry-basis.v1`

Owner/posture:
Coordinator; inert no-contact semantic input, not a claim receipt or launch
authority.

Ordered fields:

```text
schema_id: literal
basis_ref: R
c2b3d_lineage: L34
selection_key: K8
selected_proposal_ref: R
selected_proposal_digest: H
selected_artifact_ref: R
selected_artifact_digest: H
selected_artifact_binding_digest: H
selected_plan_safe_projection_digest: H
disposition_ref: R
disposition_digest: H
disposition: "selected_for_dispatch_gates"
selection_head_revision: S41N
selection_head_digest: H
current_effect_head_revision: N
current_effect_head_state: "ready_for_delivery" | "delivery_pending" |
  "delivery_outcome_unknown" | "observed" |
  "cancellation_effect_established" | "terminal"
current_effect_head_digest: H
current_delivery_head_revision: N
current_delivery_head_state: "planned" | "submitted" | "outcome_unknown" |
  "acknowledged" | "rejected" | "completed"
current_delivery_head_digest: H
global_stop_ref: R
global_stop_version: N
global_stop_state: "clear" | "active"
path_scope_digest: H
basis_digest: H
```

L34 owns complete program/work/WorkSpec and execution lineage. K8 is derived
from L34. `selection_head_digest` binds the existing head postimage; B1 creates
no second selected-plan identity.

2. `RW0AuthorityVerificationObservationV1`

Schema:
`governed-execution.nwp-rw0-authority-verification-observation.v1`

Owner/posture:
External verifier; safe source claim unauthenticated by B1.

Ordered fields:

```text
schema_id: literal
observation_ref: R
source_ref: R
evidence_ref: R
evidence_digest: H
phase_basis_ref: R
phase_basis_digest: H
parent_grant_ref: R
parent_grant_digest: H
grant_family_ref: R
grant_family_digest: H
attempt_basis_ref: R
attempt_basis_digest: H
effect_basis_ref: R
effect_basis_digest: H
attempt_fence_ref: R
attempt_fence_digest: H
effect_fence_ref: R
effect_fence_digest: H
audience_ref: R
repository_ref: R
base_git_object_format: "sha1"
base_git_oid: exact 40-character lowercase hexadecimal string
path_scope_digest: H
allowed_effect_classes: E
effect_class: one existing deliverable C2A effect class
parent_ceilings: C
status: "verified" | "denied" | "unknown"
family_status: "compatible" | "incompatible" | "unknown"
revocation_status: "unrevoked" | "revoked" | "unknown"
grant_expires_at: T
observed_at: T
observation_expires_at: T
current_effect_head_digest: H
current_delivery_head_digest: H
global_stop_ref: R
global_stop_version: N
global_stop_state: "clear" | "active"
observation_digest: H
```

The two basis pairs are role-specific and may be equal or different. Family
compatibility is a verifier claim, not derived from digest equality.

3. `RW0SubordinateAuthorizationProposalV1`

Schema:
`governed-execution.nwp-rw0-subordinate-authorization-proposal.v1`

Owner/posture:
Coordinator; inert strict-narrowing proposal, not an issued grant, bearer,
permission, or fence replacement.

Ordered fields:

```text
schema_id: literal
proposal_ref: R
phase_basis_ref: R
phase_basis_digest: H
verification_ref: R
verification_digest: H
parent_grant_ref: R
parent_grant_digest: H
grant_family_ref: R
grant_family_digest: H
attempt_basis_ref: R
attempt_basis_digest: H
effect_basis_ref: R
effect_basis_digest: H
attempt_fence_ref: R
attempt_fence_digest: H
effect_fence_ref: R
effect_fence_digest: H
audience_ref: R
repository_ref: R
base_git_object_format: "sha1"
base_git_oid: exact 40-character lowercase hexadecimal string
path_scope_digest: H
effect_class: one existing deliverable C2A effect class
ceilings: C
expires_at: T
global_stop_ref: R
global_stop_version: N
proposal_digest: H
```

Only observation and proposal carry the family pair. Existing fences carry
parent-grant and role-specific authorization pairs, not family fields.

4. `RW0CustodyAvailabilityObservationV1`

Schema:
`governed-execution.nwp-rw0-custody-availability-observation.v1`

Owner/posture:
Physical custodian; safe availability and asserted-byte claim.

Ordered fields:

```text
schema_id: literal
observation_ref: R
source_ref: R
evidence_ref: R
evidence_digest: H
phase_basis_ref: R
phase_basis_digest: H
subject_kind: "work_spec" | "selected_plan"
subject_ref: R
subject_semantic_digest: H
content_sha256: H
byte_length: BL
availability: "available" | "unavailable" | "unknown"
observed_at: T
expires_at: T
observation_digest: H
```

Semantic digest and raw-byte hash are distinct. No bytes are retained.

5. `RW0RetrievalCapabilityEventObservationV1`

Schema:
`governed-execution.nwp-rw0-retrieval-capability-event-observation.v1`

Owner/posture:
Issuer/custodian; source event with non-bearer correlation only.

Ordered fields:

```text
schema_id: literal
event_ref: R
source_ref: R
evidence_ref: R
evidence_digest: H
phase_basis_ref: R
phase_basis_digest: H
safe_correlation_ref: R
subject_kind: "work_spec" | "selected_plan"
subject_ref: R
subject_semantic_digest: H
content_sha256: H
byte_length: BL
semantic_attempt_ref: R
attempt_fence_ref: R
attempt_fence_digest: H
effect_intent_ref: R
effect_fence_ref: R
effect_fence_digest: H
audience_ref: R
repository_ref: R
base_git_object_format: "sha1"
base_git_oid: exact 40-character lowercase hexadecimal string
path_scope_digest: H
authority_observation_ref: R
authority_observation_digest: H
subordinate_proposal_ref: R
subordinate_proposal_digest: H
custody_observation_ref: R
custody_observation_digest: H
event_kind: "issued" | "redeemed" | "consumed" | "expired" | "revoked" |
  "failed" | "unknown"
predecessor_event_ref: R?
predecessor_event_digest: H?
sequence_number: Q
occurred_at: T
expires_at: T
event_digest: H
```

No bearer, credential, token, endpoint, host path, or retrieval material exists
in the value.

6. `RW0RemoteHostReadinessObservationV1`

Schema:
`governed-execution.nwp-rw0-remote-host-readiness-observation.v1`

Owner/posture:
Host-owning source; safe profile claim, not host identity or permission.

Ordered fields:

```text
schema_id: literal
observation_ref: R
source_ref: R
evidence_ref: R
evidence_digest: H
safe_host_correlation_ref: R
status: "ready" | "unready" | "unknown"
platform: "linux"
platform_profile_ref: R
platform_profile_digest: H
architecture_profile_ref: R
architecture_profile_digest: H
worker_artifact_ref: R
worker_artifact_digest: H
worker_protocol_ref: R
worker_protocol_digest: H
execution_identity_profile_ref: R
execution_identity_profile_digest: H
process_profile_ref: R
process_profile_digest: H
isolation_profile_ref: R
isolation_profile_digest: H
resource_profile_ref: R
resource_profile_digest: H
cancellation_profile_ref: R
cancellation_profile_digest: H
credential_handoff_profile_ref: R
credential_handoff_profile_digest: H
capsule_store_profile_ref: R
capsule_store_profile_digest: H
validation_tool_profile_ref: R
validation_tool_profile_digest: H
review_tool_profile_ref: R
review_tool_profile_digest: H
cleanup_profile_ref: R
cleanup_profile_digest: H
observed_at: T
expires_at: T
observation_digest: H
```

There is no `CeilingsV1` host-capacity field and no hostname, IP, endpoint,
username, host key, credential, absolute path, or invented architecture enum.

7. `RW0EffectHostQualificationV1`

Schema:
`governed-execution.nwp-rw0-effect-host-qualification.v1`

Owner/posture:
Coordinator; deterministic evaluation of one supplied readiness claim for one
effect. It authenticates neither host nor scenario profile.

Ordered fields:

```text
schema_id: literal
qualification_ref: R
phase_basis_ref: R
phase_basis_digest: H
effect_intent_ref: R
effect_fence_ref: R
effect_fence_digest: H
verification_ref: R
verification_digest: H
readiness_ref: R
readiness_digest: H
required_scenario_profile_ref: R
required_scenario_profile_digest: H
required_platform_profile_ref: R
required_platform_profile_digest: H
required_architecture_profile_ref: R
required_architecture_profile_digest: H
required_worker_artifact_ref: R
required_worker_artifact_digest: H
required_worker_protocol_ref: R
required_worker_protocol_digest: H
required_execution_identity_profile_ref: R
required_execution_identity_profile_digest: H
required_process_profile_ref: R
required_process_profile_digest: H
required_isolation_profile_ref: R
required_isolation_profile_digest: H
required_resource_profile_ref: R
required_resource_profile_digest: H
required_cancellation_profile_ref: R
required_cancellation_profile_digest: H
required_credential_handoff_profile_ref: R
required_credential_handoff_profile_digest: H
required_capsule_store_profile_ref: R
required_capsule_store_profile_digest: H
required_validation_tool_profile_ref: R
required_validation_tool_profile_digest: H
required_review_tool_profile_ref: R
required_review_tool_profile_digest: H
required_cleanup_profile_ref: R
required_cleanup_profile_digest: H
result: "qualified" | "blocked" | "unknown"
reason: QualificationReason
evaluated_at: T
qualification_digest: H
```

Exact `QualificationReason` domain:

```text
qualified
readiness_unready
readiness_unknown
readiness_expired
authority_not_verified
authority_denied_or_revoked
authority_expired
phase_or_effect_mismatch
worker_artifact_mismatch
worker_protocol_mismatch
platform_or_architecture_mismatch
profile_mismatch
global_stop_active
unknown
```

Constructor matrix:

- `qualified` permits only `qualified`;
- `unknown` permits only `unknown`;
- `blocked` permits exactly the twelve blocking reasons.

Exact relation precedence and output pair:

- phase/effect/fence mismatch
  -> `blocked / phase_or_effect_mismatch`
- active global stop
  -> `blocked / global_stop_active`
- authority denied or revoked
  -> `blocked / authority_denied_or_revoked`
- expired authority/grant/observation window
  -> `blocked / authority_expired`
- unknown authority or revocation status
  -> `unknown / unknown`
- incompatible/unknown family claim or structurally unestablished common-family
  claim
  -> `blocked / authority_not_verified`
- expired readiness
  -> `blocked / readiness_expired`
- readiness unready
  -> `blocked / readiness_unready`
- readiness unknown
  -> `blocked / readiness_unknown`
- worker artifact mismatch
  -> `blocked / worker_artifact_mismatch`
- worker protocol mismatch
  -> `blocked / worker_protocol_mismatch`
- platform or architecture profile mismatch
  -> `blocked / platform_or_architecture_mismatch`
- any remaining required profile-pair mismatch
  -> `blocked / profile_mismatch`
- otherwise
  -> `qualified / qualified`

Equal-time expiry is expired.

`required_scenario_profile_ref/digest` is a Coordinator-owned evaluation-context
binding. It has no host-readiness counterpart and no B1 scenario-profile class.
If implementation would require such a class, stop.

8. `RW0TerminalOutcomeV1`

Schema:
`governed-execution.nwp-rw0-terminal-outcome-value.v1`

Owner/posture:
Coordinator; proposed pure value distinct from C2B decision and RW0-C's future
durable terminal fact.

Ordered fields:

```text
schema_id: literal
outcome_value_ref: R
phase_basis_ref: R
phase_basis_digest: H
branch: "normal" | "active_cancel_reconciled" |
  "active_cancel_unresolved" | "pre_effect_cancel_basis_unusable"
outcome: "accept" | "repair" | "replan" | "terminal_reject" | "block" |
  "cancel"
decision_ref: R
decision_digest: H
decision_kind: "accept" | "repair" | "replan" | "terminal_reject" |
  "block" | "cancel"
program_head_revision: N
program_head_digest: H
work_item_head_revision: N
work_item_head_digest: H
selection_head_revision: S41N
selection_head_digest: H
effect_head_revision: N
effect_head_digest: H
delivery_head_revision: N
delivery_head_digest: H
global_stop_ref: R
global_stop_version: N
global_stop_state: "clear" | "active"
evidence_set_ref: R
evidence_set_digest: H
latch_postimage_ref: R?
latch_postimage_digest: H?
reconciliation_ref: R?
reconciliation_digest: H?
mismatch_ref: R?
mismatch_digest: H?
outcome_value_digest: H
```

Exact branch matrix:

- `normal`, `accept -> accept`: latch pair required; reconciliation and mismatch
  absent.
- `normal`, same-kind `repair`, `replan`, `terminal_reject`, or `block`: all
  three optional pairs absent.
- `active_cancel_reconciled`, `cancel -> cancel`: reconciliation pair required;
  latch/mismatch absent.
- `active_cancel_unresolved`, `cancel -> block`: reconciliation pair required;
  latch/mismatch absent.
- `pre_effect_cancel_basis_unusable`, `cancel -> block`: mismatch pair required;
  latch/reconciliation absent.

The evidence-set pair binds a later C-owned set. B1 defines no evidence-member
graph, completeness test, durable readback, latch atomicity proof,
reconciliation completeness proof, or effect/request absence proof.

PATH-SCOPE CORRELATION

B1 owns no path list or path policy.

Exact domain:

`governed-execution.nwp-rw0-current-path-scope-binding.v1.identity`

Digest:

`SHA256(domain_utf8 + NUL + canonical compact JSON array of the exact supplied,
validated C2A path tuple)`

Relations recompute the digest from supplied `WorkSpecV1` and applicable C2A
fence path tuples after their owning validators establish consistency. The
digest is correlation only, not a replacement identity or permission.

The current C2A three-path set is a compatibility edge, not permanent RW0
grammar. Strict subordinate narrowing uses effect-set reduction, a lower
ceiling, or earlier expiry—not path-subset mechanics in this slice.

VALUE VALIDITY VERSUS PROGRESSION ELIGIBILITY

Keep representation and progression checks distinct:

- constructors accept every closed enum state, including denied, unknown,
  unavailable, unready, blocked, failed, revoked, expired, and diagnostic
  unknown states when their shape is valid;
- `validate_authority_observation` is a current progression check and passes
  only verified/compatible/unrevoked/fresh input;
- `validate_custody_binding` is a current progression check and passes only a
  live `available` claim for the exact subject;
- `validate_retrieval_event_sequence` validates both successful and diagnostic
  legal sequences; terminal failure/unknown never grants retry or progression;
- `validate_host_qualification` validates that the supplied qualification pair
  equals the deterministic result for supplied claims. A later progression
  gate may require `qualified`; B1 itself does not launch;
- terminal branch validators check structural binding only.

EXACT PURE RELATIONS

Every function is keyword-only, returns `None` on its stated positive relation,
and otherwise raises `RW0PhaseValueError`.

`now_utc` is a caller-supplied exact `T`; it is not proof of clock authority.
B1 recomputes B1 digests/path binding, delegates supplied exact objects to their
owners, and never authenticates source claims.

1. `validate_phase_entry_basis(basis, lineage, selection_result,
   selection_head, selected_proposal, selected_artifact, work_spec,
   attempt_fence, author_effect_fence, author_command, author_delivery,
   effect_head, delivery_head, global_stop)`

   Require exact L34/K8, selected disposition/head postimage, WorkSpec binding,
   existing C2A authoring/delivery relations, current heads/stop, and recomputed
   path binding. Fail with `relation_mismatch`,
   `path_scope_binding_mismatch`, or
   `current_head_or_global_stop_mismatch`.

2. `validate_authority_observation(basis, observation, attempt_fence,
   author_effect_fence, current_effect_fence, author_command,
   capsule_manifest: CandidateCapsuleManifestV1 | None,
   cancellation_target: EffectFenceV1 | None, now_utc)`

   Require verified/compatible/unrevoked; `observed_at <= now <
   observation_expires_at`; now before grant and applicable fence expiries;
   exact parent, fence, audience, repository, base, current effect, ceilings,
   heads/stop, and path binding. Use existing C2A effect relation when current
   effect differs from author effect. This validates a verifier claim.

3. `validate_per_fence_basis(observation, proposal, attempt_fence,
   current_effect_fence)`

   Each observation/proposal authorization pair equals its corresponding
   persisted fence pair and each fence ref/digest. Do not require the two basis
   pairs to equal or differ. Fail `per_fence_basis_mismatch`.

4. `validate_external_common_family_claim(observation, proposal,
   attempt_fence, current_effect_fence)`

   Observation claims compatible; observation/proposal family pairs agree;
   parent pairs agree with both fences' existing parent-grant pairs; each
   role-specific basis pair agrees with its fence. Neither fence stores a family
   pair. This does not independently prove ancestry. Fail
   `common_family_unverified` or `per_fence_basis_mismatch`.

5. `validate_subordinate_narrowing(basis, observation, proposal,
   attempt_fence, current_effect_fence, now_utc)`

   Require current authority/basis/family conditions, same phase/audience/
   repository/base/stop/parent/path binding, proposed effect in observed set,
   every proposal ceiling <= parent and both applicable fences, and proposal
   expiry <= parent and both fences. Require at least one strict effect-set,
   ceiling, or expiry reduction. Fail with specific authority/freshness/basis/
   family/scope reasons.

6. `validate_custody_binding(basis, availability, subject, now_utc)`

   Subject is exact `WorkSpecV1` or
   `DevelopmentPrivateProposalArtifactBindingRowValue` selected by subject kind.
   Require exact semantic ref/digest and phase; selected-plan byte length equals
   artifact canonical byte length; claim is available and live. Content SHA is
   still a custodian assertion. Fail `custody_subject_mismatch` or
   `observation_stale_or_expired`.

7. `validate_retrieval_event_sequence(basis, availability, observation,
   proposal, events, attempt_fence, current_effect_fence, now_utc)`

   `events` is exact tuple of 1–3 exact event values. Every event binds authority,
   proposal, custody, subject semantic/byte pairs, attempt/effect/fences,
   audience/repository/base/path, and one safe correlation. Sequence numbers
   start at zero; predecessor pairs and times are exact/nondecreasing.

   Legal prefixes:

   - `issued`
   - `issued -> redeemed`
   - `issued -> redeemed -> consumed`
   - `expired|revoked|failed|unknown` may terminate an issued or redeemed prefix
   - singleton `failed|unknown` is diagnostic only

   Issuance/redemption/consumption require live custody, verification,
   proposal, grant, and fence windows. Expired may be recorded at/after expiry.
   Failure/unknown/expiry/revocation never permits reuse. Fail with exact
   retrieval/custody/path/freshness reason.

8. `validate_host_qualification(basis, authority, readiness, qualification,
   current_effect_fence, now_utc)`

   Require exact phase/effect/fence/stop, fresh readiness, matching profile
   pairs, Linux platform, and recomputed path binding. Compute the exact
   result/reason precedence above and require equality with the supplied
   qualification. No physical capacity comparison or authentication.

9. `validate_terminal_outcome_binding(basis, outcome, decision,
   program_head, work_head, selection_head, effect_head, delivery_head,
   global_stop)`

   Require exact phase pair, existing decision ref/digest/kind, current head
   revisions/digests and stop; dispatch to exact shape validator. Bind but do
   not expand the evidence set.

10. `validate_normal_outcome_shape(outcome, decision)`
11. `validate_reconciled_cancel_outcome_shape(outcome, decision)`
12. `validate_unresolved_cancel_outcome_shape(outcome, decision)`
13. `validate_unusable_cancel_basis_outcome_shape(outcome, decision)`

   Enforce only the exact branch matrix above. Do not claim completeness,
   absence, or atomicity. Fail `terminal_branch_mismatch`.

WORK BUDGETS

A B1 traversal unit is one value occurrence, collection-container occurrence,
or field/member occurrence, charged before descent. An active-object-ID set
rejects cycles. Shared-DAG aliases are charged at every occurrence. Existing
external exact values are one B1 leaf each and are separately validated by
their owners.

Per-value construction/reconstruction uses `2V`, where
`V = 1 + field_count + maximum_B1_owned_nested_occurrences`:

```text
Phase basis:             fields 26, nested 60, V 87, limit 174
Authority observation:  fields 39, nested 22, V 62, limit 124
Subordinate proposal:   fields 29, nested 16, V 46, limit 92
Custody observation:    fields 16, nested 0,  V 17, limit 34
Retrieval event:        fields 37, nested 0,  V 38, limit 76
Host readiness:         fields 39, nested 0,  V 40, limit 80
Host qualification:     fields 45, nested 0,  V 46, limit 92
Terminal value:         fields 31, nested 0,  V 32, limit 64
```

Nested additions:

- L34 = one container plus 34 fields = 35;
- K8 = one container plus eight pair containers plus sixteen members = 25;
- Ceilings = one container plus fifteen members = 16;
- effect set = one container plus up to five members = 6.

Per-relation maxima:

```text
Phase basis:
  87 + 13 external leaves + 4 current-path occurrences = 104

Authority observation:
  87 + 62 + 6 external leaves + 1 time + 4 path
  + 30 external ceiling members + 6 effect-set occurrences = 196

Per-fence basis:
  62 + 46 + 2 external leaves = 110

External common-family claim:
  62 + 46 + 2 external leaves = 110

Subordinate narrowing:
  87 + 62 + 46 + 2 external leaves + 1 time
  + 8 path occurrences + 30 external ceiling members
  + 6 effect-set occurrences = 242

Custody binding:
  87 + 17 + 1 subject leaf + 1 time = 106

Retrieval sequence:
  87 + 17 + 62 + 46 + 3*38 events + 1 sequence container
  + 2 fence leaves + 1 time + 8 path occurrences = 338

Host qualification:
  87 + 62 + 40 + 46 + 1 fence leaf + 1 time + 4 path = 241

Terminal binding including one dispatched shape check:
  87 + 32 + 7 head/decision/stop leaves + (32 + 1 decision leaf) = 159

Each standalone branch shape check:
  32 + 1 decision leaf = 33
```

The `8 path occurrences` term is traversal of two current three-member C2A path
tuples: each tuple charges one container plus three members. It is not eight
distinct path tuples.

One relation invocation uses one shared budget through called B1 helpers. Tests
pin each formula/literal, largest valid, one over, cycles, and compact shared-DAG
expansion. If faithful single-pass implementation of the exact frozen fields
requires a larger limit, stop; do not change a limit.

CONTENT-FREE ERROR ALGEBRA

`RW0PhaseValueError` is sealed. Exact reasons:

```text
invalid_field_type
missing_field
unknown_field
duplicate_field
invalid_enum
malformed_ref
malformed_digest
invalid_timestamp_window
invalid_length_or_cardinality
graph_cycle
cumulative_work_exhausted
relation_mismatch
observation_stale_or_expired
authority_denied_or_revoked
per_fence_basis_mismatch
common_family_unverified
scope_or_ceiling_mismatch
path_scope_binding_mismatch
current_head_or_global_stop_mismatch
custody_subject_mismatch
retrieval_transition_invalid
readiness_profile_mismatch
qualification_reason_mismatch
terminal_branch_mismatch
privacy_forbidden_material
```

Messages contain only reason and fixed field label. Never echo supplied values,
private material, or chained foreign exceptions.

Constructor mapping:

- wrong external type/subclass: `invalid_field_type`;
- missing key: `missing_field`;
- unknown key: `unknown_field`;
- wrong fixed literal/finite enum: `invalid_enum`;
- safe-ref syntax: `malformed_ref`;
- SHA/base-object syntax: `malformed_digest`;
- syntactically valid but wrong self-digest: `relation_mismatch`;
- timestamp syntax/order/window: `invalid_timestamp_window`;
- negative/out-of-range integer, collection count, optional-pair asymmetry:
  `invalid_length_or_cardinality`;
- cycle: `graph_cycle`;
- budget exhaustion: `cumulative_work_exhausted`;
- forbidden private/bearer shape or known material:
  `privacy_forbidden_material`.

`duplicate_field` is reserved for a future duplicate-aware decoder; B1 adds no
decoder.

PRIVACY

No B1 field, canonical bytes, digest input, exception, repr/str, projection, or
test fixture may contain raw WorkSpec/plan bytes, bearer/credential/signature/
trust material, hostname/IP/endpoint/host key/username/absolute path, prompt,
transcript, hidden reasoning, Codex JSONL, stdout/stderr, provider session/account
metadata, IM bundle body, or mutable workspace/store path.

Safe refs/digests do not prove semantic privacy, authenticity, or permission.
Later source-ingest/authority owners remain responsible for those facts.

REUSE AND CONSUMERS

B1 stores reconstructed L34/K8 and Ceilings only where specified. It stores safe
bindings of existing identities and validates supplied C2A/Section 41/row
objects. It creates no competing WorkSpec, selected plan, attempt, candidate,
effect, command, fence, delivery, source-observation, decision, latch, or
durable-terminal identity.

Permitted production consumers in this tranche: none. Direct tests import the
private module. Later separately governed B2/C/D/E code may consume it.

Prohibited consumers in B1: package root, StateStore, WriterSession, Bridge, ES,
adapters, workers, model/provider clients, public APIs.

MODULE ORDER AND IMPORTS

New module order:

1. docstring;
2. standard-library `datetime`, `hashlib`, `json`, `re`, `typing`;
3. exact private pure C2A, Section 41, and row-value imports;
4. `__all__: tuple[str, ...] = ()`;
5. schema/domain/field/reason constants;
6. sealed error;
7. local bounded canonical/clone helpers;
8. eight classes in the order above;
9. pure relations in the order above.

Use the current immutable slotted-value idiom, not dataclasses or NamedTuple.
Do not add a shared helper module. Existing C2A source and vectors remain
byte-identical.

EXACT MAXIMUM TOUCHED-FILE ALLOWLIST

Exactly these sixteen paths may differ from HEAD:

1. `.docs/rw0-b1-pure-phase-values.md` — new governing owner
2. `src/ge_nwp_coordinator/_rw0_phase_entry_semantic_values.py` — new private source
3. `tests/test_rw0_b1_phase_values.py` — new
4. `tests/test_rw0_b1_relations.py` — new
5. `tests/test_rw0_b1_vectors.py` — new
6. `tests/test_rw0_b1_boundaries.py` — new
7. `tests/test_c2a_nonimplementation.py`
8. `tests/test_runtime_non_authority.py`
9. `.docs/rw0-remote-worker-contact-phase-entry.md`
10. `.docs/authority-boundaries.md`
11. `.docs/autonomous-software-development-operating-model.md`
12. `.docs/durable-state-model.md`
13. `.docs/worker-execution-boundary.md`
14. `tests/test_rw0_remote_contact_phase_entry_contract.py`
15. `tests/test_architecture_contracts.py`
16. `tests/test_remote_worker_pre_execution_planning_contract.py`

Expected closeout classifications:

- six new untracked regular files: governing doc, private source, four tests;
- ten tracked modifications;
- zero staged/unmerged;
- regular mode `0644`, except preserve any opening tracked file's stricter safe
  mode exactly;
- no Git recorded add/delete/rename/copy/mode change.

Stop if any seventeenth path is required.

EXPLICITLY PROTECTED

Require byte identity with HEAD for everything outside the allowlist,
particularly:

- `src/ge_nwp_coordinator/_worker_execution_semantic_values.py`;
- `.docs/c2a-first-slice-semantic-protocol-contract.md`;
- `.docs/c2a1-pure-semantic-values.md`;
- `tests/c2a_contract_support.py` and existing C2A vectors;
- all existing C2A schemas/domains/source/observation/effect enums;
- `src/ge_nwp_coordinator/_development_pre_execution_plan_disposition_contracts.py`;
- all Section 41 row/semantic/runtime modules;
- migrations 0001–0003, catalog, and application generation;
- `src/ge_nwp_coordinator/__init__.py`;
- StateStore and public WriterSession surfaces;
- schemas, fixtures, scripts, configuration, `pyproject.toml`, `.gitignore`;
- AGENTS.md and README.md;
- all supporting repositories.

SOURCE REQUIREMENTS

The new module must:

- have empty `__all__: tuple[str, ...] = ()`;
- use only standard library and exact private pure modules needed by this
  contract;
- contain no filesystem, SQLite, subprocess, socket/network, environment read,
  provider/model, Bridge, ES, clock read, random, UUID, logging, or public
  package integration;
- expose no package-root symbol;
- retain no caller-owned mutable collection;
- disable subclassing and pickling;
- use content-free repr/str/errors and suppress foreign exception chains;
- reject bool and integer subclasses for integer fields;
- preserve exact Unicode code points;
- add no decoder;
- never treat a digest as authenticity or permission.

GOVERNING DOCUMENT AND CURRENT STATUS

Create `.docs/rw0-b1-pure-phase-values.md` as sole detailed B1 owner. It must
state exact current implementation, nonclaims, all schemas/fields/domains/
budgets/relations/privacy, consumers, B2/C/D/E/ES ownership, tests, and stop
conditions.

Update RW0-A only through a bounded current-status successor/section. Preserve
accepted RW0-A target and historical bytes.

In all four bounded cross-references use normalized-identical current meaning:

> A private no-I/O RW0-B1 semantic value and relation layer is now implemented. No phase-entry persistence, verifier authenticity, custody, transport, process, worker, terminal-outcome runtime, latch, Git, ES route, service, scheduler, queue, or autonomous loop is implemented. The durable and executable boundary remains private C2B3D planned author delivery plus Section 41 pre-execution selection.

Preserve complete four-document map, unique owners, markers, headings, adjacency,
fence-aware parsing, normalized body identity, historical/same-title relocation
rejection, hidden-duplicate controls, and existing causal mutants.

TEST-FIRST CAUSAL GATE

Before creating the production source:

1. create governing doc and four new test files;
2. run one isolated direct red gate over the four new files;
3. require failure caused by absent B1 module/classes/relations, not syntax,
   collection weakening, or unrelated setup;
4. retain exact evidence;
5. then create source and complete bounded status/inventory edits.

TEST REQUIREMENTS

New tests independently and causally cover:

- exact class order, `_FIELDS`, schema IDs, domains;
- independently calculated canonical bytes/digests without importing production
  constants as oracle;
- no Unicode normalization;
- exact types, hostile subclasses, bool rejection;
- every enum and qualification pair;
- unknown-before-missing;
- optional-pair symmetry;
- defensive copying, subclass/pickle disabling, content-free repr/str/error;
- every value and relation budget, largest valid, one over, cycles, aliases;
- exact K8/L34/Section 41/head binding;
- C2A WorkSpec/fence/command/delivery reuse;
- path digest and compatibility edge;
- equal and unequal valid authorization basis pairs;
- external common-family claim limits;
- strict and non-strict subordinate narrowing;
- custody kinds, semantic/raw digest distinction, freshness, artifact length;
- retrieval triple binding, legal/illegal transitions, predecessor/time rules,
  diagnostic failure/unknown and no retry implication;
- readiness profiles, qualification precedence/matrix;
- terminal binding and all five branch rows, with no B1 atomicity/completeness/
  absence proof;
- no-I/O AST/import boundary, no production importer, empty private exports,
  unchanged package root;
- privacy sentinels;
- causal one-field ref/digest/head/stop/family/ceiling/profile/branch mutants.

Do not weaken, skip, xfail, gratuitously rename, or reparameterize existing
tests to obtain green.

VALIDATION EVIDENCE ROOT

Create one external operator-owned non-symlink mode-0700 root under
`/private/tmp` with prefix such as `gec-rw0-b1-implementation.`.

For every pytest child:

- save actual caller umask;
- create evidence securely;
- restore caller umask before launch;
- record and require equal caller/child numerical umask;
- use:
  - `env -u PYTHONTRACEMALLOC -u PYTHONWARNINGS`;
  - `LC_ALL=C`, `LANG=C`;
  - `PYTHONDONTWRITEBYTECODE=1`;
  - distinct external `PYTHONPYCACHEPREFIX`, `TMPDIR`, `--basetemp`, JUnit;
  - `PYTEST_DISABLE_PLUGIN_AUTOLOAD=1`;
  - `PYTEST_ADDOPTS=''`;
  - `PYTHONHASHSEED=0`;
  - `python3 -B -m pytest -p no:cacheprovider -W error`;
  - serial execution.

Before/after final green runs require unchanged branch/HEAD/upstream, allowlist-
only dirty paths, zero staged/unmerged, no residue, operation, or lock.

OPENING NODE COLLECTION

After branch creation and before edits, collect complete ordered node list once
under isolated posture. Retain exact IDs and SHA-256. Do not assume a count.

FINAL VALIDATION ORDER

After implementation and cleanup:

1. collect complete final ordered nodes once;
   - opening minus final empty;
   - final minus opening exactly nodes from four new B1 test files;
   - removing additions reproduces opening order;
   - no duplicate/skip/xfail/collection hook/warning.

2. `tests/test_rw0_b1_phase_values.py`
3. `tests/test_rw0_b1_relations.py`
4. `tests/test_rw0_b1_vectors.py`
5. `tests/test_rw0_b1_boundaries.py`
6. `tests/test_c2a_nonimplementation.py tests/test_runtime_non_authority.py`
7. C2A regression:
   - `tests/test_worker_execution_semantic_values.py`
   - `tests/test_worker_execution_semantic_vectors.py`
   - `tests/test_worker_execution_semantic_relations.py`
   - `tests/test_worker_execution_semantic_boundaries.py`
   - `tests/test_c2a_relations.py`
   - `tests/test_c2a_first_slice_semantic_protocol_contract.py`
8. RW0/docs regression:
   - `tests/test_rw0_remote_contact_phase_entry_contract.py`
   - `tests/test_architecture_contracts.py`
   - `tests/test_remote_worker_pre_execution_planning_contract.py`
   - `tests/test_autonomous_software_development_operating_model.py`
9. `git diff --check` and exact path/mode/status/residue guards.
10. complete suite against final bytes:

`python3 -B -m pytest -p no:cacheprovider -W error --basetemp=<external> --junitxml=<external> -q .`

Run final attempt 001 once. If it fails from this patch and every repair remains
inside the allowlist, repair and run one attempt 002. Otherwise stop. Never run
attempt 003.

Every final green run requires rc 0, exact collected/passed accounting, zero
fail/error/skip/xfail/warning, empty stderr, valid unique mapped JUnit, equal
umask, unchanged bytes.

ARTIFACT HYGIENE

Remove only implementation-created transient caches, pycache, basetemps,
temporary files, and repository residue after preserving evidence. Do not run
compileall or py_compile against repository paths.

FINAL PROVENANCE

After final validation and cleanup use this exact unchanged recipe twice.

Recipe source:

- 3,945 bytes
- SHA-256:
  db21f2b67ba73a03a98c1d309323e5cabc014a10248ef96d5e25cc52081460bc

Safely classify and preserve any pre-existing fixed external output; stop on
unsafe path. Copy each generated manifest into evidence root and restore the
fixed path exactly.

Require two runs: rc 0, empty stderr, byte-identical complete stdout/manifests,
exact branch/HEAD/upstream, final allowlisted path set, safe regular types/modes,
stable tracked-diff hash.

EXACT PROVENANCE RECIPE

```python
from __future__ import annotations

import hashlib
import json
import os
import stat
import subprocess
from pathlib import Path

RECIPE_ID = "governed-execution.audit-patch-manifest.v1"
OUTPUT_PATH = Path("/tmp/ge-coordinator-b3a-audit-manifest-v1.json")


def git_bytes(*args: str) -> bytes:
    env = os.environ.copy()
    env["LC_ALL"] = "C"
    env["LANG"] = "C"
    result = subprocess.run(
        ["git", *args],
        check=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        env=env,
    )
    return result.stdout


def git_text(*args: str) -> str:
    return git_bytes(*args).decode("utf-8", "strict").strip()


def nul_paths(data: bytes) -> list[str]:
    return [
        item.decode("utf-8", "strict")
        for item in data.split(b"\0")
        if item
    ]


head = git_text("rev-parse", "HEAD")
branch = git_text("branch", "--show-current")
upstream = git_text("rev-parse", "--abbrev-ref", "--symbolic-full-name", "@{u}")

tracked = set(
    nul_paths(git_bytes("diff", "--name-only", "--no-renames", "-z", "HEAD", "--"))
)
added = set(
    nul_paths(
        git_bytes(
            "diff",
            "--name-only",
            "--no-renames",
            "--diff-filter=A",
            "-z",
            "HEAD",
            "--",
        )
    )
)
deleted = set(
    nul_paths(
        git_bytes(
            "diff",
            "--name-only",
            "--no-renames",
            "--diff-filter=D",
            "-z",
            "HEAD",
            "--",
        )
    )
)
untracked = set(
    nul_paths(git_bytes("ls-files", "--others", "--exclude-standard", "-z"))
)

if tracked & untracked:
    raise SystemExit("tracked/untracked path overlap")

entries: list[dict[str, object]] = []
for relative_path in sorted(tracked | untracked):
    if relative_path in untracked:
        kind = "untracked"
    elif relative_path in deleted:
        kind = "tracked_deleted"
    elif relative_path in added:
        kind = "tracked_added"
    else:
        kind = "tracked_modified"

    entry: dict[str, object] = {
        "kind": kind,
        "path": relative_path,
    }

    if kind == "tracked_deleted":
        entry.update(
            {
                "file_type": "missing",
                "mode": None,
                "sha256": None,
                "size": None,
            }
        )
    else:
        path = Path(relative_path)
        metadata = path.lstat()
        mode = f"{stat.S_IMODE(metadata.st_mode):04o}"
        if stat.S_ISREG(metadata.st_mode):
            payload = path.read_bytes()
            file_type = "regular"
        elif stat.S_ISLNK(metadata.st_mode):
            payload = os.readlink(path).encode("utf-8")
            file_type = "symlink"
        else:
            raise SystemExit(f"unsupported file type: {relative_path}")

        entry.update(
            {
                "file_type": file_type,
                "mode": mode,
                "sha256": hashlib.sha256(payload).hexdigest(),
                "size": len(payload),
            }
        )

    entries.append(entry)

diff_bytes = git_bytes(
    "diff",
    "--full-index",
    "--binary",
    "--no-ext-diff",
    "--no-textconv",
    "--no-renames",
    "HEAD",
    "--",
)
textual_diff_sha256 = hashlib.sha256(diff_bytes).hexdigest()

manifest = {
    "branch": branch,
    "files": entries,
    "head": head,
    "recipe_id": RECIPE_ID,
    "textual_diff_sha256": textual_diff_sha256,
    "upstream": upstream,
}

canonical = (
    json.dumps(
        manifest,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")
    + b"\n"
)
manifest_sha256 = hashlib.sha256(canonical).hexdigest()
OUTPUT_PATH.write_bytes(canonical)

print(f"recipe_id={RECIPE_ID}")
print(f"textual_diff_sha256={textual_diff_sha256}")
print(f"manifest_sha256={manifest_sha256}")
print(f"file_count={len(entries)}")
print(canonical.decode("utf-8"), end="")
```

IMPLEMENTATION CLOSEOUT

Return exactly:

COORDINATOR_RW0_B1_PURE_PHASE_VALUES_IMPLEMENTED_READY_FOR_INDEPENDENT_AUDIT

only when implementation, validation, cleanup, guards, and repeated provenance
are complete.

Report:

1. opening/final identity and feature branch;
2. exact touched paths/classes/modes/sizes/SHA-256;
3. implemented semantic decisions and observable/nonclaim boundary;
4. prerequisite ownership treatment;
5. causal red evidence;
6. opening/final nodes and exact additions/order;
7. every validation command/result/evidence hash;
8. failed/repaired attempts and whether attempt 002 was used;
9. protected/public-boundary comparisons;
10. artifact hygiene;
11. authority/privacy/protocol/dependency/cross-repo widening: none or exact
    exceptions;
12. recipe identity, two-run output identity, tracked diff, manifest size/hash,
    file count, safe manifest path;
13. assumptions, unresolved seams, skipped validation, inspection boundary;
14. separate provenance, validation, implementation confidence.

Required final statements:

INDEPENDENT_AUDIT_NOT_PERFORMED
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED
REMOTE_CONTACT_NOT_PERFORMED
WORKER_OR_MODEL_NOT_INVOKED
SUPPORTING_REPOSITORIES_NOT_MODIFIED
DEPENDENCIES_NOT_CHANGED
MIGRATIONS_NOT_CHANGED
PUBLIC_API_NOT_WIDENED

STOP CONDITIONS

Stop without staging, commit, push, or scope widening if:

- baseline/branch preconditions fail;
- any seventeenth path is required;
- existing C2A schema/field/enum/effect/source/observation kind/domain/vector/path
  grammar/relation must change;
- private/bearer material enters B1 value/canonical bytes/error/projection/test;
- authenticity or permission would be inferred from a digest;
- second selected-plan/WorkSpec/attempt/candidate/effect/command/fence/delivery/
  source-observation identity is needed;
- exact scenario-profile class is required;
- frozen field/relation/budget/error rule is mechanically inconsistent;
- SQLite/migration/durable state/filesystem/subprocess/network/model/provider/
  Bridge/ES/worker/adapter/public API/dependency/script/config work is required;
- B2 framing/terminal-result/Codex mechanics are required;
- existing test must be weakened/skipped/xfailed/gratuitously renamed;
- final validation cannot become exact-green within allowlist;
- provenance is unstable or residue remains.
````

## END COMPLETE REPLACEMENT CODEX PROMPT

### Sources

- Reconciled RW0-B1 packet and baseline. 
- Shared value and canonicalization contract. 
- Pure relations and bounded-work rules. 
- Consumer boundaries, exact touched scope, and validation plan. 
- Parent-only implementation and later independent-audit separation. 

**Confidence:** The original 98%/96% pre-execution forecast is preserved as recorded. Current confidence is high that no owning-contract contradiction remains; the primary remaining uncertainty is whether the exact frozen traversal budgets and existing private APIs are mechanically compatible without an ordinary in-scope repair.
