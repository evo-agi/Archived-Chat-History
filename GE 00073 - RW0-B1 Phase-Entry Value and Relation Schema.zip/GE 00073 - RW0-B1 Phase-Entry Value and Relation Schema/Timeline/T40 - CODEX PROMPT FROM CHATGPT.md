TITLE

Coordinator RW0-B1 — squash-merge PR #3 and verify the accepted tree

ENGAGEMENT TYPE

Bounded squash-merge and post-merge verification gate.

Use the existing write-enabled RW0-B1 implementation/commit-gate conversation.
Do not use an independent-audit conversation.

This prompt authorizes only:

1. read-only verification of the accepted audit, commit-gate evidence, local
   repository, remote refs, PR #3, repository settings, and effective rulesets;
2. exactly one ordinary squash-merge command for PR #3, pinned to the exact
   accepted head commit;
3. one exact fetch of the required base and feature refs;
4. switching the clean local worktree to `trunk_dev`;
5. one `git merge --ff-only origin/trunk_dev`;
6. one isolated focused post-merge pytest invocation over the ten changed test
   files;
7. read-only final local, remote, PR, ruleset, tree, blob, and evidence
   verification.

This prompt does NOT authorize:

- implementation or test repair;
- source, documentation, or configuration editing;
- staging or another feature commit;
- amend, rebase, cherry-pick, reset, revert, force push, direct trunk push, or
  alternate-history operations;
- an update-branch operation;
- a second merge attempt;
- admin or ruleset bypass;
- review, self-approval, review-request creation, comment creation, thread
  resolution, auto-merge, branch deletion, tag, release, deployment, remote
  worker/model invocation, or supporting-repository mutation.

REPOSITORY

/Users/ds/Repositories/Governed Execution Coordinator/

PULL REQUEST

Repository:

`evo-agi/Governed-Execution-Coordinator`

PR:

`#3`

URL:

`https://github.com/evo-agi/Governed-Execution-Coordinator/pull/3`

Expected base branch:

`trunk_dev`

Expected base OID:

`bf68a5232bff1b412c9414c076d82cab18c8e0aa`

Expected head branch:

`codex/rw0-b1-pure-phase-values-v1`

Expected head OID:

`a09e64894dd2b50fd15171147af81013811b778a`

Expected head tree:

`0b5394c591bd277d56797794f71af954ccb93846`

Expected head sole parent:

`bf68a5232bff1b412c9414c076d82cab18c8e0aa`

Expected head subject:

`feat: implement RW0-B1 pure phase-entry semantics`

Expected head body:

empty

EXPECTED OPENING LOCAL STATE

Require exactly:

- root:
  `/Users/ds/Repositories/Governed Execution Coordinator/`
- current branch:
  `codex/rw0-b1-pure-phase-values-v1`
- local HEAD:
  `a09e64894dd2b50fd15171147af81013811b778a`
- local HEAD tree:
  `0b5394c591bd277d56797794f71af954ccb93846`
- sole parent:
  `bf68a5232bff1b412c9414c076d82cab18c8e0aa`
- upstream:
  `origin/codex/rw0-b1-pure-phase-values-v1`
- ahead/behind:
  `0/0`
- worktrees:
  `1`
- worktree/index/untracked/unmerged:
  clean
- no Git operation, lock, or repository-local test/build/database/cache
  residue.

Stop on mismatch. Do not repair or normalize the worktree.

ACCEPTED AUDIT AND PUBLICATION EVIDENCE

Safely read and retain:

1. Accepted audit report:

   `/private/tmp/gec-rw0-b1-audit5-ll6lr5xg/audit-report.md`

   Require:
   - `ACCEPT`;
   - token
     `COORDINATOR_RW0_B1_FOURTH_AUDIT_REPAIR_ACCEPTED_READY_FOR_COMMIT_AND_PR_GATE`;
   - exact 17-path accepted candidate;
   - independent collection 4,566;
   - independent full suite 4,566/4,566;
   - no material patch defect.

2. Implementation final manifest:

   `/private/tmp/gec-rw0-b1-repair4.ljh_96ne/final-provenance-1.manifest.json`

   Require manifest SHA-256:

   `7b547ad33cccd25f33ff32db9f815efd19de539e79e607e96b90e294866dc1c7`

3. Successful commit/PR gate report:

   `/private/tmp/gec-rw0-b1-commit-gate2.vmtslolm/gate-report.md`

4. Commit/PR gate evidence index:

   `/private/tmp/gec-rw0-b1-commit-gate2.vmtslolm/evidence-index.json`

   Require:
   - size:
     `14,889` bytes;
   - SHA-256:
     `7efdc4ca059a213631dde856da09ff7118fd973610481c3b4f534476545c35e7`.

5. Prior failed harness evidence root:

   `/private/tmp/gec-rw0-b1-commit-gate.6hub_blf`

   Preserve it. The missing attempt-001 raw output is a disclosed
   evidence-retention limitation, not a repository-byte or acceptance finding.
   Do not reconstruct missing evidence.

For every external path:

- `/`, `/private`, and `/private/tmp` are trusted fixed system ancestors and may
  be root-owned;
- `/private/tmp` must be a real sticky temporary directory;
- each named evidence root and every descendant used here must be
  operator-owned, non-symlink, and a supported safe file type;
- create one new operator-owned, non-symlink, mode-0700 merge-gate root under
  `/private/tmp`;
- retain key evidence files mode 0400;
- do not retain credentials, tokens, private values, prompts, transcripts,
  endpoints, host identities, raw WorkSpec/plan bytes, or raw database content.

COMMIT AND MANIFEST REVALIDATION

Before any remote mutation:

1. Verify the local commit object, tree, parent, subject, empty body, author,
   committer, time, and signature status.
2. Verify the commit contains exactly:
   - 11 modified paths;
   - 6 added paths;
   - 0 deleted, renamed, copied, or mode-changed paths;
   - all Git modes `100644`.
3. For every one of the 17 paths:
   - compare committed blob bytes, size, and SHA-256 with the accepted manifest;
   - require exact equality.
4. Require the local commit tree to equal:
   `0b5394c591bd277d56797794f71af954ccb93846`.
5. Verify the successful gate report records:
   - two accepted provenance runs;
   - corrected collection attempt 002 matching all 4,566 ordered audit nodes;
   - one complete suite with 4,566/4,566;
   - one commit and one plain feature-branch push;
   - PR #3 open and unmerged;
   - no implementation repair, direct trunk push, bypass, force push, amend,
     second commit/push/PR, merge, auto-merge, self-review, branch deletion, tag,
     release, or deployment.

Stop if any committed blob differs from the accepted manifest.

REMOTE, PR, SETTINGS, AND RULESET PREFLIGHT

Use read-only GitHub/Git queries and record exact responses.

Require immediately before merge:

Remote refs:

- `trunk_dev` exactly:
  `bf68a5232bff1b412c9414c076d82cab18c8e0aa`;
- `codex/rw0-b1-pure-phase-values-v1` exactly:
  `a09e64894dd2b50fd15171147af81013811b778a`.

PR #3:

- state:
  OPEN;
- non-draft;
- merged:
  false;
- base branch/OID exact;
- head branch/OID exact;
- one commit;
- exactly 17 changed files;
- exact title:
  `feat: implement RW0-B1 pure phase-entry semantics`;
- exact body equal to the retained gate-report/PR-body artifact;
- mergeable:
  true;
- merge-state status:
  clean or its current GitHub equivalent;
- auto-merge:
  absent;
- no requested reviewers;
- no submitted reviews;
- no unresolved review thread;
- no pending review submission by the current user.

Record comments and non-review discussion if present; do not create or change
them. A non-review comment is not itself a blocker unless it changes PR state or
identifies a material unresolved defect.

Checks and workflows:

- enumerate commit statuses, check runs, workflow runs, and combined status;
- identify required checks from the effective ruleset, not from a synthetic
  combined `pending` state with `total_count=0`;
- require every actually required check to be successful;
- if there are no required checks, an otherwise empty/synthetic pending
  aggregate is not a blocker.

Rulesets and repository settings:

- effective `trunk_dev` rule requires pull requests;
- squash merge is permitted for this PR;
- no current-user bypass is available or used;
- no rule or setting was changed;
- no unresolved-thread condition is violated;
- determine the exact required approval count and any
  last-push/code-owner/unattributed-change requirements;
- require the current PR state to satisfy those review rules without the current
  user submitting or fabricating a review;
- require automatic branch deletion on merge to be disabled;
- require repository auto-merge to remain disabled;
- record whether merge/rebase methods are otherwise enabled, but use squash
  only.

If any required approval, review, thread, check, base update, or policy condition
is unmet, stop. Do not self-approve, request bypass, use admin merge, enable
auto-merge, update the branch, or alter policy.

TREE-EQUALITY GATE

Immediately before merge, compare:

- accepted manifest blobs;
- feature commit blobs;
- feature tree `0b5394c591bd277d56797794f71af954ccb93846`.

Require all equal.

Also require local worktree/index to remain clean and local/remote feature refs
to remain equal.

MERGE

Execute exactly once:

```text
gh pr merge 3 \
  --repo evo-agi/Governed-Execution-Coordinator \
  --squash \
  --match-head-commit a09e64894dd2b50fd15171147af81013811b778a \
  --subject "feat: implement RW0-B1 pure phase-entry semantics (#3)" \
  --body ""
```

Requirements:

- no `--admin`;
- no auto-merge;
- no branch deletion;
- no second merge command;
- no fallback merge method;
- no update-branch, rebase, or force action.

Capture exact start/end times, argv, return code, stdout, and stderr.

If the command fails, do not retry. Preserve evidence and report the failure.

IMMEDIATE POST-MERGE REMOTE VERIFICATION

After a successful command, require:

- PR #3 is closed and merged;
- merged timestamp and actor are recorded;
- merge commit OID exists;
- remote `trunk_dev` advanced exactly once from the pinned base to that merge
  commit;
- remote feature branch remains at
  `a09e64894dd2b50fd15171147af81013811b778a`;
- no other remote ref was changed by this engagement.

Verify the squash commit:

- sole parent:
  `bf68a5232bff1b412c9414c076d82cab18c8e0aa`;
- tree:
  `0b5394c591bd277d56797794f71af954ccb93846`;
- subject:
  `feat: implement RW0-B1 pure phase-entry semantics (#3)`;
- body:
  empty;
- path status:
  exactly 11 M + 6 A + 0 D;
- all modes:
  `100644`;
- every merged blob equals both the feature commit and accepted manifest;
- feature commit is not an ancestor of the squash commit;
- record GitHub signature verification and local Git verification separately and
  honestly.

If the merge commit tree or blobs differ from the feature tree, stop without any
corrective Git operation.

LOCAL SYNCHRONIZATION

After remote verification:

1. Fetch exactly the remote `trunk_dev` and feature refs needed for verification.
2. Require the local feature branch/worktree is still clean.
3. Switch to `trunk_dev`.
4. Require local `trunk_dev` is still the pinned pre-merge base and clean.
5. Execute exactly once:

   `git merge --ff-only origin/trunk_dev`

6. Require:
   - local `trunk_dev` equals the squash merge commit;
   - local tree equals
     `0b5394c591bd277d56797794f71af954ccb93846`;
   - upstream is `origin/trunk_dev`;
   - ahead/behind `0/0`;
   - local and remote feature refs remain intact;
   - one clean worktree;
   - no operation, lock, untracked path, staged path, unmerged path, or
     repository residue.

Do not delete either feature ref.

POST-MERGE FOCUSED VALIDATION

Run exactly one serial isolated pytest invocation from merged local `trunk_dev`
over all ten changed test files:

```text
tests/test_rw0_b1_phase_values.py
tests/test_rw0_b1_relations.py
tests/test_rw0_b1_vectors.py
tests/test_rw0_b1_boundaries.py
tests/test_c2a_nonimplementation.py
tests/test_runtime_non_authority.py
tests/test_rw0_remote_contact_phase_entry_contract.py
tests/test_architecture_contracts.py
tests/test_remote_worker_pre_execution_planning_contract.py
tests/test_c2b2_development_row_value_boundaries.py
```

Use:

- actual caller umask captured and restored;
- equal caller/child numerical umask required;
- `env -u PYTHONTRACEMALLOC -u PYTHONWARNINGS`;
- `LC_ALL=C`, `LANG=C`;
- `PYTHONDONTWRITEBYTECODE=1`;
- distinct external `PYTHONPYCACHEPREFIX`, `TMPDIR`, `--basetemp`, and JUnit;
- `PYTEST_DISABLE_PLUGIN_AUTOLOAD=1`;
- `PYTEST_ADDOPTS=''`;
- `PYTHONHASHSEED=0`;
- `python3 -B -m pytest -p no:cacheprovider -W error -q`;
- serial execution.

Determine outcomes structurally from process return code, JUnit, and anchored
pytest summary. Never infer warnings/skips/failures from words inside test
names.

Require:

- return code 0;
- all collected cases passed;
- zero failures, errors, skips, xfails, warnings;
- empty stderr;
- no duplicate, ambiguous, parse-error, or unmapped JUnit case;
- tree/status unchanged before and after.

Do not rerun the focused validation. Do not run the complete repository suite
again: the merged tree is required to be byte-identical to the independently
audited and commit-gate-validated tree.

FINAL VERIFICATION

PR:

- final state MERGED;
- exact base/head OIDs;
- exact merge commit OID;
- exact title/body;
- squash method;
- auto-merge absent;
- feature branch not deleted;
- record reviews, threads, comments, statuses, checks, workflows, and effective
  ruleset without changing any of them.

Git:

- local and remote `trunk_dev` equal the squash commit;
- local and remote feature refs equal the feature commit;
- merged tree equals accepted feature tree;
- every merged blob equals the accepted manifest;
- worktree/index/untracked/unmerged clean;
- one worktree;
- no operation, lock, or repository residue.

Boundaries:

- exactly the 17 audited files changed between the pre-merge base and squash
  commit;
- no dependency, migration, application-generation, package export, public API,
  StateStore, WriterSession, process, worker, model/provider, Bridge, ES,
  network, Git-effect implementation, or supporting-repository widening;
- RW0-B1 remains private, pure semantic values and relations over supplied
  evidence; it grants no permission and implements no worker contact or durable
  state.

EVIDENCE

Retain a deterministic mode-0400 evidence index under the mode-0700 merge-gate
root, including safe identities for:

- accepted audit and accepted manifest;
- commit/PR gate report and evidence index;
- local opening state;
- feature commit and manifest/blob comparison;
- preflight remote refs, PR state, comments/reviews/threads, statuses/checks,
  workflows, rulesets, and repository settings;
- exact merge invocation/result;
- squash commit metadata/tree/parent/signature/path status;
- feature-to-merged and manifest-to-merged blob comparisons;
- remote ref transition;
- local fetch/switch/ff-only synchronization;
- focused pytest argv/environment/umask/stdout/stderr/JUnit/result;
- final PR/local/remote/ruleset/boundary guards.

Do not include the evidence index itself in its own entries. Remove only
merge-gate-created transient caches and test scratch after retaining terminal
evidence.

CLOSEOUT

Return exactly:

`COORDINATOR_RW0_B1_PURE_PHASE_VALUES_SQUASH_MERGED_AND_VERIFIED`

only if merge, local synchronization, focused validation, and every final guard
succeed.

Report:

1. opening local identity and accepted evidence identities;
2. preflight PR, remote, ruleset, settings, review, thread, status, and check
   state;
3. accepted-manifest/feature-tree equality;
4. exact merge command and result;
5. squash commit OID, tree, parent, subject/body, author/committer/times,
   signature, and exact path status;
6. feature-to-merged and manifest-to-merged blob equality;
7. remote refs before and after;
8. local fetch/switch/ff-only synchronization;
9. exact focused validation command/result/evidence;
10. final PR and local/remote/ruleset state;
11. evidence-root and evidence-index identity;
12. assumptions, limitations, and non-blocking observations.

Required final statements:

IMPLEMENTATION_REPAIR_NOT_PERFORMED
DIRECT_TRUNK_PUSH_NOT_PERFORMED
BYPASS_NOT_USED
FORCE_PUSH_NOT_PERFORMED
SECOND_COMMIT_NOT_PERFORMED
AMEND_NOT_PERFORMED
REBASE_NOT_PERFORMED
SECOND_MERGE_ATTEMPT_NOT_PERFORMED
AUTO_MERGE_NOT_ENABLED
REVIEW_NOT_SUBMITTED
THREAD_NOT_RESOLVED
FEATURE_BRANCH_NOT_DELETED
TAG_NOT_CREATED
RELEASE_NOT_CREATED
DEPLOYMENT_NOT_PERFORMED

STOP CONDITIONS

Stop without merge if:

- accepted audit, manifest, gate report, or evidence index is unsafe,
  unavailable, incomplete, or inconsistent;
- local feature state, remote refs, PR base/head, tree, title/body, commit count,
  or changed-file count differs;
- committed blobs differ from the accepted manifest;
- remote `trunk_dev` advanced;
- feature head changed;
- PR is draft, unmergeable, dirty, already merged/closed, or auto-merge-enabled;
- a required approval, review, thread resolution, or status check is missing;
- merge would require admin/bypass, update-branch, rebase, force, another commit,
  another push, or another PR;
- automatic branch deletion is enabled;
- a second merge attempt would be needed.

After a successful merge, do not attempt rollback or corrective history
operations. If post-merge tree, blob, synchronization, validation, or final
verification fails, preserve exact evidence and report the failure honestly.
