The RW0-B1 implementation prompt has been issued in this conversation but has
not yet been sent to Codex. Treat that prompt as an unexecuted draft.

Before Codex begins, perform a concise post-issue, pre-execution
freeze-acceptance review of the reconciled RW0-B1 design and the implementation
handoff you just produced.

Do not start another Codex reconnaissance pass by default. Do not reopen the
accepted B1/B2 split broadly, create a separate evaluation workstream, or add a
new approval gate merely for this review.

First, provide a short engineering review outside the Codex prompt.

1. Observable result and capability contribution

State exactly what B1 will make true and observable:

- the local private, pure, no-I/O value-and-relation result;
- what RW0-B2, RW0-C, RW0-D, and RW0-E are expected to consume from it;
- why this result is non-disposable on the path to remote worker contact
  through semantic decision; and
- what remains target-only or explicitly outside B1.

Do not describe private semantic representability as worker contact, executable
authority, custody, terminal-outcome persistence, or operating autonomy.

2. Action-specific prerequisites

For each material semantic dependency, state:

- the exact later action it blocks;
- whether it is established by an owning contract, depends on missing evidence,
  or is a proposed engineering precaution; and
- whether it must be resolved before B1 implementation or may remain open.

Concentrate on:

- Section 41 K8/L34, selected-plan lineage, and selection-head bindings;
- external authority observation versus inert subordinate-authorization
  proposal;
- custody availability versus retrieval-capability events;
- remote-host readiness versus effect-bound qualification;
- terminal outcome versus the existing C2B development-decision grammar and
  future acceptance-latch ownership;
- current C2A path-scope compatibility versus any permanent RW0 path grammar;
- scalar, cardinality, traversal, and graph-work bounds, including whether each
  is derived from an owning contract or newly selected B1 policy.

Do not pull a later effect’s prerequisite forward merely because it matters to
the complete RW0 phase. Conversely, do not assume a no-I/O value is harmless if
its identity or semantics would constrain later persistence or execution.

3. Owning-contract conflict review

Check the reconciled freeze and implementation prompt against the owning
contracts most likely to contradict it:

- C2A and C2A1;
- Section 41 pre-execution selection;
- C2B3D author-effect establishment;
- the current development-decision grammar;
- RW0-A phase-entry authority, custody, cancellation, terminal-outcome, and
  acceptance semantics.

For each material relation, classify it as:

- resolved for B1;
- explicitly deferred without blocking B1; or
- still unresolved enough to block or revise implementation.

Do not treat Codex’s `RW0_B1_SCHEMA_FREEZE_RECONCILED_READY` verdict, the packet
size, test breadth, or textual exactness as proof that the semantics are
complete.

4. Prospective forecasts

Preserve the previously recorded 98%/96% confidence statements as the original
pre-execution forecast; do not revise them retrospectively.

Record two or three additional falsifiable forecasts, without unsupported
numerical confidence percentages, covering matters such as:

- likely implementation or independent-audit blocker classes;
- whether the sixteen-path allowlist will be sufficient;
- whether a frozen field, relation, or traversal budget is likely to require
  revision;
- expected test-oracle or current-status compatibility repairs; and
- evidence that would require architectural replanning rather than an ordinary
  implementation repair.

Keep these forecasts outside the Codex prompt. They are discussion evidence,
not Codex acceptance requirements.

5. Engineering disposition

Make the engineering decision yourself:

- retain the design and prompt;
- narrow or revise them before implementation; or
- block implementation on a concrete unresolved contradiction.

Do not return ordinary schema, implementation, validation, or risk decisions to
me.

After the review, issue one complete, self-contained replacement Codex prompt.

The replacement prompt must explicitly supersede the previously issued RW0-B1
implementation prompt, which must not be used. Do not provide a delta or ask me
to combine prompt fragments.

Preserve all accepted baseline, scope, authority, privacy, validation,
provenance, touched-file, audit, and stop-condition requirements unless the
review identifies a specific reason to change them. Incorporate only engineering
conclusions that affect implementation; do not add evaluation-only reporting
work for Codex.

Clearly delimit the complete replacement prompt for copying. Codex has not
started work, so no repository state or implementation result should be
presumed.
