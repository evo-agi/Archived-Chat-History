TITLE

Coordinator RW0-B1 — resume the stopped implementation with one exact
collateral test-scope expansion

ENGAGEMENT TYPE

Bounded parent-only continuation of the stopped RW0-B1 implementation in the
same foreground Codex conversation and the same working tree.

Do not restart the implementation from HEAD. Do not revert, reset, clean,
rebase, or discard the preserved sixteen-path candidate.

Do not create or resume subagents. You remain the sole repository writer.

This continuation authorizes exactly:

1. one minimal repair inside the existing new B1 production source for the
   full-suite failure that flags the literal word `expiry`; and
2. one newly authorized tracked test modification:
   `tests/test_c2b2_development_row_value_boundaries.py`,
   solely to record the exact direct row-value-provider imports of the new
   private B1 module.

No other repository path may change from the stopped candidate.

This continuation does not authorize staging, commit, push, PR creation, merge,
tag, release, deployment, remote contact, dependency installation, migration,
supporting-repository mutation, or independent audit.

REPOSITORY

/Users/ds/Repositories/Governed Execution Coordinator/

EXPECTED STOPPED STATE

Before any new mutation, require exactly:

- branch:
  codex/rw0-b1-pure-phase-values-v1
- HEAD:
  bf68a5232bff1b412c9414c076d82cab18c8e0aa
- tree:
  8fc05f5626bdbb01808df1698c9c2245ab06f1cb
- sole parent:
  1a894c5527c610ab40d8e5ae5e530a762c6e60bf
- upstream:
  origin/trunk_dev
- ahead/behind:
  0/0
- worktrees:
  1
- dirty paths:
  exactly 16
- tracked modifications:
  exactly 10
- untracked paths:
  exactly 6
- staged/unmerged:
  0/0
- all dirty paths are exactly the sixteen paths authorized by the superseding
  RW0-B1 implementation prompt;
- no deletion, rename, copy, symlink, Git-recorded mode change, Git operation,
  Git lock, or repository residue;
- the test-first causal-red evidence exists;
- opening collection evidence exists and records exactly 4,284 baseline nodes;
- final candidate collection evidence exists and records exactly 4,331 nodes,
  with the original 4,284 nodes retained in order and exactly 47 additions in
  the four new B1 test files;
- full-suite attempt 001 exists and is the only full-suite attempt;
- final provenance has not been run.

Stop without mutation if any condition differs.

PRESERVE ATTEMPT-001 EVIDENCE

Safely verify and retain, without overwrite:

- `/private/tmp/gec-rw0-b1-implementation.Cp4fNa/full-attempt-001.stdout`
- `/private/tmp/gec-rw0-b1-implementation.Cp4fNa/full-attempt-001-junit.xml`

Parse the immutable JUnit and require exactly:

- 4,331 collected cases;
- 4,329 passed;
- 2 failed;
- no additional error, skip, xfail, or warning case.

Record the exact two failing node IDs, failure messages, stdout/JUnit sizes, and
SHA-256 before editing.

If attempt 001 contains any third failure or differs from the report, stop.

OPENING CONTINUATION PROVENANCE

Before editing, create a new external operator-owned, non-symlink, mode-0700
continuation evidence root beneath `/private/tmp`.

Use the exact provenance recipe below twice against the stopped sixteen-path
candidate.

Require:

- return code 0;
- empty stderr;
- byte-identical complete stdout;
- byte-identical canonical manifests;
- exact branch, HEAD, and upstream;
- exactly 16 manifest entries;
- exactly 10 `tracked_modified`;
- exactly 6 `untracked`;
- safe regular file types and opening modes.

Preserve the immutable opening-continuation manifest and all per-file
size/SHA-256 identities. These bytes are the comparison baseline for this
continuation.

Safely classify the recipe's fixed output path before use. Preserve and restore
any pre-existing safe output exactly. Stop on any unsafe path component or
unsupported file type.

ENGINEERING DISPOSITION

The second failure is a handoff-scope omission, not authorization to hide or
remove legitimate imports.

The reconciled B1 contract intentionally permits the new private module to
validate supplied existing row/head/decision values. A static test that owns
the closed consumer inventory must therefore be updated when the new private
module is an exact direct consumer.

Do not change an existing row-value provider, row schema, public surface, or B1
semantic contract to avoid the inventory.

Do not convert runtime imports to dynamic imports, string imports, or other
indirection merely to satisfy the test.

AUTHORIZED FINAL PATH SET

The final candidate may contain exactly 17 dirty paths:

- the stopped sixteen-path candidate; plus
- `tests/test_c2b2_development_row_value_boundaries.py`.

Expected final topology:

- exactly 17 dirty paths;
- exactly 11 tracked modifications;
- exactly 6 untracked files;
- zero staged and zero unmerged paths;
- no deletion, rename, copy, symlink, or Git-recorded mode change.

Relative to the stopped-candidate opening manifest, only these two entries may
change:

1. `src/ge_nwp_coordinator/_rw0_phase_entry_semantic_values.py`
2. `tests/test_c2b2_development_row_value_boundaries.py`

The other fifteen candidate entries must remain byte-identical to the
continuation-opening manifest.

REPAIR 1 — `expiry` FAILURE

Inspect the exact attempt-001 node and its owning assertion before editing.

Make the smallest source-only correction in:

`src/ge_nwp_coordinator/_rw0_phase_entry_semantic_values.py`

that closes the reported forbidden-literal failure without changing any frozen
B1 class name, schema ID, ordered field, enum, digest domain, canonical bytes,
relation signature, relation semantics, error reason, traversal limit,
privacy boundary, or current/nonclaim status.

In particular:

- do not rename frozen fields such as `expires_at`, `grant_expires_at`,
  `observation_expires_at`, or any schema member;
- do not remove expiry/freshness validation;
- do not weaken or edit the failing existing test unless it is already one of
  the original sixteen allowlisted paths and the test is demonstrably testing a
  non-contract lexical false positive;
- prefer removing or replacing only an incidental internal comment, helper
  name, local variable, or non-contract literal when that is the actual cause;
- preserve exact external behavior and canonical identities.

If the failure cannot be closed without changing the frozen contract or a third
path relative to the stopped candidate, stop and report the exact conflict.

REPAIR 2 — ROW-VALUE CONSUMER INVENTORY

Modify only:

`tests/test_c2b2_development_row_value_boundaries.py`

Derive the new B1 module's direct row-value-provider imports mechanically from
its AST and source. Add:

`src/ge_nwp_coordinator/_rw0_phase_entry_semantic_values.py`

to the test's closed expected consumer mapping with exactly the private
row-value provider modules it directly and legitimately imports.

Requirements:

- every mapped provider is actually imported directly by the B1 source;
- every direct row-value-provider import is represented;
- no C2A pure-value module, Section 41 contract module, helper module, or
  standard-library module is misclassified as a row-value provider;
- no extra provider is admitted;
- no other production consumer is added or removed;
- existing consumer mappings remain exact;
- the new test treatment proves this is private composition only and adds no
  package-root export, StateStore method, WriterSession protocol method,
  durable authority, or public API;
- test names, decorators, parameterization, skip/xfail posture, and node
  identity remain unchanged.

If source inspection shows that one of the direct row-value imports is
unnecessary under the frozen relation design, remove that unnecessary import
from the B1 source instead of broadening the inventory. If deciding that would
change the frozen relation contract, stop.

FOCUSED REPRODUCTION AND REPAIR VALIDATION

After the two edits, run under the same isolated posture as the original
implementation:

1. the exact two attempt-001 failing node IDs;
2. the complete owning file for the expiry failure;
3. `tests/test_c2b2_development_row_value_boundaries.py`;
4. the four new B1 test files;
5. `tests/test_c2a_nonimplementation.py`;
6. `tests/test_runtime_non_authority.py`.

Require exact green results with:

- return code 0;
- empty stderr;
- zero failures, errors, skips, xfails, or warnings;
- no JUnit parse error, duplicate, ambiguous, or unmapped case;
- equal caller/child umask;
- unchanged candidate bytes before and after each final green run.

Then rerun the complete final focused regression groups from the superseding
implementation prompt:

A. C2A compatibility:

- `tests/test_worker_execution_semantic_values.py`
- `tests/test_worker_execution_semantic_vectors.py`
- `tests/test_worker_execution_semantic_relations.py`
- `tests/test_worker_execution_semantic_boundaries.py`
- `tests/test_c2a_relations.py`
- `tests/test_c2a_first_slice_semantic_protocol_contract.py`

B. RW0/current-status and structural documentation:

- `tests/test_rw0_remote_contact_phase_entry_contract.py`
- `tests/test_architecture_contracts.py`
- `tests/test_remote_worker_pre_execution_planning_contract.py`
- `tests/test_autonomous_software_development_operating_model.py`

C. Direct B1 files individually:

- `tests/test_rw0_b1_phase_values.py`
- `tests/test_rw0_b1_relations.py`
- `tests/test_rw0_b1_vectors.py`
- `tests/test_rw0_b1_boundaries.py`

Do not rerun the test-first red gate.

NODE IDENTITY

Use the retained opening 4,284-node list as the authoritative pre-implementation
baseline. Do not recollect it.

After all focused tests and cleanup, collect the complete final ordered node
list exactly once.

Require:

- exactly 4,331 nodes;
- opening minus final is empty;
- final minus opening contains exactly 47 nodes;
- all 47 additions belong to the four new B1 test files;
- removing those 47 additions reproduces the opening list in exact order;
- `tests/test_c2b2_development_row_value_boundaries.py` has no added, removed,
  renamed, collapsed, skipped, xfailed, or reparameterized node;
- no duplicate node or collection warning.

FULL SUITE ATTEMPT 002 — EXACTLY ONCE

Only after every focused gate, node comparison, path guard, mode guard,
`git diff --check`, and repository-residue scan is green, run exactly one final
full-suite attempt 002 against the frozen 17-path bytes:

`python3 -B -m pytest -p no:cacheprovider -W error --basetemp=<external> --junitxml=<external> -q .`

Require exactly:

- 4,331 collected;
- 4,331 passed;
- zero failed, errors, skipped, xfailed, or warnings;
- return code 0;
- empty stderr;
- no duplicate, ambiguous, parse-error, or unmapped JUnit case;
- caller and child umask equal;
- repository bytes, modes, path set, and status unchanged.

Do not run attempt 003.

If attempt 002 fails for any reason, stop, preserve its evidence, make no
further repository edit, and do not run provenance as a successful closeout.
Report the exact next required scope rather than retrying.

PROTECTED SURFACES

Require exact byte identity with the stopped candidate for the other fifteen
candidate paths, and exact HEAD identity for every path outside the final
17-path set, especially:

- existing C2A source, schemas, enums, relations, and vectors;
- Section 41 selection source and row contracts;
- all row-value provider modules;
- migrations 0001–0003 and application generation;
- package root, StateStore, WriterSession, public protocols;
- SQL, schemas, fixtures, scripts, config, `pyproject.toml`, `.gitignore`;
- AGENTS.md, README.md;
- supporting repositories.

No source consumer beyond the new B1 module may be introduced.

ARTIFACT HYGIENE

Remove only continuation-created transient external caches, pycache, basetemps,
temporary files, and any repository-local residue after preserving terminal
evidence.

Do not delete or overwrite attempt-001 evidence.

Do not run `compileall`, `py_compile`, or any command that writes bytecode into
the repository.

FINAL PROVENANCE

After attempt 002 is exact-green and cleanup is complete, run the exact
unchanged provenance recipe below twice.

Require:

- return code 0;
- empty stderr;
- byte-identical complete stdout;
- byte-identical canonical manifests;
- branch:
  `codex/rw0-b1-pure-phase-values-v1`;
- HEAD unchanged:
  `bf68a5232bff1b412c9414c076d82cab18c8e0aa`;
- upstream:
  `origin/trunk_dev`;
- exactly 17 entries;
- exactly 11 `tracked_modified`;
- exactly 6 `untracked`;
- expected modes and safe regular file types;
- stable tracked textual-diff SHA-256.

Compare final versus continuation-opening manifests and require exactly two
changed identities: the B1 source and the row-value boundary test.

EXACT PROVENANCE RECIPE

```python
from __future__ import annotations

import hashlib
import json
import os
import stat
import subprocess
from pathlib import Path

RECIPE_ID = "governed-execution.audit-patch-manifest.v1"
OUTPUT_PATH = Path("/tmp/ge-coordinator-b3a-audit-manifest-v1.json")


def git_bytes(*args: str) -> bytes:
    env = os.environ.copy()
    env["LC_ALL"] = "C"
    env["LANG"] = "C"
    result = subprocess.run(
        ["git", *args],
        check=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        env=env,
    )
    return result.stdout


def git_text(*args: str) -> str:
    return git_bytes(*args).decode("utf-8", "strict").strip()


def nul_paths(data: bytes) -> list[str]:
    return [
        item.decode("utf-8", "strict")
        for item in data.split(b"\0")
        if item
    ]


head = git_text("rev-parse", "HEAD")
branch = git_text("branch", "--show-current")
upstream = git_text("rev-parse", "--abbrev-ref", "--symbolic-full-name", "@{u}")

tracked = set(
    nul_paths(git_bytes("diff", "--name-only", "--no-renames", "-z", "HEAD", "--"))
)
added = set(
    nul_paths(
        git_bytes(
            "diff",
            "--name-only",
            "--no-renames",
            "--diff-filter=A",
            "-z",
            "HEAD",
            "--",
        )
    )
)
deleted = set(
    nul_paths(
        git_bytes(
            "diff",
            "--name-only",
            "--no-renames",
            "--diff-filter=D",
            "-z",
            "HEAD",
            "--",
        )
    )
)
untracked = set(
    nul_paths(git_bytes("ls-files", "--others", "--exclude-standard", "-z"))
)

if tracked & untracked:
    raise SystemExit("tracked/untracked path overlap")

entries: list[dict[str, object]] = []
for relative_path in sorted(tracked | untracked):
    if relative_path in untracked:
        kind = "untracked"
    elif relative_path in deleted:
        kind = "tracked_deleted"
    elif relative_path in added:
        kind = "tracked_added"
    else:
        kind = "tracked_modified"

    entry: dict[str, object] = {
        "kind": kind,
        "path": relative_path,
    }

    if kind == "tracked_deleted":
        entry.update(
            {
                "file_type": "missing",
                "mode": None,
                "sha256": None,
                "size": None,
            }
        )
    else:
        path = Path(relative_path)
        metadata = path.lstat()
        mode = f"{stat.S_IMODE(metadata.st_mode):04o}"
        if stat.S_ISREG(metadata.st_mode):
            payload = path.read_bytes()
            file_type = "regular"
        elif stat.S_ISLNK(metadata.st_mode):
            payload = os.readlink(path).encode("utf-8")
            file_type = "symlink"
        else:
            raise SystemExit(f"unsupported file type: {relative_path}")

        entry.update(
            {
                "file_type": file_type,
                "mode": mode,
                "sha256": hashlib.sha256(payload).hexdigest(),
                "size": len(payload),
            }
        )

    entries.append(entry)

diff_bytes = git_bytes(
    "diff",
    "--full-index",
    "--binary",
    "--no-ext-diff",
    "--no-textconv",
    "--no-renames",
    "HEAD",
    "--",
)
textual_diff_sha256 = hashlib.sha256(diff_bytes).hexdigest()

manifest = {
    "branch": branch,
    "files": entries,
    "head": head,
    "recipe_id": RECIPE_ID,
    "textual_diff_sha256": textual_diff_sha256,
    "upstream": upstream,
}

canonical = (
    json.dumps(
        manifest,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")
    + b"\n"
)
manifest_sha256 = hashlib.sha256(canonical).hexdigest()
OUTPUT_PATH.write_bytes(canonical)

print(f"recipe_id={RECIPE_ID}")
print(f"textual_diff_sha256={textual_diff_sha256}")
print(f"manifest_sha256={manifest_sha256}")
print(f"file_count={len(entries)}")
print(canonical.decode("utf-8"), end="")
```

CLOSEOUT

Return exactly:

COORDINATOR_RW0_B1_PURE_PHASE_VALUES_IMPLEMENTED_READY_FOR_INDEPENDENT_AUDIT

only if:

- both original failures are causally closed;
- every focused gate is exact-green;
- node identity is exact;
- full-suite attempt 002 is 4,331/4,331;
- final path scope is exactly 17;
- only the two authorized continuation entries changed from the stopped
  candidate;
- artifact hygiene and repeated provenance are complete.

Report:

1. exact stopped opening identity and topology;
2. attempt-001 evidence identities and two exact failed nodes;
3. continuation-opening manifest size/hash and per-file baseline;
4. exact two-path continuation delta with before/after size/SHA-256;
5. why the row-value boundary change is static composition coverage rather than
   runtime/public widening;
6. exact expiry repair and proof that frozen schemas/vectors are unchanged;
7. every focused validation command/result/evidence hash;
8. final node count/hash, exact 47 additions, and order comparison;
9. attempt-002 command, result, stdout/stderr/JUnit sizes and SHA-256;
10. protected-file and public-boundary comparisons;
11. artifact/residue guards;
12. final recipe source identity, two-run output identity, tracked-diff hash,
    canonical-manifest size/hash, file count, and safe manifest path;
13. assumptions, limitations, unresolved seams, skipped validation, and
    inspection boundary;
14. separate provenance, validation, and implementation confidence.

Required final statements:

INDEPENDENT_AUDIT_NOT_PERFORMED
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED
REMOTE_CONTACT_NOT_PERFORMED
WORKER_OR_MODEL_NOT_INVOKED
SUPPORTING_REPOSITORIES_NOT_MODIFIED
DEPENDENCIES_NOT_CHANGED
MIGRATIONS_NOT_CHANGED
PUBLIC_API_NOT_WIDENED
FULL_SUITE_ATTEMPT_001_PRESERVED
FULL_SUITE_ATTEMPT_002_RUN_EXACTLY_ONCE

STOP CONDITIONS

Stop without additional mutation when:

- the stopped state differs;
- attempt-001 evidence differs;
- a third continuation path is required;
- a frozen B1 field, schema, relation, digest domain, canonical vector, error,
  traversal limit, privacy rule, or nonclaim must change;
- a legitimate production import would need to be hidden or made dynamic;
- an existing row-value provider or public surface must change;
- a test must be weakened, skipped, xfailed, renamed, or reparameterized;
- C2A, Section 41, SQLite, migration, durable state, filesystem, subprocess,
  network, provider/model, Bridge, ES, worker, adapter, dependency, script, or
  configuration work is required;
- focused validation is not exact-green;
- final node identity differs;
- attempt 002 is not exact-green;
- provenance is unstable or residue remains.
