TITLE

Coordinator RW0-B1 — reconcile the exact schema freeze before implementation

ENGAGEMENT TYPE

Focused read-only correction of the preceding RW0-B1 schema-freeze packet.

Continue in the same read-only Codex conversation. Do not implement, edit,
create, delete, format, chmod, stage, commit, push, create a PR, merge, install,
run tests, invoke a model/provider, launch a process/worker, access a live
database, contact a remote host, contact GitHub, or mutate any repository.

Do not reopen the accepted B1→B2 split broadly. Correct only the finite schema,
relation, budget, and touched-surface defects below, then return one complete
replacement implementation packet.

REPOSITORY

/Users/ds/Repositories/Governed Execution Coordinator/

REQUIRED BASELINE

Require exactly at opening and closing:

- branch: trunk_dev
- HEAD: bf68a5232bff1b412c9414c076d82cab18c8e0aa
- tree: 8fc05f5626bdbb01808df1698c9c2245ab06f1cb
- sole parent: 1a894c5527c610ab40d8e5ae5e530a762c6e60bf
- subject: docs: freeze RW0-A phase-entry contract (#2)
- upstream: origin/trunk_dev
- ahead/behind: 0/0
- worktrees: 1
- worktree/index/untracked/unmerged: clean
- no Git operation, lock, or repository residue

Do not fetch. Stop with:

RW0_B1_SCHEMA_FREEZE_BASELINE_MISMATCH

on any mismatch.

STATUS OF THE PRECEDING PACKET

The preceding packet made substantial progress and remains the source for:

- the B1/B2 split;
- one private B1 module;
- the eight role families;
- no C2A schema/enum/vector widening;
- private/no-I/O/non-authoritative semantics;
- C2A-compatible canonical JSON and domain-separated identity;
- exact built-in external types;
- the privacy boundary;
- RW0-C/D/E and ES ownership exclusions;
- parent-only implementation, validation, provenance, and fresh-audit lifecycle.

Its `RW0_B1_SCHEMA_FREEZE_READY` verdict is not accepted as implementation-ready
because the packet contains source conflicts and mechanically incomplete rules.
Treat its exact class and relation inventory as a draft to reconcile, not an
authorized implementation contract.

BLOCKER B1-FREEZE-001 — GRANT-FAMILY RELATION OVERCLAIMS EXISTING FENCES

Current C2A facts:

- `AttemptFenceV1` carries the parent-standing-grant pair and its own
  attempt-authorization pair.
- `EffectFenceV1` carries the parent-standing-grant pair and its own
  effect-authorization pair.
- Neither fence carries a grant-family ref/digest field.

The preceding packet says the observation, proposal, attempt fence, and effect
fence all bind the same grant-family pair. That relation cannot be implemented
against the existing classes without inventing fields or deriving authority
from a digest.

Required correction:

1. Keep `grant_family_ref` and `grant_family_digest` only in the external
   authority observation and the subordinate proposal.
2. Require the observation and proposal to agree exactly on that pair.
3. Require both existing fences to agree on the exact parent-standing-grant
   ref/digest already present in C2A.
4. Require each observation/proposal authorization-basis pair to equal its
   corresponding existing fence authorization pair byte-for-byte.
5. Treat `family_status=compatible` as an externally authored verifier claim.
   B1 can validate its exact bindings and freshness but cannot authenticate or
   independently derive grant-family ancestry.
6. Do not say that either existing fence stores the family pair.
7. Rename/rewrite the common-family relation so its positive claim is exact and
   no stronger than the supplied external observation.

BLOCKER B1-FREEZE-002 — HOST READINESS COLLAPSES POLICY CEILINGS INTO CAPACITY

`CeilingsV1` contains effect-policy fields such as deployments, commits,
merges, pull requests, pushes, model tokens, deliveries, candidate bytes, and
resource limits. It is not a host-capacity schema.

The preceding packet puts `CeilingsV1` into host readiness and qualification
and compares it as physical capacity. That conflates host evidence with effect
policy and assigns a host meaning to Git/model ceilings.

Required correction:

1. Remove `capacity_ceilings` from `RW0RemoteHostReadinessObservationV1`.
2. Remove `required_capacity_ceilings` from
   `RW0EffectHostQualificationV1`.
3. Keep host readiness bounded to exact safe profile ref/digest pairs for:
   platform, architecture, worker artifact/protocol, execution identity,
   process, isolation, resource, cancellation, credential handoff, capsule,
   validation/review tools, cleanup, freshness, and evidence.
4. Keep effect ceilings exclusively in the authority/fence relation.
5. Do not add numeric physical-host limits in B1. Their mechanics remain RW0-D/E.
6. Qualification may compare exact required profile bindings and current
   authority/effect identity; it must not claim that `CeilingsV1` is host
   capacity.

BLOCKER B1-FREEZE-003 — STALE PROOF FIXTURE PATHS WERE PROMOTED TO B1 GRAMMAR

RW0-A explicitly classifies the earlier ES commit and three-path fixture as
stale-able, non-authoritative proof evidence requiring fresh selection before
RW0-E. Existing C2A currently represents those three paths, but B1 must not
make the fixture a new B1-owned global path grammar.

Required correction:

1. Remove the B1-owned `P` rule that independently hard-codes the three fixture
   paths into every new class.
2. B1 values must bind the exact current path scope supplied by existing C2A
   WorkSpec/fence values without creating a competing path identity.
3. Prefer a safe `path_scope_digest` field whose value is recomputed in
   relations from the exact supplied current C2A path tuple under one explicit
   B1 binding domain.
4. The B1 digest is a correlation binding, not a replacement WorkSpec/fence
   path identity and not permission.
5. The first B1 implementation may support only the path scope currently
   representable by C2A, but the governing document must classify that as a
   compatibility edge rather than a permanent RW0 path contract.
6. Strict subordinate narrowing for this slice must not require path-subset
   mechanics. Exact current path binding is sufficient; strict narrowing must
   occur through effect-set reduction, a lower ceiling, or earlier expiry.

BLOCKER B1-FREEZE-004 — RETRIEVAL EVENTS OMIT THE NARROWER AUTHORIZATION AND
CUSTODY OBSERVATION

The retrieval event draft binds the external verification but not the exact
Coordinator subordinate proposal or the exact custody-availability observation.
That leaves issuance/redemption/consumption disconnected from the narrower
binding and subject availability it is meant to exercise.

Required correction:

Add exact ref/digest pairs for:

- authority-verification observation;
- subordinate-authorization proposal;
- custody-availability observation.

The retrieval-sequence relation must bind all three, plus the exact subject,
semantic digest, asserted content hash/length, attempt/effect/fences, audience,
repository, base, path-scope binding, and validity window. It still proves no
bearer possession or authenticity by itself.

BLOCKER B1-FREEZE-005 — TERMINAL-OUTCOME EVIDENCE AND ABSENCE PROOFS ARE NOT
CLOSED

The generic `evidence_bindings` list allows 0–32 members but the packet does not
freeze exact required/forbidden roles and multiplicities for each branch. The
pre-effect-cancel relation also claims to prove that no effect/request exists,
while B1 has no durable current-state readback that can prove absence.

Required correction:

1. Replace the generic member list with one exact
   `evidence_set_ref`/`evidence_set_digest` pair.
2. B1 validates only the terminal value's pure structural relations:
   phase identity, exact decision pair/kind, exact current-head/stop bindings,
   branch/outcome combination, and the applicable latch, reconciliation, or
   mismatch pair.
3. RW0-C owns the exact evidence-member graph, persisted readback, completeness,
   ambiguity, and proof that an effect/request does or does not exist.
4. Do not claim that B1 proves no effect, no request, complete reconciliation,
   or transaction atomicity. B1 only binds the supplied safe pair representing
   the later C-owned fact.
5. Preserve these exact branch rules:
   - normal accept: outcome `accept`, decision `accept`, latch pair required,
     reconciliation/mismatch pairs absent;
   - normal repair/replan/terminal_reject/ordinary block: same-kind decision,
     all branch-specific optional pairs absent;
   - active_cancel_reconciled: decision `cancel`, outcome `cancel`,
     reconciliation pair required, latch/mismatch absent;
   - active_cancel_unresolved: decision `cancel`, outcome `block`,
     reconciliation pair required, latch/mismatch absent;
   - pre_effect_cancel_basis_unusable: decision `cancel`, outcome `block`,
     mismatch pair required, latch/reconciliation absent.
6. Rename branch validators so they do not imply C-owned absence/completeness
   proof.

BLOCKER B1-FREEZE-006 — THE 1,436 GLOBAL GRAPH BUDGET HAS NO CONSTRUCTION PATH

The eight classes are constructed independently. There is no complete B1 graph
class or aggregate constructor through which one shared construction budget can
flow. The literal 1,436 therefore cannot enforce the claimed whole-graph
construction bound.

Required correction:

1. Remove the unsupported single 1,436 construction budget and formula.
2. Freeze exact per-value reconstruction budgets derived from each class's
   final field/nested-collection inventory.
3. Freeze exact per-relation traversal budgets derived from each relation's
   final argument graph.
4. Every budget charges each occurrence before descent, rejects cycles with an
   active-object set, and does not make shared-DAG aliases free.
5. One relation invocation uses one shared budget across every B1 value and
   nested value it traverses.
6. Pin every formula and literal in tests, including largest-valid and one-over,
   cycles, and compact shared-DAG expansion.
7. Do not add an aggregate schema merely to justify a global budget. A private
   non-schema budget helper inside the one B1 module is sufficient.

BLOCKER B1-FREEZE-007 — CLOSED-WORLD AND INTEGER RULES ARE INCONSISTENT

A regex-open qualification `reason_code` is not a finite reason algebra. The
blanket `0..2^63-1` integer rule is also not existing C2A semantics; C2A uses
field-specific validation and currently accepts non-negative integers without
that general cap.

Required correction:

1. Replace qualification `reason_code` with a finite exact enum and an exact
   result/reason matrix.
2. At minimum distinguish:
   `qualified`, `readiness_unready`, `readiness_unknown`, `readiness_expired`,
   `authority_not_verified`, `authority_denied_or_revoked`,
   `authority_expired`, `phase_or_effect_mismatch`,
   `worker_artifact_mismatch`, `worker_protocol_mismatch`,
   `platform_or_architecture_mismatch`, `profile_mismatch`,
   `global_stop_active`, and `unknown`.
3. `qualified` result requires reason `qualified`; `unknown` requires `unknown`;
   `blocked` requires one of the closed blocking reasons.
4. Remove the blanket `I` rule.
5. For fields inherited from existing C2A/row/global-stop values, use their
   exact owning validators and compare the supplied validated value.
6. For genuinely new integers such as asserted byte length, freeze one explicit
   B1 bound and label it as a new B1 compatibility limit. Do not claim it is an
   existing C2A invariant.
7. If an exact new integer bound cannot be justified and selected in this
   correction pass, return PARTIAL rather than implementation READY.

BLOCKER B1-FREEZE-008 — CURRENT-STATUS TOUCHED SCOPE IS TOO NARROW

The live RW0 owner and four bounded cross-references currently say the complete
implemented boundary stops at C2B3D plus Section 41. Once B1 source exists, the
executable/durable boundary still stops there, but the complete source boundary
does not.

Required correction:

1. Plan one bounded successor/current-status update in the RW0 owner.
2. Update all four normalized-identical current cross-references to say exactly:
   - a private no-I/O RW0-B1 semantic value/relation layer is now implemented;
   - no phase-entry persistence, verifier authenticity, custody, transport,
     process, worker, terminal-outcome runtime, latch, Git, ES route, service,
     scheduler, queue, or autonomous loop is implemented;
   - the durable/executable boundary remains C2B3D plus Section 41.
3. Preserve one complete four-document map and all existing structural/hostile
   mutation protections.
4. Expand the maximum touched-file allowlist to include, when mechanically
   required:
   - `.docs/authority-boundaries.md`;
   - `.docs/autonomous-software-development-operating-model.md`;
   - `.docs/durable-state-model.md`;
   - `.docs/worker-execution-boundary.md`;
   - `tests/test_architecture_contracts.py`;
   - `tests/test_remote_worker_pre_execution_planning_contract.py`;
   in addition to the preceding ten-path proposal.
5. Do not add AGENTS.md, README.md, broad post-publication normalization, or
   unrelated docs unless a current owning test proves they are required.
6. Return one exact maximum allowlist after inspecting every current owner/test.

REQUIRED REPLACEMENT PACKET

Return the entire corrected B1 freeze, not only an errata list.

It must include:

1. final exact class inventory and ordered fields;
2. final exact types, enum domains, optional-pair rules, safe projections, and
   digest domains;
3. corrected authority/family semantics;
4. corrected path-scope binding;
5. corrected retrieval bindings;
6. corrected host readiness/qualification schemas and finite reason matrix;
7. corrected terminal-outcome schema and limited B1 relation claims;
8. exact per-value and per-relation work-budget formulas;
9. exact error algebra;
10. exact reuse/non-collapse ledger;
11. exact module order/imports and allowed production importers;
12. exact maximum touched-file allowlist;
13. exact protected-file list;
14. exact future tests, node-delta rule, validation commands, provenance, audit
    perspectives, and stop conditions;
15. explicit rejected alternatives and why.

PRESERVED NON-GOALS

Do not select or implement:

- B2 framing, terminal-result wire grammar, byte/frame/stderr/process caps;
- Codex CLI versus App Server;
- SQLite, migration 0004, rows, receipts, graphs, writer operations, recovery,
  latch representation, or durable terminal-outcome representation;
- filesystem, subprocess, network, provider/model, Bridge, ES, worker, host, or
  public API behavior;
- a new C2A source/observation/effect enum or changed C2A schema/vector/domain;
- a second plan, attempt, effect, command, candidate, fence, or delivery
  identity.

SUBAGENTS

Use no new subagents unless the parent cannot mechanically reconcile one of the
finite blockers from already inspected source. If a bounded follow-up is
strictly necessary, use at most two read-only explorers, no nested delegation,
and report why parent inspection was insufficient.

VERDICT

Return exactly one:

RW0_B1_SCHEMA_FREEZE_RECONCILED_READY
RW0_B1_SCHEMA_FREEZE_PARTIAL
RW0_B1_SCHEMA_FREEZE_BLOCKED
RW0_B1_SCHEMA_FREEZE_BASELINE_MISMATCH

Use RECONCILED_READY only when every blocker above is closed and the replacement
packet is implementation-exact.

Do not implement.

Required final statements:

REPOSITORY_MUTATION_NOT_PERFORMED
TESTS_NOT_RUN
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED
REMOTE_CONTACT_NOT_PERFORMED
WORKER_OR_MODEL_NOT_INVOKED
SUPPORTING_REPOSITORIES_NOT_MODIFIED
