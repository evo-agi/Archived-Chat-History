TITLE

Coordinator RW0-B1 — exact pure phase-entry value and relation schema freeze

ENGAGEMENT TYPE

Focused continuation of the completed RW0-B read-only reconnaissance.

Remain read-only. Do not implement, edit, create, delete, format, chmod, stage,
commit, push, create a PR, merge, install dependencies, run tests, invoke a
model/provider, launch a process or worker, access a live database, contact a
remote host, contact GitHub, or mutate any repository.

Use bounded read-only subagents when useful. The parent owns the final schema
and implementation-tranche freeze. No repository writer exists in this
engagement.

REPOSITORY

/Users/ds/Repositories/Governed Execution Coordinator/

REQUIRED BASELINE

Require exactly at opening and closing:

- branch:
  trunk_dev
- HEAD:
  bf68a5232bff1b412c9414c076d82cab18c8e0aa
- tree:
  8fc05f5626bdbb01808df1698c9c2245ab06f1cb
- sole parent:
  1a894c5527c610ab40d8e5ae5e530a762c6e60bf
- subject:
  docs: freeze RW0-A phase-entry contract (#2)
- upstream:
  origin/trunk_dev
- ahead/behind:
  0/0
- worktrees:
  1
- worktree/index/untracked/unmerged:
  clean
- no Git operation or lock
- no repository residue

Do not fetch. Stop with:

RW0_B1_SCHEMA_FREEZE_BASELINE_MISMATCH

on any mismatch.

PRIOR RECONNAISSANCE DISPOSITION

The preceding reconnaissance returned:

RW0_B_RECONNAISSANCE_PARTIAL

Accept these source-grounded conclusions as the starting planning overlay, but
recheck every material schema decision against repository source:

1. RW0-B must split:

   - RW0-B1:
     private pure phase-entry, authority, custody, readiness/qualification, and
     terminal-outcome semantic values and relations;

   - RW0-B2:
     private wire framing, bounded terminal-result grammar, protocol/resource
     limits, precedence, and the Codex capability interface.

2. B2 depends on B1. B2 is not part of this engagement.

3. Existing C2A/C2A1 schemas, ordered fields, enum domains, digest domains,
   golden vectors, effect classes, source kinds, observation kinds, and public
   behavior remain byte-identical.

4. Exact Section 41 selected-plan, K8, L34, disposition, selection-head, effect,
   fence, command, candidate, and initial-delivery identities are reused. B1
   must not create a second plan, command, effect, attempt, candidate, delivery,
   or source-observation identity.

5. External verifier facts, custody facts, host facts, and Coordinator
   evaluations remain distinct. A digest is identity evidence, never
   authenticity or permission.

6. RW0-B1 is private, deterministic, immutable, standard-library-only, no-I/O,
   non-authoritative, non-executable, and not durable state.

7. RW0-C owns rows, tables, receipts, mutations, persistence, recovery probes,
   latch representation, and terminal-outcome persistence.

8. RW0-D owns physical custody, bearer handling, process/supervisor/worker
   behavior, transport, Codex invocation, capsule mechanics, and offline
   execution proof.

9. RW0-E owns live-host proof.

10. Exact B2 framing bytes, terminal-result grammar, numeric wire caps, and
    Codex CLI-versus-App-Server mechanics remain deliberately open.

PARENT STRATEGIC DECISIONS

Treat these as decisions for this B1 freeze, not questions:

A. B1 PROCEEDS BEFORE B2

B1’s exact safe semantic values and relations can and should be frozen without
selecting a frame header, wire payload cap, terminal-result wire grammar, stderr
capture cap, CLI/App Server mechanism, SSH mechanism, subprocess API, or
physical custodian.

Do not allow B2’s remaining cap proof to make this result PARTIAL.

B. SELECTED PLAN IS REUSE, NOT A NEW VALUE FAMILY

Do not create a second selected-plan record or digest.

The B1 phase-entry basis must bind the exact current Section 41 selection and
its existing identities:

- K8;
- complete L34;
- selected proposal ref/digest;
- disposition ref/digest/value;
- selection-head revision/digest/postimage;
- exact current program/version/work/WorkSpec safe binding;
- exact semantic attempt, candidate, effect, command, fences, and initial
  delivery;
- current effect and delivery heads;
- global-stop version/state.

A compact B1 class may carry these fields directly or compose one exact private
Section 41/C2A value when source ownership makes that safer. It must not invent
an alternate identity.

C. NEW B1 FACT FAMILIES

Freeze exact private class names, schema IDs, ordered fields, types, finite
domains, canonical encoding, digest domains, bounds, safe projections, and
relations for the minimum necessary roles below.

The role names are fixed; the exact Python class names must be selected in this
engagement.

1. Phase-entry basis

   A Coordinator-authored, no-contact semantic input that binds exact current
   selected lineage and heads. It is not a claim receipt, mutation command,
   launch authority, or durable phase-entry fact.

2. External authority verification observation

   An externally authored safe observation/projection over the current parent
   grant, both distinct persisted per-fence authorization-basis pairs, current
   grant-family compatibility, scope, ceilings, expiry, revocation, audience,
   repository, base, paths, effect, current heads, and global stop.

   Its finite observation status must distinguish at least:
   `verified`, `denied`, and `unknown`.

   A claimed `verified` value is still an external observation until B1
   relations validate exact bindings and freshness. The Coordinator does not
   issue the parent grant.

3. Subordinate authorization proposal

   A Coordinator-authored inert proposal for a narrower authorization binding.
   It binds the exact external observation, exact existing attempt/effect
   fences, and each fence’s exact distinct persisted authorization-basis pair.

   It has its own identity/digest but is not a bearer, executable grant,
   permission, fence replacement, or externally issued authority.

4. Custody availability observation

   A custodian-authored safe observation for exactly one subject kind:
   `work_spec` or `selected_plan`.

   Availability, asserted exact-byte identity, and custody evidence must remain
   explicit. This observation does not prove capability issuance, redemption,
   or consumption.

5. Retrieval capability event observation

   A source-authored safe event observation with a closed event domain that
   keeps at least:
   `issued`, `redeemed`, `consumed`, `expired`, `revoked`, `failed`, and
   `unknown`
   distinct.

   The value contains only a non-bearer safe correlation and exact semantic
   bindings. It never contains the capability, credential, token, secret,
   endpoint, host path, or retrieval material.

6. Remote-host readiness observation

   A host-owner-authored safe capability observation. It contains no hostname,
   IP, host key, credential, endpoint, username, absolute path, environment
   value, or IM bundle body.

   It must safely describe the exact capability/profile dimensions required by
   RW0-A, including worker artifact/protocol identity, platform/architecture,
   process/cancellation, isolation, credential-handoff, capsule, validation/
   review tools, capacity, cleanup, evidence, observed time, and expiry.

   It is readiness evidence, not host identity, launch permission, or
   qualification.

7. Effect-bound host qualification evaluation

   A Coordinator-authored deterministic evaluation over one readiness
   observation, one exact phase/effect/fence basis, and the required scenario
   profile.

   Its finite result must distinguish:
   `qualified`, `blocked`, and `unknown`.

   It does not establish authenticity or perform launch.

8. RW0 terminal-outcome value

   A Coordinator-authored pure semantic value suitable for later RW0-C
   persistence.

   Its finite outcome domain is exactly:

   `accept`, `repair`, `replan`, `terminal_reject`, `block`, `cancel`.

   It must bind the exact RW0 phase-entry basis, exact current heads and evidence
   refs/digests, exact earlier C2B decision pair/kind when applicable, and the
   conditional branch-specific facts:

   - `accept`:
     exact accept decision and exact latch postimage already committed
     atomically by that decision;

   - non-cancel `repair`, `replan`, `terminal_reject`, ordinary `block`:
     exactly one same-kind earlier C2B decision;

   - active `cancel`:
     exact earlier pre-effect C2B cancel decision plus complete reconciliation;

   - pre-effect unusable cancel basis:
     outcome `block` bound to the unusable cancel decision and mismatch
     evidence, with no second C2B block decision.

   The B1 value is not itself durable closure, a C2B development decision,
   effect authority, source observation, latch mutation, program-version
   transition, or successor permission.

D. NO NEW C2A SOURCE OR OBSERVATION ENUM

Do not widen `WorkerObservationV1`, source kinds, observation kinds, effect
classes, routes, or existing C2A schema identities.

The new external authority, custody, retrieval, and host values are separate
RW0-B1 classes. Existing C2A records are composed or referenced where their
closed grammar applies.

E. NO B1 RECOVERY PROBE

Do not define an authoritative recovery-probe value in B1. Exact persisted
readback, receipts, graph membership, commit uncertainty, and recovery belong
to RW0-C.

F. NO GENERIC SHARED HELPER MODULE YET

Default source layout:

src/ge_nwp_coordinator/_rw0_phase_entry_semantic_values.py

Do not introduce a generic shared support module unless source inspection proves
that implementation would otherwise duplicate a security- or identity-critical
algorithm in more than one new production module.

B1 may import exact private C2A and Section 41 values or validators when that
preserves ownership and avoids reinterpretation. It must not import SQLite,
filesystem, subprocess, network, provider, Bridge, ES, or public runtime code.

G. CANONICALIZATION POSTURE

B1 composes C2A identities and therefore must preserve C2A’s canonical text
posture:

- compact deterministic UTF-8 JSON;
- sorted keys when the current C2A contract requires them;
- exact Unicode code points;
- no silent NFC/NFKC normalization;
- strict duplicate-key rejection for decoded canonical objects where decoding
  exists;
- domain-separated SHA-256 identity;
- no timestamps, paths, random values, or machine-specific material outside
  explicitly modeled safe fields.

Do not reuse a Section 41 helper whose Unicode-normalization behavior would
change C2A-compatible bytes.

H. EXACT BUILT-IN TYPES

External constructor inputs must use exact built-in types and reject subclasses
when the existing C2A style does so.

In particular:

- `bool` must never satisfy an integer field;
- mutable `list`, `dict`, or `set` inputs must not be retained;
- closed collections must become exact immutable tuples;
- optionality must be represented explicitly and symmetrically;
- unknown fields, duplicate fields, missing fields, reordered fields where
  order is semantic, and unsupported enum members must fail closed.

I. PRIVACY

No B1 value, canonical bytes, digest input, exception text, `repr`, safe
projection, or test fixture may contain:

- raw WorkSpec or selected-plan bytes;
- bearer capability or credential;
- signature, trust root, token, secret, or environment value;
- hostname, IP, endpoint, host key, username, or absolute path;
- prompt, transcript, hidden reasoning, Codex JSONL, stdout, or stderr;
- provider account/session metadata;
- IM support-bundle body;
- mutable workspace or capsule-store physical path.

Only bounded safe refs, digests, enums, lengths, timestamps, finite profile
identifiers, and non-sensitive correlations may appear.

J. BOUNDS

This engagement must freeze exact B1 bounds.

Derive them mechanically from existing C2A/Section 41 scalar and collection
limits wherever a B1 field carries or composes an existing value.

For genuinely new safe scalars, choose the narrowest existing repository limit
with equivalent semantics and explain the mapping.

For fixed relationships, prefer exact cardinality rather than a broad maximum:

- exactly one phase-entry basis;
- exactly two distinct fence/basis bindings where the author attempt and effect
  fences are both applicable;
- exactly one authority observation per evaluation value;
- exactly one readiness observation per host qualification value;
- exactly one terminal outcome value;
- fixed finite enum domains;
- fixed subject kinds.

Freeze one cumulative construction/reconstruction work budget for the complete
B1 object graph. It must reject compact shared-DAG expansion and cycles before
unbounded work, while accepting the largest valid B1 graph.

Do not select B2 wire payload, frame, stderr, process, or transport limits here.

K. ERROR ALGEBRA

Freeze exact content-free error reasons for:

- invalid external type;
- missing required field;
- unknown field;
- invalid enum;
- malformed ref;
- malformed digest;
- invalid timestamp/window;
- invalid length/cardinality;
- graph cycle;
- cumulative work exhausted;
- relation mismatch;
- stale or expired observation;
- revoked or denied authority;
- per-fence basis mismatch;
- common-family unverified;
- scope/ceiling/audience/repository/base/path/effect mismatch;
- current-head or global-stop mismatch;
- custody subject mismatch;
- invalid retrieval event transition;
- readiness-profile mismatch;
- terminal-outcome branch mismatch;
- privacy-forbidden material.

Align with current private error style. Do not expose offending private values in
messages.

OBJECTIVE

Produce a complete, source-grounded, implementation-ready RW0-B1 schema and
relation packet.

READY requires exact decisions, not candidate ranges or “for example” fields.

MANDATORY OUTPUT

1. Exact class inventory

For every B1 class provide:

- exact Python class name;
- exact schema ID;
- exact digest domain;
- author/fact owner;
- authority posture;
- exact ordered field list;
- exact external constructor type for every field;
- internal stored type;
- required/optional rule;
- finite enum values;
- exact scalar and collection bounds;
- canonical object shape and key order;
- canonical byte rule;
- digest rule;
- safe projection;
- privacy classification;
- permitted consumers;
- prohibited consumers;
- exact content-free errors.

2. Exact relation inventory

For every pure relation provide:

- exact function name;
- exact argument classes and order;
- exact return type;
- exact positive relation;
- exact fail-closed conditions;
- freshness/window rule;
- identity versus evidence distinction;
- cumulative work treatment;
- whether the relation recomputes any digest or only compares;
- exact error reason.

At minimum freeze relations for:

- phase-entry basis consistency with C2A and Section 41;
- external authority observation freshness and scope;
- per-fence basis equality;
- common parent-family compatibility;
- strict subordinate narrowing;
- custody availability to subject binding;
- retrieval event sequence legality;
- readiness observation to effect-bound qualification;
- terminal-outcome branch consistency;
- latch-postimage binding on `accept`;
- same-kind C2B decision binding on non-cancel outcomes;
- cancel-decision/reconciliation binding on active cancel;
- unusable pre-effect cancel basis to terminal `block`.

3. Reuse ledger

For every field and relation identify exact reuse from:

- WorkSpecV1;
- AttemptFenceV1;
- EffectFenceV1;
- WorkerCommandV1;
- DeliveryEnvelopeV1;
- WorkerObservationV1;
- CandidateCapsuleManifestV1;
- CapsuleEntryV1;
- CeilingsV1;
- Section 41 K8/L34/disposition/head contracts;
- C2B decision and latch semantics.

State explicitly where B1 stores an existing object, stores only its
ref/digest/safe projection, or merely validates a supplied existing object.

4. Exact exclusions

List everything excluded from B1 and assign it to B2, C, D, E, ES, or an
external authority/custodian.

5. Exact module design

Require a final recommendation for:

src/ge_nwp_coordinator/_rw0_phase_entry_semantic_values.py

Report:

- top-level class/function order;
- imports;
- `__all__` posture;
- whether dataclasses, NamedTuple, enum, or another current repository idiom is
  used;
- dependency direction;
- allowed production importers during B1;
- why no helper module is needed;
- why C2A source remains byte-identical.

6. Exact implementation touched-file allowlist

Return one maximum path list, not a category list.

Default candidate scope to prove or narrow:

- `.docs/rw0-b1-pure-phase-values.md` — new governing owner;
- `src/ge_nwp_coordinator/_rw0_phase_entry_semantic_values.py` — new private
  source;
- `tests/test_rw0_b1_phase_values.py` — new;
- `tests/test_rw0_b1_relations.py` — new;
- `tests/test_rw0_b1_vectors.py` — new;
- `tests/test_rw0_b1_boundaries.py` — new;
- `tests/test_c2a_nonimplementation.py` — existing exact source/import/export
  inventory;
- `tests/test_runtime_non_authority.py` — existing production/package/public
  boundary;
- `.docs/rw0-remote-worker-contact-phase-entry.md` — bounded successor/current
  status only if mechanically required;
- `tests/test_rw0_remote_contact_phase_entry_contract.py` — bounded owner/status
  protection only if the RW0-A document changes.

Do not include AGENTS.md, README.md, broad architecture cross-references, or
post-publication status normalization by default. If one is required for a
current invariant rather than discoverability, cite the exact owning test and
explain why it cannot be deferred to a later status-normalization tranche.

No `pyproject.toml`, `__init__.py`, SQL, migration, schema, fixture, script,
config, or supporting-repository path may be included.

7. Exact protected files and identities

Name the source/docs/tests that must remain byte-identical, especially:

- `_worker_execution_semantic_values.py`;
- C2A governing contract and golden vectors;
- Section 41 selection implementation;
- migrations 0001–0003;
- application generation;
- `src/ge_nwp_coordinator/__init__.py`;
- StateStore and WriterSession public surfaces;
- `pyproject.toml`;
- existing source/observation/effect enums.

8. Exact validation design

Do not run tests. Return exact future commands and expected node/count strategy
for:

- direct value tests;
- canonical vector tests;
- relation matrices;
- privacy/error tests;
- hostile type/subclass tests;
- maximum and one-over-limit cases;
- shared-DAG/cycle budget cases;
- no-I/O AST/import tests;
- exact importer/source inventory;
- package-root/public export tests;
- C2A compatibility/golden-vector regression;
- RW0-A nonimplementation regression;
- full-suite gate;
- artifact isolation;
- provenance;
- fresh independent audit.

Do not invent exact final test counts that cannot be known before collection.
Instead freeze the expected node-delta rule and exact collection comparison
procedure.

9. Audit plan

Freeze independent perspectives for:

- authority and privacy;
- semantic identity/non-collapse;
- relation correctness and hostile graph bounds;
- test adequacy and causal mutants;
- public boundary and artifact hygiene;
- provenance.

10. Stop conditions

At minimum stop implementation if:

- any existing C2A schema/vector/enum/domain must change;
- a B1 value would contain private or bearer material;
- authenticity or permission is inferred from a digest;
- a new plan/attempt/effect/command/candidate/delivery identity is needed;
- SQLite, filesystem, subprocess, network, model, provider, ES, Bridge, or
  public API code is required;
- B2 framing or Codex mechanics are needed to define B1;
- a path outside the frozen allowlist must change;
- exact bounds cannot be justified from current contracts;
- one class combines external observation with Coordinator authority;
- one value collapses readiness into qualification, availability into
  consumption, or terminal outcome into a C2B decision.

SUBAGENT PLAN

Use exactly three bounded read-only explorers if available; make at most one
retry for a failed start; no nested delegation.

1. Schema/identity explorer
   - exact current class idioms, validators, canonicalization, domains, bounds;
   - exact proposed class/field schemas;
   - C2A/Section 41 reuse.

2. Authority/privacy/relation explorer
   - fact owners, source assertions, freshness, equality/narrowing relations,
     privacy and failure algebra;
   - terminal-outcome branch relations.

3. Module/test/scope explorer
   - imports and consumers, exact module layout, historical assertions,
     smallest touched-file scope, tests, validation, provenance, and audit.

Every explorer must cite repo-relative paths and lines, label evidence,
inference, and uncertainty, and report no mutation/tests/side effects.

PARENT RECONCILIATION

The parent must:

- inspect all material claims directly;
- preserve disagreements;
- choose one exact schema where children differ;
- reject alternative schemas explicitly;
- ensure B2 is not smuggled into B1;
- verify baseline unchanged;
- return one closed implementation packet.

VERDICT

Return exactly one:

RW0_B1_SCHEMA_FREEZE_READY
RW0_B1_SCHEMA_FREEZE_PARTIAL
RW0_B1_SCHEMA_FREEZE_BLOCKED
SUBAGENT_UNAVAILABLE
RW0_B1_SCHEMA_FREEZE_BASELINE_MISMATCH

Use READY only when every class, field, type, enum, bound, domain, relation,
error, module, touched file, test, validation command, audit perspective, and
stop condition is exact.

Use PARTIAL only for a genuinely irreducible B1 decision. Do not return PARTIAL
because B2 wire caps or Codex runtime mechanics remain open; they are outside
this engagement.

Do not implement.

Required final statements:

REPOSITORY_MUTATION_NOT_PERFORMED
TESTS_NOT_RUN
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED
REMOTE_CONTACT_NOT_PERFORMED
WORKER_OR_MODEL_NOT_INVOKED
SUPPORTING_REPOSITORIES_NOT_MODIFIED
