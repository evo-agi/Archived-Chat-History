## Engineering disposition

**Advance to a fresh independent audit. Do not repair, stage, commit, push, or create a PR yet.**

Codex reports a complete implementation closeout:

- the continuation remained bounded to the intended semantic slice;
- the final candidate contains exactly 17 paths, including the newly authorized static row-value consumer test;
- the original two full-suite failures were closed without changing the frozen schemas or relations;
- the final node set is 4,331, with exactly 47 additions in the four new B1 test files;
- full-suite attempt 002 passed 4,331/4,331;
- repeated provenance produced a stable 17-path canonical manifest.

Those are sufficient **implementation-reported conditions for audit entry**, not acceptance. The governing freeze defines B1 as private semantics over supplied evidence that grant no permission and implement no contact or durable state.  Its relations may compare identities, currentness, and supplied claims, but cannot authenticate source facts or prove later latch, reconciliation, or absence properties. 

The project lifecycle requires a fresh read-only conversation after implementation. Independent audit must reproduce provenance before inspecting correctness and must not repair the candidate. 

## What the audit must challenge

The implementation report does not expose an immediate reason for another repair turn, but four areas deserve aggressive counterexamples:

1. **Identity and authority non-collapse.** Verify that no valid digest becomes authenticity or permission; the external family claim remains external; the path-scope digest remains correlation rather than path authority; and no new selected-plan, attempt, effect, command, fence, or delivery identity appears.

2. **Canonicalization and hostile graph bounds.** Recompute vectors independently, test exact types and subclasses, cycles, shared-DAG aliases, largest-valid and one-over limits, and prove that called helpers share rather than reset relation budgets. The freeze pins exact value and relation limits, including alias charging and current C2A path-tuple assumptions.  

3. **Relation semantics.** Exercise every authority, custody, retrieval, qualification, and terminal branch with one-field mutants. In particular, confirm that:
   - unavailable or unknown custody does not imply retrieval;
   - failed or unknown retrieval does not authorize retry;
   - qualification precedence is exact;
   - the terminal value does not claim evidence completeness, latch atomicity, reconciliation completeness, or effect/request absence.

4. **Test and boundary causality.** Verify that canonical vectors are independent rather than production-derived, documentation owners cannot be satisfied by hidden or relocated text, the `expiry` change did not weaken a real invariant, and the row-value consumer allowlist contains exactly the three direct provider imports—not a broader static exemption.

The freeze expressly permits no production consumer in B1, no package-root or public persistence exposure, and no B2/C/D/E/ES mechanics.  It also requires fresh independent perspectives covering authority/privacy, non-collapse, relation and budget correctness, test adequacy, public boundaries, artifacts, and provenance. 

## Next action

Start a **new read-only Codex conversation** and send:

:chatgpt-content-reference{index="3"}

The prompt is self-contained. It includes:

- the exact branch, HEAD, upstream, and 17-path topology;
- the final target manifest path, size, and SHA-256;
- the exact 3,945-byte provenance recipe;
- attempt 001 and attempt 002 evidence identities;
- the complete accepted 40,515-byte reconciled freeze packet;
- four bounded independent audit perspectives;
- direct hostile probes and mutation matrices;
- candidate-versus-clean-HEAD node comparison;
- one independently run full suite, gated on source inspection being green;
- closing provenance and artifact hygiene;
- exact `ACCEPT`, `BLOCK`, `REJECT`, and `AUDIT_PROVENANCE_MISMATCH` rules.

The successful verdict is:

```text
ACCEPT

COORDINATOR_RW0_B1_PURE_PHASE_VALUES_ACCEPTED_READY_FOR_COMMIT_AND_PR_GATE
```

Any repository byte change after this point requires new validation, new provenance, and a new independent audit. Provenance binds everyone to the same bytes but does not itself establish correctness or sound authority boundaries. 

### Sources

- Reconciled RW0-B1 governing packet. 
- Exact relations and deferred proof boundaries. 
- Bounded-work contract. 
- Consumer, exclusion, touched-surface, and validation requirements. 
- Independent-audit lifecycle. 

**Confidence:** 99% that fresh independent audit is the correct next gate; 94% that the candidate will require at most bounded implementation repairs rather than an architecture refreeze.
