TITLE

Coordinator RW0-B1 — repair first independent-audit findings and prepare fresh
re-audit

ENGAGEMENT TYPE

Bounded parent-only repair in the original RW0-B1 implementation conversation.

Do not continue in the independent-audit conversation. Return to the existing
write-enabled implementation conversation that produced the current candidate.

Do not create or resume subagents. You are the sole repository writer.

This engagement authorizes mutation only in the exact eight-path repair
allowlist below, isolated local validation, external repair evidence, and exact
new patch provenance.

This engagement does not authorize staging, commit, push, PR creation, merge,
tag, release, deployment, remote contact, dependency installation, migration,
supporting-repository mutation, or independent audit.

REPOSITORY

/Users/ds/Repositories/Governed Execution Coordinator/

AUDIT VERDICT TO REPAIR

The fresh independent audit returned `BLOCK`.

Accepted findings:

- F1 — High — strict subordinate narrowing accepts equality to the verified
  parent by counting reduction only against an over-broad fence.
- F2 — High — current authority binding omits exact fence stop/head/author-fence
  relations and uses an object-identity shortcut.
- F3 — High — retrieval and host-qualification relations do not enforce the
  prerequisite authority/narrowing/current-stop conditions available from
  their supplied arguments.
- F4 — Medium — B1 canonical JSON has an undocumented Python-runtime integer
  digit limit while the frozen `N` grammar has no upper bound.
- F5 — High — field/vector, relation, and relation-budget tests are materially
  non-causal or incomplete.
- F6 — Low — the RW0 owner simultaneously says B1 is implemented and calls
  C2B3D plus Section 41 the unqualified complete implemented boundary.
- F7 — observation requiring an engineering decision — retrieval sequencing
  currently accepts repeated event refs and a later event that extends the
  issued capability expiry.

No fundamental design rejection was found. Repair the candidate; do not reopen
the B1/B2 split or add runtime/durable behavior.

EXPECTED OPENING STATE

Before mutation, require exactly:

- physical root:
  /Users/ds/Repositories/Governed Execution Coordinator/
- branch:
  codex/rw0-b1-pure-phase-values-v1
- HEAD:
  bf68a5232bff1b412c9414c076d82cab18c8e0aa
- HEAD tree:
  8fc05f5626bdbb01808df1698c9c2245ab06f1cb
- sole parent:
  1a894c5527c610ab40d8e5ae5e530a762c6e60bf
- subject:
  docs: freeze RW0-A phase-entry contract (#2)
- upstream:
  origin/trunk_dev
- ahead/behind:
  0/0
- worktrees:
  1
- dirty paths:
  exactly 17
- tracked modifications:
  exactly 11
- untracked paths:
  exactly 6
- staged/unmerged:
  0/0
- all candidate paths:
  regular mode 0644
- no deletion, rename, copy, symlink, Git-recorded mode change, Git operation,
  Git lock, or repository residue.

Require the live bytes to match exactly:

`/private/tmp/gec-rw0-b1-continuation.qbmvj7qo/final-provenance-1.manifest.json`

with:

- size:
  3,685 bytes
- SHA-256:
  5e2ccb1fffb6af4db4e242041a8ef56b511b7b30149b80c0a2cb121bb82aeeb5
- tracked textual-diff SHA-256:
  28864c904c2f9a09ac6d0d38a61d7aade901cdc4077406702a8019d66883d883

Require the independent audit terminal record to be safely readable:

`/private/tmp/gec-rw0-b1-audit-if52pwsc/terminal-evidence.json`

Retain its safe identity in the repair evidence. Do not alter audit evidence.

Run the exact provenance recipe below twice before editing and require exact
equality to the pinned 17-path target. On mismatch, stop.

REPAIR OBJECTIVE

Close F1–F7 without changing:

- any class name;
- any schema ID;
- any ordered field list;
- any digest domain;
- any relation name or public signature;
- canonical bytes for every previously valid fixture whose integer leaves are
  within the new canonical compatibility limit;
- the eight-role decomposition;
- the B1/B2/C/D/E/ES ownership split;
- the no-I/O, private, non-authoritative, non-executable boundary;
- existing C2A, C2B3D, Section 41, row, decision, and global-stop contracts;
- package exports, dependencies, migrations, or public surfaces.

One bounded contract correction is authorized for F4:

- every exact integer leaf serialized into a B1 canonical identity MUST be in
  `0..2^63-1`;
- this applies to direct B1 integer fields and integer leaves inside stored
  reconstructed L34 and `CeilingsV1` mappings;
- `bool` and integer subclasses remain invalid;
- this is an explicit B1 canonical/durable-compatibility bound only;
- it does not change C2A or Section 41 owning validators and is not a wire,
  allocation, process, token, output, or host-resource cap;
- overflow fails at construction/reconstruction before `json.dumps` with
  `invalid_length_or_cardinality`;
- canonicalization must not depend on `sys.set_int_max_str_digits`, global
  interpreter mutation, machine configuration, or an environment-specific
  exception.

No other schema change is authorized.

EXACT REPAIR ALLOWLIST

Only these eight existing candidate paths may change relative to the pinned
17-path target:

1. `.docs/rw0-b1-pure-phase-values.md`
2. `.docs/rw0-remote-worker-contact-phase-entry.md`
3. `src/ge_nwp_coordinator/_rw0_phase_entry_semantic_values.py`
4. `tests/test_rw0_b1_phase_values.py`
5. `tests/test_rw0_b1_relations.py`
6. `tests/test_rw0_b1_vectors.py`
7. `tests/test_rw0_b1_boundaries.py`
8. `tests/test_rw0_remote_contact_phase_entry_contract.py`

The other nine candidate paths must remain byte-identical to the opening repair
target. Every path outside the complete 17-path candidate must remain
byte-identical to HEAD.

Final topology remains exactly:

- 17 dirty paths;
- 11 tracked modifications;
- 6 untracked;
- 0 staged;
- 0 unmerged;
- all regular mode 0644;
- no Git-recorded addition/deletion/rename/copy/mode change.

Stop if a ninth repair path is required.

F1 — STRICT NARROWING

Repair `validate_subordinate_narrowing` so that:

1. The verified parent observation is the narrowing reference point.
2. The attempt fence and current effect fence must themselves fit within the
   verified parent:
   - each applicable fence ceiling is componentwise <= parent ceilings;
   - each applicable fence expiry is <= the verified parent grant expiry;
   - the current effect class is inside the verified parent's allowed set.
3. The proposal must remain <= parent and both applicable fences for ceilings
   and expiry.
4. Strictness is satisfied only by at least one reduction from the verified
   parent:
   - the verified allowed-effect set has more than the proposal's one effect;
   - or at least one proposal ceiling is strictly lower than the corresponding
     verified parent ceiling;
   - or proposal expiry is strictly earlier than verified parent expiry.
5. A proposal equal to the parent is invalid even when a supplied fence is
   broader than the parent.
6. Over-broad or otherwise parent-incompatible fences fail
   `scope_or_ceiling_mismatch`.
7. Do not add path-subset narrowing.

Add a deterministic causal regression reproducing the audit counterexample.

F2 — CURRENT AUTHORITY, AUTHOR FENCE, HEAD, AND STOP BINDING

Repair authority and narrowing validation so that:

1. `author_effect_fence` is always bound semantically to the exact author fence
   in the phase basis/L34 before any same-current-fence optimization.
2. Do not use Python object identity (`is`) as a semantic bypass.
3. When current and author effect fences are semantically the same, establish
   that using their exact ref/digest and owning C2A relation—not object identity.
4. When current effect differs, run the existing later-effect relation exactly.
5. Require the basis, observation, proposal, attempt fence, author effect fence,
   and current effect fence to agree on every current global-stop coordinate
   they actually carry. At minimum, every fence stop version must equal the
   basis current stop version.
6. Require a clear current stop for authority progression and subordinate
   narrowing. Matching `active` claims do not pass.
7. Require the observation's current effect-head and delivery-head digests to
   equal the phase basis current head digests.
8. Require the proposal's phase, stop, fence, parent, family, path, repository,
   base, audience, and current-effect bindings to agree with the current
   observation and basis.
9. Preserve the external-source nature of family compatibility; do not derive
   ancestry from digests.

Add exact causal tests for:

- basis/claims at stop version 8 with fences at version 7;
- observation bound to a different current effect-head digest;
- later current effect fence passed in both author/current roles;
- active stop matching across supplied claims;
- one-field head/stop/fence drift.

F3 — ENFORCEABLE DOWNSTREAM COMPOSITION

Make downstream composition explicit and mechanically enforced without changing
relation signatures or frozen traversal-limit literals.

A. Retrieval

`validate_retrieval_event_sequence` must, in one shared-budget invocation:

- establish the exact current subordinate-narrowing relation over the supplied
  basis, observation, proposal, attempt fence, current effect fence, and
  `now_utc`;
- establish the exact live custody binding for the supplied availability and
  subject;
- bind every event to the exact authority observation, proposal, custody
  observation, phase, subject, physical-byte assertion, attempt/effect/fences,
  repository/base/path, and safe correlation;
- reject active stop, denied/revoked/unknown/incompatible/stale authority,
  wrong proposal effect, non-narrow proposal, parent/fence mismatch, stale or
  unavailable custody, and head/stop drift before treating
  issued/redeemed/consumed as valid.

Use internal single-pass helpers over already charged objects. Called checks
must share the existing retrieval relation budget; do not reset the budget or
double-charge an already traversed argument. If the frozen limit cannot cover
the exact single-pass implementation, stop and report the mechanical
contradiction rather than changing the limit.

B. Host qualification

`validate_host_qualification` must compute and verify the exact closed
result/reason using all predicates available from its existing arguments:

- exact phase, current effect/fence, current head, path, and stop bindings;
- effect class membership in `allowed_effect_classes`;
- verified/compatible/unrevoked and fresh authority;
- parent/current-fence ceiling and expiry compatibility needed for the current
  effect;
- exact current effect-head/delivery-head digests;
- fresh readiness and exact profile pairs.

Required result treatment remains:

- active global stop -> `blocked/global_stop_active`;
- denied or revoked -> `blocked/authority_denied_or_revoked`;
- expired authority -> `blocked/authority_expired`;
- unknown authority/revocation -> `unknown/unknown`;
- effect excluded by the allowed set, incompatible family, or otherwise
  structurally invalid current authority -> `blocked/authority_not_verified`
  unless an exact phase/effect/fence identity mismatch takes the earlier
  `blocked/phase_or_effect_mismatch` precedence;
- only a completely eligible current claim may be `qualified/qualified`.

This relation still does not authenticate a source or launch anything.

Add the exact audit counterexamples:

- retrieval event with a proposal for the wrong effect class;
- qualified result while allowed effects exclude the effect;
- narrowing/retrieval with matching active stop.

F4 — CANONICAL INTEGER COMPATIBILITY

Update the B1 governing document, source, and tests so that:

- every exact integer leaf entering B1 canonical identity is
  `0..2^63-1`;
- the check covers direct fields, L34 integer leaves, and all fifteen
  `CeilingsV1` leaves;
- the check occurs before canonical JSON conversion;
- one-over fails with `invalid_length_or_cardinality`;
- a 4,301-digit exact integer fails deterministically for that B1 reason rather
  than leaking Python's integer-string conversion error;
- existing canonical vectors with in-range values remain byte-identical;
- no global interpreter conversion limit is modified;
- the documentation clearly labels this as new B1 compatibility policy, not an
  inherited C2A rule or practical runtime limit.

Add maximum, one-over, huge-integer, nested-L34, and nested-ceiling cases.

F5 — CAUSAL TEST ORACLES

Strengthen the four B1 test files.

1. Literal field inventory

- Pin every class's `_FIELDS` as literal test-owned tuples.
- Do not derive expected fields, schema IDs, domains, enum sets, or field counts
  from production constants.
- Add a same-count field rename/reorder mutant or equivalent control proving the
  literal oracle is causal.

2. Independent vectors

- Build literal valid mappings and independently compute canonical bytes and
  digests without using production field tuples or canonical helpers as the
  expected oracle.
- Preserve no-normalization checks and exact valid-vector identities.

3. Every relation

Directly invoke all thirteen relations in positive and causal-negative tests:

- `validate_phase_entry_basis`
- `validate_authority_observation`
- `validate_per_fence_basis`
- `validate_external_common_family_claim`
- `validate_subordinate_narrowing`
- `validate_custody_binding`
- `validate_retrieval_event_sequence`
- `validate_host_qualification`
- `validate_terminal_outcome_binding`
- all four terminal shape validators.

`validate_phase_entry_basis` and `validate_terminal_outcome_binding` must no
longer be existence-only assertions.

4. Real relation budgets

- Exercise every actual relation under its shared traversal budget.
- Prove largest valid, one-over, cycle, and repeated shared-DAG alias charging.
- Prove helper composition does not reset or make aliases free.
- Do not test only the budget helper in isolation.

5. Audit counterexamples

Check in exact causal negatives for every F1–F4 and F7 case.

Do not weaken, skip, xfail, rename gratuitously, or reduce existing coverage.

F6 — RW0 CURRENT STATUS

Make the smallest owner correction so that the RW0 document says:

- B1 private pure semantics are implemented;
- the complete durable and executable implemented boundary remains C2B3D plus
  Section 41;
- no persistence, authenticity, custody, transport, process, worker,
  terminal-outcome runtime, latch, Git, ES route, service, queue, scheduler, or
  autonomy is implemented.

Do not leave an unqualified statement that C2B3D plus Section 41 are the
complete implemented boundary.

Add a direct contract assertion and a causal stale-wording mutant in
`tests/test_rw0_remote_contact_phase_entry_contract.py`.

Do not change the four already normalized cross-reference bodies.

F7 — RETRIEVAL EVENT IDENTITY AND EXPIRY

Resolve the audit observation as follows:

1. Every event ref in one sequence is unique.
2. All events in one sequence use one immutable `expires_at` value for the same
   safe correlation.
3. `issued`, `redeemed`, and `consumed` must occur strictly before that immutable
   expiry.
4. `expired` must occur at or after that expiry.
5. `revoked`, `failed`, and `unknown` may occur before or after expiry but are
   terminal and permit no later event or retry.
6. No event may reference itself as predecessor.
7. Predecessor ref/digest, sequence number, nondecreasing occurrence time, and
   terminality remain exact.
8. A later event may not extend the capability lifetime by claiming a later
   expiry.

Update the B1 governing document, source, and causal tests. Do not add fields or
change the sequence cardinality.

TEST-FIRST REPAIR GATE

Before changing production source or documentation:

1. Add/strengthen the exact tests for F1–F7 in the five repair-authorized test
   files.
2. Run one isolated causal-red gate over those exact tests.
3. Require failures caused by current false acceptance, incomplete oracle,
   unbounded integer handling, or stale status wording—not syntax errors,
   invalid fixtures, collection weakening, or unrelated setup.
4. Retain stdout, stderr, JUnit, exact argv/environment/umask, repository
   fingerprint, and node identities.
5. Do not rerun the red gate.

Then repair source and documentation.

VALIDATION ISOLATION

Create one new external operator-owned, non-symlink, mode-0700 repair root under
`/private/tmp`.

For every pytest child:

- capture actual caller umask;
- restore it before launch;
- record and require equal caller/child numerical umask;
- use:
  - `env -u PYTHONTRACEMALLOC -u PYTHONWARNINGS`;
  - `LC_ALL=C`, `LANG=C`;
  - `PYTHONDONTWRITEBYTECODE=1`;
  - distinct external `PYTHONPYCACHEPREFIX`, `TMPDIR`, `--basetemp`, JUnit;
  - `PYTEST_DISABLE_PLUGIN_AUTOLOAD=1`;
  - `PYTEST_ADDOPTS=''`;
  - `PYTHONHASHSEED=0`;
  - `python3 -B -m pytest -p no:cacheprovider -W error`;
  - serial execution.

Before and after every final green run require exact candidate bytes, modes,
path set, branch/HEAD/upstream, zero staged/unmerged, no operation/lock, and no
repository residue.

OPENING REPAIR NODE COLLECTION

Before editing, collect the complete ordered candidate node list exactly once.
Do not assume 4,331 after new test design.

FINAL VALIDATION ORDER

After source/docs repair and cleanup:

1. Collect the complete final ordered node list exactly once.

   Require:

   - repair-opening minus final is empty;
   - final additions belong only to:
     - `tests/test_rw0_b1_phase_values.py`
     - `tests/test_rw0_b1_relations.py`
     - `tests/test_rw0_b1_vectors.py`
     - `tests/test_rw0_b1_boundaries.py`
     - `tests/test_rw0_remote_contact_phase_entry_contract.py`
   - every repair-opening node retains exact order;
   - no duplicate, skip, xfail, warning, collection hook, renamed or collapsed
     node.

2. Run the exact causal F1–F7 tests.

3. Run each B1 test file individually.

4. Run the five B1 test files together, including the RW0 owner contract file.

5. Run source/public/static boundaries:

- `tests/test_c2a_nonimplementation.py`
- `tests/test_runtime_non_authority.py`
- `tests/test_c2b2_development_row_value_boundaries.py`
- `tests/test_b2a_writer_session_contract.py`

6. Run C2A compatibility:

- `tests/test_worker_execution_semantic_values.py`
- `tests/test_worker_execution_semantic_vectors.py`
- `tests/test_worker_execution_semantic_relations.py`
- `tests/test_worker_execution_semantic_boundaries.py`
- `tests/test_c2a_relations.py`
- `tests/test_c2a_first_slice_semantic_protocol_contract.py`

7. Run RW0/current-status/docs:

- `tests/test_rw0_remote_contact_phase_entry_contract.py`
- `tests/test_architecture_contracts.py`
- `tests/test_remote_worker_pre_execution_planning_contract.py`
- `tests/test_autonomous_software_development_operating_model.py`

8. Run exact path, mode, status, import, public-surface, protected-byte,
   `git diff --check`, operation/lock, and repository-residue guards.

9. Run the complete suite against frozen repair bytes.

Repair full-suite policy:

- run repair attempt 001 exactly once;
- if it fails only because of this repair and every correction remains inside
  the exact eight-path repair allowlist, repair and run repair attempt 002
  exactly once;
- never run repair attempt 003;
- if any ninth repair path or frozen architecture change is required, stop.

For every final green run require:

- return code 0;
- exact collected/passed accounting;
- zero failed/errors/skipped/xfailed/warnings;
- empty stderr;
- no duplicate, ambiguous, parse-error, or unmapped JUnit case;
- equal caller/child umask;
- unchanged frozen bytes.

PROTECTED SURFACES

Relative to the pinned 17-path opening target:

- only the eight repair-authorized entries may change;
- the other nine candidate entries remain byte-identical.

Relative to HEAD, everything outside the complete 17-path candidate remains
byte-identical, especially:

- existing C2A source, schemas, enums, relations, vectors, and path grammar;
- C2B3D and Section 41 source/contracts;
- row-value providers;
- SQLite, migrations, catalog, application generation;
- package root, StateStore, WriterSession, public protocols;
- dependencies, scripts, configuration, fixtures;
- AGENTS.md and README.md;
- supporting repositories.

No production consumer beyond the private B1 module may appear.

ARTIFACT HYGIENE

Remove only repair-created transient caches, pycache, basetemps, temporary
archives/files, and repository residue after preserving terminal evidence.

Do not modify or delete implementation or audit evidence.

Do not run `compileall` or `py_compile` against repository paths.

FINAL PROVENANCE

After final validation and cleanup, run the exact unchanged provenance recipe
below twice.

Require:

- return code 0;
- empty stderr;
- byte-identical complete stdout;
- byte-identical canonical manifests;
- exact branch/HEAD/upstream;
- exactly 17 entries;
- exactly 11 tracked modifications and 6 untracked;
- safe regular file types and expected modes;
- stable tracked textual-diff SHA-256.

Compare final with the pinned opening target and prove:

- only repair-authorized entries changed;
- all other candidate entries are exact;
- no path became newly dirty or ceased being dirty.

EXACT PROVENANCE RECIPE

```python
from __future__ import annotations

import hashlib
import json
import os
import stat
import subprocess
from pathlib import Path

RECIPE_ID = "governed-execution.audit-patch-manifest.v1"
OUTPUT_PATH = Path("/tmp/ge-coordinator-b3a-audit-manifest-v1.json")


def git_bytes(*args: str) -> bytes:
    env = os.environ.copy()
    env["LC_ALL"] = "C"
    env["LANG"] = "C"
    result = subprocess.run(
        ["git", *args],
        check=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        env=env,
    )
    return result.stdout


def git_text(*args: str) -> str:
    return git_bytes(*args).decode("utf-8", "strict").strip()


def nul_paths(data: bytes) -> list[str]:
    return [
        item.decode("utf-8", "strict")
        for item in data.split(b"\0")
        if item
    ]


head = git_text("rev-parse", "HEAD")
branch = git_text("branch", "--show-current")
upstream = git_text("rev-parse", "--abbrev-ref", "--symbolic-full-name", "@{u}")

tracked = set(
    nul_paths(git_bytes("diff", "--name-only", "--no-renames", "-z", "HEAD", "--"))
)
added = set(
    nul_paths(
        git_bytes(
            "diff",
            "--name-only",
            "--no-renames",
            "--diff-filter=A",
            "-z",
            "HEAD",
            "--",
        )
    )
)
deleted = set(
    nul_paths(
        git_bytes(
            "diff",
            "--name-only",
            "--no-renames",
            "--diff-filter=D",
            "-z",
            "HEAD",
            "--",
        )
    )
)
untracked = set(
    nul_paths(git_bytes("ls-files", "--others", "--exclude-standard", "-z"))
)

if tracked & untracked:
    raise SystemExit("tracked/untracked path overlap")

entries: list[dict[str, object]] = []
for relative_path in sorted(tracked | untracked):
    if relative_path in untracked:
        kind = "untracked"
    elif relative_path in deleted:
        kind = "tracked_deleted"
    elif relative_path in added:
        kind = "tracked_added"
    else:
        kind = "tracked_modified"

    entry: dict[str, object] = {
        "kind": kind,
        "path": relative_path,
    }

    if kind == "tracked_deleted":
        entry.update(
            {
                "file_type": "missing",
                "mode": None,
                "sha256": None,
                "size": None,
            }
        )
    else:
        path = Path(relative_path)
        metadata = path.lstat()
        mode = f"{stat.S_IMODE(metadata.st_mode):04o}"
        if stat.S_ISREG(metadata.st_mode):
            payload = path.read_bytes()
            file_type = "regular"
        elif stat.S_ISLNK(metadata.st_mode):
            payload = os.readlink(path).encode("utf-8")
            file_type = "symlink"
        else:
            raise SystemExit(f"unsupported file type: {relative_path}")

        entry.update(
            {
                "file_type": file_type,
                "mode": mode,
                "sha256": hashlib.sha256(payload).hexdigest(),
                "size": len(payload),
            }
        )

    entries.append(entry)

diff_bytes = git_bytes(
    "diff",
    "--full-index",
    "--binary",
    "--no-ext-diff",
    "--no-textconv",
    "--no-renames",
    "HEAD",
    "--",
)
textual_diff_sha256 = hashlib.sha256(diff_bytes).hexdigest()

manifest = {
    "branch": branch,
    "files": entries,
    "head": head,
    "recipe_id": RECIPE_ID,
    "textual_diff_sha256": textual_diff_sha256,
    "upstream": upstream,
}

canonical = (
    json.dumps(
        manifest,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")
    + b"\n"
)
manifest_sha256 = hashlib.sha256(canonical).hexdigest()
OUTPUT_PATH.write_bytes(canonical)

print(f"recipe_id={RECIPE_ID}")
print(f"textual_diff_sha256={textual_diff_sha256}")
print(f"manifest_sha256={manifest_sha256}")
print(f"file_count={len(entries)}")
print(canonical.decode("utf-8"), end="")
```

CLOSEOUT

Return exactly:

COORDINATOR_RW0_B1_FIRST_AUDIT_FINDINGS_REPAIRED_READY_FOR_FRESH_REAUDIT

only when F1–F7 are mechanically closed, every final gate is exact-green,
artifact hygiene is complete, and repeated provenance is stable.

Report:

1. opening repository identity/topology and pinned target reproduction;
2. audit finding disposition F1–F7;
3. exact repair path delta with before/after size/SHA-256;
4. causal-red command/results/evidence;
5. exact realization of strict parent narrowing;
6. author/current fence, head, and stop binding;
7. downstream retrieval/qualification composition;
8. canonical integer compatibility policy and unchanged valid vectors;
9. literal field/relation/budget oracle improvements;
10. retrieval uniqueness/immutable-expiry rules;
11. RW0 owner status correction;
12. opening/final node counts, hashes, additions, and order comparison;
13. every focused/full-suite command/result/evidence hash;
14. failed attempts and whether repair attempt 002 was needed;
15. protected/public/import/dependency/migration comparisons;
16. artifact hygiene;
17. recipe identity, two-run output identity, tracked diff, final manifest
    size/hash/count/path;
18. assumptions, limitations, unresolved later seams, skipped validation, and
    inspection boundary;
19. separate provenance, validation, and implementation confidence.

Required final statements:

INDEPENDENT_AUDIT_NOT_PERFORMED
STAGING_NOT_PERFORMED
COMMIT_NOT_PERFORMED
PUSH_NOT_PERFORMED
PR_NOT_CREATED
REMOTE_CONTACT_NOT_PERFORMED
WORKER_OR_MODEL_NOT_INVOKED
SUPPORTING_REPOSITORIES_NOT_MODIFIED
DEPENDENCIES_NOT_CHANGED
MIGRATIONS_NOT_CHANGED
PUBLIC_API_NOT_WIDENED
PRIOR_AUDIT_EVIDENCE_PRESERVED

STOP CONDITIONS

Stop without further mutation if:

- opening provenance differs;
- a ninth repair path is required;
- a class, field list, schema ID, digest domain, relation signature, role
  decomposition, or B1/B2/C/D/E/ES ownership split must change;
- the frozen traversal-limit literals are mechanically insufficient;
- a new scenario-profile class or production consumer is required;
- private/bearer material would enter B1;
- a digest would become authenticity or permission;
- existing C2A, C2B3D, Section 41, row, decision, or global-stop contracts must
  change;
- SQLite, migration, durable state, filesystem, process, network, provider,
  model, Bridge, ES, worker, adapter, dependency, script, configuration, or
  public API work is required;
- tests must be weakened, skipped, xfailed, or gratuitously renamed;
- repair full-suite attempt 002 is not exact-green;
- final provenance is unstable or residue remains.
