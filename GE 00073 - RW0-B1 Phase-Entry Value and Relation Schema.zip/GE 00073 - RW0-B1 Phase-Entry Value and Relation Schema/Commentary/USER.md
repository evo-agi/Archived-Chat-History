I started capturing this sequence of events after ChatGPT acknowledged the fresh snapshot in project sources. `Timeline/T0 - CHATGPT.md` marks a clean start for the tranche.

File `Timeline/T7 - USER PROMPT FROM CHATGPT.md` is from GE Chat 00071.

When I sent `Timeline/T24 - CODEX PROMPT FROM CHATGPT.md` to Codex, via the ChatGPT app on MacOS, the app still sent the prompt to ChatGPT, even though the chat is new and I have already changed to Codex. This sort of indeterminstic model selection is sporadic, and it might be affecting project chat 00068 as well (I can't remember clearly if that's really the case). I've stopped trying to inform Chat 00073 about the model switch, and instead called both scenarios Codex response (USER -> Codex -> Codex chat turns out to be using ChatGPT -> Codex -> ChatGPT -> USER, vs USER -> Codex).
