Chat 00077 needed a "nudge" from me to continue after T34 of chat `GE 00077 - RW0-C2 Private Value and Graph Profiles`, hence `Timeline/T0 - USER.md`. That's not a first, and it's rather annoying.

`Timeline/T4 - USER PROMPT FROM CHATGPT.md` is from GE Chat 00071, which disagrees with the scope imposed by `Timeline/T3 - CHATGPT.md` and `Timeline/T3 - CODEX PROMPT FROM CHATGPT.md`.
