# Independent audit report

**RW0_C2_SINGLE_REALIZATION_PROOF_POSTURE_CONTRACT_ACCEPTED_READY_FOR_COMMIT_GATE**

This accepts the exact eight-path **target contract and bounded verifier**. It establishes no implemented supplier, live proof, executable authorization, or RW0-E permission.

**Visible settings:** Codex is described as GPT-6 based; the exact model identifier and reasoning setting are not visible. Filesystem permission was unrestricted, with approval policy `never`. I used no subagents. The audit used repository-local inspection and one disposable local clone; no fetch or external source.

## Provenance and preservation

Opening and closing coordinates matched: `trunk_dev`, HEAD `d070bf05d2e68472e18b1b077259e67864923e8f`, tree `d662b6702e178218c12930259eda5fb690c2fe25`, sole parent `3d99e448bfe577b5a5878dd32b7e01b61322e7df`, subject `docs: freeze RW0-C2 private value and graph profiles`. There was one live worktree, no staged or unmerged path, and no active Git operation or lock. Local `HEAD...origin/trunk_dev` was `0/0`; I did not verify the remote afresh.

| Status | Repository-relative path | Bytes | SHA-256 | HEAD blob |
|---|---|---:|---|---|
| M | `.docs/autonomous-software-development-operating-model.md` | 39079 | `cba69a4e88eeb34bb0f25d3ac8f2ca8774b471fd6dc70a6af1211b3d661b963f` | `e94f9209399d9d957683b6bdeccc5faf350ca1c7` |
| M | `.docs/rw0-c2-bootstrap-acceptance-guard-semantic-contract.md` | 26007 | `e91b82190ccb4969ff670a365b66419e7c5ac945ca328f3c832c5db1e5eb0d09` | `d1dd3f29a85a4c2ed30153f3da241e8349dbe9fb` |
| ?? | `.docs/rw0-c2-first-live-proof-posture.md` | 15741 | `0064fd833337dee2503da1296525e32e4e76a799c803a86122434b86919f6541` | absent |
| M | `.docs/rw0-c2-private-value-versioning.md` | 207512 | `8d0477a2d1ba0cc6f94bacb59927932123582231ebecf345355492e3e6817a37` | `57f7f889774e8cf24ed3ef3be490a4355b4cf0bf` |
| M | `.docs/rw0-remote-worker-contact-phase-entry.md` | 58068 | `fc74ac0d75bf3e762fdd25775bbf91befa533e53b3b90d5cc092457516fab7b5` | `f4c6540dfe998aa9e5493785882c4356904a55a9` |
| M | `.docs/sqlite-operations-and-recovery.md` | 38657 | `86c2cd7b1f780d153c2237d5d47c52b7724630b4cc1d2adc4ad1e4c7a9a701a4` | `676fb5bfa96d8f6a2901e8bb2a7fcbc725507a57` |
| ?? | `tests/test_rw0_c2_first_live_proof_posture_contract.py` | 12877 | `8568aecff3c499db9acbffa1933b3b79770474e426bad60a22127c1d69f03e39` | absent |
| M | `tests/test_rw0_remote_contact_phase_entry_contract.py` | 173945 | `53da2ec508272a886e3b7b793bd564f0bf218344d6ce917b5ceaa6ac2ab6ed70` | `d6ee81446fcf9dd389f1ef0939572d9a58970082` |

I read and hashed each tracked baseline blob from HEAD, compared its diff, and checked the index against the HEAD tree. The prescribed **one grouped tracked diff followed by the two no-index diffs**, concatenated without separators, reproduced twice at opening and twice at close: component lengths `10033 + 16200 + 13434`, total **39667 bytes**, SHA-256 `d7b2c9442645b83c76fbbe02e066300c5a368eb05a5e5e8ba36f291bfde33ffc`. The no-index commands returned expected status 1. No external diff helper was configured or run.

All eight worktree files were regular nonsymlink mode 0644, valid UTF-8, with one final LF and no BOM, CR, or trailing whitespace. `git diff --check` returned 0; both new-file no-index whitespace checks returned 1 with no diagnostics. All 236 noncandidate tracked files matched HEAD by blob bytes and Git-relevant mode. One pre-existing noncandidate test file has Unix mode 0600 while its Git mode is nonexecutable `100644`; that is no Git mode drift. Source, schemas, configuration, scripts, README, AGENTS, and other tests were preserved. The packaged migration catalog and SQL remain 0001–0004; 0005 is absent.

The live cache inventory matched at close by every member’s path, type, mode, size, nanosecond mtime, and file hash: **37 bytecode files plus their directory**, 38 entries under `src/ge_nwp_coordinator/__pycache__/`. I did not inspect unrelated ignored operator or product state.

## Contract and authority findings

The eight paths contain target documentation and tests. Current RW0-C1 evidence persistence remains implemented; RW0-C2 guard/decision storage, the first-live supplier, RW0-D, and RW0-E remain future. The default executable authorization provider still fails closed at `src/ge_nwp_coordinator/lease.py:335-347`. The current local writer lock and issuance do not supply external lineage or custody authority (`.docs/writer-session-authority.md:134-194`, `src/ge_nwp_coordinator/sqlite_writer_session.py:6718`).

- **Enrollment and activation.** External standing policy admits the lineage. A distinct, independently durable, non-reissuable enrollment assigns one incarnation before activation; an absent local row or read-only enrollment lookup supplies no fresh launch authority. A possible launch with a lost response bars a second launch. Enrollment and preacceptance failure create no acceptance fact. The later separate provisioner records exact program-independent admission; the guarded C2 transaction alone authors acceptance. Evidence: `.docs/rw0-c2-first-live-proof-posture.md:32-65`, `.docs/rw0-c2-bootstrap-acceptance-guard-semantic-contract.md:36-83`. Migration-0002 receipts require a `program_ref`, so the proposal correctly rejects a dummy program (`src/ge_nwp_coordinator/sqlite_migrations/0002_development_program_and_effect_state.sql:537-543`).

- **Continuous custody and permission.** The selected mechanism class binds the original process and writable SQLite state, including journal and sidecars, to a privileged live cell. It requires detection or denial of path replacement, in-place and VM rollback, copied process credentials, supervisor restart, and clone activation. Every applicable command needs fresh source-authored posture before protected receipt disclosure; parent grant, expiry, revocation, effect, audience, repository/path, and global-stop checks remain with their owners. The enforcer supplies custody facts and fencing, with no C2 branch or acceptance authority. No per-progression external checkpoint or routine user relay was added. Evidence: `.docs/rw0-c2-first-live-proof-posture.md:67-104`.

- **One shot, recovery, and terminal order.** Acceptance alone additionally requires exhaustive unclaimed-family proof. All four nonaccept branches create no acceptance fact or unclaimed assertion; unknown claimed status alone does not defeat an otherwise exact nonaccept path (`.docs/rw0-c2-bootstrap-acceptance-guard-semantic-contract.md:64-83`). Exact replay/readback requires the same original incarnation, state, and positive current custody. The decision owner retains the sole `committed_exact` / `definitely_not_committed` / `unresolved` classifier and the original family and timestamp (`.docs/rw0-c2-first-live-proof-posture.md:106-145`; `.docs/rw0-c2-durable-progression-decision-semantic-contract.md:418-485`). A kill request, timeout, or network credential revocation does not prove a local commit impossible. Custody loss creates no synthetic C2 block, cancel, terminal, acceptance, or noncommit fact. Existing one-delivery, effect-cancellation, and terminal ordering remain in `.docs/rw0-remote-worker-contact-phase-entry.md:139-169,327-375`.

- **Offline/live and compatibility.** RW0-D remains repeatable offline engineering with fake sources and disposable state, and still needs its real offline process/custody mechanics. RW0-E requires concrete supplier qualification, provisioning, C2 physical/transaction/terminal work, and existing host, authority, effect, validation, review, and delivery gates. Full-custodian and acceptance-focused checkpoint paths remain unselected successors (`.docs/rw0-c2-first-live-proof-posture.md:197-216`; `.docs/rw0-remote-worker-contact-phase-entry.md:482-524`). The phase-entry test diff adds exact RW0-C/RW0-E, RW0-D, and RW0-E assignment rows and checks table equality and mutations; it does not merely relax assertions (`tests/test_rw0_remote_contact_phase_entry_contract.py:901-959,1949-1965,2968`). The private-value provisioner wording now permits exact authorized recording and owner-governed readback, with no replacement, renewal, orphan repair, or implicit retry (`.docs/rw0-c2-private-value-versioning.md:18-41`). Ordinary B1 administrative restore remains available but cannot reactivate this profile (`.docs/sqlite-operations-and-recovery.md:465-482`).

The private-value machine block from its begin marker through EOF is byte identical to HEAD: 11 schema IDs and digest domains, 86 dependency nodes and 266 common edges, the 30-coordinate command digest, receipt graph, replay/recovery vocabulary, and 13-clause/37-assertion owner profile were preserved. Its parser/test source was unchanged, and the owner regression group passed.

**Mechanism class:** An independently controlled conditional enrollment record outside Coordinator restore domains, paired with a privileged process/storage cell that serializes launch and binds live process identity to exclusive writable state, is a credible class. Object-version retention alone cannot prevent newer versions or deletion markers; a file name or copied credential cannot establish nontransferability. Before implementation entry, an actual supplier must demonstrate uniqueness and response-loss handling, nontransferable process binding, original-state isolation, blocked restore/clone/VM paths, full subtree and descriptor/storage fencing, supervisor-failure closure, and stale-response rejection (`.docs/rw0-c2-first-live-proof-posture.md:147-195`). No supplier or platform conformance was tested or selected.

The general phase-entry table contains restart readback and source-reconciliation rows (`.docs/rw0-remote-worker-contact-phase-entry.md:348-360`). For this selected profile, its specific custody rule permits no productive restart and no protected C2 readback without positive original custody (`.docs/rw0-c2-first-live-proof-posture.md:127-145`). I found no row granting a replacement or successor; this scope distinction must stay explicit at implementation entry.

## Finite causal evidence

The new module has 16 actual tests. Its anchor test checks the 15 named document rows at `tests/test_rw0_c2_first_live_proof_posture_contract.py:77-92`. I independently ran a fixed oracle against its synthetic `_Proof` predicates and recorded the reached boundary:

| History | Candidate inputs and actual assertion | Fixed expected result |
|---|---|---|
| D-repeat | Two empty fake proofs; no enrollment or command (`tests/test_rw0_c2_first_live_proof_posture_contract.py:95-103`) | Repeat offline; no live authority |
| Enroll-before-program | Policy → enrollment → activation → separate admission (`:106-125`) | Activation initially possible; command only after admission |
| Lost-activation-response | Attempted launch with missing current source (`:128-134`) | No second launch or command |
| Copied-state | Original-state and current-source premises removed (`:137-148`) | No command |
| Late-response | New incarnation with old source response (`:137-148`) | No command |
| Nonaccept-four | Four named branch specimens at zero acceptances (`:151-162`) | Commands may proceed with intact posture; no acceptance fact or checkpoint claim |
| First-then-second | Acceptance count changes 0 → 1 (`:164-170`) | First eligible; second denied |
| Lost-commit-response | Count 1 with intact custody (`:173-181`) | Readback may be exact; no second acceptance |
| Restored-preaccept | Same count 0, custody lost (`:184-193`) | No command or acceptance |
| Restart | Process and supervisor loss specimens (`:196-203`) | No resume or synthetic outcome |
| In-place-restore | In-place SQLite and memory rollback observations (`:206-211`) | No command despite coherent-looking bytes |
| Fence-request | Exit and storage exclusion unproved (`:214-222`) | No complete fence or successor |
| Preaccept-failure | Custody lost at count 0 (`:225-231`) | Availability retires without an acceptance claim |
| Normal-close | Closed after one acceptance (`:234-243`) | No renewal |
| ES-later | Same closed enrollment and count (`:234-243`) | ES does not replenish direct-local allowance |

Four external compiled copies of the observed test model removed enrollment, copied-state, missing-posture, and restart/re-enrollment guards; each flipped a direct baseline denial to admission. Two in-memory transformations of the test’s actual timeout and enforcer-branch specimens produced the forbidden noncommit inference and branch substitution (`tests/test_rw0_c2_first_live_proof_posture_contract.py:246-280`). The independent oracle also denied activation-ack-loss plus copied database and acceptance-response-loss plus in-place preaccept restore. Separate fixed controls kept exact intact-custody readback distinct from lost-custody `unresolved`, denied duplicate launch, and retained possible old local commit after an incomplete fence.

These probes reached **synthetic predicates and audit-side classification only**. They did not exercise signatures, hardware/storage fencing, a C2 production classifier, or a live supplier. All expected outcomes were fixed outside the mutated subject. No probe received credit from parse/import failure or collection shrinkage.

## Serial validation and disposition

I cloned exact HEAD locally, removed the clone’s remote, overlaid the eight verified bytes, and ran Python 3.13.4 with the required `PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=.:src python3 -m pytest -q -p no:cacheprovider --basetemp=<external-parent/group>` prefix. Each group had its own precreated external basetemp parent; collection preceded execution, and the groups ran serially.

| Group | Actual collection | Actual execution |
|---|---:|---:|
| A — new proof-posture test file | 16 unique nodes | 16 passed |
| B — the nine specified C2 guard, decision, private-value, phase-entry, architecture, operating-model, C2B0, SQLite B0, and B2a contract files | 3192 unique nodes | 3192 passed |
| C — complete repository, no path arguments | 8758 unique nodes across 116 modules | 8758 passed; 3 warnings |

Parsed collection node IDs were unique; A and B were disjoint and each was a subset of C. The three warnings were unchanged Python 3.13 multithreaded-`fork()` deprecations in `tests/test_sqlite_b2c_writer_session.py`: `test_operation_guard_close_waits_and_retains_authority_until_exit` (stdlib `multiprocessing/popen_fork.py:67`), `test_fork_child_operation_with_inherited_locked_session_sync_does_not_hang` (`:1442`), and `test_fork_child_finalizer_with_inherited_locked_session_sync_does_not_hang_or_prolong_lock` (`:1554`). No warning was suppressed. The reported earlier intermediate phase-entry assertion failures were historical; the final eight bytes passed.

**Severity-ranked disposition:** no remaining in-scope contract/authority drift, code bug, or material bounded-test causality finding. Platform conformance remains unperformed and is a required future gate, not an acceptance claim. No required validation was skipped. Two audit-only command corrections had no candidate effect: an initial overstrict noncandidate Unix-mode assumption was corrected to Git-relevant mode checking; shell recursive deletion was rejected, then a path-guarded Python cleanup removed the external directory.

The clone overlays still matched all eight live receipts after testing, its remote list was empty, and it had no generated files inside its checkout. Tests did create temporary external fixtures, including SQLite databases, locks, source copies, and five bytecode files under the isolated basetemp; all audit-created clone, basetemp, probe, mutant, and log paths were removed.

**Actions not taken:** no live candidate edit, repair, staging, commit, push, PR, merge, or publication; no source/schema/migration/config change; no live product import, pytest, SQLite connection, generated file, or cache change; no fetch, network/provider/service/credential experiment, dependency installation, sibling repository, subagent, production worker, ES, or Bridge invocation; and no delivered external evidence artifact.

### Continuation capsule

The exact eight-path candidate above is provenance matched and accepted for a **separately authorized commit gate on those same bytes only**. Any byte, path, index, mode, or baseline drift requires renewed provenance review. The selected `rw0-c2-single-realization-proof-v1` profile admits one externally authorized lineage, one independent non-reissuable incarnation enrollment, and protected progression only during continuous original process/storage custody. Enrollment never supplies acceptance or reusable launch permission. The separate admission provisioner and guarded C2 decision family remain future physical work; current executable authorization remains fail-closed. RW0-D is still offline engineering, and RW0-E remains blocked on concrete supplier conformance plus its other stated gates. This audit authorizes no implementation, supplier selection, runtime activation, or live proof.
