## Decision

**Select model 3: proof-only single-realization posture for the first RW0-E live slice.**

The previous admission/continuity tranche prompt is **superseded as an unexecuted draft**. Do not send it to Codex.

My earlier recommendation went beyond what the reconnaissance established. The indistinguishable-database argument establishes a need for independent evidence **when restoring or resuming a lineage after state loss**. It does not establish that the first live proof needs an externally checkpointed history of ordinary Coordinator progression. The reconnaissance itself left concrete custody and fencing untested. Pasted text

The narrowest credible first slice is:

> **One independently enrolled, non-reissuable live authority incarnation, operating within continuously enforced process-and-storage custody. Loss of that continuity ends this proof’s permission to continue; it never creates another allowance.**

This still requires a small independent enrollment and custody mechanism. It does **not** require a per-mutation external arm/checkpoint protocol, recoverable handoff, or a general continuity service.

That choice fits the existing RW0 scope unusually well: one author delivery, no author relaunch or redelivery, no replacement semantic attempt, and no successor execution after the terminal outcome. Those are already the accepted proof boundaries in `.docs/rw0-remote-worker-contact-phase-entry.md:125–175`.

## What the repository actually requires

The merged guard requires positive lineage continuity and one active authority for every applicable command. It does not make a local lock, process identity, machine identity, or missing acceptance row sufficient evidence. It also separates universal posture from acceptance-only exhaustive unclaimed-scope proof. **Model 3 must satisfy those requirements through a bounded source, not waive them.** See `.docs/rw0-c2-bootstrap-acceptance-guard-semantic-contract.md:29–77`.

RW0-D is explicitly an offline process/package proof using fake transport, fake model executables, temporary workspaces, and no live credentials or network. RW0-E is one separately authorized qualified-host proof. The open-decision table must not silently turn a real continuity service into a prerequisite for running RW0-D’s fake-source engineering. See `.docs/rw0-remote-worker-contact-phase-entry.md:467–510`.

None of these models is implemented today. The current source still has bounded local writer fencing and a default authorization provider that returns no executable authorization. See `.docs/writer-session-authority.md:134–183` and `src/ge_nwp_coordinator/lease.py:335–348`.

## Comparison of the operating models

The claims below are engineering assessments of the proposed models, not descriptions of current capabilities.

### 1. Full continuity custodian

**Safety claim.** This can support recovery of an explicitly defined protected history across crash, restore, rollback, and authority handoff. Every mutation that can invalidate that claimed history must either participate in its arm/checkpoint protocol or terminate the claim. An acceptance checkpoint alone would not establish the currentness of subsequently changed program heads or decision bases.

**External participation.** Admission enrollment, fresh applicable-command posture, an arm before every enumerated protected mutation, settlement/checkpoint advancement, and fenced handoff. Replay and recovery need fresh custody evidence; a pending operation must permit its own bounded readback without permitting another write.

**Availability and recovery.** This offers the strongest recovery potential, but introduces the largest dependency. A lost arm acknowledgment, unresolved old writer, unavailable custodian, or inconsistent checkpoint can halt protected progression. It still cannot guarantee recovery when both custody domains lose history or when an old writer cannot be fenced. Those are explicit limits in the reconnaissance. Pasted text

**Coordinator ownership.** It remains valid only if the custodian owns enrollment, epochs, arms, and checkpoint attestations—not branches, acceptance, retry decisions, or C2 recovery classifications. Coordinator remains the only progression and acceptance writer.

**Credible implementation class.** An independently administered append-only/conditionally updated journal, combined with privileged host or hypervisor agents that can terminate old execution and revoke its actual storage access. This does not require a new software-development orchestrator, but it does require a substantial operational coordination component. Power and storage fencing are concrete implementation classes; a disconnected node or expired lease is not equivalent to a completed fence. [Red Hat Documentation](https://docs.redhat.com/en/documentation/red_hat_enterprise_linux/10/html/configuring_and_managing_high_availability_clusters/configuring-fencing?utm_source=chatgpt.com)

**RW0-D:** not blocked by a *live* custodian; use explicitly simulated observations.  
**RW0-E:** blocked until the full selected custody, checkpoint, and fencing path is implemented and qualified.

**Judgment:** credible, but excessive for a proof that already forbids relaunch and successor execution.

### 2. Admission/acceptance-focused continuity

**Safety claim.** This can preserve the admission and one-shot acceptance history across rollback without claiming recoverable continuity for all later Coordinator progression. A durable arm before admission recording and productive acceptance closes their commit-before-acknowledgment gaps. Other progression cannot be reconstructed or declared current merely from those two checkpoint classes.

**External participation.** Fresh external admission/continuity/sole-active evidence remains necessary for applicable C2 commands. Durable arms and permanent checkpoints cover only admission recording and productive acceptance. The four nonaccept branches and other local progression have no per-mutation external checkpoint.

**Availability and recovery.** It reduces write-path coupling. However, a restored database may preserve admission and acceptance correctly while losing nonaccept decisions, evidence, or newer heads. Such ambiguity must still stop progression. Any supported replacement also needs an effective old-writer fence; the acceptance checkpoint does not supply one.

**Coordinator ownership.** Coordinator still owns all progression and acceptance facts. The external record can establish that an acceptance attempt may have occurred or bind evidence of an exact committed family; it cannot decide that acceptance occurred or authorize a retry.

**Credible implementation class.** The same independent journal and managed-execution fencing primitives as model 1, but with a closed two-operation durable participation set. It is materially smaller than a full history protocol, though not merely an extra signature or local file.

**RW0-D:** not blocked by a live source.  
**RW0-E:** blocked until the focused enrollment, arm, settlement, and fencing mechanisms are qualified, plus the existing C2/runtime prerequisites.

**Judgment:** a reasonable successor when recoverable admission/acceptance custody becomes a real requirement. It buys little for the first one-contact proof while retaining cross-store commit-uncertainty machinery.

### 3. Proof-only single-realization posture — selected

**Safety claim.** At most one productive acceptance may commit within one externally enrolled, continuously controlled authority incarnation. No restored, restarted, cloned, relocated, or replacement incarnation may resume under that enrollment. A loss of provable custody makes the proof permanently unavailable under this profile, without declaring acceptance either committed or absent.

**External participation.**

| Operation | Required external participation |
|---|---|
| First live activation | One irreversible enrollment binding the admitted lineage to the exact live incarnation, established before activation |
| Admission recording | Authenticated standing-policy act and current controlled-incarnation evidence; Coordinator records the fact |
| Applicable C2 command, including nonaccept | Fresh source-authored posture plus existing policy/currentness checks; **no external mutation arm or checkpoint** |
| Productive acceptance | Same posture, exhaustive local family verification under intact custody, and the existing atomic Coordinator acceptance family |
| Exact replay/uncertain commit | Current evidence of the same intact incarnation and storage custody; Coordinator’s existing classifier performs readback |
| Restart, rollback, restore, clone, relocation, or handoff | No resumption path in this profile; deny continuation |

Fresh evidence can be supplied by a separately privileged host enforcer. It does not imply a remote round trip or a new durable journal entry for every decision. Existing grant-expiry, revocation, and global-stop requirements remain; an old signed admission is not perpetual permission.

**Availability and recovery.** This deliberately sacrifices restart availability. Response loss can be reconciled within the still-live, intact incarnation. Loss of the Coordinator authority process, supervising custody boundary, or storage continuity ends first-slice continuation. Diagnostics may continue under their own permissions, but no report or cleanup action fabricates a terminal outcome.

**Coordinator ownership.** The enforcer knows which incarnation is eligible to operate and whether its custody remains intact. It does not know which development branch should be selected, maintain program heads, classify C2 recovery, or write acceptance.

**RW0-D:** repeatable offline engineering remains permitted with isolated fake sources and disposable state.  
**RW0-E:** one bounded proof is permitted once the smaller incarnation/custody mechanism and existing runtime prerequisites pass their implementation-entry gates.

**Judgment:** this best matches the requested default. It preserves safety without introducing an unimplemented checkpoint service into ordinary progression.

There is no materially better fourth model in the inspected evidence. A single irrevocable proof-session enrollment is the implementation discipline for model 3, not a disguised full-custodian protocol.

## Why model 3 is technically credible

It cannot be implemented by writing “restore unsupported” in a document. The exclusion must be enforced.

A credible class combines **independent one-time enrollment with a managed process/storage cell**:

**Independent custody.** Before activation, an authenticated standing-policy actor records that the admitted lineage has been assigned to one specific live incarnation. That record lives outside the Coordinator database and its snapshot/restore domain. It cannot be replaced or deleted by the Coordinator, worker, or proof launcher. Enrollment response ambiguity does not permit a second launch.

Conditional creation and retention-protected object storage are existing primitives for this class. For example, S3 documents conditional writes and policy-enforced preconditions, alongside version retention. Those features are illustrative, not a vendor selection. [AWS Documentation](https://docs.aws.amazon.com/AmazonS3/latest/userguide/conditional-writes.html?utm_source=chatgpt.com)

Crucially, **Object Lock alone is insufficient**: it protects a version, not the key against new versions or delete markers. A credible design must additionally prevent replacement, deletion-marker bypass, identifier substitution, and silent retention expiry from reopening enrollment—or fail closed. [AWS Documentation](https://docs.aws.amazon.com/AmazonS3/latest/userguide/object-lock.html)

**Controlled incarnation.** A separately privileged manager launches one isolated Coordinator process, supplies a process-bound live capability, and controls the database’s writable exposure. Workers cannot access Coordinator state. Automatic restart, memory restore, database replacement, and snapshot rollback cannot recreate the capability. The management authority and its credentials are not included in the Coordinator’s backup.

This is stronger than “the PID and inode still match.” It combines an independent enrollment, exclusive resource control, and current observations from an authority outside the copied state.

**Effective fencing.** The manager can terminate the entire relevant process group and revoke its storage/launch access; completion must be observed rather than inferred from sending a signal. Linux cgroup v2 provides a concrete family of primitives: subtree process containment, `cgroup.kill`, and population observation. Those primitives do not themselves prove the whole design, but they make the class credible. [Linux Kernel Documentation](https://docs.kernel.org/admin-guide/cgroup-v2.html)

There is **no takeover after a timeout**. If termination cannot be established, no replacement is activated. An in-flight commit may still have completed; its outcome remains unknown until legitimate readback can establish it.

The threat boundary excludes compromised policy roots, a malicious privileged manager, or storage that silently violates the qualified durability/custody assumptions. Ordinary snapshot, restore, and clone operations must be prevented or detected by the manager; they cannot simply be excluded while remaining available through an unnoticed administrative path.

### What this avoids

The external enrollment record says:

> This proof incarnation was assigned.

It does **not** say:

> Acceptance occurred, the allowance was consumed, or retry is permitted.

An early crash can therefore lose the ability to finish this proof **without consuming acceptance**. Neither a new process nor a newly named database restores that ability. A later separately accepted continuity mechanism may reconcile the lineage; this profile does not do so.

This is the essential trade: **one setup-time durable boundary plus enforced non-resumption, instead of durable external participation around every relevant write.**

## Scope decision

A contract-writing tranche remains worthwhile, but it should freeze only:

- the first-live single-realization support profile;
- the independent enrollment and controlled-custody obligations;
- fail-closed termination and readback limits;
- the RW0-D/RW0-E separation;
- the mandatory concrete implementation-entry evidence.

Do **not** freeze the full custodian, acceptance-focused barrier protocol, or detailed provisioning transaction grammar in this tranche.

Program-independent admission provisioning remains necessary later. The existing migration-0002 receipt requires a program and has a closed result algebra; narrowing continuity does not make a dummy program acceptable. The reconnaissance’s conclusion on that seam remains sound. Pasted text

The repository inspection below was static snapshot inspection, not execution. The implementation-class checks used primary technical documentation; no host, service, or candidate mechanism was tested.

---

## Complete replacement Codex prompt

```text
# Governed Execution Coordinator — First-Live Single-Realization Proof Posture

## Objective and authorization

Write one documentation-and-causal-contract-test tranche selecting the
proof-only single-realization posture for the FIRST RW0-E live slice.

This prompt supersedes the unexecuted
Coordinator_RW0_C2_Admission_Continuity_and_Provisioning_Contract_Tranche_Prompt.txt.
That draft was not executed. Do not implement or preserve its general
per-protected-mutation custodian/checkpoint protocol by inertia.

The selected operating model is:

One explicitly standing-policy-admitted lineage, one independently recorded
non-reissuable live incarnation, continuous controlled process/storage custody,
and permanent fail-closed loss of first-slice continuation if that custody is
lost. No restore, rollback, process restart, cloning, relocation, or handoff
resumption is supported by this profile.

The parent is the sole writer. No subagents. Use the highest exposed reasoning
setting; report visible model, reasoning setting, and permissions, or “not
visible”. Do not seek additional access to discover hidden settings.

Only documentation and tests are authorized. No source, migration, schema,
runtime, service, deployment, credentials, network, live database, or sibling
repository work. No staging, commit, push, PR, merge, or branch changes.

Return one substantive inline report and a continuation capsule of at most
800 words. No delivered manifest, report file, package, or historical attachment
requirement. Do not issue a later implementation prompt.

## 1. Exact baseline

Repository:
 /Users/ds/Repositories/Governed Execution Coordinator

Required opening:
 branch: trunk_dev
 HEAD: d070bf05d2e68472e18b1b077259e67864923e8f
 tree: d662b6702e178218c12930259eda5fb690c2fe25
 sole parent: 3d99e448bfe577b5a5878dd32b7e01b61322e7df
 subject: docs: freeze RW0-C2 private value and graph profiles
 upstream: origin/trunk_dev
 locally observed divergence: 0 ahead / 0 behind
 one worktree
 clean index/worktree/untracked/unmerged sets
 no active Git operation or unexpected lock.

Read AGENTS.md first. Verify opening and closing using non-mutating Git
inspection. Do not fetch; tracking state is not fresh remote verification.
Stop on drift or another actor’s edits. Do not normalize the checkout.

The merged repository owns current and accepted-target semantics. The
reconnaissance is evidence, not adopted design. No JSONL package, prior audit,
merge receipt, snapshot, or downloaded artifact is a prerequisite.

## 2. Fixed architecture

Preserve:

- One scope per explicitly admitted Coordinator authority lineage.
- One immutable admission fact; at most one immutable productive acceptance
  fact across programs in that scope.
- Machine, process, database, restore, clone, grant renewal, and policy epoch
  do not create a new lineage or allowance.
- Current external lineage/continuity/sole-active/no-foreign posture remains
  necessary for every applicable command.
- Acceptance-only exhaustive unclaimed-scope proof remains distinct from
  universal posture.
- Coordinator alone derives progression and writes the atomic acceptance
  decision/version/head/result/receipt family.
- The four nonaccept branches create no acceptance fact.
- One C2 result, receipt, replay owner, and whole-family recovery classifier.
- No mutable available/consumed latch and no external acceptance classifier.
- Exact replay preserves original command/family/timestamp.
- Unresolved is not retry permission.
- Terminal output and separately governed ES operation never replenish the
  direct-local allowance.
- The user supplies intent and standing policy, not routine command approval,
  evidence transport, or recovery-message relay.
- Existing RW0 author-delivery, no-redelivery/no-relaunch, cancellation, and
  terminal boundaries remain unchanged.

This is a restricted first-live support profile, not the enduring Coordinator
deployment architecture. Do not make single-realization operation a permanent
product restriction.

## 3. Required inspection and mutation scope

Inspect relevant sections of:

 AGENTS.md
 README.md
 .docs/architecture.md
 .docs/autonomous-software-development-operating-model.md
 .docs/authority-boundaries.md
 .docs/durable-state-model.md
 .docs/worker-execution-boundary.md
 .docs/rw0-remote-worker-contact-phase-entry.md
 .docs/rw0-c2-bootstrap-acceptance-guard-semantic-contract.md
 .docs/rw0-c2-durable-progression-decision-semantic-contract.md
 .docs/rw0-c2-private-value-versioning.md
 .docs/writer-session-authority.md
 .docs/sqlite-operations-and-recovery.md
 .docs/c2b-durable-development-state.md

Read relevant source as data, particularly lease.py, WriterSession/lock
ownership, transaction/recovery owners, migration-0002 receipt algebra,
migration catalog, exports, pyproject.toml, and .gitignore.

Create:
 .docs/rw0-c2-first-live-proof-posture.md
 tests/test_rw0_c2_first_live_proof_posture_contract.py

The inspected documentation above, except AGENTS.md and README.md, may change
only for the selected support profile, its routing/dependencies, and the
specific compatibility clarifications below.

Existing tests may change only where they directly own those amendments:
 tests/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.py
 tests/test_rw0_c2_durable_progression_decision_semantic_contract.py
 tests/test_rw0_c2_private_value_versioning_contract.py
 tests/test_rw0_remote_contact_phase_entry_contract.py
 tests/test_architecture_contracts.py
 tests/test_autonomous_software_development_operating_model.py
 tests/test_c2b0_durable_state_contract.py
 tests/test_sqlite_backend_b0_contract.py
 tests/test_b2a_writer_session_contract.py

Before editing, record the smallest coherent selected path set and the exact
owner/test dependency requiring each edit. This allowlist is not a target
file count. Do not rewrite unrelated sections.

Keep AGENTS.md, README.md, src/, schemas/, migrations, scripts, configuration,
and all other tests unchanged. Their current implementation summaries remain
true. Do not extend the existing Markdown parser or restart its audit.

## 4. New owner’s scope and status

Use the logical support-profile identifier:
 rw0-c2-single-realization-proof-v1

Classify it as ACCEPTED TARGET / FIRST-LIVE SUPPORT PROFILE, unimplemented.

The document owns supported operating conditions, external source obligations,
loss-of-continuity behavior, and entry evidence for this first live proof.

It does not own:
- C2 branch reduction or acceptance classification;
- standing-policy authorship;
- SQL, row/index layout, migrations, transport, cryptographic encoding;
- a production launcher, supervisor, verifier, or service;
- a general checkpoint protocol;
- a second recovery or retry owner.

The existing eleven private value/profile grammars and their digest meanings
remain unchanged. Any later proof-source envelope must be separately versioned,
not appended silently to an existing canonical value.

Do not create the two full-custodian/provisioning owner documents proposed by
the superseded draft in this tranche.

## 5. One non-reissuable live enrollment

Specify the following semantics:

1. External standing policy authenticates the lineage and its initial live
   proof admission. Local emptiness or absence of an enrollment entry is not
   itself admission authority.
2. Before any live activation, an independently durable record assigns that
   lineage’s proof to one exact authority incarnation.
3. The assignment is outside the Coordinator database and any snapshot domain
   capable of recreating that incarnation.
4. Coordinator, workers, and the launcher cannot delete, replace, renew, or
   reissue the assignment.
5. Enrollment response loss is reconciled read-only. If whether launch became
   possible is ambiguous, no second launch is allowed.
6. A different process, restored memory image, database copy, machine, or
   operational identifier cannot reuse the assignment.
7. An already enrolled or historically ambiguous lineage cannot be relabeled
   as a new independent lineage for routine recovery.
8. This record is an incarnation assignment, not an acceptance receipt,
   acceptance fact, consumed allowance, or C2 recovery classification.

A failure after enrollment but before acceptance can permanently end this
proof’s availability without asserting that acceptance occurred.

No per-admission-write or per-acceptance-write external arm is selected.
No per-nonaccept or general-progression checkpoint is selected.

## 6. Continuous custody and fresh source evidence

A separately privileged managed-execution boundary must establish:

- the exact live authority incarnation;
- exclusive access to the original Coordinator state;
- no unauthorized writer or restored/copied state;
- a live, nontransferable source relationship outside copied Coordinator state;
- enforcement of the no-restart/no-restore/no-clone/no-handoff support profile.

A PID, inode, local lock, signed old response, or database row alone is
insufficient.

Every applicable C2 command still obtains fresh, source-authored current
posture. This may be local authenticated communication with the privileged
enforcer; it is not a requirement for a new remote checkpoint transaction.

The enforcer owns incarnation/custody observations and resource fencing only.
It must not inspect program intent to choose a branch, author acceptance,
advance heads, schedule development work, choose retries, classify C2 recovery,
or expand standing policy.

Existing current grant, expiry, revocation, global-stop, repository/path,
effect, and audience checks remain. Enrollment is not a permanent substitute
for current authority.

Workers and model processes must not have access to Coordinator database,
enrollment credentials, management APIs, or proof-source signing authority.

## 7. Exact lifecycle and failure behavior

Supported:
- one initial activation;
- ordinary Coordinator-owned progression under intact custody;
- the four nonaccept branches without an unclaimed-scope assertion;
- at most one productive acceptance;
- exact same-incarnation replay/readback where original state and current
  custody remain provable;
- bounded source-owned teardown under existing effect/cancellation rules.

Unsupported continuation:
- Coordinator authority-process restart;
- supervising custody authority restart or loss of its live identity;
- database replacement or in-place snapshot rollback;
- memory checkpoint/restore;
- a clone becoming active;
- relocation, machine replacement, or authority handoff;
- unproved storage continuity or former-writer status.

On an unsupported transition, deny new protected work. The first-live profile
has no resume, replacement-incarnation, or reset operation.

Enforce the transition boundary; merely documenting unsupported operations
while leaving unnoticed restore or clone paths available is insufficient.

Loss of the profile is not a C2 terminal-outcome fact. Do not manufacture block,
cancel, noncommit, or acceptance merely because a process was stopped.

An already admitted in-flight commit may have completed. A kill request,
timeout, expired response, or unreachable process does not prove otherwise.
No replacement may start while that uncertainty remains.

Same-incarnation uncertain-commit readback remains owned by Coordinator. If
custody itself has been lost, return/retain unresolved and do not reactivate
the proof. Offline diagnostics are not productive resumption.

Normal successful closure also does not renew enrollment. Later ES operation
remains separately governed and does not replenish this allowance.

## 8. Credible mechanism class and mandatory feasibility gate

Record one credible class, without choosing a vendor or deploying it:

An independently administered, conditionally created, nonreplaceable enrollment
record plus a privileged host-managed process/storage cell whose authority
cannot be recreated by copying Coordinator state.

Explain concretely:

- why the enrollment survives Coordinator database rollback;
- how first activation is serialized without a per-command user relay;
- why copied credentials or memory cannot authenticate a second incarnation;
- how writable storage is restricted to the original guarded writer;
- how snapshot/restore and restart paths are denied or invalidate the profile;
- how the complete process subtree can be terminated and completion observed;
- how supervisor failure prevents re-enrollment;
- why an unreachable old writer never causes automatic takeover.

Existing mechanism families include conditional immutable object retention and
privileged process/hypervisor fencing. They are feasibility evidence only,
not an adopted product or already available Coordinator capability.

Retention protection of one object version does not prevent new versions or
delete markers. A supplier must prevent those enrollment-bypass paths and
handle retention expiry by continued protection or fail-closed behavior.

Process-kill issuance alone is not fencing completion. Require actual process
exit/storage exclusion evidence. Network credential revocation alone is not
a fence against a local SQLite commit.

State the trusted components and excluded compromises. A compromised policy
root or privileged enforcer is outside this first profile. Routine database
restore/clone operations must nevertheless be mechanically covered.

Do not freeze a detailed wire format, credential schema, hardware API, or
deployment. Stop before a success claim if no credible class can satisfy the
essential custody and fencing properties.

Separate:
A. contract validity from finite causal histories;
B. concrete implementation-entry conformance;
C. separately authorized RW0-E execution.

Before later source/runtime entry, require platform evidence for independent
enrollment custody, launch uniqueness, anti-replay/nontransferability,
storage isolation, forbidden restore/clone paths, complete fencing, and
fail-closed supervisor failure. No fixture can satisfy that platform gate.

## 9. RW0-D and RW0-E dependency treatment

RW0-D offline engineering must not require:
- real enrollment;
- real standing-policy grants;
- a live continuity service;
- production credentials;
- network access;
- consumption of the live lineage’s allowance.

Use explicitly artificial source observations, fake transport/model processes,
and isolated disposable test state. Tests may repeat and reset those fixtures.
They confer no production admission, acceptance, continuity, or permission.

Preserve the requirement to implement and test actual offline process/custody
mechanics in the appropriate later RW0-D tranche. Do not claim RW0-D is
implemented or fully runnable merely because this profile is frozen.

RW0-E remains blocked until:
- this support contract is accepted;
- a concrete supplier passes the feasibility/conformance gate;
- program-independent admission provisioning and necessary C2 physical,
  transaction, and terminal contracts/implementation are ready;
- the existing qualified-host, standing-authority, custody, effect, validation,
  review, and single-delivery prerequisites are met.

RW0-E does NOT require the full-custodian or acceptance-focused checkpoint
protocol.

Clarify the existing deferred-decision table accordingly. Do not erase offline
custody requirements; distinguish them from a production continuity supplier.

## 10. Compatibility and downstream scope

Preserve program-independent admission recording as a later separate owner.
Migration-0002 receipts remain program-bound; no dummy program or v1 field
repurposing.

Narrow “admission creation and repair” wording to exact authorized recording
and owner-governed readback/recovery. No replacement, renewal, orphan repair,
or implicit retry.

Qualify SQLite administrative restore: successful local integrity checks do
not reactivate this first-live support profile or establish C2 continuity.

Do not make ordinary B1 administration or all existing Coordinator operations
depend on this proof profile. It applies only to the explicitly selected live
RW0 proof.

Full continuity and acceptance-focused continuity remain unselected successor
options. No automatic migration to either is prescribed.

## 11. Finite causal tests

Use direct hand-authored histories with independently authored expectations.
Do not build another prose verifier, general protocol engine, universal mutant
framework, or source-byte manifest test.

Cover at minimum:

- repeated RW0-D runs with fake sources and no live enrollment;
- initial authenticated enrollment and admission recording before a program;
- enrollment recorded but activation response lost: no second activation;
- same database copied to another process/host: no usable incarnation authority;
- late old response cannot authorize a new incarnation;
- uninterrupted nonaccept progression without external checkpoint writes;
- first acceptance and attempted second acceptance;
- acceptance commit followed by lost response while original custody survives;
- identical preaccept database bytes after restore but no valid live custody;
- process/supervisor restart: no re-enrollment or synthetic outcome;
- prohibited in-place restore/VM-memory-restore path invalidates custody;
- fence request without completion: no successor activation;
- failure before acceptance retires proof availability without claiming consumed
  acceptance;
- normal terminal closure does not renew the profile;
- later ES policy does not replenish direct-local allowance.

Include a small number of causal mutants: remove irreversible enrollment,
allow copied session authority, default missing posture to positive, enable
restart, infer noncommit from timeout, or let the enforcer choose a C2 branch.

Synthetic evidence tests protocol logic only. Real custody/fencing remains
the mandatory later conformance gate.

## 12. Validation and preservation

Before execution, create a clean local-only external clone from exact HEAD,
with no remote, and overlay exactly the changed/new candidate files.
Do not import or test from the live checkout. No dependency installation.

Run collection followed by execution serially using:
 PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=.:src python3 -m pytest \
   -q -p no:cacheprovider --basetemp=<precreated-external-parent/group>

Required:
1. New test module.
2. Existing guard, decision, private-value, RW0 phase-entry, architecture,
   operating-model, SQLite administrative, and writer-session contract tests.
3. Complete repository with no path arguments.

Record exact commands and results. The reported baseline was 8,742 tests and
three writer-session Python 3.13 fork warnings; do not manufacture counts.
Reconcile changed test nodes and actual warning records.

Run git diff --check, new-file no-index whitespace checks, UTF-8/BOM/CR/final-LF
checks, and exact changed-path/type/mode checks.

Preserve source, schemas, migrations 0001–0004, configuration, scripts,
AGENTS.md, README.md, and all noncandidate tracked bytes. Migration 0005 absent.

Record live cache members safely before tests and prove exact metadata/content
equality afterward. Remove only task-created external clones and test fixtures.
No live product/operator database access or live cache cleanup.

## 13. Closeout and stops

Return:
- verdict and visible settings;
- opening/closing Git coordinates;
- exact changed/new file table with mode, size, SHA-256, and baseline blob;
- selected authority/custody model and supported/unsupported lifecycle;
- exact external participation by operation class;
- RW0-D/RW0-E dependency treatment;
- credible mechanism class, trust assumptions, and unperformed platform proofs;
- finite cases, causal mutants, validation, and limitations;
- unchanged implementation surfaces and cleanup;
- continuation capsule; no later implementation prompt.

Recompute candidate file receipts twice from fresh reads. Include one complete
ordered Git patch recipe, byte count, and SHA-256 inline. Do not deliver a
manifest or make the user transport evidence files.

Stop on baseline drift, an essential custody/fencing impossibility in the
selected class, an unapproved path requirement, source/schema/migration needs,
or a conflict requiring changed v1 canonical meaning.

On a block, restore only this task’s own identifiable edits; never overwrite
concurrent work. Report any remaining state.

Success:
 RW0_C2_SINGLE_REALIZATION_PROOF_POSTURE_CONTRACT_READY_FOR_INDEPENDENT_AUDIT

Blocked:
 RW0_C2_SINGLE_REALIZATION_PROOF_POSTURE_CONTRACT_BLOCKED

Success requests only a fresh independent read-only audit. It grants no commit,
publication, source, migration, runtime, service, deployment, or live-proof
authorization.
```

**Sources:** Refreshed Coordinator snapshot, especially `.docs/rw0-remote-worker-contact-phase-entry.md:125–209,467–510`, `.docs/rw0-c2-bootstrap-acceptance-guard-semantic-contract.md:29–114`, `.docs/writer-session-authority.md:134–183`, and migration-0002 receipt definitions at lines 537–559; the attached reconnaissance; primary Linux, AWS, and Red Hat documentation cited above.

**Confidence:** High on selecting model 3 for this first live slice and keeping RW0-D independent of live continuity infrastructure. Medium-high on the managed-incarnation implementation class; its building blocks are concrete, but the assembled custody and fencing guarantees require the explicit platform conformance gate.
