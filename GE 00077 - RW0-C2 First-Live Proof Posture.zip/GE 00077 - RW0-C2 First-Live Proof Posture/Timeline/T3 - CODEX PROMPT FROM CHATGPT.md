# Governed Execution Coordinator — Admission/Continuity and Scope-Provisioning Contract Tranche

## Objective and effect ceiling

Write one coordinated documentation-and-causal-contract-test candidate with two
distinct semantic owners:
- .docs/rw0-c2-admission-continuity-source-contract.md
- .docs/rw0-c2-scope-admission-provisioning-contract.md

The accepted direction is an independently custodied, monotonic lineage record
with a durable possible-commit barrier BEFORE a protected SQLite commit, plus
program-independent immutable admission provisioning. This is a TARGET contract,
not evidence that a suitable custodian or fencing mechanism already exists.

The parent alone may edit the explicitly allowed docs/tests below and validate
their candidate in a disposable local-only external clone. No subagents.
No product source, SQL, migration, config, public API, runtime, service, host,
network, credential, worker, ES, Bridge, or sibling-repository work. No staging,
commit, push, PR, merge, installation, or live product/operator database access.
Do not issue an implementation prompt for a later tranche.

Use the highest exposed reasoning setting and report the visible model, effort,
and permission posture, or "not visible". Do not seek extra access to identify
hidden settings. Broad filesystem permissions do not widen this task.

Return ONE substantive inline report and continuation capsule. No external
report/manifest/package deliverable. Disposable validation files are permitted
only outside the live repository and must be cleaned up.

## 1. Exact baseline and source hierarchy

Repository:
 /Users/ds/Repositories/Governed Execution Coordinator

Required opening:
 branch: trunk_dev
 HEAD: d070bf05d2e68472e18b1b077259e67864923e8f
 tree: d662b6702e178218c12930259eda5fb690c2fe25
 sole parent: 3d99e448bfe577b5a5878dd32b7e01b61322e7df
 subject: docs: freeze RW0-C2 private value and graph profiles
 upstream: origin/trunk_dev
 locally observed divergence: 0 ahead / 0 behind
 one worktree; clean index/worktree/untracked/unmerged
 no active Git operation or unexpected lock.

Read AGENTS.md first. Verify opening and closing with non-mutating Git inspection,
using optional-lock suppression where appropriate. Do not fetch or contact the
remote; the upstream is a locally observed tracking ref, not fresh remote truth.
Stop before edits on mismatch; do not normalize state.

Git owns objects/refs. Owning repository contracts define current and accepted
target semantics. Source/migrations define current implementation. Tests and
reconnaissance reports are evidence, not independent authority. No historical
JSONL, snapshot, receipt, or attached report is needed as a prerequisite.

Current implementation includes bounded local WriterSession fencing, existing
program mutation families, and RW0-C1 evidence persistence. It has no C2
provisioner, continuity custodian/verifier, guarded post-execution writer,
migration 0005, or C2 recovery runtime. PR #11 adopted private target values and
tests, not those capabilities.

## 2. Fixed decisions and exclusions

Preserve:
- One bootstrap scope per explicitly standing-policy-admitted Coordinator
  authority lineage. Machines, databases, restores, clones, programs, grants,
  and policy epochs do not create a lineage or replenish its allowance.
- One active authority per lineage; no active-active database copies.
- One immutable admission fact and at most one immutable productive direct-local
  acceptance fact across participating programs.
- Coordinator's guarded decision commit is the acceptance linearization point.
  The four nonaccept branches create no acceptance fact.
- One C2 result/receipt and one whole-family C2 replay/recovery owner. No mutable
  available/consumed latch, separate guard transaction, or external acceptance
  classifier.
- Positive universal admission/lineage/continuity/sole-active/no-foreign posture;
  acceptance-only exhaustive unclaimed proof remains a separate requirement.
  Unknown claimed status alone is not a universal failure for nonaccept.
- Exact replay preserves the original command, family, and timestamp. Recovery
  creates no fragment repair, new decision, or automatic retry after unresolved.
- Terminal output and later ES routing are separately governed and nonreplenishing.
- No user in routine per-command approval or evidence-relay paths.

Preserve unchanged:
- all eleven adopted private value/profile grammars, canonical v1 preimages,
  digest domains, branch/result/recovery semantics, and owner-assertion profile;
- current migration-0002 decision/version/head/result/receipt meanings;
- migrations 0001–0004; 0005 remains absent;
- current fail-closed UnsupportedAuthorizationProvider;
- B1 latch_postimage_* compatibility/nonproof semantics.

New source/provisioning protocol values must have separately named owners and
versioned grammars. Do not add fields to existing v1 canonical values.
No deployment product, network transport, new repository, distributed-consensus
system, hardware API, provider integration, or single-Mac constraint is selected.

## 3. Required re-grounding and pre-edit plan

Read the relevant sections of:
- AGENTS.md; README.md
- .docs/architecture.md
- .docs/autonomous-software-development-operating-model.md
- .docs/authority-boundaries.md
- .docs/rw0-c2-bootstrap-acceptance-guard-semantic-contract.md
- .docs/rw0-c2-private-value-versioning.md
- .docs/rw0-c2-durable-progression-decision-semantic-contract.md
- .docs/sqlite-operations-and-recovery.md
- .docs/writer-session-authority.md
- .docs/rw0-remote-worker-contact-phase-entry.md
- .docs/c2b-durable-development-state.md: current Section 36/41/42 and successors
- .docs/rw0-c1-durable-evidence.md
- .docs/c2b2-migration-0002.md
- .docs/c2b2-pure-durable-row-values.md
- .docs/c2b2-private-readers.md

Inspect actual source and relevant tests as data before changing contracts:
- src/ge_nwp_coordinator/lease.py
- src/ge_nwp_coordinator/sqlite_writer_session.py
- src/ge_nwp_coordinator/state_authority_lock.py
- src/ge_nwp_coordinator/sqlite_mutation_transaction_contracts.py
- src/ge_nwp_coordinator/sqlite_transition_transaction.py
- src/ge_nwp_coordinator/_development_decision_row_values.py
- src/ge_nwp_coordinator/_development_program_row_values.py
- src/ge_nwp_coordinator/_development_program_initialization_contracts.py
- src/ge_nwp_coordinator/_sqlite_development_program_initialization.py
- current development and C1 private readers/recovery contracts
- sqlite_migrations/0002_development_program_and_effect_state.sql and
  0004_rw0_c1_durable_evidence.sql under that source package
- current migration catalog, public exports, pyproject.toml, .gitignore
- the existing tests named in the allowed scope and validation sections.

Inspect current docs/test routing rather than assuming the reconnaissance's
suggested paths are exhaustive. Before editing, record the selected subset of
allowed files and the exact clause/test dependency requiring each change.
Resolve logical authority, checkpoint, barrier, and recovery questions in that
plan. Do not produce a partially specified owner and rely on later tests to
invent its meaning.

## 4. Mutation scope

Create exactly these four new files:
 .docs/rw0-c2-admission-continuity-source-contract.md
 .docs/rw0-c2-scope-admission-provisioning-contract.md
 tests/test_rw0_c2_admission_continuity_contract.py
 tests/test_rw0_c2_scope_admission_provisioning_contract.py

The following existing documentation MAY change only for direct ownership
routing, the source/provisioning prerequisite, exact supersession of the two
identified ambiguities, and truthful current/target status:
 .docs/architecture.md
 .docs/autonomous-software-development-operating-model.md
 .docs/authority-boundaries.md
 .docs/rw0-c2-bootstrap-acceptance-guard-semantic-contract.md
 .docs/rw0-c2-durable-progression-decision-semantic-contract.md
 .docs/rw0-c2-private-value-versioning.md
 .docs/sqlite-operations-and-recovery.md
 .docs/writer-session-authority.md
 .docs/rw0-remote-worker-contact-phase-entry.md
 .docs/c2b-durable-development-state.md

The following existing tests MAY change only to enforce the corresponding
authorized normative/status amendments and exact cross-reference routing:
 tests/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.py
 tests/test_rw0_c2_durable_progression_decision_semantic_contract.py
 tests/test_rw0_c2_private_value_versioning_contract.py
 tests/test_autonomous_software_development_operating_model.py
 tests/test_architecture_contracts.py
 tests/test_rw0_remote_contact_phase_entry_contract.py
 tests/test_c2b0_durable_state_contract.py
 tests/test_sqlite_backend_b0_contract.py
 tests/test_b2a_writer_session_contract.py

This is an allowlist, not a required file count. Use the smallest coherent
subset; justify every changed existing path. No unrelated rewrites.

Keep AGENTS.md and README.md unchanged: their current implementation/nonimplementation
summaries remain true, and existing capability guards pin their byte identities.
Route the new owners through the guard, decision, operating-model, and architecture
docs. Do not start another capability-identity reset merely to announce new docs.

Keep all other files, especially src/, schemas/, migrations, tests/c2a_contract_support.py,
config, package exports, and scripts unchanged. Do not alter the existing prose
parser, broaden its language, weaken its assertion profile, or bypass its tests.
A real conflict requiring another path or an adopted v1 semantic change is a
bounded stop, with exact path:line evidence—not automatic scope expansion.

## 5. Admission/continuity source owner

### 5.1 Name authority accurately

Specify the standing-policy-delegated continuity custodian's own authority:
enrollment binding, monotonic custody history, active-realization epoch,
outstanding protected-operation barriers, and checkpoint acknowledgments.

These are external continuity/coordination facts. They are not merely decorative
diagnostics. They are also NOT Coordinator progression decisions, acceptance
facts, acceptance receipts, policy grants, worker/ES permission, or publication
authority. The custodian cannot expand standing policy or choose a C2 branch.

Coordinator remains sole author of admission recording and its acceptance
decision family. The source verifier authenticates externally owned facts;
well-shaped values or hashes do not manufacture verification.

Define author, recorder, custodian, verifier, lifetime, revocation/freshness,
and effect ceiling for each logical fact. No hidden state in chat or helper repos.

### 5.2 Custody and threat assumptions

Define the independent rollback/copy failure domain. Custodian history and
credentials cannot be reproduced by copying/restoring Coordinator SQLite.
Specify monotonicity, protection of its own backups, rollback detection or
fail-closed re-enrollment, and source identity/trust-root transition.

Supported assumptions: correct guarded Coordinator/provisioner code; crash,
response loss, ordinary restore/rollback/clone/relocation, partitions, and stale
messages. Identify compromised policy roots, custodian compromise, malicious
bypass, and rollback of both custody domains as unsupported unless independently
addressed. Do not claim same-account malicious-process protection from a lock.

The contract may define these required properties without an implemented
supplier. Actual custody/fencing conformance is a later implementation-entry
gate. Do not block writing a target contract solely because no service exists.
Conversely, do not claim that a signed response, finite test, or abstract
"fenced" flag establishes real deployment feasibility.

### 5.3 Cumulative protected-state coverage

An opaque latest-family digest is insufficient unless its ancestry and coverage
are specified. Define exactly what logical protected state a checkpoint covers:
admission binding, permanent acceptance history, relevant immutable family
closure, and any mutable heads needed by the claimed currentness proof.

A later nonaccept operation must not erase the commitment to an earlier
acceptance. Matching the latest unrelated family is not proof that older
acceptance records are present or absent. Define semantic checkpoint/ancestry
verification and retention obligations; no SQL/index/file-format choice.

Identify every future mutation class that can change this protected closure.
It must participate in the protocol or invalidate the claimed continuity.
Classify existing C2B/C1 operations, writer-generation bookkeeping, migrations,
restore, and unrelated state explicitly. Do not make every SQLite write a
protected operation by accident; do not permit a bypass of protected state.

No raw database-file hash is sufficient where harmless current writer/session
bookkeeping legitimately changes bytes. Machine, inode, path, and lock remain
operational evidence, not lineage identity.

### 5.4 Pre-commit barrier and ordering

Specify a finite logical operation protocol:
- independently verified enrollment and predecessor checkpoint;
- operation-bound request with lineage/scope, authority epoch/realization,
  operation identity, canonical command digest, and expected protected checkpoint;
- durable arm acknowledgement BEFORE any possible protected local commit;
- at most one unresolved protected operation per lineage in the initial model;
- exact Coordinator commit/readback;
- monotonic settlement/checkpoint acknowledgment or retained unresolved barrier.

This serializes protected mutation admission, not cognitive planning or every
read. It introduces no scheduler or operator-approved backlog.

Freeze linearization points, allowed transitions, idempotency, and failure
results for enrollment, arm, acknowledgment, settlement, and handoff. A lost
arm response is not absence; exact read-only reconciliation must precede any
progression. Repeated same operation/digest cannot mint another write permit.
Different digest, wrong epoch, stale checkpoint, and foreign realization conflict.

An arm means "this operation may have committed", not "accepted" or "spent".
C2 SQLite commitment remains the sole acceptance linearization point even when
external acknowledgment is lost. No 2PC/atomic-cross-store-commit claim.

Fresh challenges, arm identifiers, settlement messages, and current epochs use
separate source-protocol bindings to an already defined command. They do not
rewrite historical C2 command digests, become new v1 fields, or create a digest
cycle. Specify dependency order before assigning versioned source envelopes.

### 5.5 Resolve pending operations without circular authority

A pending barrier forbids new conflicting protected writes and unsafe handoff;
it must not automatically forbid all readback of the operation it protects.

Define operation-bound recovery/read-only posture distinct from fresh-write
admission. It may support C2/provisioner readback only when lineage, actual
custody, current epoch, sole-active posture, and the relevant old-writer fence
are positively established. Unknown outcome is not itself unknown custody.

Show an allowed path:
 pending arm + intact positive custody -> original-family readback ->
 owning classifier -> authenticated settlement.
No requirement that settlement already exist before this readback can occur.

Show the fail-closed alternative:
 pending arm + rollback/clone/custody ambiguity -> unresolved;
 stale local absence never closes the arm.

Read authorization is not permission to retry, create a fact, repair a fragment,
or disclose protected data under unproved posture. Preserve the adopted
seven-field recovery result and its normal unresolved handling.

### 5.6 Arm settlement and old-writer fencing

Specify what prevents an already armed or delayed writer from committing AFTER
a "noncommit" settlement or authority handoff. An epoch number alone is not a
physical fence for a disconnected SQLite copy; checking it once is not enough.

A definite-noncommit observation supports release only with proof the original
execution can no longer commit AND intact custody for the original read set.
Local absence, response expiry, timer expiry, process unreachability, or loss of
a reply is not that proof.

For committed settlement, require the owning Coordinator family classifier and
exact family/checkpoint binding. The custodian validates evidence references
and advances its own record, but does not become the C2 classifier.

Retain the unresolved barrier if source proof or an effective old-writer fence
cannot be demonstrated. No time-based forced takeover, lease-expiry-only
promotion, or scope reset. Specify the logical fence obligation now; concrete
platform enforcement must pass a later conformance gate.

### 5.7 Operation classes and lifecycle traces

Keep separate:
- initial admission verification before any local admission fact exists;
- ordinary fresh command universal posture;
- acceptance-only unclaimed proof;
- nonaccept without an unclaimed assertion;
- exact historical replay with fresh current disclosure posture;
- uncertain original-operation readback;
- planned transfer and unplanned recovery.

Unknown claimed status alone can still permit a nonaccept branch when universal
posture and all ordinary prerequisites are exact. A pending uncertain operation
or unproved custody is a different condition, not a pretext to change that rule.

Revocation/key or source transition can suspend new authorization without
rewriting admission or acceptance. Define independently permitted diagnostic
inspection versus protected readback; no new broad public read path.

A stale response or former realization returning after a planned handoff cannot
regain permission. Handoff drains pending operations, verifies protected
ancestry, and demonstrates the old fence before activation of a successor epoch.
Lost handoff response is reconciled from monotonic source state, not a new scope.

## 6. Program-independent admission-provisioning owner

Select provisioning before any development program exists. Do not invent a
dummy program. Current development_mutation_receipts requires program_ref and
a closed family/result algebra; preserve it unchanged.

Define a separately versioned admission command/result/receipt/replay/recovery
family. It is a separate provisioning operation, NOT a second guard acceptance
receipt or classifier. Share future transaction/session mechanics where valid,
not program-bound semantics.

Freeze semantic fields, identity inputs, authority checks, exact replay keys,
pre/postconditions, no-write/result classifications, and response-loss behavior.
Keep SQL tables, columns, indexes, queries, migrations, entry signatures, and
executable transport implementation out of scope.

Required properties:
- authenticated explicit policy act authorizes one lineage/scope; local schema
  creation/empty store is never admission;
- source enrollment bootstraps without requiring a nonexistent local fact;
- provisioner records only the exact act and immutable admission binding;
- no new branch, acceptance, execution, Git, runtime, or publication permission;
- admission-fact identity retains its existing v1 meaning and is independent of
  the command, program, machine, database, and renewed grant;
- one operation/digest records at most one exact fact/result/receipt family;
- same operation/digest returns the original complete family/time;
- same operation/different digest conflicts;
- same act under a new operation ID never mints a second fact/receipt and is not
  silently described as exact replay of a different command;
- foreign/different act for an occupied lineage/scope conflicts;
- no automatic replacement, amendment, renewal, or replenishment;
- arm before local commit, one local commit, original-family readback afterward;
- response loss gives committed_exact / definitely_not_committed / unresolved
  under this provisioner owner's exact family and source-custody rules;
- no completion/repair of an orphan or partial family;
- proved definite noncommit may allow a separately authorized repeat of the SAME
  original operation only after old execution is unable to commit and ordinary
  source/policy checks pass; no automatic retry after unresolved.

Give the narrow recorded-fact readset and collision classes semantically.
Do not define physical selectors or widen existing current private readers.
New protocol identity/digest dependencies must be acyclic and source-attributed.
No per-command human approval workflow.

## 7. Exact compatibility amendments

Make two explicit, narrow governing clarifications:
1. SQLite restore "becomes authoritative" refers to existing managed local
   SQLite acceptance checks. It does not establish C2 lineage continuity,
   sole-active status, or unclaimed allowance. Preserve that administrative
   restore contract; add the later C2 prerequisite without making all B1 reads
   depend on the proposed custodian.
2. The private value owner's admission "creation and repair" wording means
   recording the authorized immutable binding and exact same-operation
   readback/recovery. It does not permit reauthoring, replacement, renewal,
   orphan repair, or replenishment. Remove the ambiguity explicitly.

The guard keeps scope/eligibility/family ownership. The decision owner keeps
five branches and C2 recovery. The new source owner defines evidence and
continuity-operation rules; the new provisioner owner defines admission recording.
Operating model owns composition/status.

Preserve the existing private machine registry and owner assertion/profile
identities. New protocol schemas belong to new owners, not the adopted eleven
values. Do not silently turn all source facts into standing execution permission.
A real incompatibility with these constraints must be surfaced before drafting
a success candidate, with a named successor seam.

## 8. Finite causal evidence, not another assurance framework

Use direct hand-authored finite histories and separately authored expected
outcomes. A small pure test-side transition checker is permitted only for this
finite protocol. It is not runtime code or a general orchestration/recovery
engine. Do not duplicate the C2 reducer.

At minimum test these paired histories:
1. First explicit admission without a program; local emptiness alone rejected.
2. Exact provisioning replay; same ID/different digest; same act/new ID;
   different act for occupied scope; none creates extra fact/receipt.
3. Crash before arm, arm persisted/reply lost, arm before local commit, local
   commit/reply lost, local commit before source acknowledgment, acknowledgment
   before caller response.
4. Same D0 bytes with no attempted acceptance versus acceptance then D0 restore;
   independent source histories differ; post-commit-only witness mutant fails.
5. Acceptance followed by nonaccept checkpoint; restoring/deleting the older
   acceptance cannot appear unclaimed from latest-family equality.
6. Own pending barrier + intact positive custody permits bounded readback;
   pending barrier + stale/ambiguous custody remains unresolved.
7. Original operation absent but old execution still able to commit: no release;
   definitively fenced original + intact absence: owner-classified noncommit.
8. Two copied databases each obtaining local writer locks; only enrolled current
   authority can progress. Advancing epoch without an effective fence fails.
9. Planned transfer; late arm/settlement response; old process resumes; timeout
   alone never activates a replacement.
10. Source unavailable or rolled back, wrong audience/issuer, stale challenge,
    revoked source/key, or policy expiry: no new protected effect.
11. Unknown claim with exact universal posture on all four nonaccept branches:
    no acceptance fact and no unclaimed assertion.
12. Replay after later program-head movement returns original bytes/time, using
    new disclosure evidence without changing the historical command.
13. Partial/orphan original family versus competing complete winner, including
    simultaneous fragments: owner taxonomy preserved; no automatic repair/retry.
14. Barriers/checkpoints themselves never create an acceptance fact, set an
    available/consumed bit, manufacture C2 classification, or renew a scope.

Include modest hostile variations removing the single causal event/check each
case depends on. Report reached boundaries, not just test counts. Keep fixed
specimens outside the mutated observed structures. Simulated observations are
explicit assumptions, not proof of custody, signature validity, or fencing.

Do not build a new Markdown grammar, all-prose contradiction parser, universal
JSON-pointer mutation suite, all-history package, broad source hash manifest,
or tests purporting to authenticate arbitrary coordinated rewrites of themselves.
No minimum test-count target. Existing parser behavior is not extended.

## 9. Validation and live preservation

Before execution, create a clean local-only external clone from exact HEAD with
no configured remote; overlay the exact complete candidate (including new files).
No live checkout imports/tests. Use only installed dependencies.

Run collection then execution SERIALly, with separate pre-created external
basetemp parents for each group:
 PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=.:src python3 -m pytest \
   -q -p no:cacheprovider --basetemp=<external-existing-parent/group>

Required groups:
A. Both new test modules.
B. Existing directly affected tests from the selected allowlist, at minimum:
 tests/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.py
 tests/test_rw0_c2_durable_progression_decision_semantic_contract.py
 tests/test_rw0_c2_private_value_versioning_contract.py
 tests/test_autonomous_software_development_operating_model.py
 tests/test_architecture_contracts.py
 tests/test_rw0_remote_contact_phase_entry_contract.py
 tests/test_sqlite_backend_b0_contract.py
 tests/test_b2a_writer_session_contract.py
C. Full repository, with no test path arguments.

Add focused groups only when actual dependency inspection justifies them.
Record exact paths/commands, collection, execution, warnings, failures, repairs,
and skipped work. Baseline full-suite report is 8,742 passed with three existing
writer-session Python 3.13 fork warnings; do not treat old counts as acceptance
criteria or manufacture tests to reach totals. Reconcile changed node sets.
Never identify warning presence by substring search over test names.

Run git diff --check, each new-file no-index whitespace check, strict UTF-8/
BOM/CR/trailing-whitespace/final-LF checks, and exact path/type/mode checks.
No-index exit 1 with no whitespace diagnostic means a difference, not failure.

Confirm live src/, schemas/, migrations, configs, scripts, all protected tests,
AGENTS.md/README.md, and all noncandidate tracked bytes still equal HEAD.
Migrations remain exactly 0001–0004.

Inventory pre-existing live cache safely without imports. Preserve member
path/type/mode/size/mtime/hash equality; distinguish directory from bytecode files.
Do not move, remove, or "clean up" pre-existing material. Do not open sensitive
ignored state. Dispose only of this task's external clones, fixtures, and logs.

Candidate-related failures require repair inside the allowed doc/test scope.
A setup error can be corrected externally, then the clone rebuilt and a clean
serial run completed. No acceptance credit to overlap, skipped tests, arbitrary
warning suppression, or mutated expectation-only success.

## 10. Candidate provenance and report

No staging/commit/publication. Closing HEAD, tree, parent, upstream, and
worktree count must equal opening; zero staged/unmerged paths.

For the actual changed/new paths, compute an inline deterministic receipt:
 recipe_id: rw0-c2-admission-continuity-contract-candidate-v1
 baseline_head; baseline_tree
 files: lexicographically ordered records with path, change (M or A),
        regular-file mode, size_bytes, sha256, and baseline_blob (null if new).
Encode recursively sorted object keys, compact separators, UTF-8,
ensure_ascii=false, allow_nan=false, no final LF. Recompute from fresh reads
twice and report equality, byte count, hash, and complete per-file table.
A digest proves identity, not correctness.

Also report a complete ordered patch: for each sorted tracked path use
git diff --binary --full-index --no-ext-diff --no-textconv HEAD -- <path>;
for each new path use git diff --no-index --binary --full-index --no-ext-diff
--no-textconv -- /dev/null <path>. Concatenate stdout with no separators.
Record recipe, byte count, and hash. Do not require user transport of a manifest
file; the next auditor will read the repository.

Inline closeout:
- verdict and visible settings;
- exact opening/closing coordinates and actual touched set;
- authority matrix and selected source/provisioner semantics;
- checkpoint coverage and protected-write participation;
- recovery-under-pending-barrier, settlement, and late-writer safety;
- provisioning family and preserved v1 boundaries;
- exact amendments and unchanged file/semantic surfaces;
- finite histories and reached hostile boundaries;
- validation commands/results, limitations, and cleanup;
- receipt/patch coordinates;
- concrete supplier, anti-rollback custody, and fencing proof still absent;
- continuation capsule <=800 words; no later implementation prompt.

## 11. Stops and disposition

Before edits: block on wrong baseline, unavailable primary owners, another
actor's dirty state, or unresolvable authority contradiction.

During work: block if a required path lies outside the allowlist; source/SQL/
migration changes are needed; custody or fencing is replaced by a self-authored
positive flag; barrier becomes a second acceptance owner; exact recovery
requires permission already withheld by the same unresolved barrier; protected
history can be erased by a later checkpoint; or a v1 field/domain change is
needed without a separately selected successor contract.

When blocked, restore only this task's own edits to the exact opening baseline
when they can be identified unambiguously. Never overwrite concurrent work;
otherwise stop and report the remaining state.

Success requires fully specified target semantics and finite contract evidence,
not an implemented custodian. A deployed supplier, trust-root bootstrap,
anti-rollback behavior, effective old-writer fencing, and end-to-end atomic
failure handling remain explicit later feasibility/implementation gates.

Success:
 RW0_C2_ADMISSION_CONTINUITY_AND_PROVISIONING_CONTRACTS_WRITTEN_VALIDATED_READY_FOR_INDEPENDENT_AUDIT

Blocked:
 RW0_C2_ADMISSION_CONTINUITY_AND_PROVISIONING_CONTRACTS_BLOCKED

Success requests a fresh independent read-only audit; it grants no commit,
publication, migration, source, or runtime authority.

State actual non-actions and deviations: product source/schema/migrations/config
unchanged; no migration 0005; no external custodian/verifier/provisioner/guarded
writer/recovery runtime; no public surface, worker, ES, or Bridge integration;
no live database/import/test/cache edit; no network, service, dependency, sibling,
or subagent use; no staging/commit/push/PR/merge; no delivered external evidence
artifact. Temporary isolated test databases and external clone mutations are
validation effects, not live product effects; do not deny that they occurred.
