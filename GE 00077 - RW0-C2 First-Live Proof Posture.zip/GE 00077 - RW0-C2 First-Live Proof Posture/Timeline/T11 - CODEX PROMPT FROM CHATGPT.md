# Governed Execution Coordinator — First-Live Proof Posture: PR #12 Squash Merge and Local Realignment

## Mandate and bounded effects

Perform one parent-only merge gate for the exact published source commit and
PR #12 below. This is a merge/publication finalization task, not contract
implementation or another audit.

Prior accepted evidence:
 RW0_C2_SINGLE_REALIZATION_PROOF_POSTURE_CONTRACT_ACCEPTED_READY_FOR_COMMIT_GATE
 RW0_C2_SINGLE_REALIZATION_PROOF_POSTURE_CONTRACT_COMMITTED_AND_PR_OPENED

The prior gate reports exact working/index/committed eight-file equality and
serial validation from index-derived bytes: 16 new tests; 3,192 affected
contract tests; full repository 8,758 passed with three unchanged writer-session
Python 3.13 fork warnings. This is historical evidence, not fresh GitHub state.
Do not rerun tests, collection, repository scripts, probes, mutants, supplier
qualification, or migrations in this gate.

This prompt authorizes only, in order:
1. Read-only local Git-object/working-state verification and authenticated reads
   of the configured GitHub repository, PR, refs, effective rules, and readiness.
2. At most ONE ordinary synchronous, head-SHA-guarded squash-merge request for
   this exact PR and source. No retry, bypass, queue, or asynchronous request.
3. Independent readback and verification of the resulting remote commit,
   parent, tree, message, attribution/signature status, and exact file effects.
4. After those checks pass, ONE narrow fetch of trunk_dev into origin/trunk_dev.
5. After verifying the fetched raw object, ONE expected-old-object-guarded
   update of the already checked-out local trunk_dev to the verified squash.
6. Final verification and cleanup of this gate's own disposable external files.

Ordinary object database, FETCH_HEAD, remote-tracking-ref and reflog writes
caused by the exact authorized fetch/ref update are permitted. They are not
permission for any additional branch, worktree, index, or source operation.

Never edit or stage candidate files; create/amend a source commit; perform a
local merge/squash, rebase, cherry-pick, reset, checkout, switch, or branch
creation; push any ref; delete the topic; change PR title/body/metadata; enable
auto-merge; join a merge queue; issue an async merge; alter rules/settings or
credentials; request/review/resolve conversations; trigger CI; make a tag,
release, deployment, supplier selection, enrollment, launch, fencing action,
or live proof. No product database access, source imports, dependency installs,
service experiments, sibling repositories, or subagents.

Ordinary platform notifications and already configured non-deploying repository
checks induced by an ordinary merge are implicit publication effects. They are
not authorization for a deployment or another broader workflow. Inspect known
merge/push workflow triggers as data. If merging inherently requires or triggers
a prohibited operational effect, stop rather than disable protections.

Use the highest exposed reasoning setting and report visible model, reasoning
setting, and permission posture, or "not visible". Do not seek extra account or
computer access merely to discover hidden settings. Broad host permissions do
not widen this mandate.

Return ONE substantive INLINE report plus a continuation capsule of at most
800 words. No delivered receipt, manifest, patch, snapshot, or evidence package.
This prompt is self-contained; request no prior audit or publication attachment.

## 1. Exact opening repository and PR

Repository root:
 /Users/ds/Repositories/Governed Execution Coordinator
Configured origin identity:
 github.com/evo-agi/Governed-Execution-Coordinator
PR:
 https://github.com/evo-agi/Governed-Execution-Coordinator/pull/12
PR number: 12
PR node ID: PR_kwDOTYw1Ic8AAAABIUevug
Base branch: trunk_dev
Head branch: codex/rw0-c2-first-live-proof-posture-v1

Required LOCAL opening state:
 branch: trunk_dev
 HEAD/source: bd997da10df551afadd7854ffecf92018ade0fb6
 source tree: cd81f7cca8b64cb9ff221537257e70e2c5a655a3
 sole parent: d070bf05d2e68472e18b1b077259e67864923e8f
 parent tree: d662b6702e178218c12930259eda5fb690c2fe25
 subject: docs: freeze RW0-C2 first-live proof posture
 upstream: origin/trunk_dev
 local origin/trunk_dev: d070bf05d2e68472e18b1b077259e67864923e8f
 divergence: 1 ahead / 0 behind
 exactly one live worktree
 index and working tree match the source commit
 no staged/unstaged/untracked/unmerged change
 no active merge/rebase/cherry-pick/revert/bisect/sequencer or unexpected lock.

Required REMOTE opening state, to be freshly verified:
 refs/heads/trunk_dev -> d070bf05d2e68472e18b1b077259e67864923e8f
 refs/heads/codex/rw0-c2-first-live-proof-posture-v1 -> bd997da10df551afadd7854ffecf92018ade0fb6
 PR #12 OPEN, non-draft, unmerged, exact base/head repositories and branches,
 exact head OID, one source commit, exactly eight file effects.

The configured authenticated actor was reported as SeritArbores. Verify the
current login and source author/committer attribution through GitHub without
exposing credentials. Use that already configured actor; do not switch accounts
or change identity to satisfy policy. A different actor is a preflight block.

Read AGENTS.md and applicable local guidance first. Read the first-live support
owner and relevant changed status sections as needed to understand the merge,
not to restart semantic design. Inspect local hook and signing metadata as data;
do not execute hooks, external diff helpers, or repository code.

Use read-only object/status commands with optional locks suppressed where
appropriate. Confirm refs/heads/trunk_dev is a direct ref and HEAD symbolically
points to it. Do not fetch or normalize local state before opening checks.

If another actor already merged or closed the PR before this gate, report its
actual state and stop without sending a merge request or moving local refs.
Do not silently reinterpret this task as reconciliation of another actor's work.

## 2. Exact source tree and accepted file endpoints

The source contains 244 tracked regular file entries: 236 unchanged from its
parent, six modifications and two additions. Reproduce exact path sets and
Git-relevant modes, not just counts. No rename, deletion, executable-bit change,
symlink, submodule, extra path, or alternate blob is permitted.

All eight entries below are Git mode 100644. The eight worktree endpoints are
regular nonsymlink mode 0644, strict UTF-8, one final LF, no BOM/CR or trailing
whitespace. The same source blob OIDs must appear in the squash tree.

| Effect | Repository-relative path | Bytes | SHA-256 | Parent blob | Source/squash blob |
|---|---|---:|---|---|---|
| M | `.docs/autonomous-software-development-operating-model.md` | 39079 | `cba69a4e88eeb34bb0f25d3ac8f2ca8774b471fd6dc70a6af1211b3d661b963f` | `e94f9209399d9d957683b6bdeccc5faf350ca1c7` | `9207ff698920682dc25057a9fc12b9f2a8cb28d7` |
| M | `.docs/rw0-c2-bootstrap-acceptance-guard-semantic-contract.md` | 26007 | `e91b82190ccb4969ff670a365b66419e7c5ac945ca328f3c832c5db1e5eb0d09` | `d1dd3f29a85a4c2ed30153f3da241e8349dbe9fb` | `b737b4feff254e2da5d04151575acfbd06f201f3` |
| A | `.docs/rw0-c2-first-live-proof-posture.md` | 15741 | `0064fd833337dee2503da1296525e32e4e76a799c803a86122434b86919f6541` | absent | `d88c3a6a0ec032e460cbd68c97dfe5b915a0514d` |
| M | `.docs/rw0-c2-private-value-versioning.md` | 207512 | `8d0477a2d1ba0cc6f94bacb59927932123582231ebecf345355492e3e6817a37` | `57f7f889774e8cf24ed3ef3be490a4355b4cf0bf` | `54f84052d97d927e8ccc874b39b1fe8aa8596cff` |
| M | `.docs/rw0-remote-worker-contact-phase-entry.md` | 58068 | `fc74ac0d75bf3e762fdd25775bbf91befa533e53b3b90d5cc092457516fab7b5` | `f4c6540dfe998aa9e5493785882c4356904a55a9` | `d3d503a7c5b2c54575acbecd585dc4480ed7f563` |
| M | `.docs/sqlite-operations-and-recovery.md` | 38657 | `86c2cd7b1f780d153c2237d5d47c52b7724630b4cc1d2adc4ad1e4c7a9a701a4` | `676fb5bfa96d8f6a2901e8bb2a7fcbc725507a57` | `80bd68911b386da086f1634681b80d4f06aa00d3` |
| A | `tests/test_rw0_c2_first_live_proof_posture_contract.py` | 12877 | `8568aecff3c499db9acbffa1933b3b79770474e426bad60a22127c1d69f03e39` | absent | `a39b940a6941052093ef85de2b9180ad32264124` |
| M | `tests/test_rw0_remote_contact_phase_entry_contract.py` | 173945 | `53da2ec508272a886e3b7b793bd564f0bf218344d6ce917b5ceaa6ac2ab6ed70` | `d6ee81446fcf9dd389f1ef0939572d9a58970082` | `49e812ef8fca792f8723ecc3db794496d3bac583` |

Read every listed source and baseline blob directly as data. Verify raw sizes,
SHA-256 values, computed Git blob identities, and index/working-file equality.
Verify all 236 unaffected tree entries against the parent and all 244 working
files against the source by content/type and Git-relevant mode.

An unrelated pre-existing nonexecuting test file can have Unix mode 0600 while
Git represents it as 100644. Preserve that actual OS mode; do not turn this into
a global requirement for all files to be OS 0644. The exact OS 0644 condition
applies only to the eight accepted endpoints.

Preserve AGENTS.md, README.md, all src/, schemas/, scripts, configuration, and
unaffected tests. Migration catalog/resources remain exactly 0001-0004 and
0005 remains absent. Inspect SQL/config as data only, never a live database.

The historical uncommitted patch was 39,667 bytes with SHA-256
 d7b2c9442645b83c76fbbe02e066300c5a368eb05a5e5e8ba36f291bfde33ffc.
It is prior acceptance evidence, not the current working-tree representation.
Do not rerun the old unstaged grouped-diff recipe against a clean committed
checkout or interpret its empty output as a lost candidate. Current provenance
is the exact commit, parent, tree, blob and endpoint identity above.

## 3. Exact commit message and PR text

Read the source message from the RAW Git commit object, separating headers from
message bytes at the true blank header separator. Do not hash output from a
pretty-printing command that appends or removes line endings. Signatures are
headers, not part of the message. Read source author/committer and signature
status safely; the published source was unsigned, not falsely verified.

Exact title/subject:
```text
docs: freeze RW0-C2 first-live proof posture
```

Exact source body, excluding its terminal LF in this block:
```text
Adopt the target-only single-realization support profile for the first
bounded RW0-E proof and its causal contract tests.

Preserve one independently enrolled, non-reissuable authority incarnation,
continuous original process/storage custody, and Coordinator-owned
progression and acceptance. Custody loss ends continuation under this profile
without creating an acceptance, noncommit, cancellation, or terminal fact.
Keep RW0-D offline engineering independent of live enrollment.

This change implements no custody supplier, admission provisioner, guarded
decision writer, migration 0005, recovery runtime, public API, RW0-D/E
execution, or Execution Substrate integration. Concrete supplier conformance
and separate runtime/live-proof gates remain required.

Audit:
RW0_C2_SINGLE_REALIZATION_PROOF_POSTURE_CONTRACT_ACCEPTED_READY_FOR_COMMIT_GATE
```

Source message = exact subject + TWO LF bytes + body + ONE final LF.
Required raw source message: 894 bytes; SHA-256:
 662094d19e691b3733d85c2741647acff16b611ebcc38c862b208e2eeffb74ef
Body without final LF: 847 bytes; SHA-256:
 2913e519122e1516dbce10accfbf77ba7af15218a763385d7f6c183905b0d386
Body with one final LF: 848 bytes; SHA-256:
 fad42170aac20b59e707842827368b86a5e49a447c63f7bb8484be9b745fd427

The squash request uses the same title and the 847-byte body WITHOUT final LF.
The exact final squash message is allowed in only these two forms:
- subject + two LFs + body, no terminal LF:
  893 bytes; SHA-256:
  d4d8cbe069e17b8f6439ff25ce9e5bee13237fded4fecf665b0b85bb1e125f2d
- the same plus exactly one terminal LF:
  894 bytes; SHA-256:
  662094d19e691b3733d85c2741647acff16b611ebcc38c862b208e2eeffb74ef

Do not accept an appended PR number, generated source list, co-author trailer,
other text, whitespace rewrite, or altered scope as equivalent. Do not edit or
amend any object after a mismatch.

Exact PR title equals the subject above. Exact PR body, one final LF:
```markdown
## Summary

- adopt the target-only `rw0-c2-single-realization-proof-v1` profile for the first bounded RW0-E proof
- require independent non-reissuable enrollment and continuous original process/storage custody, with no productive resumption after custody loss under this profile
- preserve Coordinator ownership of progression, acceptance, exact replay, and whole-family recovery
- keep repeatable RW0-D offline engineering independent of live enrollment and a full continuity custodian
- clarify program-independent admission recording and the distinction between administrative SQLite restore and live-proof continuity

## Validation

Validated exact staged blobs in a remote-free local clone, serially:

- new proof-posture contract: 16 passed
- nine affected owner and composition contract files: 3,192 passed
- complete repository: 8,758 passed, with 3 unchanged writer-session fork warnings

The prior independent audit accepted the bounded synthetic histories and counterexamples. They do not establish concrete supplier, signature, storage, or fencing conformance.

## Non-implementation

No product source, schema, migration, configuration, supplier, service,
deployment, admission provisioner, guarded decision writer, recovery runtime,
terminal implementation, public API, runtime activation, RW0-D implementation,
RW0-E execution, or Execution Substrate integration is introduced.

Full-custodian and acceptance-focused checkpoint protocols remain unselected
successor options, not hidden prerequisites for this proof profile.

Audit:
`RW0_C2_SINGLE_REALIZATION_PROOF_POSTURE_CONTRACT_ACCEPTED_READY_FOR_COMMIT_GATE`
```
PR body with final LF: 1,630 bytes; SHA-256:
 4ea862a33f74da016839fc686ae0582ad7b68a77bb51e12cbf2bf06bc4fb6e93
Only allowed API representation difference: omission of the single final LF:
 1,629 bytes; SHA-256:
 1ce3d32aa3778a45170ac6f769f67ba027013fa47842c4f6b98d4ad258738a55

Verify exact text by readback. Do not edit the PR to normalize a permitted LF
omission. A different title/body or a different PR identity is a preflight block.

## 4. Live cache and local preservation

Before any authorized remote mutation, inventory only the known live cache
under src/ge_nwp_coordinator/__pycache__/ by member path, type, OS mode, size,
nanosecond mtime and file hash. Treat bytecode as opaque bytes, never import it.
The preceding gate reported 37 regular .pyc files plus their directory (38
entries). Reconcile membership, not an invented historical aggregate.

Leave all pre-existing cache and unrelated ignored state untouched. Do not open
env files, credentials, private operator/product databases or security material
for cleanliness checks. Unexpected opening material is a classification and
stop question, not cleanup authority. Require exact member-level equality
immediately before merge, before local ref update, and at closeout.

No test run or live module import is needed. No validation clone or repository
code execution is authorized. Safe standard-library byte/hash/JSON processing
of inspected data may be used outside the live checkout.

## 5. Fresh remote/policy/readiness preflight

After local provenance passes, authenticated read-only access is permitted only
to the configured origin repository and policy metadata directly governing its
trunk/PR. Use existing authentication; do not expose secrets, create tokens,
change credentials, or contact sibling repositories or a supplier.

The publication closeout's 2026-10-14 05:17:44 UTC observations are historical:
mergeable/clean, zero checks/statuses/workflows/reviews/unresolved threads,
combined status pending, no auto-merge or queue. Re-read every material fact.
Do not substitute those old observations for current permission.

Verify:
- repository and PR node identity, number, exact branches and both repositories;
- current remote base equals the exact parent, current topic and PR head equal
  the exact source, one source commit and exactly eight complete file effects;
- complete source tree equals all 244 local source entries and their modes;
- exact PR title/body and source attribution, no conflicting edit;
- PR is OPEN, non-draft and unmerged, with no auto-merge, queued or pending
  asynchronous merge request, stacked-PR requirement, or update-branch request;
- current mergeability is conclusively mergeable/clean for these exact OIDs.

Follow pagination for commits, changed files, check runs, status contexts,
workflow runs, reviews, comments and review threads. A truncated patch preview
or first page is insufficient. A recursive Git-tree response may include
DIRECTORIES as well as files; compare leaf entries to the 244-file source set,
and require truncated=false or resolve the remainder completely.

Read effective organization/repository/branch rules and classic protection for
trunk_dev, the current actor's applicability/bypass posture, allowed merge
methods, required reviews and attribution, code-owner/last-push obligations,
conversation resolution, check/workflow rules, signing, merge queue, and
repository automatic source-branch-deletion configuration. Verify actual
applicability, not just a listed ruleset ID.

Ruleset 18957283 and zero ordinary approvals were reported earlier. They are
not fixed policy claims. Honor the current rules. Read the conditional approval
rule for unattributed changes and source author/committer attribution exactly.
Do not treat an API capability or mergeable=CLEAN as a policy override.

Require ordinary NON-BYPASS squash merge to be permitted and all applicable
reviews/checks/conversations to be satisfied. No unresolved change request or
material unresolved discussion may be ignored. No failing required check,
missing required approval, ambiguity in effective rules, or signing conflict
may be bypassed. Do not dismiss reviews, resolve threads, approve the PR, change
rules, switch actor, enable checks, or manually dispatch/retry workflows.

Empty status contexts with combined state pending are not a CI pass. If fresh
rules require no check and all inventories are actually empty, report that
fact rather than demanding a fictitious check. If a real pending/failing gate
or ambiguous policy remains, stop. New ordinary reviews/checks may be evaluated
on their actual merits; zero counts are historical, not immutable requirements.

Require automatic source-branch deletion to be disabled. The topic must remain
at the exact source throughout this gate. If preservation would require a
settings change, block without changing settings. Capture the complete remote
head inventory before merge for post-merge non-trunk preservation checks.

A transient mergeability calculation may receive bounded read-only refreshes.
Do not poll indefinitely, enable automation, or turn a blocked gate into future
background work. Stop with observed readiness if it cannot be established.

## 6. Final pre-merge barrier and exact request

Immediately before the only merge request, recheck local source HEAD/tree,
clean index/worktree, eight endpoints, unaffected files and cache, plus remote
base, topic, PR head/state/text, actor attribution, readiness and effective
policy. Record the observation time in UTC.

Base must still be d070bf05d2e68472e18b1b077259e67864923e8f.
Head must still be bd997da10df551afadd7854ffecf92018ade0fb6.
No intervening source/base/PR-policy drift may be silently adopted.

Use only the ordinary synchronous REST merge endpoint:
 PUT /repos/evo-agi/Governed-Execution-Coordinator/pulls/12/merge

Use existing authenticated tooling with explicit JSON input and recorded API
version/headers. Ensure no client write retry is configured. Do not use an
admin option, merge queue, async endpoint, update-branch call, or CLI operation
that also checks out/updates/deletes branches. A required queue/async/stacked
route is a block, not permission to substitute another merge mechanism.

Canonical request has exactly four string-valued fields:
 commit_message: the exact 847-byte body above, no final LF
 commit_title: the exact 44-byte subject above
 merge_method: squash
 sha: bd997da10df551afadd7854ffecf92018ade0fb6

Serialization: recursively sorted object keys, compact separators comma/colon,
ensure_ascii=false, allow_nan=false, UTF-8, and ONE terminal LF on JSON bytes.
The JSON terminal LF is not a newline inside commit_message.

Exact request bytes: 1,019.
SHA-256: b5029cb21be7a680a58c9c301a8d110f5a9fc308fb3d35558653685ddd420369

Reconstruct independently twice before sending and require equality. A private
mode-0600 external request file is permitted but not required.

The sha field guards the PR HEAD, NOT the base. This request has no atomic
expected-base field. Do not claim atomic protection against concurrent base
movement. Immediate base readback reduces the window; mandatory post-merge
parent/tree verification detects an unexpected result. Do not create a lock
service or alter branch rules to try to remove that limit.

Send at most ONE merge write. Preserve response status, body, returned merged
flag and SHA, and any error before interpreting the outcome.

## 7. Resolve merge outcome and verify remotely before any fetch

Do not use the pre-merge test merge_commit_sha as the expected squash commit.
The returned squash SHA is discovered, not known in advance.

After a successful response, or after a response whose outcome is ambiguous,
perform read-only authoritative readback of PR #12, base/topic refs, and the
resulting commit/tree. An ambiguous response never authorizes another write.

Before allowing the fetch, require:
- PR #12 CLOSED and merged with merged_at/merger recorded, exact preserved
  base/head identities, no queue or auto-merge entry;
- post-merge PR merge-commit SHA equals the returned/intended squash;
- current remote trunk_dev equals that exact squash, not a descendant;
- topic remains bd997da10df551afadd7854ffecf92018ade0fb6;
- resulting squash has ONE parent, exactly
  d070bf05d2e68472e18b1b077259e67864923e8f;
- tree exactly cd81f7cca8b64cb9ff221537257e70e2c5a655a3;
- exactly the table's six M and two A effects, eight expected source blob OIDs,
  244 exact leaf entries, and all 236 unaffected parent entries preserved;
- exact title/body in one of the TWO allowed full-message LF forms;
- no generated PR/co-author text or other semantic message change;
- source identity and local index/worktree/cache are still unchanged.

Read GitHub signature-verification status and reason for source and squash;
distinguish a signature header from verified cryptographic evidence. If the
squash is signed, require GitHub's verification to be valid and not merely a
header. If fresh policy requires signing, it must be satisfied. An invalid
signature or unresolved required signature result blocks local alignment.
Do not require a new local signing key, change signing configuration, or run a
repo script. Report an unsigned result accurately if current policy permits it;
never call it signed/verified.

Compare final non-trunk remote heads to the opening inventory. Do not recreate
or move any unexpectedly changed branch. Source deletion or unrelated drift
must be reported; no corrective push is authorized.

If remote merge occurred with an unexpected parent, tree, message, head, policy
result, or concurrently advanced trunk: preserve remote effects, DO NOT fetch
or realign under this gate, and return the appropriate incomplete status with
actual coordinates. No revert or remote rollback is authorized.

## 8. One narrow fetch and raw-object verification

Only after all section 7 checks pass, recheck local source/cleanliness/cache and
remote trunk/topic once more. Then perform exactly this narrow fetch, once:

```sh
git -c gc.auto=0 -c maintenance.auto=false fetch   --no-auto-maintenance --no-tags --no-recurse-submodules   origin refs/heads/trunk_dev:refs/remotes/origin/trunk_dev
```

Command-scoped suppression of automatic maintenance prevents unrelated local
maintenance effects; it changes no stored configuration. No fetch --all,
pruning, forced refspec, topic/tag fetch, submodule recursion, or second fetch.
If installed Git cannot support this narrow invocation, stop rather than
install/update Git or broaden the operation.

Verify origin/trunk_dev equals the exact verified squash. Read the raw fetched
commit and recheck its sole parent, tree, message bytes and headers. Reproduce
all eight blob receipts, all 244 tree entries, source/squash tree equality, and
unaffected parent equality from the local fetched objects.

A GitHub API message presentation is not a substitute for this raw fetched
commit check. The raw squash message may differ only by the allowed single
terminal LF. Signature bytes are separate headers; report remote verification
and local header observation distinctly.

Fetch may update ordinary object storage, FETCH_HEAD and the one remote-tracking
ref/reflog. It must not move local trunk_dev or rewrite working files. If the
fetched tracking ref is not the exact verified squash, stop with remote-merged/
local-realignment-incomplete disposition. Do not adopt a newer commit, fetch
again, reset, or force the tracking ref back.

## 9. One expected-old-object local realignment

Immediately before updating the local branch require:
- HEAD symbolically points to the direct refs/heads/trunk_dev;
- local trunk_dev still equals bd997da10df551afadd7854ffecf92018ade0fb6;
- source and fetched squash have the identical required tree;
- index and working files still exactly equal that tree;
- origin/trunk_dev and freshly observed remote trunk equal the exact squash;
- topic still equals the source, PR still reports this merge;
- one worktree, no active operation/lock, unchanged cache.

Then run ONCE, substituting only the independently verified squash SHA:

```sh
git update-ref -m "realign trunk_dev after PR #12 squash merge"   refs/heads/trunk_dev   <verified_squash_sha>   bd997da10df551afadd7854ffecf92018ade0fb6
```

The expected-old argument is mandatory. Do not use reset, checkout, read-tree,
cherry-pick, rebase, a new source commit, or a worktree rewrite. Tree equality
is a precondition, not something to achieve by changing files.

Verify the resulting reflog old/new transition and exact reason text. Reobserve
local HEAD/trunk/upstream, status, tree, endpoints, source preservation, topic,
remote trunk, PR merge identity, and cache. Require:
 local HEAD = local trunk_dev = origin/trunk_dev = remote trunk_dev = squash;
 source/squash/index/worktree tree = cd81f7cca8b64cb9ff221537257e70e2c5a655a3;
 divergence 0 ahead / 0 behind;
 clean staged/unstaged/untracked/unmerged posture;
 one worktree and no active operation/unexpected lock;
 unchanged eight endpoints and 236 unaffected paths;
 unchanged live cache;
 preserved remote topic at the original source.

Do not delete the source branch or source commit. If another actor moves state
between checks, report it and stop without corrective writes.

## 10. Stop rules and partial outcomes

Before the merge write:
- baseline, source/tree/blob/message/index/working-file identity mismatch:
  AUDIT_PROVENANCE_MISMATCH.
- policy, readiness, actor, PR-text, branch-deletion setting, unavailable read,
  pre-existing merge, unsupported ordinary route, or other preflight block:
  RW0_C2_SINGLE_REALIZATION_PROOF_POSTURE_CONTRACT_MERGE_GATE_BLOCKED.
No local or remote mutation is permitted on those paths beyond this gate's own
external temporary files. Do not repair the candidate or edit policy/PR state.

After sending the one merge request:
- known refusal and readback conclusively unmerged: MERGE_GATE_BLOCKED; no retry;
- outcome not conclusively known after bounded read-only reconciliation:
  RW0_C2_SINGLE_REALIZATION_PROOF_POSTURE_CONTRACT_MERGE_OUTCOME_UNRESOLVED;
  no fetch, realignment, retry, close/reopen or other corrective write;
- exact desired merge conclusively occurred despite response loss: verify all
  remaining conditions, then continue only with the not-yet-performed authorized
  fetch and ref update;
- merge occurred but any verification/fetch/local realignment/cleanup/final
  synchronization condition remains incomplete:
  RW0_C2_SINGLE_REALIZATION_PROOF_POSTURE_CONTRACT_MERGED_LOCAL_REALIGNMENT_INCOMPLETE.
State the actual failed phase. This token may include a completed local update
with a later closing-state conflict; do not conceal that distinction.

If fetch or update-ref reports an error or ambiguous response, inspect refs and
objects read-only to determine actual effects. Do not repeat either command.
If the exact intended effect already occurred, verify it and continue only to
remaining authorized checks. A mismatched local old OID must stop realignment;
never remove the expected-old guard.

Never roll back a completed remote merge or drop the source commit to make the
report look clean. Preserve all real partial effects and name the next bounded
reconciliation point; do not issue a new mutation prompt from this gate.

## 11. Cleanup, reporting and continuation meaning

A private mode-0700 temporary root outside the checkout may hold only this
gate's request/readback/hash processing files, with sensitive individual files
mode 0600. No global umask change is needed and no tests run here. Create no
validation clone, worktree, operator state, or credential file. Do not reuse
historical temporary paths or traverse untrusted symlinks for cleanup.

Remove only this gate's positively identified external files after extracting
inline evidence. If cleanup is denied, do not evade platform restrictions or
broaden the target. Use another permitted guarded method on those same owned
files, or report residue. Never touch live cache or unrelated material.

Return a substantive inline report containing:
- verdict, visible settings, actual inspection scope and commands;
- opening local/source/parent/upstream and fresh remote/PR coordinates;
- exact eight-file table with parent/source/squash identities and full-tree proof;
- source raw message, PR-body form, attribution and signature observations;
- effective policy, required evidence, review/check/discussion inventories and
  observation times, including why the normal non-bypass squash route was ready;
- exact canonical request length/hash and count of merge writes;
- response and independently verified PR merge identity, time, merger, remote
  parent/tree/message/signature result;
- actual fetch and expected-old-object update commands, refs and reflog result;
- closing local/remote synchronization, preserved topic/source, file/cache
  equality, and cleanup;
- all corrected read-only inspection errors, unknowns, skipped checks, and actual
  partial effects; do not deny expected Git/network effects or temporary files;
- continuation capsule at most 800 words with exact new squash/tree/parent,
  source/topic/PR, target-only capability and next separately authorized boundary.

Success requires all sections above and ends with:
 RW0_C2_SINGLE_REALIZATION_PROOF_POSTURE_CONTRACT_PR_SQUASH_MERGED_AND_LOCAL_REALIGNED

This merge adopts only the target-only rw0-c2-single-realization-proof-v1 support
profile and bounded synthetic verifier. It does not enroll a lineage, consume
acceptance, qualify a custody supplier, implement a provisioner, guarded decision
writer, migration 0005, terminal owner, runtime recovery, public API, RW0-D, or
RW0-E. Full-custodian and acceptance-focused checkpoint architectures remain
unselected successors. General restart-readback rows must not become productive
restart permission under this profile's original-custody rule.

State actual non-actions: no candidate edit/staging/new source commit/amend;
no test/collection/probe/migration/repository-script or live import; no source,
schema, config, product DB or cache change; no supplier/credential change,
service/installation/host experiment, enrollment, launch, fencing or live proof;
no sibling/subagent; no rebase/reset/checkout/local squash/cherry-pick;
no push or source-branch deletion; no async/auto/queue/bypass merge, tag, release,
deployment or manual CI; no delivered evidence artifact. The one ordinary
remote merge, narrow fetch, guarded ref update and their normal bookkeeping
must be reported as performed when they actually occur.

Public command-contract references (not evidence of private repository state):
- https://docs.github.com/en/rest/pulls/pulls#merge-a-pull-request
  The ordinary endpoint documents commit_title, commit_message, head sha,
  merge_method, and its merge response. The head check is not a base check.
- https://git-scm.com/docs/git-update-ref
  The third object argument checks the ref's expected old object before update.
Do not contact external docs or install tooling from them merely to satisfy
this task; the configured installed CLI/API must support the bounded operation.
