# Governed Execution Coordinator — Admission Provisioning and Continuity Operating-Model Reconnaissance

## Objective and permission

Perform one focused, repository-first, READ-ONLY engineering decision pass for
the next RW0-C2 admission-provisioning and continuity/currentness contracts.

The accepted private-value/graph-profile tranche is merged through PR #11.
Do not restart that reconnaissance, reopen its parser audit, or implement its
values. Determine the operating model that can supply its admitted-lineage,
fresh-continuity, sole-active-authority, and safe provisioning inputs truthfully.

Return ONE substantive INLINE report, grounded in exact repo-relative
path:line evidence, followed by a continuation capsule of at most 800 words.
Create no report file, JSON freeze manifest, bundle, attachment, or code patch.
Do not issue an implementation prompt.

Use the highest reasoning setting actually exposed. Record visible model,
reasoning setting, and permission posture, or "not visible". Do not seek account,
computer, or extra tooling access merely to discover hidden settings. A broad
filesystem permission does not widen the read-only authority of this task.

## 1. Exact repository baseline

Work only in:
`/Users/ds/Repositories/Governed Execution Coordinator`

Expected opening state:
- branch: `trunk_dev`
- HEAD: `d070bf05d2e68472e18b1b077259e67864923e8f`
- tree: `d662b6702e178218c12930259eda5fb690c2fe25`
- sole parent: `3d99e448bfe577b5a5878dd32b7e01b61322e7df`
- subject: `docs: freeze RW0-C2 private value and graph profiles`
- upstream: `origin/trunk_dev`
- local tracking divergence: 0 ahead / 0 behind
- one worktree; clean index/worktree/untracked/unmerged state
- no active Git operation or unexpected lock.

Read AGENTS.md first. Verify opening and closing committed coordinates and
cleanliness using read-only inspection with optional-lock suppression where
appropriate. Do not normalize state to match. Stop on baseline drift, unexpected
dirty files, or unavailable primary contracts.

Do not fetch or contact the remote. The tracking ref is locally observed; do not
call it freshly verified remote truth. Git owns current commit/tree/blob facts.
The merged repository owns current contracts. Historical reports, chat decisions,
test fixtures, and earlier JSONL packages do not override it.

No attachment is needed. Do not require snapshots, V11, old audit reports, merge
receipts, or prior reconnaissance output as local inputs.

## 2. Exact read-only boundary

Permitted: local Git object/status reads, safe text inspection, in-memory
standard-library JSON/AST parsing of source AS DATA, and ordinary filesystem
metadata inspection of in-scope repository files.

Prohibited:
- edits, file creation/deletion/renaming, formatting, cleanup, staging, commits,
  pushes, branches, PR actions, fetches, or merges;
- tests or collection, repository script execution, repository imports, bytecode
  generation, migrations, database connections, dependency installation;
- services, workers, Codex/model invocation, network/host contact, credential
  access, sibling repositories, or external provider/tool experiments;
- creating retained temporary artifacts or printing secrets, raw private state,
  credential material, or ignored database/cache contents.

Do not move or inspect bytecode as executable content. Classify existing ignored
artifacts only where needed; leave them alone. Do not inspect live operator or
product state. Static SQL text and schema definitions are in scope.

Parent-only is the default. At most two bounded read-only explorers may be used:
one for authority/continuity, one for provisioning/persistence compatibility.
No nested delegation or audit-agent persona that freezes obsolete P1 scope.
Give each explorer the exact baseline, fixed semantics, exclusions, assigned
paths, and required path:line evidence. No tests/imports by children. The parent
must inspect central evidence, preserve disagreements, and own the synthesis.
Proceed parent-only if the required child posture cannot be ensured.

## 3. Fixed accepted inputs; do not reopen product policy

Treat these as merged ACCEPTED TARGET contracts, not implemented capabilities:

- One immutable scope-admission fact per explicitly standing-policy-admitted
  Coordinator authority lineage; at most one immutable productive direct-local
  acceptance fact across all programs in that scope.
- Independent lineage admission requires an explicit independent standing-policy
  act. Deployment, machine, process, database, program, attempt, grant renewal,
  restore, rollback, clone, passive backup, and relocation do not create a new
  lineage or allowance.
- One active Coordinator authority per lineage. No active-active operation by
  copied databases. Positive continuity is required; ambiguity fails closed.
- Local absence, schema integrity, a lock, a private digest, a model response, or
  a report is not proof of an unclaimed scope or current external authority.
- External standing policy authors admission. A separate future Coordinator
  provisioner records the verified immutable binding. The decision writer may
  not create, admit, repair, renew, or replenish scope.
- Acceptance is written by the future guarded C2 decision transaction, in the
  same atomic decision/version/head/result/receipt family. No mutable
  available/consumed subsystem or separate guard transaction/receipt/classifier.
- The four nonaccept branches create no acceptance fact. Preserve the guard's
  distinction between universal posture and acceptance-only unclaimed proof.
  Unknown claimed status alone is not automatically a universal posture failure.
- Exact replay retains original family and timestamp; one C2 whole-family
  recovery owner classifies committed_exact / definitely_not_committed /
  unresolved. Unresolved is not permission for automatic retry.
- Terminal output remains later and non-mutating. ES routing is separately
  governed and does not replenish direct-local allowance.
- PR #11 fixes the eleven private logical value/profile surfaces, canonical
  command/preassignment rules, lifecycle partitions, observation/result grammar,
  owner assertions, and receipt-profile treatment. Preserve the current v1
  decision/version/head/result/receipt algebra and B1 nonproof compatibility.
- Migrations 0001–0004 and current private runtime families exist. No migration
  0005, scope provisioner, guarded post-execution decision writer, continuity
  service, or recovery runtime was implemented by PR #11.
- The user sets intent, standing risk posture, and major direction, not routine
  per-attempt approvals. Do not select a manual-per-command relay as the target.

Do not assign missing external authority to Bridge, CP, IM, MA, Git, CI, ES, or
chat by convenience. Do not introduce a new enduring repository/service,
distributed consensus system, or single-Mac-only deployment constraint by
default. A proposed external dependency is a proposal, not an existing owner.

## 4. Required primary inspection

Read the governing ownership/status and relevant semantic sections completely:
- AGENTS.md and README.md
- .docs/autonomous-software-development-operating-model.md
- .docs/authority-boundaries.md
- .docs/rw0-c2-bootstrap-acceptance-guard-semantic-contract.md
- .docs/rw0-c2-private-value-versioning.md
- .docs/rw0-c2-durable-progression-decision-semantic-contract.md
- .docs/rw0-c1-durable-evidence.md
- .docs/rw0-remote-worker-contact-phase-entry.md
- .docs/worker-execution-boundary.md
- .docs/software-development-progression-boundary.md
- .docs/writer-session-authority.md
- .docs/sqlite-operations-and-recovery.md
- .docs/sqlite-threat-model.md
- .docs/c2b2-migration-0002.md
- .docs/c2b2-pure-durable-row-values.md
- .docs/c2b2-private-readers.md
- .docs/c2b-durable-development-state.md: relevant current Section 36/38/41/42
  contracts and current RW0-C2 successors. Do not import historical latch SQL
  or old operator-approved architecture as current target.

Inspect the actual source dependencies, not just status prose:
- src/ge_nwp_coordinator/lease.py
- src/ge_nwp_coordinator/sqlite_writer_session.py
- src/ge_nwp_coordinator/sqlite_writer_state.py
- src/ge_nwp_coordinator/state_authority_lock.py
- src/ge_nwp_coordinator/sqlite_mutation_transaction_contracts.py
- src/ge_nwp_coordinator/sqlite_transition_transaction.py
- src/ge_nwp_coordinator/_development_decision_row_values.py
- src/ge_nwp_coordinator/_development_program_row_values.py
- src/ge_nwp_coordinator/_development_program_initialization_contracts.py
- src/ge_nwp_coordinator/_sqlite_development_program_initialization.py
- src/ge_nwp_coordinator/_sqlite_development_readers.py and its contracts
- src/ge_nwp_coordinator/_rw0_c1_mutation_contracts.py
- src/ge_nwp_coordinator/_sqlite_rw0_c1.py and its reader contracts
- src/ge_nwp_coordinator/_rw0_phase_entry_semantic_values.py
- src/ge_nwp_coordinator/sqlite_migration.py
- src/ge_nwp_coordinator/sqlite_migrations/0002_development_program_and_effect_state.sql
- src/ge_nwp_coordinator/sqlite_migrations/0004_rw0_c1_durable_evidence.sql
- relevant package exports, schemas/sqlite/coordinator-state-v1.sql,
  pyproject.toml, .gitignore, and .codex agent guidance.

Inspect, without running, the owning test groups:
- test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.py
- test_rw0_c2_durable_progression_decision_semantic_contract.py
- test_rw0_c2_private_value_versioning_contract.py
- test_c2b3_program_initialization_contract.py
- test_c2b3_program_initialization_recovery.py
- test_c2b3_private_atomic_program_initialization.py
- relevant RW0-C1 persistence/recovery, B2c writer-session, migration, authority,
  composition, and nonimplementation tests.

All test names above are under tests/. Follow exact dependencies revealed by
these files. Report missing/renamed owners; do not silently omit them.

Re-grounding locators, not immutable line-number contracts:
- operating model:81–86: remaining prerequisite contracts;
- guard:29–55, 59–114: admission, continuity, universal/acceptance-only gates;
- private value owner:19–32, 34–50, 522–555: external basis versus private values;
- authority boundaries:134–169: external authorship and unselected trust model;
- writer-session authority:135–183: local fencing is not external authority;
- SQLite operations/recovery:444–479: bounded backup/restore treatment;
- lease.py:328–348: production/default executable authorization fails closed;
- _development_decision_row_values.py:458–499: generic receipt includes program_ref;
- _sqlite_development_program_initialization.py:196–270: bounded receipt-first
  replay and local-family recovery; not lineage-wide unclaimed proof.

## 5. Decision A — admission source, verifier, and provisioner

Select the narrowest truthful owner decomposition. Distinguish:
1. standing-policy act authorship;
2. external authenticity/currentness verification;
3. Coordinator immutable admission recording;
4. later decision acceptance recording;
5. diagnostic/projection outputs.

For each fact, identify author, recorder, custodian, verifier, trust anchor,
lifetime, and effect ceiling. A future interface cannot be labeled "verified"
solely because its input is a well-shaped private value.

Resolve:
- What authorizes first admission and distinguishes an independent lineage from
  a restored/renamed operational copy?
- How is admission verification bootstrapped without requiring an admission row
  that the provisioner has not yet created?
- Can scope recording happen before any development program exists? Recommend
  explicitly. If yes, inspect the program-bound generic receipt algebra; do not
  invent a dummy program or repurpose a v1 result to obtain reuse.
- Does provisioning need a separate command/result/receipt/replay/recovery family
  for admission recording? Distinguish that from the forbidden second GUARD
  acceptance receipt/recovery owner.
- Which existing transaction/session mechanics are reusable unchanged and which
  semantic receipt/result contracts are not?
- What are exact idempotent same-act replay, different-act collision, conflicting
  admission, interrupted recording, and uncertain-commit outcomes?
- Admission permanence is not standing permission forever. Explain revocation,
  key/source change, or expired current verification without rewriting admission
  or resetting the one-shot acceptance status.

Use the existing private admission-act/fact field grammars. Do not append fields
to accepted v1 values silently. Name any required successor contract as an
explicit dependency rather than smuggling it through implementation detail.

## 6. Decision B — positive continuity, sole-active posture, and rollback

This is the central operating-model decision.

Give a concrete causal explanation of how the proposed evidence source learns
what it attests, what it stores, who writes that state, and which failure domain
it survives. "External verifier says current" is not a sufficient architecture.

Construct these two histories:
A. a legitimately admitted preaccept database, with no prior acceptance;
B. acceptance commits, then a preaccept backup replaces the active database.

The local database can be byte-identical in A and B. Identify the exact
independent observation that distinguishes them, its author/custodian, and why
the same rollback/clone cannot reproduce a valid old observation as fresh.

Also cover two copied databases on different machines, each able to acquire its
own local WriterSession lock. Identify what prevents both being admitted as the
one active lineage authority; a local lock or SQLite generation alone is not
that proof.

Select the first supportable posture and explain:
- authenticated source identity and audience/lineage/scope/authority-epoch binding;
- freshness, stale evidence, replay, revocation, and fail-closed unavailability;
- evidence validity between verification and protected operation, including
  concurrent authority handoff and stalled former authorities;
- distinction between current continuity, current sole-active posture, and
  acceptance-only exhaustive unclaimed-scope proof;
- how restarted, restored, relocated, cloned, or backed-up realizations regain
  positive evidence without another allowance;
- which scenarios remain deliberately blocked and the exact condition for safe
  resumption under standing policy;
- which source/custody/deployment choices can be deferred and which are required
  now to make the proposed guarantees meaningful.

Do not assume a remote service is necessary, or that another local file is
sufficient. Identify rollback/copy failure domains explicitly for every proposed
source. Do not select hardware/platform APIs without available evidence.

An external receipt, witness, counter, epoch, or lease must not silently become
a second acceptance owner or a disguised mutable available/consumed latch.
If any proposed mechanism needs external state changes around local acceptance,
show all crash windows and state exactly which facts remain authoritative in
Coordinator. In particular, acceptance followed by a crash before external
acknowledgment cannot reopen the scope. Treat a required authority-model change
as a named seam, not permission to violate the merged immutable architecture.

## 7. Decision C — operational sequence and liveness

Provide ordered traces for:
- first explicit admission and immutable recording;
- ordinary protected command and first acceptance;
- nonaccept command when claimed status alone is unknown but all universal
  posture and ordinary prerequisites are exact;
- exact replay with newly verified current posture and the ORIGINAL command
  digest/family/timestamp;
- uncertain-commit recovery;
- planned relocation/replacement;
- ambiguous restore or clone, including return of the former active process.

For every boundary give the actor, input evidence, check, durable effect if any,
safe returned result, and crash/response-loss consequence. Name the precise
logical linearization points; do not design SQL or network retry loops.

Fresh verification for replay must not rewrite the historical command digest
or require the original historical head to be current. Normal fresh commands
must still honor currentness and head expectations. Preserve no-write,
durable-block, and recovery-unresolved distinctions.

List what automation may do under standing policy, what can only be observed,
and when intent/policy intervention is genuinely required. Do not place the
user in routine authentication, approval, evidence transport, or per-command
recovery. Do not invent automated recovery for an unresolved state.

## 8. Bounded acceptance-evidence matrix

Give a finite matrix, not generated fixtures or another executable interpreter.
For each case state decisive source evidence, expected safe outcome, existing
owner/reason taxonomy, and the missing proof required to proceed:

1. initial admitted lineage with no program or admission row;
2. exact provisioning replay and conflicting act;
3. provisioning commit response lost;
4. acceptance commits, then local process/host fails;
5. restore a preaccept database after acceptance;
6. same database copied to a second machine with a valid local lock;
7. planned handoff with the old authority demonstrably fenced;
8. old authority resumes or a verification response arrives late;
9. witness/verifier unavailable or freshness cannot be established;
10. unknown claimed status with otherwise exact nonaccept prerequisites;
11. exact decision replay with a later mutable program head and fresh posture;
12. partial/orphan acceptance family versus a competing complete winner.

A valid local digest or schema check is never the decisive proof for cases 5–9.
Separate proof fixtures from operating capability. No simulation in this pass
establishes that a real external verifier exists.

## 9. Compatibility and scope decisions

Inspect these seams explicitly:
- generic SQLite restore acceptance versus the later lineage-specific gate:
  preserve the current local administrative contract without calling its
  integrity checklist sufficient for bootstrap continuity;
- private-value prose describing the provisioner as owning "creation and repair":
  distinguish recording/recovery of an exact previously authorized admission
  from forbidden reauthoring, renewal, replacement, or allowance restoration;
  report any normative conflict instead of resolving it by wording alone;
- current fail-closed UnsupportedAuthorizationProvider versus a future admission
  verification interface: no production allow-all shortcut or fake provider;
- program-bound migration-0002 receipt/result grammar versus program-independent
  scope recording;
- adopted private-value profiles versus future admission-operation inputs and
  external proof envelopes;
- existing document/test cross-reference and nonimplementation guards.

Retain migration 0005 as the bounded additive direction where genuinely required,
but do not select tables, indexes, application-generation changes, full SQL,
public APIs, or executable wire protocols in this pass.

Do not force a two-file/eight-file ceiling before inspecting the owning
cross-references. Identify the smallest coherent proposed touched-file set for
the NEXT contract tranche. Owner documents and their causal tests must change
together if a seam actually needs amendment; never work around a guard test.

## 10. Recommendation and next-tranche gate

Select one operating-model recommendation, with rejected alternatives and
consequences. Do not merely enumerate options or defer ordinary engineering
choices to the user.

Determine whether the next mutation-bearing tranche should combine or split:
- the admission/continuity source-verification handoff contract;
- the provisioner command/recording/replay/recovery contract;
- later bounded-hybrid migration representation;
- later guarded decision transaction integration.

Recommend the narrowest truthful order. Do not start any of those tranches here.

For the next contract tranche provide:
- proposed owner document(s) and exact purpose;
- proposed tests and specific finite acceptance evidence;
- exact existing paths needing cross-reference/status changes;
- current values/mechanics preserved unchanged;
- external dependencies and assumed threat limits;
- exact repository-grounded validation commands for the later authorized work;
- stopping conditions and later source/physical implementation gates.

Keep verification proportional: direct causal tests for admission, freshness,
rollback ambiguity, fencing, identity binding, replay, and non-renewal. Do not
grow another generic prose-language verifier, broad source manifest, exhaustive
token-pointer suite, or all-history mutation package.

## 11. Report and disposition

Return:
1. Verdict, visible settings, exact opening/closing coordinates, inspection
   boundary, and actual commands used.
2. Current implementation versus accepted target versus proposed design.
3. A compact fact/authority/evidence ownership matrix.
4. Selected admission/continuity model, causal traces, and rejected alternatives.
5. The bounded case matrix, unresolved dependencies, and compatibility findings.
6. Exact next contract tranche, touched surfaces, later validation, stop rules.
7. Continuation capsule (at most 800 words), plus actual non-actions.

Every material repository claim needs path:line evidence. Label inference,
report-only overlays, and unselected external mechanisms explicitly. Use
qualitative confidence, separating provenance, semantic reasoning, and untested
implementation feasibility.

End with exactly one:
`RW0_C2_ADMISSION_CONTINUITY_OPERATING_MODEL_READY_FOR_CONTRACT`
`RW0_C2_ADMISSION_CONTINUITY_PRODUCT_POLICY_DECISION_REQUIRED`
`RW0_C2_ADMISSION_CONTINUITY_OPERATING_MODEL_BLOCKED`

READY means one grounded, causally coherent recommendation and a bounded next
contract plan, not independent acceptance or permission to implement. A proposed
external source may be unimplemented, but its required authority, observations,
custody, failure assumptions, handoffs, and acceptance evidence must be explicit.
An opaque oracle or self-authored positive flag is not READY.

Use PRODUCT_POLICY_DECISION_REQUIRED only for one real unresolved fork that
changes product meaning or trust assumptions beyond the accepted intent.
Recommend a default and its consequence; do not ask the user to choose field
names, tables, migration mechanics, selectors, or test organization.

BLOCKED applies to baseline/input failure or an unresolvable contradiction
preventing a truthful bounded recommendation. Preserve useful partial findings.

State actual non-actions: no repository mutation; no tests/collection/imports;
no databases/migrations/services/dependencies; no remote or host contact; no
credential access; no sibling inspection; no runtime/worker/ES/Bridge invocation;
no staging/commit/push/PR/merge; no generated or delivered external artifacts;
no implementation or implementation prompt. The inline report is evidence and
a proposed decision, never hidden Coordinator authority.
