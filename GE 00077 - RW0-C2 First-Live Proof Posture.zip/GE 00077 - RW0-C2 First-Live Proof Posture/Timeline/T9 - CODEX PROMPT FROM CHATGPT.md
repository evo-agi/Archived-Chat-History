# Governed Execution Coordinator — First-Live Proof Posture: Commit and PR Publication Gate

## Objective, acceptance evidence, and effect ceiling

Perform one parent-only publication gate for the exact independently accepted
eight-path target-documentation and bounded-test candidate below.

Independent audit verdict:
RW0_C2_SINGLE_REALIZATION_PROOF_POSTURE_CONTRACT_ACCEPTED_READY_FOR_COMMIT_GATE

The audit reproduced all eight endpoints and the exact 39,667-byte patch,
closed its in-scope findings, and independently ran 16 new tests, 3,192 affected
owner/composition tests, and the complete 8,758-test repository suite with three
existing writer-session warnings. These are prior acceptance and validation
evidence, not freshly verified live Git or GitHub facts.

This prompt authorizes, in order:
1. Read-only local provenance and current configured-origin/PR/policy preflight.
2. Stage only the eight accepted paths.
3. Validate exact index-derived candidate bytes in a remote-free external clone.
4. Create at most one local commit on the already checked-out trunk_dev.
5. Push that exact commit once to the named remote topic, using a plain
   non-force refspec. Never push remote trunk_dev.
6. Create and verify at most one non-draft PR into trunk_dev.
7. Remove only gate-created disposable external material.

No candidate repair, wording update, reformatting, new contract, source change,
migration, service, supplier selection, credential/platform experiment, runtime
activation, deployment, or live proof is authorized. Do not rerun hostile-copy
matrices, expand the prose parser, or reopen the selected support model.

No merge, auto-merge, queue request, tag, release, branch deletion, amendment,
rebase, cherry-pick, live checkout/switch/reset, force push, alternate topic,
manual CI dispatch, sibling access, or subagent invocation. Ordinary permitted
repository checks triggered by publication are observations, not manual workflow
or deployment authorization. If publication inherently requires a broader
prohibited effect, stop rather than disable safeguards.

Use the highest reasoning setting exposed by the interface. Record visible
model, reasoning setting, and permissions, or "not visible". Do not seek extra
account/computer access to identify hidden settings. Broad host permissions do
not widen this gate.

Return ONE inline closeout and a continuation capsule of at most 800 words.
Create no delivered report, manifest, receipt, patch, snapshot, or package.
This complete prompt is sufficient; request no historical audit attachment.
Disposable private files may be used only outside the live checkout and removed
at closeout. Do not print tokens, keys, environment secrets, or ignored private
operator/product data.

## 1. Exact repository and opening state

Repository:
 /Users/ds/Repositories/Governed Execution Coordinator

Required opening:
 branch: trunk_dev
 HEAD: d070bf05d2e68472e18b1b077259e67864923e8f
 tree: d662b6702e178218c12930259eda5fb690c2fe25
 sole parent: 3d99e448bfe577b5a5878dd32b7e01b61322e7df
 subject: docs: freeze RW0-C2 private value and graph profiles
 upstream: origin/trunk_dev
 locally observed origin/trunk_dev: d070bf05d2e68472e18b1b077259e67864923e8f
 locally observed divergence: 0 ahead / 0 behind
 exactly one live worktree
 index exactly matches HEAD; no staged changes or unmerged entries
 six tracked modifications and two untracked files, exactly the table below
 no active merge/rebase/cherry-pick/revert/bisect/sequencer or unexpected lock.

Read AGENTS.md and the relevant repository guidance first. Read the new
first-live proof-posture owner and the changed status/ownership sections of the
other five candidate documents. Inspect the final phase-entry test diff to know
what is being published, not to restart its already accepted semantic audit.
Inspect pyproject.toml and configured local hook/signing metadata safely.

Use non-mutating Git inspection with optional-lock suppression where appropriate.
Do not refresh, normalize, clean, fetch, or change configuration to meet the
opening coordinates. Hooks outside the authorized local validation/publication
effects are not permission to widen this task; do not bypass a required hook.
No global author, signing, hook, remote, or credential configuration changes.

Git owns objects and refs; owning repository documents define current and
accepted-target semantics; source/migrations define current implementation.
Reports and hashes are evidence, not execution or acceptance authority.

The accepted change is a first-RW0-E support profile, not an enduring single-host
restriction. Enrollment is not acceptance; local or managed-source posture is
not a C2 progression decision. RW0-D remains offline engineering, not implemented
by these docs. Concrete supplier conformance and all relevant runtime/live-proof
gates remain future.

## 2. Exact accepted eight-path candidate

Before staging require exactly these statuses and endpoints. All eight working
files must be regular, nonsymlink mode 0644 and strict UTF-8, with one final LF,
no BOM/CR, and no trailing whitespace. Existing baseline entries are Git 100644.
New paths are absent from HEAD and the opening index; they do not have index
entries until staging.

| Opening status | Repository-relative path | Bytes | SHA-256 | HEAD blob OID |
|---|---|---:|---|---|
| `M` | `.docs/autonomous-software-development-operating-model.md` | 39,079 | `cba69a4e88eeb34bb0f25d3ac8f2ca8774b471fd6dc70a6af1211b3d661b963f` | `e94f9209399d9d957683b6bdeccc5faf350ca1c7` |
| `M` | `.docs/rw0-c2-bootstrap-acceptance-guard-semantic-contract.md` | 26,007 | `e91b82190ccb4969ff670a365b66419e7c5ac945ca328f3c832c5db1e5eb0d09` | `d1dd3f29a85a4c2ed30153f3da241e8349dbe9fb` |
| `??` | `.docs/rw0-c2-first-live-proof-posture.md` | 15,741 | `0064fd833337dee2503da1296525e32e4e76a799c803a86122434b86919f6541` | absent |
| `M` | `.docs/rw0-c2-private-value-versioning.md` | 207,512 | `8d0477a2d1ba0cc6f94bacb59927932123582231ebecf345355492e3e6817a37` | `57f7f889774e8cf24ed3ef3be490a4355b4cf0bf` |
| `M` | `.docs/rw0-remote-worker-contact-phase-entry.md` | 58,068 | `fc74ac0d75bf3e762fdd25775bbf91befa533e53b3b90d5cc092457516fab7b5` | `f4c6540dfe998aa9e5493785882c4356904a55a9` |
| `M` | `.docs/sqlite-operations-and-recovery.md` | 38,657 | `86c2cd7b1f780d153c2237d5d47c52b7724630b4cc1d2adc4ad1e4c7a9a701a4` | `676fb5bfa96d8f6a2901e8bb2a7fcbc725507a57` |
| `??` | `tests/test_rw0_c2_first_live_proof_posture_contract.py` | 12,877 | `8568aecff3c499db9acbffa1933b3b79770474e426bad60a22127c1d69f03e39` | absent |
| `M` | `tests/test_rw0_remote_contact_phase_entry_contract.py` | 173,945 | `53da2ec508272a886e3b7b793bd564f0bf218344d6ce917b5ceaa6ac2ab6ed70` | `d6ee81446fcf9dd389f1ef0939572d9a58970082` |

Independently read the six baseline blobs from HEAD. Compare the full index to
HEAD, and every noncandidate tracked path by actual bytes/type and Git-relevant
mode. No deletion, rename, executable-bit change, symlink, submodule, extra
tracked effect, or extra untracked file is permitted.

There are 242 baseline tracked paths, six modified tracked candidates, 236
unaffected tracked paths, and two candidate additions. Derive the exact path
sets, not just their counts. The prospective complete tree therefore has 244
regular tracked entries, subject to exact set verification.

One pre-existing noncandidate test was observed as OS mode 0600 with nonexecuting
Git mode 100644. Do not mistake that for Git mode drift or normalize it to 0644.
The exact 0644 requirement applies to the eight candidate working files only.
All unaffected content and Git-relevant executable bits must match HEAD.

Preserve source, schemas, migrations, configs, scripts, AGENTS.md, README.md,
existing private-value parser/tests, and all other tests. Migration resources
and catalog remain exactly 0001-0004; migration 0005 is absent. Check definitions
as data only; do not open live state databases.

## 3. Reproduce the audited opening patch exactly

Run from the live repository root before staging. Concatenate exact stdout
from these THREE commands in this order, with NO separators:

```sh
git diff --binary -- .docs/autonomous-software-development-operating-model.md .docs/rw0-c2-bootstrap-acceptance-guard-semantic-contract.md .docs/rw0-c2-private-value-versioning.md .docs/rw0-remote-worker-contact-phase-entry.md .docs/sqlite-operations-and-recovery.md tests/test_rw0_remote_contact_phase_entry_contract.py
git diff --no-index --binary -- /dev/null .docs/rw0-c2-first-live-proof-posture.md
git diff --no-index --binary -- /dev/null tests/test_rw0_c2_first_live_proof_posture_contract.py
```

The first is one GROUPED tracked-file diff, not sorted per-file concatenation.
Its baseline is the unchanged index, which must equal HEAD.
No-index exit 1 means differences found, not failure.

Expected component lengths: 10,033 + 16,200 + 13,434.
Expected complete length: 39,667 bytes.
Expected SHA-256:
d7b2c9442645b83c76fbbe02e066300c5a368eb05a5e5e8ba36f291bfde33ffc

Reconstruct twice from independent fresh reads and require equality. Do not run
a configured external diff helper. Inspect possible rendering/configuration
causes read-only if needed. An unresolved endpoint or aggregate mismatch is
AUDIT_PROVENANCE_MISMATCH; no repair or silent acceptance is allowed.

No extra canonical freeze-manifest prerequisite is introduced. The exact
endpoints, baseline, and patch above bind the audited opening candidate.

After staging this unstaged recipe is no longer applicable. Use staged
tree/blob identity and the verified opening endpoints. Do not treat an empty
worktree diff after staging as a lost candidate.

## 4. Live cache and ignored-state preservation

Safely inventory the existing src/ge_nwp_coordinator/__pycache__/ members as
metadata and bytes for hashing only, without import or execution.

The audit observed 37 regular .pyc files plus their directory: 38 entries.
Record paths, types, modes, sizes, nanosecond mtimes, and file hashes. Reconcile
files versus directory count, not an unspecified historical aggregate.

Require exact member-level equality throughout and at closeout. Do not move,
delete, regenerate, or clean live cache. Never inspect unrelated sensitive
ignored files or operator databases to establish this invariant.

Unexpected opening material must be classified, not removed automatically.
Any task-created live cache or other live-file change is a stop and must be
reported, not hidden through cleanup.

## 5. Current remote and publication-policy preflight BEFORE staging

After local provenance passes, authenticated read-only contact is permitted
only with the configured GitHub origin:
 evo-agi/Governed-Execution-Coordinator

Verify configured remote identity. Use the existing authenticated account;
record its safe login and attribution, not credentials. Do not switch accounts
or alter access/policy to get a successful publication.

Required remote base:
 refs/heads/trunk_dev -> d070bf05d2e68472e18b1b077259e67864923e8f

Selected topic:
 refs/heads/codex/rw0-c2-first-live-proof-posture-v1

Require that topic to be absent and no existing PR for that head, including a
closed or merged prior use. Follow pagination; do not guess the next PR number.
An existing branch/PR before this gate is a conflict, not an idempotent write
owned by this gate. Stop and report it; do not overwrite, close, delete, reuse,
or select an alternate topic.

Read effective repository/organization/branch rules relevant to this base and
topic, signing and attribution requirements, PR routing, and ordinary push/PR
automation. Record current policy, not earlier ruleset assumptions.
Do not assume earlier approval counts, squash policy, or actor attribution
remain current.

Publication must honor the ordinary non-bypass route. Identify requirements
for making this topic commit and opening the PR. Merge-only pending reviews or
checks do not themselves prevent opening an ordinary PR; report them and leave
merge to its later gate. An unsatisfied publication/signing/permission rule,
unknown target identity, material base drift, or broader prohibited required
effect blocks before staging.

Do not fetch. Use remote read-only observations; local tracking equality alone
is not remote verification. Do not treat empty check inventories as CI success.

## 6. Stage exactly the accepted bytes

Recheck local HEAD/index, all eight endpoints, unaffected paths, live cache,
remote base, and topic/PR absence immediately before staging.

Execute only this literal path-scoped add, with no -A or directory/wildcard:

```sh
git add -- \
  .docs/autonomous-software-development-operating-model.md \
  .docs/rw0-c2-bootstrap-acceptance-guard-semantic-contract.md \
  .docs/rw0-c2-first-live-proof-posture.md \
  .docs/rw0-c2-private-value-versioning.md \
  .docs/rw0-remote-worker-contact-phase-entry.md \
  .docs/sqlite-operations-and-recovery.md \
  tests/test_rw0_c2_first_live_proof_posture_contract.py \
  tests/test_rw0_remote_contact_phase_entry_contract.py
```

Require:
- exactly eight staged path effects relative to opening HEAD: six M and two A;
- stage 0 only; all eight staged entries mode 100644;
- each staged blob's exact bytes, size, and SHA-256 match the accepted table;
- each live working file matches its staged blob;
- every unaffected index tree entry matches HEAD;
- no unstaged tracked difference, additional untracked file, or unmerged entry.

Use git write-tree to record the exact staged tree OID. Normal Git index/object
bookkeeping for staging/write-tree is authorized. Do not invent the candidate
tree or new blob IDs in advance.

Record the eight staged OIDs and staged tree. Verify them again after validation
and before committing. Do not stage or alter any other path.

## 7. Exact index-derived external validation

Create one independently named private mode-0700 root OUTSIDE the live repo,
for example under the system temporary directory. All gate scripts, logs,
messages, clones and basetemps belong under it. Sensitive temporary request/
message material must be mode 0600. Do not use or replace unrelated paths.

Build a disposable local-only clone of exact opening HEAD, with no hardlinks
or configured remote. Clone construction and detached checkout are allowed only
in that external clone, not in the live checkout. Remove the clone's origin.

Populate the eight overlaid files exclusively from the verified live INDEX blob
OIDs. Do not copy working-tree bytes as the authoritative candidate input.
Materialize bytes safely with exact regular type/mode. Verify all 244 resulting
candidate files equal the staged tree by Git-relevant modes and computed blob
IDs; the six baseline modifications and two additions in the clone are expected
overlay changes, not a new live candidate.

Do not import repository modules from the live checkout. Use installed Python/
pytest only; no dependency installation, live databases, or supplier/network
experiments. Existing tests may exercise code and migrations in disposable
external fixture databases. That is not live product migration or runtime
activation.

### Exact serial commands

From the external clone, create basetemp parents before execution. Use a shell
runner equivalent to the following, stopping on every nonzero command:

```sh
set -euo pipefail
mkdir -p "$GATE_ROOT/basetemps"

run_group() {
  local label="$1"
  shift
  PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=.:src \
    python3 -m pytest -q -p no:cacheprovider \
    --basetemp="$GATE_ROOT/basetemps/${label}-collect" \
    --collect-only "$@"
  PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=.:src \
    python3 -m pytest -q -p no:cacheprovider \
    --basetemp="$GATE_ROOT/basetemps/${label}-run" \
    "$@"
}

run_group proof_posture \
  tests/test_rw0_c2_first_live_proof_posture_contract.py

run_group affected_contracts \
  tests/test_rw0_c2_bootstrap_acceptance_guard_semantic_contract.py \
  tests/test_rw0_c2_durable_progression_decision_semantic_contract.py \
  tests/test_rw0_c2_private_value_versioning_contract.py \
  tests/test_rw0_remote_contact_phase_entry_contract.py \
  tests/test_architecture_contracts.py \
  tests/test_autonomous_software_development_operating_model.py \
  tests/test_c2b0_durable_state_contract.py \
  tests/test_sqlite_backend_b0_contract.py \
  tests/test_b2a_writer_session_contract.py

run_group full
```

GATE_ROOT must be the actual root created by this gate, not a guessed historical
path. No concurrent groups, background pytest, xdist, overlapping collect/run,
or old test processes still running against shared state.

Expected:
 A: 16 unique collected nodes; 16 passed.
 B: 3,192 unique collected nodes; 3,192 passed.
 C: 8,758 unique collected nodes across 116 test modules; 8,758 passed.
 A and B disjoint; each a subset of C.
 C has exactly the three existing Python 3.13 multithreaded-fork warnings below.

Existing warning cases in tests/test_sqlite_b2c_writer_session.py:
- test_operation_guard_close_waits_and_retains_authority_until_exit
  (stdlib multiprocessing/popen_fork.py:67 in the reported environment)
- test_fork_child_operation_with_inherited_locked_session_sync_does_not_hang
  (reported test line 1442)
- test_fork_child_finalizer_with_inherited_locked_session_sync_does_not_hang_or_prolong_lock
  (reported test line 1554)

Inspect actual collected node IDs and structured warning records, not word
matches for "warning" in test names. Use the already available Python 3.13
environment corresponding to the audit where available. Report actual Python
version. Do not change dependencies/interpreter installation, suppress warnings,
edit expectations, or create tests to match counts. An environment-induced
difference requires a supported explanation, not invented equivalence; stop
before commit on any unresolved validation discrepancy.

The old implementation's three intermediate phase-entry assertion failures
were repaired before this accepted candidate. Do not replay those historical
bytes or reopen the accepted final diff.

A clearly identified external setup/runner failure may be corrected outside
the live checkout, then the clone rebuilt from the SAME index tree and all
three groups rerun serially. No acceptance credit to failed or incomplete
trials. A candidate-related failure is a publication block, not repair authority.

### Post-validation preservation

Require:
- all external candidate files still equal the staged tree, including new paths;
- no generated cache, build, archive, database/journal, lock, or unexpected file
  inside the external clone's checkout;
- fixture artifacts under external basetemp explicitly classified and later removed;
- live HEAD still the exact opening HEAD;
- live index still the exact staged tree with those eight entries;
- live working bytes and unaffected files unchanged;
- live ignored-cache members unchanged;
- no unexpected live untracked/staged/unmerged path.

Run git diff --cached --check after staging; also retain opening worktree
whitespace and encoding checks and both new-file no-index checks.
Do not repair an accepted file to pass any check.

No additional hostile-copy matrix, parser audit, structural-consequence
campaign, or provider qualification is requested here. This gate revalidates
the exact staged bytes and preserves the completed independent audit scope.

## 8. Create at most one exact local commit

After validation, recheck remote trunk, topic/PR absence, and effective
publication requirements again. If the remote base moved, preserve the candidate
and stop; do not rebase or accept a different parent.

Require live HEAD unchanged, the exact index tree, clean unstaged state, and
cache preservation immediately before commit.

Commit once on the currently checked-out local trunk_dev, using the configured
author/committer and required signing arrangement. No --amend, --no-verify,
bypass, identity change, or alternative source commit. Do not create a local
topic or checkout another branch.

Exact subject:
```text
docs: freeze RW0-C2 first-live proof posture
```

Exact body:
```text
Adopt the target-only single-realization support profile for the first
bounded RW0-E proof and its causal contract tests.

Preserve one independently enrolled, non-reissuable authority incarnation,
continuous original process/storage custody, and Coordinator-owned
progression and acceptance. Custody loss ends continuation under this profile
without creating an acceptance, noncommit, cancellation, or terminal fact.
Keep RW0-D offline engineering independent of live enrollment.

This change implements no custody supplier, admission provisioner, guarded
decision writer, migration 0005, recovery runtime, public API, RW0-D/E
execution, or Execution Substrate integration. Concrete supplier conformance
and separate runtime/live-proof gates remain required.

Audit:
RW0_C2_SINGLE_REALIZATION_PROOF_POSTURE_CONTRACT_ACCEPTED_READY_FOR_COMMIT_GATE
```

Complete message = exact subject + TWO LF bytes + exact body + ONE final LF.
Required complete message bytes: 894.
Required complete message SHA-256:
662094d19e691b3733d85c2741647acff16b611ebcc38c862b208e2eeffb74ef

A private external message file is permitted. Preserve exact message bytes.
If hooks/signing alter content, mutate candidate paths, or require forbidden
effects, stop without bypassing or amending.

After the commit verify from the raw Git object:
- exactly one parent: d070bf05d2e68472e18b1b077259e67864923e8f;
- tree exactly equals the previously recorded staged tree;
- exact subject/body/final-LF message and safe attribution/signature information;
- exactly six modifications and two additions, with the literal eight paths;
- all eight committed modes/OIDs equal the verified staged entries;
- each committed size/SHA-256 equals the accepted endpoint;
- every unaffected tree entry equals its parent;
- live index/worktree/untracked/unmerged posture clean;
- local trunk_dev at the new source commit, upstream still origin/trunk_dev,
  1 ahead / 0 behind the unchanged local tracking ref;
- exact live-cache equality.

Record source commit/tree, sole parent, message size/hash, and full committed
blob table inline. These OIDs are discovered facts, not prescribed guesses.

If a commit command errors or its response is ambiguous, determine whether it
created a commit with read-only object/ref inspection. Do not repeat it
automatically. Once a commit exists or may exist, preserve it and all evidence;
no reset, amend, replacement, or drop is authorized.

## 9. One topic push and one non-draft PR

Reobserve remote base, effective publication policy, topic absence, and existing
PR inventory immediately before push. Require base still:
 d070bf05d2e68472e18b1b077259e67864923e8f

Push exactly once:
```sh
git push origin <verified_new_commit_oid>:refs/heads/codex/rw0-c2-first-live-proof-posture-v1
```

Substitute only the newly created verified commit OID. No force/force-with-lease,
--all, --tags, trunk push, retry, alternate branch, or trunk-upstream change.
A plain push is not an atomic base lock; recheck base/head after each remote
effect and report races rather than hiding them.

After push, independently verify:
- remote topic equals the exact new commit;
- remote trunk remains the required baseline;
- remote object/tree agrees with the local source object and staged tree.

Recheck PR inventory before creation. An already-existing unrelated PR is not
permission to edit it. After response loss from this gate's own write, use only
read-only observations to decide whether the exact effect occurred.

Create at most one non-draft PR in:
 evo-agi/Governed-Execution-Coordinator
with:
 base: trunk_dev
 head: codex/rw0-c2-first-live-proof-posture-v1
 head OID: exact verified new commit
 title: docs: freeze RW0-C2 first-live proof posture
 auto-merge: absent; do not enable it
 no labels, assignees, review requests, milestone, project, or unrelated edit.

Exact PR body, ONE final LF:
```markdown
## Summary

- adopt the target-only `rw0-c2-single-realization-proof-v1` profile for the first bounded RW0-E proof
- require independent non-reissuable enrollment and continuous original process/storage custody, with no productive resumption after custody loss under this profile
- preserve Coordinator ownership of progression, acceptance, exact replay, and whole-family recovery
- keep repeatable RW0-D offline engineering independent of live enrollment and a full continuity custodian
- clarify program-independent admission recording and the distinction between administrative SQLite restore and live-proof continuity

## Validation

Validated exact staged blobs in a remote-free local clone, serially:

- new proof-posture contract: 16 passed
- nine affected owner and composition contract files: 3,192 passed
- complete repository: 8,758 passed, with 3 unchanged writer-session fork warnings

The prior independent audit accepted the bounded synthetic histories and counterexamples. They do not establish concrete supplier, signature, storage, or fencing conformance.

## Non-implementation

No product source, schema, migration, configuration, supplier, service,
deployment, admission provisioner, guarded decision writer, recovery runtime,
terminal implementation, public API, runtime activation, RW0-D implementation,
RW0-E execution, or Execution Substrate integration is introduced.

Full-custodian and acceptance-focused checkpoint protocols remain unselected
successor options, not hidden prerequisites for this proof profile.

Audit:
`RW0_C2_SINGLE_REALIZATION_PROOF_POSTURE_CONTRACT_ACCEPTED_READY_FOR_COMMIT_GATE`
```

PR body bytes: 1630.
PR body SHA-256:
4ea862a33f74da016839fc686ae0582ad7b68a77bb51e12cbf2bf06bc4fb6e93

A server-side omission of that single final LF is the only permitted API
representation difference:
 bytes: 1629
 SHA-256: 1ce3d32aa3778a45170ac6f769f67ba027013fa47842c4f6b98d4ad258738a55
Report which form was read; do not edit the PR merely to normalize it.
No other title/body drift is authorized.

Verify by independent readback:
- actual PR number/URL/node identity; OPEN, non-draft, unmerged;
- exact repository/base/head, head OID, one source commit;
- exact eight path effects and full source tree/blob equality, not a truncated
  diff preview; follow pagination;
- exact title and allowed body form;
- no auto-merge or queue request;
- remote topic equals source commit; remote trunk remains the baseline;
- observed mergeability/merge state, checks, statuses, workflow runs, reviews
  and unresolved discussions with observation time.

Do not describe zero checks, empty status contexts, or mergeable/CLEAN as CI
success or merge permission. Checks can be absent or pending at publication.
Record actual state; a later separately authorized merge gate rechecks policy,
head/base and readiness. Do not launch, rerun, repair, or merge workflows.

## 10. Stops and partial effects

Before staging:
- An opening baseline/path/byte/index/mode/patch identity mismatch:
  AUDIT_PROVENANCE_MISMATCH.
- Other policy/permission/preflight block with no commit:
  RW0_C2_SINGLE_REALIZATION_PROOF_POSTURE_CONTRACT_COMMIT_PUBLICATION_BLOCKED.
Leave the candidate and index unchanged.

After staging but before any commit exists:
Do not repair candidate bytes. If HEAD and all opening working bytes are still
exact and only this gate's eight staging effects exist, explicitly authorized
cleanup is to unstage those eight literal paths only, using
git restore --staged -- <the eight exact paths>.
This restores six modifications and two untracked additions with zero staged
changes. No worktree restore/reset/checkout or broad cleanup.
If concurrent changes or commit existence are uncertain, do not unstage or
overwrite them; report and preserve state.

Once any commit exists or may exist:
Never reset, amend, delete, rebase, or replace it. Verify its identity read-only.
A known commit with incomplete push/PR/final verification is:
 RW0_C2_SINGLE_REALIZATION_PROOF_POSTURE_CONTRACT_COMMITTED_PUBLICATION_INCOMPLETE.
If commit outcome remains unknown, report that uncertainty explicitly with the
same incomplete status; never claim the commit did or did not occur without
object/ref evidence.

Push/PR response loss:
No write retry. Read remote topic and PR state. If the exact intended effect is
conclusively present, complete its verification and continue only to the next
not-yet-performed authorized step. If absent after refusal or still ambiguous,
stop with incomplete publication. Do not delete/close completed remote effects,
repush, use a new branch, or manufacture success.

If another actor moves remote trunk at any stage, do not fetch/realign/adopt it
or modify this source commit. Report source/base/PR state and stop; a future gate
must adjudicate actual concurrency.

## 11. Final preservation and inline closeout

Remove only this gate's external clones, fixture DBs, basetemps, scripts, logs,
message/request/response material after all test processes finish and inline
evidence is extracted. Use guarded paths under the actual gate-owned root.
If a cleanup command is denied, do not broaden access or delete another path;
use only a permitted safe cleanup of that same gate-owned material, or report
residue. No live or unrelated temporary cleanup.

Successful final state:
- local trunk_dev at the one new source commit;
- local index/worktree/untracked/unmerged sets clean;
- one worktree, no active operation/unexpected lock;
- unchanged upstream origin/trunk_dev at the opening baseline;
- divergence 1 ahead / 0 behind;
- exact committed tree and eight accepted endpoints;
- unaffected file content and Git-relevant modes unchanged;
- live cache exactly 37 original .pyc files plus their directory, unchanged;
- remote trunk unchanged at the opening baseline;
- remote topic at the new source commit;
- one OPEN, non-draft, unmerged PR for this exact source;
- no auto-merge/queue request; no retained delivered evidence artifact.

Success:
 RW0_C2_SINGLE_REALIZATION_PROOF_POSTURE_CONTRACT_COMMITTED_AND_PR_OPENED

Return:
1. Verdict and visible settings.
2. Opening local and observed remote/policy coordinates and safe actor identity.
3. All eight endpoints, baseline blobs, exact opening grouped patch reproduction,
   and live-cache count/type reconciliation.
4. Exact staged tree, path/status/mode/blob/size/SHA-256 table.
5. Exact collection/execution commands, node counts, warning records, environment,
   and every setup failure/rebuild or skipped check.
6. Post-validation staged-tree/working-byte/cache equality.
7. Raw source commit/tree/parent/message digest, attribution/signature status,
   and committed-blob equality.
8. The one push refspec and observed effect; PR identity/title/body/head/base/
   state/file/commit counts; current policy/check/review observations.
9. Final local and remote coordinates, cleanliness, live preservation, cleanup,
   any partial effect, uncertainty, or retained residue.
10. Continuation capsule (at most 800 words) naming exact source/tree/base/topic/PR
    and the next separately authorized merge gate. No next implementation prompt.

State actual non-actions and deviations, not blanket claims of "no mutations":
candidate bytes unchanged; no source/schema/migration/config/runtime changes;
no live product imports/tests/DB/cache modification; no supplier qualification,
enrollment, launch, fencing or live-proof operation; no installation, credential
change, sibling or subagent work; no amend/rebase/reset/cherry-pick/checkout;
no direct trunk or force push; no merge/auto-merge/queue; no deletion/tag/release/
deployment; no manual CI action; no delivered evidence package.

This publication records an accepted target-only support profile and bounded
synthetic verifier. It does not enroll a lineage, consume acceptance, qualify a
supplier, implement RW0-D or execute RW0-E. Supplier conformance, separate
program-independent admission provisioning, C2 physical/transaction/terminal
work and live-proof authorization remain later gates. The general phase-entry
restart-readback rows must not be treated as productive restart permission under
this profile's specific original-custody rule.

End with the applicable verdict token. Success authorizes no merge, later
implementation, supplier selection, service/deployment, or live-proof effect.
