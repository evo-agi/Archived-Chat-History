The admission/continuity contract-tranche prompt has not been sent to Codex.
Treat it as an unexecuted draft.

The reconnaissance established one important impossibility result:

- local Coordinator bytes alone cannot distinguish a genuinely unclaimed
  preaccept state from an accepted state followed by rollback to the same
  preaccept bytes.

I accept that some independent non-rollback evidence is required if we support
that recovery scenario.

It did not yet establish that the narrowest first-slice architecture is a
general externally custodied checkpoint protocol with a durable pre-commit arm
for every mutation affecting a broad protected closure.

Before issuing another mutation prompt, make one engineering decision from the
existing repository evidence and reconnaissance. Do not commission another
broad Codex pass by default.

Compare these operating models:

1. Full continuity custodian

   An independently durable lineage/epoch/checkpoint owner, with a possible-
   commit arm before every explicitly protected mutation, monotonic settlement,
   old-writer fencing, and recoverable handoff.

2. Acceptance-focused continuity

   External admission and sole-active evidence for every applicable command,
   but a durable possible-commit barrier and permanent external checkpoint only
   for scope admission and the productive acceptance family. Nonaccept and
   other local progression remain Coordinator-owned and fail closed after any
   continuity ambiguity.

3. Proof-only single-realization posture

   One explicitly admitted authority realization for the bounded RW0 proof.
   Restore, rollback, clone, relocation, and authority handoff are unsupported
   during the active proof and cause permanent fail-closed termination of that
   proof unless a later separately accepted continuity mechanism can reconcile
   them. No routine per-command user approval is permitted.

4. Another repository-supported model, if materially better.

For each model state:

- the exact safety claim it supports;
- which RW0-C2 operations require external participation;
- whether RW0-D offline proof is blocked;
- whether RW0-E live proof is blocked;
- availability and recovery consequences;
- how it preserves Coordinator as sole progression and acceptance owner;
- what external authority or component is required;
- and whether at least one credible implementation class could satisfy it
  without a new general orchestration authority or routine user relay.

A credible implementation class is required before freezing a detailed target.
It need not select a vendor, repository, transport, schema, or deployment, but
it must explain how independent non-rollback custody and effective old-writer
fencing could actually be achieved.

Do not treat “a later service will provide it” as sufficient feasibility.

My recommended default is the narrowest model that:

- preserves the one-shot acceptance invariant;
- removes me from routine evidence and recovery transport;
- permits repeatable RW0-D offline engineering;
- permits one bounded RW0-E proof;
- and does not make every Coordinator progression decision depend on an
  unimplemented external coordination service.

Then make one disposition:

- retain the full-custodian architecture and explain why every selected
  protected operation requires it;
- narrow the contract to admission/acceptance-focused continuity;
- select the proof-only single-realization posture for the first live slice;
- or identify one genuine product-policy fork with your recommended default.

If the full model remains selected, issue one complete replacement Codex prompt
that explicitly:

- enumerates the exact protected mutation classes rather than referring to
  every future mutation affecting an open-ended closure;
- states whether and why RW0-D is or is not blocked;
- separates target protocol validity from a mandatory implementation-entry
  feasibility gate;
- prevents the custodian from becoming a second decision, acceptance, retry,
  or recovery authority;
- and stops if no credible custody/fencing mechanism class can satisfy the
  contract.

If a narrower model is selected, revise the contract scope accordingly.

Do not return ordinary schema, transaction, test, or file-boundary choices to
me. Do not issue source, migration, runtime, service, or deployment work.
Return your engineering judgment first, followed by one complete replacement
Codex prompt only if a contract-writing tranche remains the recommended next
step.
