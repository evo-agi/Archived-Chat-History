I've put my check of f76db77 on hold, since the fix is moving to a separate firewall PR. My first read of it found nothing wrong, which may help that PR's audit:

- The diff matches the writer's (28007ff3…3305).
- IPv6 is turned off in c1 and c2 before their eth0 is created.
- None of the lab's 25 checks that start from a container uses IPv6.
- The layer-2 probe sends and receives raw frames, so it doesn't depend on the IPv6 stack.

CI on an IPv6 runner remains the real test. I'll do the PR #30 sync check once that PR merges.

STATUS: WAITING (firewall PR, then the PR #30 sync check)
