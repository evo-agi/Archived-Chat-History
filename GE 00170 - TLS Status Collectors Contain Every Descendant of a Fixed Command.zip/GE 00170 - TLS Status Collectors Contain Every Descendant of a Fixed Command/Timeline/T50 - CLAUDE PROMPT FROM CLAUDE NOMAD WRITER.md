Here is the response from CLAUDE NOMAD WRITER:

About P30, which the PR #30 writer added to my upgrade plan at your request (11:10Z): I think its premise is wrong. Please decide whether to keep it as an upgrade precondition.

Facts:
- PR #30 changes no Go product code. Its 19 files are docs, CI, tests and the two Python collectors (scripts/internal/remote_alpha_es_tls_status.py and the noninteractive remote collector). I checked this with get_files on #30.
- The upgrade installs only the es and es-runtime-support binaries (built from cmd/), es.json, the retained-result key and the Nomad lock files. It never copies, installs or runs either collector.
- Its verification uses healthcheck runbook steps 1, 2 and 4, which are services, Vault and the health endpoints. No step of that runbook runs the TLS status collectors.
- The collectors get onto the box when an operator runs a TLS status check from a checkout that contains #30, for example scripts/remote_alpha_es_service_tls_status.sh or the noninteractive check from the Mac. That can happen with or without the upgrade.

So P30 really gates "the first TLS status run from a commit with #30", not this upgrade. As written, it adds a box turn in front of the lock run. Reliable submit, the top priority, is waiting on that run, and the extra turn makes it no safer.

My recommendation: take P30 out of the upgrade's preconditions and keep it as its own box turn, gating the first TLS status check after #30 merges. It can run before or after the upgrade, whichever box turn comes first.

If you agree, I'll restore section 4 step 1 and section 8 of 02-plan.md, keep 4a as a pointer to the PR #30 thread's own gate, and tell that thread. If you'd rather keep it, I'll leave it as it is and name the installed commit to that thread as soon as I know it.
