~~**David, one "go ahead" here starts both remaining runs for PR #30 in a single session on your Mac:** the Mac test run and the Remote Alpha box run.~~ [Edit: nothing is needed from you yet. The Mac and box run waits until the re-audit and the red-team both accept, so it runs once on the final code. You'll be asked for the go ahead then.] The run takes about 20 to 25 minutes. On the box it touches no service and removes its temporary folder afterwards. Details are in [08-mac-and-box-brief.md](/mnt/project-files/reports/Execution-Substrate/tls-status-child-containment/08-mac-and-box-brief.md).

Audit 07's three Low findings are fixed in commit `0b8b9c0`. It's pushed and CI is green.
- **T7-1:** a leftover process can no longer stall the root collector once a command has finished normally. A new test reproduces the stall and fails on the old code.
- **T7-2 and T7-3:** tests added. The auditor's two surviving mutants are now caught.

The stall is still possible when a command times out. That is now written in the docs as a limit. Report: [08-repair.md](/mnt/project-files/reports/Execution-Substrate/tls-status-child-containment/08-repair.md).

Next: a narrow re-audit by the same auditor, then the red-team.

STATUS: ~~NEEDS DAVID~~ WAITING
