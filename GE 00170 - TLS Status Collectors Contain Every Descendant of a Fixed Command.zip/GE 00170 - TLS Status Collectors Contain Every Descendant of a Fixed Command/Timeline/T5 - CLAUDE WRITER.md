I opened draft [PR #30](https://github.com/evo-agi/Execution-Substrate/pull/30) to trunk_dev. It contains both collectors and is ready for a fresh audit and red-team.

- **Root collector:** each fixed OpenSSL command now runs in a PID namespace of its own, with an anchor process (D1 to D5).
- **Remote collector:** it implements R2. It becomes a subreaper and, after every command, kills and reaps its own children until the kernel reports none are left. If that is not proven within the 2 s bound, the command fails and every later command is refused.
- **Not included:** the root-side runner for the `sudo -n` path, as report 05 says.

All checks ran in the cloud container on the new trunk_dev base, `036d507`. PR #25 landed meanwhile, and only the workflow pin conflicted.

- **Root package as an unprivileged user:** 480 tests pass. The 8 failures and 3 skips are exactly the ones `environment-only-tests.txt` already names.
- **Gate self-test:** 132 of 132.
- **New root CI step:** 3 of 3.
- **Mutants:** 26 of 26 caught for the root collector and 22 of 22 for the remote collector.
- **go vet:** clean for Linux and macOS.

Report [06-implementation.md](/mnt/project-files/reports/Execution-Substrate/tls-status-child-containment/06-implementation.md) (sha256 `9dd58ed3…ffaf`) has the provenance (manifest `17adc312…90c9`, 19 files) and notes for the auditors.

Still needed before merge: the box run, the Mac run, and the audit and red-team. David has to write "go ahead" in this thread himself before I start anything on his Mac. GitHub refused to request a review from SeritArbores because that account is the PR author, so it is set as assignee only. I'm watching the PR's CI.

STATUS: WAITING (CI on PR #30, then audit, red-team and box run)
