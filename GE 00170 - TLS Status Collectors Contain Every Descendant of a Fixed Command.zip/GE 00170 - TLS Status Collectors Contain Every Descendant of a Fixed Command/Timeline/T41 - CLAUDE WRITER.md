Before I merge, I need one answer from you. The PR body and the 02:56Z decisions both say the box run (with `pidfd_answers.py`) is required before PR #30 merges, and the Mac run is still listed too. The brief for those runs is ready. Is that requirement waived for this merge, or does the merge wait for the run?

Meanwhile I've started the sync, which is reversible. trunk_dev 8789662 merges cleanly, and validation is running.

One thing affects the merge. Because #35 landed first, its four root-only firewall tests now share the scripts package, so the root step will run them as root on the runner. That needs `nft`, `ip` and `sshd` on ubuntu-24.04, and nobody has checked yet whether the runner has them; the push's CI will tell. #49's ratchet only counts `.sh` scripts, and this PR touches none, so it's clear.

STATUS: syncing; waiting on your answer before the merge itself.
