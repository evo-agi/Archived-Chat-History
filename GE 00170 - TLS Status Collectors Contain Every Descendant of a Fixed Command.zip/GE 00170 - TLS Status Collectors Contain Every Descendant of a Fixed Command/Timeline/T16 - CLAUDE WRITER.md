T9-1 is fixed, and the branch now includes trunk_dev `76c030f`. **New head `eed4c9b`**, manifest `ab6da82106b7387a2dce1b3d0f041d3f5bfbf02c889401682ec648a333f9019d` against base `76c030f`, 19 files (same set as before), taken twice byte-identical. CI is green on `eed4c9b`. Full report: [10-repair.md](/mnt/project-files/reports/Execution-Substrate/tls-status-child-containment/10-repair.md).

**The fix.** I applied the auditor's diff and made four changes to it:
- **Wording.** Its "without a TERM first" was wrong. The cleanup still sends TERM right after the release, and whether that or the kernel's kill lands first is a race. What the child never gets is the grace period. The docs, the comment and the test now say "without the grace period of TERM before KILL".
- **O9-1.** The anchor's code is now pinned as a whole, so the auditor's 2.5 s timer mutant (A19b) is caught.
- **Second failure path.** The outer error path had only a source-pattern check. Two new tests now catch its release being removed.
- **Line wrapping.** I rewrapped two over-long lines.

**Validation.**
- Mutants: 8 of 8 new ones caught; the earlier 26 and 22 still all caught.
- Whole package: same results as before, plus the 3 tests that #27 added.
- Gate self-test 132/132, root step 3/3, vet clean.

**PR #35.** Once both have landed, my root step will run its 3 root-only tests as root with `PATH=/usr/bin:/bin`. Its lab then can't find `nft`, which lives in `/usr/sbin`. Whichever PR lands second needs a three-line change (the PATH in `go_test_as_root.py` plus two self-test expectations). The required check will fail until that is done, so this can't be forgotten.

The Mac and box brief is updated to `eed4c9b` with one more box case for T9-1: [10-mac-and-box-brief.md](/mnt/project-files/reports/Execution-Substrate/tls-status-child-containment/10-mac-and-box-brief.md). I haven't asked David anything.

STATUS: READY for the auditor's delta check of `0b8b9c0..eed4c9b`, then the red-team
