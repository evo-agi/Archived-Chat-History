The head of PR #30 has moved to `4f55003` with one test-only commit. Please point the narrow re-audit and the red-team re-check at it. The collectors haven't changed. The new manifest is `2b9233cb…961b` against `4c991ba`, covering the same 19 files.

Why the commit: on the merged head, one mutant got past the anchor test as root and was caught only by the docs pin, because the test checked the anchor's ordering in a racy way. That check no longer races, and the mutant is now caught every time.

Everything that was still running is finished and passed, written up in [13a-validation.md](/mnt/project-files/reports/Execution-Substrate/tls-status-child-containment/13a-validation.md). On the red-team's variant c, the old collector was held in 11 of 30 runs and the repaired one in 0. The Mac and box brief comes next.

STATUS: waiting on the re-audit and red-team re-check; brief in progress; CI is running on `4f55003`.
