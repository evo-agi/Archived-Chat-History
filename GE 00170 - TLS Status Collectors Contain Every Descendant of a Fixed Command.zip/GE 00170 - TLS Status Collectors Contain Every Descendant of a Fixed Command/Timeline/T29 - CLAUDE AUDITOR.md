**ACCEPT 4f55003, with one Low documentation finding (A14-1) to fix in this PR before merge.** The red-team re-check can start on 4f55003 now. The A14-1 fix will only need a diff check.

- **RT12-1, RT12-2, RT12-3 and O12-1 are fixed.**
  - I wrote my own stray shapes: a relay, a herd of 300, a stray inside a nested PID namespace, and timeout variants of those. All of them hold eed4c9b's collector for 15 s, and all of them return on the new code with nothing left behind.
  - Audit 09's hold modes give the same results as before.
  - My 14 mutants are all caught.
  - Across 2,278 shared test names, no verdict changed against my eed4c9b run.
- **The #39 sync and 4f55003 are correct.**
  - The workflow pin matches, the gate self-test passes 132 of 132, and the emulated root step passes 5 of 5.
  - The new anchor-order check passes 30 of 30 runs as `ci` and 30 of 30 as root, and it catches the writer's N07 every time.
  - Both manifests match the writer's.
- **The writer's section 5 is an acceptable boundary, not a compromise.** Every waiting shape that beats the drain needs a changed binary at a root-owned path, so the attacker already has root, and any drain hardening can be bypassed through host services. The one guarantee that can hold against root does hold: no command ever returns success while a descendant lives. That is tested.
- **A14-1:**
  - The remote collector's documents say a killed collector takes the fixed child with it. A changed binary can undo its own parent-death request and outlive the collector. I measured that; it stays one process, which still cannot fork.
  - It can't be fixed in code without breaking `sudo`. The fix is a wording change and one limit sentence in two documents, plus a pin.

Two things are open for the merge gate:

- **CI on 4f55003** (run 45309449104) was still running at 02:22Z. The run on 700b533 passed.
- **trunk_dev has moved to 6ce0034.** It shares no file with this PR and a trial merge is clean, but the branch must be brought up to date at the gate.

[14-re-audit.md](/mnt/project-files/reports/Execution-Substrate/tls-status-child-containment/14-re-audit.md)

STATUS: READY
