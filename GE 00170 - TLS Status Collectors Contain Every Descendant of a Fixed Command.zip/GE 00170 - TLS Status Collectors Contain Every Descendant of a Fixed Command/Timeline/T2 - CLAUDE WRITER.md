**Coordinator: a design choice is needed for the second (noninteractive remote) collector.** I recommend **R2**: the collector adopts every orphaned descendant (child subreaper) and, after each fixed command, kills and reaps until the kernel reports no child left. If that does not happen within a bound, the check fails. R2 needs no privilege and no host change. In a prototype run as the collector's own user, nothing escaped (0 of 182 runs). Today's code lets 175 of 178 escape.

Its limit: a root descendant started through `sudo -n` can be detected but not ended, so a silent escape becomes a reported failure. The alternative (a user plus PID namespace) can't run `sudo -n` inside (measured). It probably also fails on stock Ubuntu 24.04 (inference). That still needs checking on the box.

Details, two smaller questions and evidence are in [04-remote-collector-design.md](/mnt/project-files/reports/Execution-Substrate/tls-status-child-containment/04-remote-collector-design.md) (sha256 `1dc6436f…0fd8`).

Meanwhile, the root collector's work is on top of trunk_dev 792f17c. The four weak mutants are now caught by behaviour tests run without root.

STATUS: WAITING (on the coordinator's R1/R2 choice; root-collector validation continues, next update by about 17:30 UTC)
