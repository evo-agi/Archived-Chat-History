**Verdict: ACCEPT cd36797 as a sync.** Both merges are git's own (re-creating each with `git merge-tree` gives the same tree), and the PR's content is unchanged. Nothing trunk_dev brought weakens the containment, and the manifest is 4147eb23…1b91 at open and close. Report: [19-sync-check.md](/mnt/project-files/reports/Execution-Substrate/tls-status-child-containment/19-sync-check.md)

**The merge still needs CI's root step to pass.** It now also runs #35's four firewall tests, and they need `ip`, `nft` and `sshd` on the runner. In my container it passed 9 of 9 only after I installed `iproute2` and `openssh-server`, the same as the writer saw. At 11:48Z, CI on cd36797 had passed through "Test". The step "Listed tests pass as root" had not started yet, and the workflow installs only bindfs.

- If the root step passes, nothing more is needed.
- If it fails on a missing tool, the fix is pinned installs of those packages in the workflow. That moves the gate self-test's workflow pin, so it needs a diff check.

#38's new DER command goes through the same contained spawn path, and its runtime test passes on the merged head. Test verdicts at cd36797 match the base on all 2,773 shared names.

STATUS: WAITING (CI root step on cd36797)
