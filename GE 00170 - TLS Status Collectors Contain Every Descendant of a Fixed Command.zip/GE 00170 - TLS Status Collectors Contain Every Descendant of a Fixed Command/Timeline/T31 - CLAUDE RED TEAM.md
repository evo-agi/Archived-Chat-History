**PR #30 re-check: ACCEPT. RT12-1, RT12-2 and RT12-3 are all closed, the fixes open nothing new, and section 5 is an honest bound, not a finding.**

Reproduced the repair at head `4f55003` (manifest `2b9233cb…961b`, collectors hash-matched) and ran my own red-team harness against the repaired collectors, with the `eed4c9b` collectors as live controls in the same runs:

- **RT12-1 (CLONE_PARENT strays):** the `sibling` attack now returns cleanly in 24 ms with nothing left behind, where `eed4c9b` hung for the whole bound. The new `end()` reaps the stray.
- **RT12-2 (namespace end):** every way of deafening the anchor is now beaten by one SIGKILL from the collector — including the case where the attacker's ptrace of the anchor genuinely succeeds. A killed collector drops its fixed child in 730 ms, versus 10.6 s on `eed4c9b`.
- **RT12-3 (remote drain):** the fixed child's `RLIMIT_NPROC (0,0)` stops the chain, herd and relay from starting at all — 0 processes left, versus 14 and 14,000 on `eed4c9b`.

On **section 5** (root and `sudo -n` stated, not hardened): I confirmed the residual is real — as root the limit doesn't bind and a waiting shape does outlast the drain — but the result is always a reported runtime failure, never a success with a process alive. I agree with stating rather than hardening it: a root descendant defeats any per-process drain anyway, and hardening would add host-wide signalling that reopens the PID-reuse risk the drain avoids. The property that protects the status result holds for root too.

Report SHA-256 `ad4a3520f0ce8a5fcc839924ff8876bb5d7d9fa170b5d1d94995aca9161bd0d0`. Nothing ran on the box; nothing pushed. At the gate, bring in current `trunk_dev` (`6ce0034`) and re-run provenance.

STATUS: WAITING — PR #30 re-check delivered (ACCEPT); available for the merge-gate provenance re-checks on #30 and #31. 9:22 PM Eastern.
