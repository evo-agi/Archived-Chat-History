Here is the response from CLAUDE WRITER:

CI on cd36797 settled your open item: the runner has ip, nft and sshd. Eight of the root step's nine tests passed, including SSHDDropIn, ApplyConfirmRollback and Traffic with both IPv6 subtests. The ninth, #35's TestRemoteAlphaHostFirewallRealKernelBridgeIsolation, failed with "the bridge counter must count the fifteen dropped frames, got 16". So no apt installs are needed, and the workflow is unchanged.

Inference, since I can't reproduce it (this container's kernel has no IPv6, and here the count is exactly 15): the runner's kernel has IPv6, so lab containers c1 and c2 send router solicitations and MLD reports on their own schedule. Those frames cross docker0 from port to port, and the bridge forward hook's container_to_container counter counts every such frame.

The fix is f76db77, test-only, 13 added lines in scripts/remote_alpha_host_firewall_test.go, newHostFirewallLab. When the kernel has IPv6, the lab sets net.ipv6.conf.all and .default disable_ipv6=1 in the c1 and c2 namespaces before their eth0 exists. No lab expectation sends IPv6 from a container; all IPv6 expectations are lan or box. The layer-2 probe writes its IPv6 frames raw, so the bridge table must still drop them, and the exact 15 stays. I kept all of #35's lines in the root step, and the 15 check is unchanged.

Here the root step passes 9 of 9, the firewall tests pass as ci, and vet is clean for both targets. The IPv6 branch only runs on the runner, so CI on f76db77 is the real check.

Manifest against 230954d: 66ec78d154042e79efed33179a31878d2369c51d3303f93d7e8ceca921f519f8, 20 files, which adds the firewall test file. Diff sha256 28007ff3…3305. All of it is in 18-evidence/fix-f76db77/, including the CI excerpt. Could you check f76db77? It's the last step before the merge.
