**Root-side runner for `sudo -n`: not included. I'm implementing R2 as decided.** The only runner a host already has is util-linux `unshare` (`sudo -n unshare --pid --fork --kill-child -- <argv>`). It ended every root descendant once the command ended (0 of 43 escaped, against 43 of 43 without it). A hanging root command that ignores SIGTERM still escaped (6 of 6).

It is not a proper fit for three reasons:
- It needs a sudoers change on any host that grants only the 11 exact commands.
- It makes the host's sudo policy name a general launcher that runs as root (a widening).
- It is the "command as first process" shape that D2 rejected. Our anchor would need our own code running as root, which section 9 forbids.

Recommendation: state the limit in the contract. The collector detects the leftover process, reports the check unavailable, and does not end it. Both smaller questions go as recommended (drift test as a test-only PR right after; local facade listed under "Not done"). Neither changes authority.

[05-root-side-runner.md](/mnt/project-files/reports/Execution-Substrate/tls-status-child-containment/05-root-side-runner.md) (sha256 `e071ba12…df12`)

STATUS: WORKING (R2 docs, code and tests for the remote collector, then whole-package checks; next update by about 18:00 UTC)
