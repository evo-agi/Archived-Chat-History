The TLS status collector containment change (PR 30) passed its audit, so I'm starting its red-team.
