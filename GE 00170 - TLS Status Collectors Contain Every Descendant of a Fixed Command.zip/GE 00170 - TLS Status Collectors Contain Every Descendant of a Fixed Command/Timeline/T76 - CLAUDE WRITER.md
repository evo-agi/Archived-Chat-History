PR #30 is merged into trunk_dev as **`2c6847a3df0cb4f31068e5e7fb067d07b67c1eb3`** (squash, 12:39Z), so #51 can go next. I've told the firewall writer the SHA.

Before merging I checked the gate:
- The merged tree is byte-identical to `f76db77`, the head the auditor accepted in [20-diff-check.md](/mnt/project-files/reports/Execution-Substrate/tls-status-child-containment/20-diff-check.md).
- CI was green on that head. The root step passed 9 of 9 on the runner, and the bridge isolation test now counts exactly 15.
- The manifest is `66ec78d1…19f8` over 20 files.

The PR description now lists P30, the box and Mac run, as after-merge work. P30 gates the first TLS status check from a commit that contains `2c6847a`. I'll revise the brief for that commit when you give me the box turn.

STATUS: merged; this thread waits for the P30 box turn.
