All three red-team findings are repaired. The new head `700b533` is pushed and ready for the narrow re-audit and the red-team re-check. Manifest `2c850673…eaa0` against base trunk_dev `4c991ba`, 19 files, taken twice with identical results and checked against the commit. The full write-up is [13-repair.md](/mnt/project-files/reports/Execution-Substrate/tls-status-child-containment/13-repair.md).

**What changed**
- **RT12-1 (root collector):** before the cleanup runs, the collector now ends each command's namespace itself. It waits until the command has ended, then reaps every leftover child the command attached to the collector, and stops only when one listing of its children shows none.
- **RT12-2 (root collector):** that end is a KILL to the anchor process, not a request it can ignore. The anchor sets a parent-death signal before it reports ready, so a killed collector takes the whole namespace with it.
- **RT12-3 and O12-1 (remote collector):** each fixed child gets a parent-death signal, a check that its parent is still the collector, and a process limit of zero. An unprivileged fixed child can start no process at all, and dies with its collector.
- **Root and `sudo -n`:** neither the limit nor the parent-death signal holds there. I stated that in the documents instead of hardening the drain; section 5 of the report explains why. If you'd rather harden it, that would be a separate change.

**Trunk_dev moved twice.** I merged `0aa4a2b` as you asked. Then #39 landed and GitHub marked the PR as conflicting. I merged `4c991ba` as well: the two new test files move into `scripts/`, and the root CI step now runs that package. That merge adds 29 lines beyond the textual merge; section 7 lists them.

**Checks**
- On the head: tests pass apart from the 8 known environment-only failures, the gate self-test passes 132 of 132, the five namespace tests pass as root, and vet is clean.
- On the repair before the second merge, every mutant was caught: 27 new ones, plus all the earlier ones that still apply.
- The new tests fail against the `eed4c9b` code.

**Still running:** CI, the mutants rerun on the merged head, the red-team's variant c, and a rehearsal of the box run here. I'll add their results as `13a-validation.md` and tell you only if something fails. The revised Mac and box brief comes after that.

STATUS: repaired and pushed, CI running; waiting on re-audit and red-team re-check.
