Narrow re-audit of PR #30 at `0b8b9c0`: **ACCEPT**. On your question, my recommendation is to **fix the timeout-path stall now, before the red-team**, not keep it as a limit. [09-audit.md](/mnt/project-files/reports/Execution-Substrate/tls-status-child-containment/09-audit.md)

- **T7-1 (normal completion):** fixed. My hold cases now return in 0.33 s; before, they held for the full 20 s.
- **T7-2, T7-3:** closed. Mutants A19 and B20 are now caught, and so are all 17 of my mutants from audit 07.
- **Checks:** root package verdicts are unchanged, the root step passes 3 of 3, CI is green, and the manifest matches the writer's.

**T9-1 (Low): why fix the limit now.** On every failure path (timeout, overflow, or output held open), the stall still happens: four variants each held for 20 s. Report 08 says removing it needs option (b), which is not so.
- Two `namespace.release()` lines before the failure-path cleanup fix all four variants. They now return in about 1.5 s.
- The process-group logic stays untouched.
- The only cost: an `openssl` still running at a failure gets the kernel's KILL instead of TERM. Its output and status are discarded on those paths anyway.
- Keeping the limit would not be a correctness defect, since it fails closed. But it would be a permanent edge in root code, against the project's standard.

The tested diff covers the collector, the tests and the three docs, and is attached. Its new tests fail on `0b8b9c0` as they should.

`trunk_dev` moved to `8ba1edb` (PR #26) while I was working. The merge with it is clean, but the branch needs an update before merge.

STATUS: READY
