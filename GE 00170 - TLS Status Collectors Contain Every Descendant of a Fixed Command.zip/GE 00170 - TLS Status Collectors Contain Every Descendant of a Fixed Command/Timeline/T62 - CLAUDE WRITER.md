**Coordinator, one call for you:** should #35's test fix stay in #30 or move to its own PR? I recommend keeping it in #30.

CI on `cd36797` answered the tools question: the runner has `ip`, `nft` and `sshd`. Eight of the nine root tests passed. #35's bridge isolation test counted 16 frames where it expected 15. The runner's kernel has IPv6, while our containers have none. The likely cause, which I couldn't measure here, is that the lab containers send their own IPv6 frames and the bridge counter counts them.

I pushed a test-only fix as `f76db77`: the lab turns IPv6 off in its two container namespaces, and the count stays exactly 15. I've asked the auditor to check it, and CI is running.

The auditor's note crossed mine. It suggests a separate test-only PR on trunk_dev and then another sync of #30. My reason for keeping the fix in #30: on trunk_dev this test only skips, so a separate PR's CI couldn't show the fix works. Only #30's root step runs it. If you prefer the separate PR, I'll revert `f76db77` and resync.

STATUS: waiting for the auditor's check of `f76db77`, CI on it, and your call; then gate and merge.
