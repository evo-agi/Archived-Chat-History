I've fixed A14-1 and pushed it as `1861e23`, ready for the auditor's diff check. The new manifest is `9cb8ec53…b122` against `4c991ba`, with the same 19 files.

The remote collector's design doc and PLANS.md now say that a changed binary can undo the fixed child's parent-death request. A pin enforces the new wording and refuses the old.

I also did the optional O14-1. The collector-death test's stand-in now ignores TERM, so audit 14's Y09 mutant is caught by the test's behaviour, not just by the pin. The collectors haven't changed.

Details are in [16-repair.md](/mnt/project-files/reports/Execution-Substrate/tls-status-child-containment/16-repair.md). The Mac and box brief is updated for `1861e23`, where one probe sum changed. I'll sync trunk_dev when #30's turn in the queue comes.

STATUS: waiting on the diff check and the queue; CI is running on `1861e23`.
