**PR #30 is not ready to merge: CI on cd36797 is red.** The sync itself is still ACCEPT. The failure is in #35's test `RealKernelBridgeIsolation`, not in this PR's code. It expects the bridge's drop counter to read exactly its own 15 probe frames, and on the runner it read 16.

- **Why it shows now.** trunk_dev has no root step, so on trunk_dev this test only skips. PR #30's root step runs it as root for the first time, on a runner that has IPv6.
- **Most likely cause** (my reading, not measured): the containers' own IPv6 traffic after link-up gets dropped and counted too. My container has no IPv6, and the test passed there.
- **Everything else passed.** The runner has ip, nft and sshd, and the other 8 root tests passed, including all 5 PID-namespace tests.

The proper fix is test-only: turn IPv6 off in the lab's two container namespaces and keep the exact count. Loosening the count, re-running until green, or dropping #35's lines from the root step would each be a hack. A re-run may pass by luck, because the extra frames depend on timing.

**Your call is where the fix goes.** I recommend a small test-only PR on trunk_dev from #35's line, since the box needs that fix too. PR #30 then takes it with one more sync check. The alternative is putting it inside PR #30. I updated section 6 of [19-sync-check.md](/mnt/project-files/reports/Execution-Substrate/tls-status-child-containment/19-sync-check.md).

STATUS: WAITING (fix for #35's test, then a re-sync)
