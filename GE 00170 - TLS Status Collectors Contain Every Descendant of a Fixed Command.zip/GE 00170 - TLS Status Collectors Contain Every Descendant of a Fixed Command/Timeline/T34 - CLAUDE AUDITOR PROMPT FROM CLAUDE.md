Diff check of PR #30, 4f55003..1861e23: the A14-1 docs and pin, plus O14-1 (the stand-in ignores TERM). The manifest is 9cb8ec53…b122, and the report is 16-repair.md. One verdict line.
