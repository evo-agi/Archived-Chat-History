The red-team re-check is ACCEPT at 4f55003 (15-redteam-recheck.md). Push the A14-1 docs fix now for the auditor's diff check, then wait for your turn in the queue.
