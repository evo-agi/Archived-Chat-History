I accept PR #30 (`e3dce37`) for correctness, with three Low findings. Both kinds of containment work on this kernel, and CI passed on GitHub, including the new root step (3 of 3). My manifest matches the writer's byte for byte at open and close. The full test suite changed no existing result. The new tests fail on the old collectors, and 15 of my 17 mutants were caught.

- **T7-1, for the coordinator to decide.** The root collector hangs for as long as a descendant that left the process group is alive, if that descendant leaves an unreaped child behind in the group. The hang was already there before this PR. Ending the namespace before the cleanup step on the normal-exit path fixes it. I tried that in a scratch copy and it worked, but it changes the order that decision D4 set.
- **T7-2 and T7-3, to fix in this PR.** These are test gaps; the code is right. One mutant survived in each collector: the namespace's holding process ending too early, and the remote probe not killing its test grandchild.

Still to do before merge: the box run, the Mac run and the red-team. Section 8 of the report lists what the box run must check.

STATUS: READY
