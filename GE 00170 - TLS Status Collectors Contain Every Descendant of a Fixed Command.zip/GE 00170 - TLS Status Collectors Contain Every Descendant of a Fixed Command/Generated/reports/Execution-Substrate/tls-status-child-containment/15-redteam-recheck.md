# ES PR #30 — red-team re-check of the RT12 repair

```
Target:            evo-agi/Execution-Substrate, draft PR #30 ("contain TLS status collector child processes")
Head:              4f55003b81580acec19f2cbe5bf1f6db4859afe1, tree 9cbfdff64f7d8ff08ae8f8488f3a0ef03418eaf8
                   recipe governed-execution.audit-patch-manifest.v2, tool sha256 c08597e2…a3ca (verified)
                   manifest_sha256 2b9233cb…961b, textual_diff af20695e…52c5, 19 paths
Scope:             the repair of red-team 12's three Low findings (RT12-1, RT12-2, RT12-3) and
                   observation O12-1, reports 13-repair.md and 13a-validation.md.
Posture:           red-team thread, separate from writer and auditor; read-only on the repo; nothing
                   pushed, no PR comment, no merge; nothing run on the Linux box. Real repaired
                   collectors run in one cloud container (kernel 6.18.44, Python 3.13.18, user ci
                   UID 1500), against the eed4c9b collectors as controls.
Verdict:           ACCEPT. RT12-1, RT12-2 and RT12-3 are closed, and the fixes open nothing new.
                   Section 5 (root and sudo -n stated, not hardened) is an honest, tested bound,
                   not a finding. The red-team does not block merge.
```

## 1. Provenance (reproduced)

New head `4f55003` (the one test-only commit on top of the repair `700b533`). I fetched
the branch, checked out `4f55003`, and ran the v2 recipe with HEAD reset to base
`4c991ba`, upstream `origin/trunk_dev`, branch `claude/project-thread-wbmulu`:

- `manifest_sha256 = 2b9233cbe3c27943c34c3e65ec68035520a134e01def9072e4b31030e876961b`, 19 paths — byte-equal to the writer's and the auditor's figure in 13a.
- `textual_diff_sha256 = af20695eded45cf7271b9373e74eecf932499fbbf5e9e837d1eda036bdea52c5`.
- Repaired collector sha256: root `c6c2dc75…dd5e`, remote `db471490…ebdc8` — the ones
  I attacked. Recipe tool sha256 `c08597e2…a3ca` verified first.

So the tree I tested is the real PR content at `4f55003`. (`provenance.txt`.)

My red-team harness is byte-identical to `12-redteam-evidence/tools/` (every `.py`,
`.sh` and `.c` checked; the `storm` and `herd` binaries recompiled from the committed
sources). I ran it unchanged against the repaired collectors.

## 2. RT12-1 — strays of the collector are reaped (root collector)  → CLOSED

RT12-1 was: a fixed child makes a process that is a child of the collector itself
(`clone3` with `CLONE_PARENT`); nothing reaped it and the collector then waited for
good (only KILL ended it). Against the repaired collector (`rt12-1-sibling.txt`):

| mode | repaired `4f55003` | eed4c9b (control) |
|---|---|---|
| `sibling` | returns `(0, b'fixed')` in 0.024 s, **no process left, collector keeps no child** | HELD for the bound; collector kept a child |
| `sibling-run` | `Incomplete('child_timeout')` at 10.0 s (the fixed child's own timeout), then clean; no process left, no child | HELD 15 s; only SIGKILL ended it |

The stray is now reaped (`end()`'s children-list sweep), and the fixed child that only
waits is bounded by the existing `CHILD_TIMEOUT`, not by an unbounded wait. No way left
to freeze the collector with a `CLONE_PARENT` child.

## 3. RT12-2 — the namespace ends by KILL, and with a killed collector  → CLOSED

RT12-2 was: the namespace ended only when the anchor noticed its control pipe closed,
and a process could stop the anchor from noticing (hold the pipe, ptrace-stop it, or
keep it busy with fork); a killed collector then left everything alive. Against the
repaired collector (`rt12-2-anchor.txt`):

| attack | repaired `4f55003` |
|---|---|
| `pipehold` (reopen the collector's control pipe for writing) | `(0, b'fixed')` in 0.024 s, nothing left |
| `pipehold-zombie` (T7-1 zombie + pipe hold) | `(0, b'fixed')` in 0.032 s, nothing left |
| `stopanchor` (ptrace-SEIZE + INTERRUPT the anchor — **the ptrace succeeded**, `seize=0/0`) | `(0, b'fixed')` in 0.024 s, nothing left |
| `stopanchor-zombie` | `(0, b'fixed')` in 0.025 s, nothing left |
| busy-anchor storm, 4000 sleepers + 4 fork chains (held eed4c9b 5/5 for the bound) | returns in 5.19 s (the stand-in's 5 s lapse + teardown), nothing left |
| killed collector, storm_kill 8000 sleepers + 4 chains | fixed child gone **730 ms** after the collector's death |
| — same, eed4c9b control | fixed child lived **10607 ms** |

The repair sends the anchor one SIGKILL from `end()` regardless of the pipe or the
anchor's state, and SIGKILL kills even a ptrace-stopped or fork-busy anchor; the
anchor's `PR_SET_PDEATHSIG(SIGKILL)` (proved before any spawn, via the ready byte)
takes the namespace down with a killed collector. Both halves verified directly,
including the case where the attacker's ptrace of the anchor genuinely succeeds.

## 4. RT12-3 and O12-1 — the remote collector's fixed child  → CLOSED

RT12-3 was: the drain is beaten by descendants that only wait (a chain of 60, a herd of
14,000, a fork relay behind a backlog); the run was reported failed, but the processes
outlived the collector. Against the repaired remote collector, fixed child as `ci`
(`rt12-3-remote.txt`, authoritative field = "process left 0.2 s after return"):

| shape | repaired `4f55003` | eed4c9b (control) |
|---|---|---|
| chain, depth 60 | returncode 1, **process left = false**, no child | runtime failure, **process left = true**, 14 alive |
| herd, 14,000 | returncode 0, **process left = false**, no child | runtime failure, **process left = true**, 14,000 alive |
| fork relay (relay4) | returncode 2, **process left = false**, no child | (timing; 0 this run — 9/10 in report 12) |

`fixed_child_setup` sets `RLIMIT_NPROC (0, 0)` on the unprivileged fixed child, so its
first fork/clone gets EAGAIN: the chain, herd and relay cannot start at all, and nothing
is left. A killed collector takes the fixed child with it (O12-1; verified in §3's
storm_kill). (The `ps -u ci` leftover counts in the log are cross-run contamination from
the eed4c9b controls' survivors still being reaped; the per-run harness field is the
authoritative signal, and it is false for every repaired run. Container confirmed clean
afterwards.)

## 5. Section 5 — root and `sudo -n` stated, not hardened  → honest bound, not a finding

The repair documents that root is not bound by `RLIMIT_NPROC`, so for a fixed command
that runs as root (an SSH target that is root, or the root command of the `sudo -n`
path) the drain is the only containment, and the waiting shapes still beat it. I checked
this directly (`section5-root.txt`):

- `RLIMIT_NPROC (0, 0)` does **not** bind root — a root fork under it succeeds.
- chain depth 60 with the fixed command as **root**: the drain is beaten (14 processes
  left), **but** the result is returncode 125, `runtime_failed = true`, capability flag
  **cleared** — a reported runtime failure, never a success with a process alive.

This matches the documents exactly. I agree it is the right call to state rather than
harden, for the reasons the repair gives: a root descendant defeats any per-process
drain anyway (it can raise its own limit, signal the collector, or use host services),
and hardening the drain against waiting shapes would require host-wide signalling of
processes that are not the collector's children, reopening the PID-reuse risk the drain
was designed to avoid. The security property that protects the status result — no success
while a process is alive, no malformed output accepted — holds for the root case too, and
is now tested. The design option (an unprivileged fixed child for the root collector)
would remove the residual at its cause but changes decision D4's privilege model; it is
correctly left out of this PR.

## 6. Nothing new opened

- The happy path still returns correct results: every non-waiting run above returned
  `(0, b'fixed')` / returncode 0 with nothing left; the capability flag is proved.
- The new stray-reaping `end()` introduces no new unbounded wait: a stray that only waits
  is ended by the anchor's KILL and the namespace teardown (verified — `sibling-run`
  and the busy-anchor storm both return bounded), and the children-list sweep ends when
  one list holds no stray.
- The remote `RLIMIT_NPROC (0, 0)` does not harm the real fixed commands (`openssl`,
  `sha256sum`, `stat` do not fork) and the writer's check shows `sudo -n` still forks its
  root shell under the limit; the box brief re-checks that on the box's PAM/sudoers.
- The one test-only commit `700b533..4f55003` (the `AnchorProcess` order fix) does not
  touch the collectors (sha256 unchanged), so it cannot affect behaviour.

## 7. Confidence

- Provenance: high (manifest reproduced byte-for-byte, collectors hash-matched).
- RT12-1 / RT12-2 / RT12-3 closed: high — each original break was reproduced on `eed4c9b`
  as a control in the same run and is gone on the repair, including the ptrace-succeeds
  variant and the killed-collector timing.
- Section 5: high — the residual and the contract that bounds it were both observed.
- That nothing new opened: medium-high — the happy path, the new waits and the limit's
  effect on real commands were checked; the writer's 27 mutants and families add to this.

## 8. For the gate

- Not blocked by the red-team. With the narrow re-audit's acceptance, the scripts/tests
  merge gate is satisfied on the red-team side.
- At the gate, bring in the current `trunk_dev` (`6ce0034` at this close; 13a's trial
  merge is clean and touches no PR file) and re-run provenance on the new head.
- The one Mac and box run stays on hold until the re-audit and this re-check accept;
  the box brief should carry section 5's root/`sudo -n` and the `sudo -n`-under-limit
  checks, as 13a already plans.

## 9. Compliance / scope

Red-team only: no commit, push, PR comment, review or merge by this thread; nothing on
the box. The only changes outside the repo are this report and `15-redteam-recheck-evidence/`.
All probes ran in this container against local copies of the collectors; no token, key,
box data or personal data is in the evidence.

## 10. Evidence

| file | what |
|---|---|
| `provenance.txt`, `00-collectors.txt` | head, manifest, collector hashes |
| `rt12-1-sibling.txt` | RT12-1 sibling / sibling-run, repaired vs eed4c9b |
| `rt12-2-anchor.txt` | RT12-2 pipehold / stopanchor / busy-anchor / killed-collector |
| `rt12-3-remote.txt` | RT12-3 chain / herd / relay, repaired vs eed4c9b |
| `section5-root.txt` | the root / `sudo -n` residual and the failure contract |
| `SHA256SUMS.txt` | sha256 of every evidence file |
