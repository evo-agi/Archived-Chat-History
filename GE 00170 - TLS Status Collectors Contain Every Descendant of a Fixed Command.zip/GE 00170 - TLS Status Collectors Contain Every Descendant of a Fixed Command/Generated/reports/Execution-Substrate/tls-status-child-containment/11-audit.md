# AUDIT 11: PR #30 delta check `0b8b9c0..eed4c9b` (T9-1 fix and trunk_dev merge)

**Verdict: ACCEPT `eed4c9b`.** T9-1 is fixed: no failure path stalls any more. The fix is my diff from audit 09 plus the writer's four changes, and all four are right. The merge of `trunk_dev` `76c030f` contains nothing but that merge. No findings. The red-team can start.

One thing for the merge gate, not for the red-team: `trunk_dev` moved again during this check, to `fdfa3bc` (PR #29). A trial merge is clean (section 5).

## 1. Identity and provenance

| Item | Value |
|---|---|
| Head | `eed4c9b41b37c0e6bf9e33e3ac2b314ca3ef89ea`, tree `c97fc0acf9465ad78e73a3a0cd08c1395d9a8c67`; commits on top of `0b8b9c0`: `514fd2d` (the fix) and `eed4c9b` (merge of `76c030f`), both authored by `Claude <noreply@anthropic.com>` |
| Base | `trunk_dev` `76c030fa7872dd22dda731591878ef284c01bd9b` = merge base |
| Writer report | `10-repair.md`, sha256 `f8edee31e0e5e515e3459cda58713a0dc4bf6e039e4cc148270e57b1943f7f29` |
| Manifest (recipe sha `c08597e2…a3ca` checked before each run) | `ab6da82106b7387a2dce1b3d0f041d3f5bfbf02c889401682ec648a333f9019d`, textual diff `e556b9e2…7a25`, 19 files, the same path set as `0b8b9c0`. Taken twice at open (21:10Z) and twice at close (21:37Z): byte-identical each time and the same bytes as the writer's `10-evidence/manifest-v2.json`; staged tree = the commit's tree |
| CI | run 45259136244 on `eed4c9b`: "build, vet and test" success (20:25 to 20:55Z); root step 3 of 3 on the runner (`ci/check-run-45259136244.txt`) |

## 2. The fix against my diff

I applied `proposed-fix-09.diff` to `0b8b9c0` and compared the result with `514fd2d`. The difference is byte-identical to the writer's `10-evidence/delta-from-proposed-fix-09.diff` (`review/`). It holds exactly the four changes the writer describes:

1. **"without a TERM first" became "without the grace period of TERM before KILL"** (collector comment, three documents, DocumentsContract). The writer is right and my wording was wrong. Right after the release, `terminate_child` sends TERM to the group, and the anchor wakes on the end of its input at about the same moment, so which signal arrives first is a race. The new phrase is true in both outcomes. "Killed by the kernel" is still slightly loose when the TERM wins, but nothing depends on which one wins. Precise enough; no change asked.
2. **Rewrapping** of two paragraphs, with no change to the words.
3. **The anchor's code is pinned whole** in DocumentsContract: the text below the docstring must equal a pinned copy. I checked that the pin compares the whole body and cannot be satisfied by a prefix. It closes O9-1: my A19b (a 2.5 s timer) and a new anchor mutant are now caught (section 4).
4. **Two recorder cases for the outer `except`:**
   - A failed reset after the spawn must release the namespace of a still-running child before the cleanup.
   - After a failed spawn it must release nothing.

   The real `restore()` never raises an `Exception` (it records the failure instead), so a raising recorder is the only way to reach that path. That is fine for a defensive path. These cases now kill the mutant that drops the outer release; my diff did not (section 4).

The collector itself has the three `namespace.release()` calls, each directly before a cleanup owner call. The path without a spawned child has no release and no cleanup. `terminate_child`, `own_child_until_proved`, the hold, the reap and the absence scan are unchanged.

## 3. The merge

- `git merge-tree --write-tree 514fd2d 76c030f` gives tree `c97fc0ac…`, the tree of `eed4c9b`. So the merge commit is the plain merge, with no edits of its own.
- The merge changed four of the PR's files, all from PR #27: the noninteractive remote collector, its test, its document, and `PLANS.md`. The other 15 are byte-identical to `514fd2d` (`review/merge-check.txt`).

## 4. Behaviour, tests, mutants

**Hold fixture of audit 09** (`hold2.py`, as root, real namespace, CHILD_TIMEOUT 1.5 s for the failure modes). Nothing was left afterwards:

| Mode | 0b8b9c0 | eed4c9b |
|---|---|---|
| `zombie`, `qalive`, `reaps` (normal path) | 0.33 s | 0.33 s, 0.35 s, 0.33 s, `(0, b'fixed', b'')` |
| `zombie-to`, `qalive-to` (fixed child still runs at the time limit) | held 20 s | `child_timeout` in 1.53 s |
| `zombie-held` (fixed child ended, output held open) | held 20 s | `child_timeout` in 1.54 s |
| `zombie-over` (output overflow, fixed child still runs) | held 20 s | `child_output_overflow` in 0.33 s |

**Tests:**

| Check | Result |
|---|---|
| Every ChildNamespace test as root (9) | 9 pass; RealDescendants 5.5 s |
| Root-collector selection as `ci` | only the 7 baseline failures, the same names as at `0b8b9c0` |
| Remote-collector selection as `ci` (the remote collector changed through the merge) | only the 11 baseline failures, same names |
| Root package as `ci`, vs my `0b8b9c0` run | 2,272 shared results, no verdict changed. 7 new results, all pass, all from PR #27: 3 tests and 4 subtests. Totals 2,041 pass, 3 skip, 235 fail (the 235 are this container's) |
| CI root step emulated as root (`rootstep30.py`) | 3 of 3 pass |
| `go vet .` linux/amd64 and darwin/arm64; `gofmt -l` on the changed Go files; Python parse of the collector | clean |

**Mutants** (fresh clone of `eed4c9b` each; root-collector selection as `ci` plus every ChildNamespace test as root, or the remote selection as `ci`):

| Mutant | Change | Caught by |
|---|---|---|
| FPI | inner failure-path release removed | FixedCommand, DocumentsContract; as root RealDescendants (both new cases ran to the 15 s lapse) |
| FPO | outer failure-path release removed | FixedCommand (the writer's new case), DocumentsContract |
| FPO2 | outer release moved after the cleanup | FixedCommand, DocumentsContract |
| OLD9 | `0b8b9c0`'s collector under the new tests | FixedCommand, DocumentsContract; as root RealDescendants |
| C1 | normal-path release moved after the cleanup | FixedCommand, DocumentsContract; as root RealDescendants |
| A19b | anchor ends with status 0 after 2.5 s (survived in 09) | DocumentsContract (anchor pin) |
| ANCHOR | anchor also ends with status 0 on a data byte | DocumentsContract (anchor pin) |
| B20 | probe closes the hold pipe before the drain | Probe, RealKernel |
| B01 | a live child counts as proof (merged remote collector) | Drain, Probe, RealKernel, RunCommand, DocumentsContract |

9 of 9 caught. I did not rerun the rest of my set from 09. The `ChildNamespace` class, the anchor and the R2 code are unchanged since `0b8b9c0`, where those mutants were caught, and their tests only gained cases.

## 5. trunk_dev moved during this check

At close, `origin/trunk_dev` was `fdfa3bc` (PR #29). PR #29 shares one file with PR #30, `PLANS.md`, at line 965; PR #30's hunks start at line 2353. `git merge-tree --write-tree eed4c9b fdfa3bc` is clean (tree `7e8ec3a5…`). The branch must be brought up to date before merge; the ruleset enforces that, and CI runs again then. I don't expect an interaction, but that update gets the usual manifest and CI.

Report 10's section 5 is about PR #35: the root step's `PATH` must gain the sbin directories in whichever PR lands second. It is outside this diff. I agree it is enforced by machine, through the required check plus up-to-date branches.

## 6. Not covered

The box and the Mac (brief `10-mac-and-box-brief.md`, not reviewed here; the coordinator plans that run after the red-team). The full-module suite.

## Evidence

`11-audit-evidence/` (SHA256SUMS inside):

- `provenance-open/` and `provenance-close/`
- `review/`: `delta-from-proposed-fix-09.diff` and `merge-check.txt`
- `probes/hold-eed4c9b.txt`
- `mutants/`
- `validation/`: `a32-steps.log`, `root-step.log`, `compare32.txt`, the root package summary, and the vet and gofmt logs
- `ci/`
- `scripts/`

STATUS: READY
