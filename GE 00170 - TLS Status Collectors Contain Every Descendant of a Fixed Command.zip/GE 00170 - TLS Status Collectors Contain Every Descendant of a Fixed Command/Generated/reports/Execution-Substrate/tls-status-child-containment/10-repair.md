# REPAIR: re-audit 09 finding T9-1 on PR #30, and the update with trunk_dev 76c030f

**T9-1 is fixed: on every path after the spawn, the root collector now ends the fixed command's PID namespace before the process-group cleanup runs, so no failure path can stall on a descendant that keeps an ended child in the group. I applied the auditor's tested diff after review, with four changes of my own (section 3). Then I merged trunk_dev `76c030f` into the branch, with no conflicts. New head `eed4c9b`, manifest `ab6da821…019d` against base `76c030f`, 19 files (the same path set as before). Next: a delta check of `0b8b9c0..eed4c9b` by the auditor, then the red-team, then the one Mac and box run (brief `10-mac-and-box-brief.md`, which replaces 08's).**

Written 2026-11-23 by the writer thread "Contain TLS status collector child processes". Earlier reports in this folder: 01 to 09.

## 1. Identity

| Item | Value |
|---|---|
| Repository | `evo-agi/Execution-Substrate`, draft PR [#30](https://github.com/evo-agi/Execution-Substrate/pull/30) |
| Base | `trunk_dev` `76c030fa7872dd22dda731591878ef284c01bd9b` (was `036d507`; trunk_dev gained #26 `8ba1edb` and #27 `76c030f`) |
| Topic branch | `claude/project-thread-wbmulu` |
| Previous head (re-audited in 09) | `0b8b9c034f1b65c938e24e7edc6f07f66b9dab94` |
| New head | `eed4c9b41b37c0e6bf9e33e3ac2b314ca3ef89ea`, two commits on top, fast-forward push: `514fd2d` (the T9-1 fix) and `eed4c9b` (merge of `76c030f`) |
| Tree | `c97fc0acf9465ad78e73a3a0cd08c1395d9a8c67` |
| Recipe | `governed-execution.audit-patch-manifest.v2`, source SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca` (checked before the run; `operating-protocol/tools/`) |
| Textual diff SHA-256 | `e556b9e28b8e4cd4b475016181452af14e487a494144a6cbb6e2845218b17a25` |
| Canonical manifest SHA-256 | `ab6da82106b7387a2dce1b3d0f041d3f5bfbf02c889401682ec648a333f9019d` |
| File count | 19 (the same path set as `0b8b9c0`) |

Flow: both commits made, TIP recorded, `git reset --mixed 76c030f`, upstream pinned to `origin/trunk_dev`, the manifest taken twice to a fresh 0700 directory (byte-identical), `git reset --mixed` back to TIP, `git status --porcelain` empty. `git diff --name-only 76c030f eed4c9b` equals the manifest path set, and all 19 committed blobs match the manifest's SHA-256 and size. The complete manifest is `10-evidence/manifest-v2.json`.

## 2. The T9-1 fix (`0b8b9c0..514fd2d`, 5 files)

**Root collector** (`scripts/internal/remote_alpha_es_tls_status.py`). `_run_fixed_in_namespace` now calls `namespace.release()` directly before each of its three cleanup owner calls:

1. the normal path (unchanged since `0b8b9c0`);
2. the inner `except` (timeout, interruption, output overflow, any failure in the read loop or after it);
3. the outer `except` when the fixed child exists (`child_run_unproved`, for example a failed reset after the spawn, or a fault that escapes the inner handler).

When nothing was spawned (`proc is None`), there is no release and no cleanup; `close()` in `run_fixed` ends the namespace, as before. `release()` closes the control pipe at most once and catches its own failures (it sets `release_failed` and `unproved`, which `close()` then reports), so a second call does nothing. If a `BaseException` interrupts the release on path 1 or 2, the next handler releases again (a no-op for the closed end) and runs the cleanup owner. The process-group logic (`terminate_child`, `own_child_until_proved`, the hold, the reap, the absence scan) is unchanged.

What this changes in behaviour, on the failure paths only: a fixed child that still runs at a failure, and anything else in its namespace, is killed by the kernel when the anchor sees the end of its input. The cleanup owner still sends TERM to the group right after the release, and the anchor ends as soon as it reads the end of its input (its `select` wakes on it at once), so the kernel's kill comes at about the same moment; which of the two arrives first is a race. Either way there is no grace period of TERM before KILL. The command is incomplete on these paths, so nothing the child could still write counts.

**Docs.** `PLANS.md`, `.docs/system_overview/remote_supported_host_alpha.md` (step 6 of the rule and the limits list) and `.docs/system_overview/remote_alpha_access_contract.md` now state one order for every path after the spawn. The limit "on a path where the fixed child may still run … holds the invocation until the descendant ends by itself" is removed from all three; the one hold that remains is a process that cannot die.

**Tests** (`remote_alpha_es_service_tls_status_child_namespace_test.go`):

- RealDescendants (root): two new cases, each with the escaped descendant that keeps an ended child unreaped in the fixed child's group, and a time limit of 1 s. In `zombie-run` the fixed child itself still runs at the limit. In `zombie-out` the fixed child has ended, but the descendant keeps its standard output open. Each must end in `child_timeout` with nothing left, no `lapsed` report, and in less than the descendant's 15 s.
- FixedCommand (recorder, every host): the output-overflow and timeout cases now require open, spawn, restore, release, cleanup, close; at the timeout the fixed child must still run when the release comes. Two new cases (mine, section 3): a failed reset after the spawn releases the namespace of a fixed child that still runs before the cleanup; a failed reset after a failed spawn releases nothing.
- DocumentsContract: each `own_child_until_proved(` line of the fixed-command body must directly follow a `namespace.release()` line, three of each; the docs must state the one order and must no longer contain the old limit or "the fixed child may still run"; the anchor's code is pinned (section 3).

## 3. Review of the auditor's diff, and what I changed

I applied `09-audit-evidence/fix09/proposed-fix-09.diff` (SHA-256 `876d5894…efe`) with `git apply`, then reviewed it line by line. The control flow is right: every cleanup owner call that can run with a spawned child now follows a release, and the path without a child gets none. Four changes on top (`10-evidence/delta-from-proposed-fix-09.diff` is the exact difference between the diff applied to `0b8b9c0` and `514fd2d`):

1. **Wording: "without a TERM first" was not accurate.** After the release, `terminate_child` sends TERM to the group at once, while the anchor ends when it is scheduled and reads the end of its input. Which comes first is a race, so a fixed child that still runs may well get a TERM first; what it never gets is the grace period before KILL. (The message of commit `514fd2d` says the TERM comes "a few milliseconds before the kernel kill"; that is too definite, the order is a race. The code, comments, documents and tests say only what holds.) The collector comment and the three documents now say "without the grace period of TERM before KILL", and DocumentsContract requires that phrase. The same imprecise phrase was in `0b8b9c0` for the normal path (a survivor still in the group), so that is corrected too.
2. **Line wrapping.** Two over-long lines in the diff (the access contract and the FixedCommand comment) are rewrapped. The access-contract paragraph is rewrapped as a whole, which also removes an orphaned short line ("No") from `0b8b9c0`.
3. **O9-1: the anchor's code is pinned whole.** DocumentsContract now requires the anchor's code below its docstring to equal a pinned text. An anchor that ends by itself after some time would kill a long command, which would then return `(-9, b'', b'')` as an ordinary result; a test that waits can only bound such an exit up to the length of its own command. The pin closes the class without a slow test. The auditor's A19b (an anchor that ends after 2.5 s), which survived in 09, is now caught.
4. **The second failure path has a behavioural test.** In the auditor's diff, the outer `except` release was checked only by the source pattern of DocumentsContract; removing it (mutant FP-OUTER) left every behavioural test green. The two new recorder cases of section 2 now catch it.

## 4. Update with trunk_dev 76c030f

`git merge --no-ff 76c030f`: no conflicts. trunk_dev's #27 touched four files of this PR, all away from this PR's changes: the noninteractive remote collector (URI SANs in certificate order; the expected operator identity must be the only URI SAN), its document, its test, and `PLANS.md`. Checks:

- For each of those four files, the change the merge brought equals trunk_dev's own change `036d507..76c030f`, line for line.
- The other 15 files of this PR are byte-identical before and after the merge.
- trunk_dev changed nothing under `.github/`, so the workflow pin of the gate self-check (`WORKFLOW_SHA256`) and the root step are unaffected.

The patch relative to its base is therefore the patch of `0b8b9c0` plus the T9-1 fix of section 2; nothing else changed.

## 5. PR #35 (box firewall) and the root CI step

Neither PR has landed. Once both have, the root step of this PR (`.github/ci/go_test_as_root.py`) runs every `skips-itself` test of the root package as root, and PR #35 adds three such tests (`TestRemoteAlphaHostFirewallRealKernelTraffic`, `…RealKernelApplyConfirmRollback`, `…SSHDDropInWithRealSSHD`). The root step empties the environment and sets `PATH=/usr/bin:/bin`. PR #35's lab looks up `ip`, `nft` and `python3` with `exec.LookPath` and fails when one is missing, and on Ubuntu `nft` is `/usr/sbin/nft`. So in the combined tree its two real-kernel tests would fail in the root step; its sshd test falls back to `/usr/sbin/sshd` itself.

Whichever PR lands second adjusts, as the coordinator decided. The adjustment is three lines:

- `.github/ci/go_test_as_root.py`, `ELEVATE`: `PATH=/usr/sbin:/usr/bin:/sbin:/bin` (root's usual system directories; nothing from `/usr/local`);
- `.github/ci/go_test_gate_selftest.py`, the two expectations of that PATH (the stand-in binary's check of its environment, and the pattern of the sudo command line).

This is machine-enforced, not a note to remember: the root step is part of the required check "build, vet and test", and the repository requires branches to be up to date, so the second PR cannot merge with a green check until it adjusts. Not checked here: whether the GitHub runner image has `nft` and `sshd` installed at all; that is PR #35's question either way.

## 6. Validation (cloud container: kernel 6.18.44, Python 3.13, Go 1.26.5, test user `ci` with UID 1500)

| Check | Result |
|---|---|
| Mutants of this repair on the final tree, unprivileged and as root (`10-evidence/mutants-10.txt`) | 8 of 8 caught. **FP-INNER** (release removed on the inner failure path): FixedCommand and DocumentsContract, and as root RealDescendants, where both new cases ran until the descendant ended by itself (33.5 s for the test). **FP-OUTER** (release removed on the outer failure path): FixedCommand (the new failed-reset case) and DocumentsContract. **FP-BOTH** (the failure paths of `0b8b9c0`): as FP-INNER. **OLD-ORDER** (no release on the normal path): FixedCommand, DocumentsContract, and as root RealDescendants. **RELEASE-BEFORE-TERMINAL**: FixedCommand, DocumentsContract, and as root RealDescendants and RealCollectorDeath. **A19** (anchor ends after 0.3 s): AnchorProcess and DocumentsContract, and as root RealDescendants. **A19b** (anchor ends after 2.5 s; survived in 09): DocumentsContract, through the anchor pin. **B20**: Probe and RealKernel. |
| Earlier mutants of report 06, re-run on the collector bytes of `eed4c9b` | Root collector 26 of 26 caught, unprivileged and as root; M06 and M14 by the test timeout, as before (`10-evidence/earlier-root-mutants-rerun.txt`). Remote collector 22 of 22 caught, unprivileged (`10-evidence/earlier-remote-mutants-rerun.txt`). Every mutant text still applied. |
| Whole root package as `ci`, `go test -count=1 .`, final tree `c97fc0a` | 483 pass, 8 fail, 3 skip. Against `0b8b9c0`: the same 8 failures (the container-only entries of `environment-only-tests.txt`, see report 08) and the same 3 skips (the `skips-itself` PID-namespace tests); the 3 more passes are the 3 root-package tests that trunk_dev's #27 added (`10-evidence/whole-package-summary.txt`) |
| Every ChildNamespace test as root (9), final tree | 9 pass; RealDescendants 5.5 s (`10-evidence/childns-root.txt`) |
| `go_test_gate_selftest.py` as `ci` | 132 of 132 (`10-evidence/gate-selftest.txt`) |
| `go_test_as_root.py` (the CI root step) as `ci` through sudo | 3 of 3 pass (`10-evidence/root-step.txt`) |
| `go vet ./...`, linux/amd64 and darwin/arm64 | clean (`10-evidence/vet.txt`) |
| Box probe (`10-evidence/pr30_box_probe.py.txt`), tried here | root part on `eed4c9b`'s collectors: probe accepted, `openssl version` 0, `setsid` 0.02 s, `zombie` 0.04 s, `zombie-run` `child_timeout` at 1.02 s with no `lapsed`, `slow` 1.03 s, nothing left, nothing unproved. The same probe on `0b8b9c0`'s collectors: `zombie-run` 30.08 s with `lapsed`. R2 part as `ci`: probe accepted, drain left nothing (`10-evidence/box-probe-tries.txt`) |
| GitHub CI on `eed4c9b` | "build, vet and test" succeeded, run [45259136244](https://github.com/evo-agi/Execution-Substrate/actions/runs/45259136244), including the root step |

Not run: the Remote Alpha host and macOS; they wait for the red-team, as the coordinator decided at 18:45Z.

## 7. Box and Mac brief

`10-mac-and-box-brief.md` replaces `08-mac-and-box-brief.md`. Changes: head `eed4c9b`, base `76c030f`, tree `c97fc0a`, the collector sums of the new head (root `b5a1344f…d474`, remote `33e5f4d5…a8c4`; the remote collector changed through the trunk_dev merge), and one more stand-in case in the box probe: `zombie-run`, the T9-1 case, which must end in `child_timeout` after about 1 s. Tried here as root: 1.02 s, nothing left, no `lapsed`; with the collector of `0b8b9c0` the same case took 30.09 s and reported `lapsed`. The R2 part, tried as `ci` in the real launch shape on the new head's remote collector: probe accepted, drain left nothing. Nobody has been asked to run it yet.

## 8. For the delta check

Target: `0b8b9c0..eed4c9b`, with provenance over `76c030f..eed4c9b` (manifest above). The fix is `514fd2d`; `eed4c9b` is the merge. Points worth a look:

- The three changes to the auditor's diff in section 3 (1, 3 and 4), and whether "without the grace period of TERM before KILL" is precise enough.
- The anchor pin: it fixes the anchor's exact text, so any later change to the anchor must change the test with it. That is the intent.
- The new recorder cases drive the outer `except` through a failed `restore()`; a real `setns` failure after a spawn is not reproduced.

## 9. Files

- `10-repair.md` (this report), `10-mac-and-box-brief.md`.
- `10-evidence/`: `manifest-v2.json`, `delta-from-proposed-fix-09.diff`, `mutants-10.txt` (with `mutants-10-apply.py.txt`), `earlier-root-mutants-rerun.txt`, `earlier-remote-mutants-rerun.txt`, `whole-package-summary.txt`, `gate-selftest.txt`, `root-step.txt`, `childns-root.txt`, `vet.txt`, `box-probe-tries.txt`, `pr30_box_probe.py.txt`, `SHA256SUMS`.
