# SYNC: PR #30 with trunk_dev 8789662 and 230954d, for the merge turn

**PR #30 now contains trunk_dev `230954d`. There were two syncs since the last accepted head `1861e23`, and git made both merges itself, with no conflict and no hand edit:**

- **`e4c6434`** merged trunk_dev `8789662`.
- **`cd36797`** merged `230954d` (#45). #45 changes three files, none of them this PR's.

**All six PR commits come out "=" in the range-diff. Against `1861e23`, the PR's changed lines are identical in all 19 files. At `cd36797`, every one of the 19 blobs is identical to `e4c6434`. The manifest against base `230954d` is `4147eb23…1b91`, and its file entries are identical to the entries of the `8789662` manifest.**

**One effect of the merge:** the root step now also runs #35's four root-only firewall tests, so it runs nine tests. Here it passed 9 of 9 once `ip` and `sshd` were installed. On the runner, CI showed that the tools are there. But one of #35's tests, the bridge isolation test, counted 16 dropped frames instead of 15. The runner's kernel has IPv6, and our containers' kernels do not. **The fix is the test-only commit `f76db77`, kept in this PR by the coordinator's decision (11:54Z), because only this PR's root step runs that test (section 4).**

**What blocks the merge, in my assessment, is the auditor's sync check, green CI and the gate. The box and Mac runs come after the merge (section 5).**

Written 2026-11-24 by the writer thread "Contain TLS status collector child processes". It builds on `16-repair.md` and on the auditor's `17-diff-check.md` (ACCEPT `1861e23`).

## 1. Identity

| Item | Value |
|---|---|
| Last accepted head | `1861e23e8dc7ea4f66aa72566ccc28665e731035` (diff check 17, CI green) |
| First sync | `e4c6434ab1db9f03168d4a59359fa0296b769b2b`, with parents `1861e23` and `8789662` (#50). Tree `6f839ede55eab7459392ad29f956f8b4a50b5f27` |
| Second sync, the new head | `cd367971fb1c7cb5095585173b623056bb9510cc`, with parents `e4c6434` and `230954d` (#45). Tree `e84def5c3610192fe8ac837bddd0e9d9121c29a1`, the same as `git merge-tree --write-tree e4c6434 230954d`. Both were pushed as fast-forwards |
| Base | `trunk_dev` `230954d867dd29b60865965dce3d7d0a19bcdf16`. Since `4c991ba` it adds 13 first-parent commits: #43, #42, #34, #31, #38, #44, #46, #12, #48, #35, #49, #50, #45 |
| Recipe | `governed-execution.audit-patch-manifest.v2`, source SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca`, checked before each run |
| Manifest SHA-256 against `230954d` | `4147eb23222ca3013363ea54e8e5712a6efc0d0fe977e9f3ad32346d13311b91`. Two runs into a fresh 0700 folder gave byte-identical output. 19 entries, the same paths as `git diff --name-only 230954d cd36797`, and 19 of 19 match the tip's blobs (SHA-256, size and mode) |
| Manifest SHA-256 against `8789662` (first sync) | `f5136a46ab401a757f3e68ab24c4f0ae8f99c299bf0048956dbffda87dfb6280`. Its `files` list is identical to the `230954d` manifest's list. Only the recorded base differs |
| Textual diff SHA-256 | `bb003736e947ec8adf224ef221c59e29b0626b445affbc6dbcdfe65e7e8348f1`, the same for both bases |
| Collectors | root `c6c2dc75…dd5e`, unchanged since `1861e23`. The remote collector's blob is `432366fa…6273`. It differs from `1861e23` only by trunk_dev's own edits |

## 2. What the merges changed in the PR's files

**First sync, `1861e23` to `e4c6434`** (`18-evidence/sync-8789662/review/patch-comparison.txt`):

- **12 files:** the blob is identical to `1861e23`.
- **7 files:** trunk_dev also changed them, and the PR's own changed lines (`-U0`, the + and − lines only) are identical. The files are:
  - the noninteractive status document;
  - `remote_supported_host_alpha.md`;
  - `environment-only-tests.txt`;
  - `PLANS.md`;
  - the remote collector;
  - the local-boundary test;
  - the noninteractive test.
- **One context line changed:** in the remote collector, one hunk's context line is now `FORBIDDEN_PATTERNS = [` instead of the `URI_SAN_RE` line.

**Second sync, `e4c6434` to `cd36797`** (`18-evidence/sync-230954d/review/patch-comparison.txt`):

- All 19 PR blobs are identical to `e4c6434`.
- `git diff e4c6434 cd36797` is byte-identical to #45's own `git diff 8789662 230954d`: three files, `.docs/system_overview/artifact_hygiene.md`, `artifact_hygiene_test.go` and `runbook_paths_docs_contract_test.go`.

**Range-diff** `4c991ba..1861e23` against `230954d..cd36797`: all six PR commits are "=" (`e3dce37`, `0b8b9c0`, `514fd2d`, `bb6e05a`, `4f55003`, `1861e23`).

**The #49 ratchet:** `TestRootScriptByNameOwnershipChangesStayCounted` counts the by-name chown, chmod and `install -d` lines in `scripts/**/*.sh`. None of this PR's 19 paths is a shell script, so the PR adds no such line. The test passes on the merged tree.

**#35 and the root step:** #35's four root-only tests are `skips-itself` lines of `execution-substrate/scripts`. This PR's root step runs every such line of that package as root. So it now runs nine tests: the five PID-namespace tests and these four:

- `TestRemoteAlphaHostFirewallRealKernelTraffic`
- `…RealKernelApplyConfirmRollback`
- `…RealKernelBridgeIsolation`
- `…SSHDDropInWithRealSSHD`

They need `ip`, `nft` and `sshd`. The step's PATH stays `/usr/bin:/bin`. The firewall tests find `nft` and `sshd` in `/usr/sbin` themselves, and `ip` is at `/usr/bin/ip`. On trunk_dev these four tests only skip, because trunk_dev has no root step. With this PR they run as root on every push. That was the #35 coupling named in report 13, and it needed no change.

## 3. Validation (cloud container, kernel 6.18.44, Go 1.26.5)

**At `e4c6434`** (`18-evidence/sync-8789662/validation/`):

- **Packages `.`, `./scripts/` and `./internal/testutil/` as the unprivileged user (UID 1500):** 580 pass, 8 fail, 13 skip.
  - The 8 failures are exactly the 8 `execution-substrate/scripts` entries of `environment-only-tests.txt` that fail here.
  - 9 of the skips are the `skips-itself` lines of `scripts`.
  - The other 4 skips are trunk_dev's real-Vault and real-SPIRE tests, which need the Vault binary and the SPIRE tarball that CI installs.
- **`go_test_gate_selftest.py`:** 132 of 132.
- **`go vet ./...`:** clean for linux/amd64 and darwin/arm64.
- **Both collector families as root:** 30 pass and 1 skip. The skip is `…RealProcessLimit`, which skips itself because the limit does not bind for root.
- **The root step (`go_test_as_root.py`, as the job user through `sudo -n`):**
  - First run: the five PID-namespace tests passed. Three firewall tests failed with "running as root but ip is missing", and the sshd test skipped. The step requires a pass, so it failed.
  - After `apt-get install iproute2 openssh-server` in this container, it passed 9 of 9 (`rootstep-with-tools.txt`). `nft` was already at `/usr/sbin/nft`.

**At `cd36797`** (`18-evidence/sync-230954d/validation/`): the same results with #45's files in.

- **Packages, as the unprivileged user:** 581 pass, 8 fail, 13 skip. That is one more pass than at `e4c6434`, because #45 adds a test. The failures and skips are the same names as at `e4c6434`.
- **Gate self-test:** 132 of 132.
- **The root step:** passed 9 of 9. `ip` and `sshd` were installed in this container by then.
- **`go vet`:** clean for both targets.
- **Not rerun:** the collector families as root. No file under `scripts/` changed between `e4c6434` and `cd36797`.

## 4. CI

**The CI run on `e4c6434`** was cancelled when `cd36797` was pushed. It was still in its Test step.

**The CI run on `cd36797`** (run 45381241057, `18-evidence/fix-f76db77/ci/cd36797-root-step.txt`):

- Every step passed up to and including "Listed tests still fail".
- The root step ran its nine tests on ubuntu-24.04, so the runner has `ip`, `nft` and `sshd`. Eight passed:
  - the five PID-namespace tests;
  - `…SSHDDropInWithRealSSHD`;
  - `…RealKernelTraffic`, including both IPv6 subtests, which run there;
  - `…RealKernelApplyConfirmRollback`.
- `TestRemoteAlphaHostFirewallRealKernelBridgeIsolation` failed with "the bridge counter must count the fifteen dropped frames, got 16".

**The cause (inference, not measured):** this container's kernel has no IPv6, and here the count is exactly 15 every time. The runner's kernel has IPv6. Lab containers c1 and c2 then send router solicitations and MLD reports on their own schedule. Those frames cross docker0 from one port to the other, and the bridge table's forward hook counts every such frame in `container_to_container`. The auditor reached the same reading independently (`19-sync-check.md`, section 6).

**The fix, `f76db77`** (test-only; 13 added lines in `scripts/remote_alpha_host_firewall_test.go`, `newHostFirewallLab`; diff `18-evidence/fix-f76db77/fix-f76db77.diff`, SHA-256 `28007ff3…3305`):

- Where the kernel has IPv6, the lab sets `net.ipv6.conf.all.disable_ipv6=1` and `net.ipv6.conf.default.disable_ipv6=1` in the c1 and c2 namespaces before their `eth0` exists.
- No lab expectation sends IPv6 from a container. All IPv6 expectations come from `lan` or `box`.
- The layer-2 probe writes its IPv6 frames raw, so the bridge table still has to drop them.
- The exact count of 15 is unchanged, and the root step still runs all nine tests.

**Validation here:** the root step passed 9 of 9, the firewall tests passed as the unprivileged user (they skip themselves there), and `go vet ./scripts/` is clean for both targets. The IPv6 branch runs only where the kernel has IPv6, so CI on `f76db77` is the real check. The coordinator's rule: if the root step still counts wrong, stop and report rather than adjust the count.

**Manifest of `f76db77`** against `230954d`: `66ec78d154042e79efed33179a31878d2369c51d3303f93d7e8ceca921f519f8`. Two runs gave byte-identical output. It has 20 entries: the 19 PR files and the firewall test file. All 20 match the tip's blobs, and the paths match `git diff --name-only 230954d f76db77`. The diff has textual SHA-256 `d7395f73…bff2`.

**Result on `f76db77`:** green (run 45388336474, 11:53Z to 12:35Z). The root step passed 9 of 9 on the runner's IPv6 kernel, and the bridge isolation test counted exactly 15 (`18-evidence/fix-f76db77/ci/f76db77-root-step.txt`). This is one run, and the cause is still an inference. With IPv6 off from the start, the containers send no IPv6 frames of their own, so the count no longer depends on when the kernel sends them.

## 5. What blocks the merge, and what comes after it

**Blocks the merge:**

- the auditor's sync check of `e4c6434` and `cd36797`;
- green CI on `cd36797`;
- the merge gate (head = checked commit, manifest, post-merge bytes).

The audit side is already done: re-audit 14 and diff check 17 accepted the PR, and red-team re-check 15 found nothing ("the red-team does not block merge").

**Comes after the merge: the box run and the Mac run** (`13-mac-and-box-brief.md`). Until now they were listed as required before merge, by the decision of 2026-11-23 02:56Z, which the coordinator reaffirmed at 10:20Z today. The coordinator's merge turn of 11:03Z asks whether they truly block. My assessment is that they do not:

- **What they can find.** The runs check facts of the real host and the Mac:
  - whether the box's sudo, sudoers and PAM let the fixed `sudo -n` commands run under the fixed child's process limit of `(0, 0)`;
  - whether the root collector's namespace probe passes on the box's kernel and Python;
  - the containment probes on that kernel;
  - `kernel.yama.ptrace_scope`, `pid_max` and `TasksMax`;
  - whether any SSH target is root;
  - `pidfd_answers.py`;
  - that the real-kernel tests skip on macOS.
- **How a problem would show.** Each problem the runs could find shows up as an explicit failure of the TLS status check: `runtime_failed`, or `openssl_child_unproved` (reported as unavailable). None gives a wrong status. None lets more descendants escape than today's code, which lost 175 of 178. The facts about ptrace and root targets are stated limits already, and they change no code.
- **Merging does not put the code on the box.** Both collectors reach the box only when an operator runs a TLS status check from a checkout that holds them. `remote_alpha_operator.sh` stages the root collector into a fresh `/tmp` folder on each run, and the noninteractive facade sends the remote collector on standard input. The ES box upgrade installs neither collector. (A first draft of this report said the root collector came with the ES upgrade. That was wrong, and the upgrade's writer corrected it.) So the box run gates the first TLS status check from such a checkout, not the merge.
- **If the box finds a problem,** the fix is a follow-up PR with its own audit. That would be the same work as a repair inside this PR.
- **The cost of holding the merge.** The Mac is offline, so holding the merge means more syncs, and each sync needs an auditor check and a CI run.

**The trigger, so this is not a "revisit later":**

- **The coordinator's decision.** At 11:10Z the coordinator agreed and lifted the hold. At 11:13Z it made the run **P30**, its own turn in the box queue. P30 gates the first TLS status check on the box from a commit that contains PR #30.
- **The gate file.** Its commands and pass criteria are in `p30-gate-moved-from-es-upgrade-plan.md` in this folder. The file was briefly section 4a of the ES box upgrade plan, and that plan now points to it.
- **The brief.** It is revised for the merged commit when the box turn comes.

## 6. Files

- Repository: merge commits `e4c6434` and `cd36797` (section 1).
- Project folder: this report, and `18-evidence/` with `sync-8789662/` and `sync-230954d/` (each with `provenance/`, `review/` and `validation/`) and `SHA256SUMS.txt`.
