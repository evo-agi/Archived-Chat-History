# ASSESSMENT: a root-side contained runner for the `sudo -n` path of the noninteractive remote collector

**Verdict: not included. It needs a host change or widens what the host's sudo policy must grant, and it would not be the root collector's containment. I recommend keeping R2's stated limit: a root descendant is detected and the check is reported unavailable.**

Written 2026-11-23 by the writer thread "Contain TLS status collector child processes", in answer to the coordinator's request of 15:25Z (R2 chosen). Measurements are in `04-evidence/` (`out/wrap-*.json`, `out/summary.txt`, `README.md`), cloud container only.

## 1. The only shape that needs no new code on the host

A runner under `sudo -n` must be an executable the host already has. A Python runner would be `sudo python3`, which section 9 of `.docs/remote_alpha_operator_healthcheck_noninteractive_status.md` forbids. A new compiled runner would have to be installed on the host. The one existing tool is util-linux `unshare`:

`/usr/bin/sudo -n /usr/bin/unshare --pid --fork --kill-child -- <fixed argv>`

Measured with the R2 prototype, 49 runs through `sudo -n` as an unprivileged user:

| Case | Without the wrapper (from 04) | With the wrapper |
|---|---|---|
| Command ends; root descendant that stays in the group, leaves it, or is a fork relay (without the wrapper: both Python relays; with it: the Python relay in the group and the C relay with `setsid`) | 40 of 40 escape (detected only) | **0 of 40 escape**, proved empty |
| Command ends at once, root descendant holds stdout | 3 of 3 escape after a 10 s timeout | 0 of 3, normal end in 0.03 s |
| Command itself ignores SIGTERM and runs on (timeout path), descendant in the group or leaving it | 6 of 6 escape | **6 of 6 still escape** (detected only) |

The wrapper ends every root descendant when the command ends: the command is the first process of the new namespace, and the kernel kills the namespace when it ends. It does not help when the command itself hangs and ignores SIGTERM. `sudo` forwards the collector's SIGTERM to `unshare`. `unshare` does not end from it, and the command, as the first process of its namespace, ignores it. Nothing unprivileged can send SIGKILL to a root process, and `sudo` cannot forward one.

## 2. Why it is not a proper fit

1. **Host change or a wider grant.** The elevated executable becomes `/usr/bin/unshare` instead of `openssl`, `sha256sum` or `stat`. On a host whose sudo policy grants the operator user exactly the 11 current argv, the wrapped argv are refused. The `sudo -n` path then reports `noninteractive_auth_required` until someone changes the sudoers file. Section 9 says the route adds and modifies no sudoers configuration. On a host with a broad grant it works unchanged. Unknown: what the Remote Alpha host grants the SSH target user (`sudo -n -l` as that user would show it).
2. **Authority shape.** In the source, each wrapped argv is still fixed and does no more than the current command plus a namespace that narrows it. On the host side, a policy that permits it must name a general process launcher that runs as root with `CAP_SYS_ADMIN`. A loosely written rule for it (`/usr/bin/unshare *`) gives root to anything. That is a new kind of elevated executable next to the "no interpreter, no shell" rule of section 9. I count it as widening.
3. **Not the root collector's containment.** The root collector puts an anchor first and the fixed command second (decision D2). With `unshare --fork` the command itself is the first process: the shape D2 rejected. Measured here: a root command that ignores SIGTERM cannot be ended. The anchor shape needs code of ours on the root side, which point 1 rules out.

## 3. Recommendation

Implement R2 as decided, without the wrapper. State the limit in the contract (section 8 or 9 of the noninteractive status document and `PLANS.md`): an unprivileged collector cannot end a root descendant of the `sudo -n` path; it detects one, reports the check unavailable, and the process outlives the collector. This is a lasting limit of the design "unprivileged collector, fixed argv through `sudo -n`", not a temporary edge, and every occurrence shows as a failed check.

If David later wants root descendants ended, the choice is his. Either the host grants exactly the 11 wrapped argv (contains everything but a hanging root command), or the collector's design changes (for example, a root-owned runner installed on the host). Both change section 9.

## 4. The two smaller questions of 04

- Q1, ES-6 drift test: a test-only PR right after this one merges. No authority change.
- Q2, local facade: out of scope, named in the PR's "Not done" list. No authority change.

## 5. Envelope

- Nothing pushed by this note. Effect status: `ASSESSMENT_ONLY` | `NOTHING_PUSHED` | `NO_PR`.
- Confidence: that the wrapper ends root descendants when the command ends, 0.9 (43 runs, this container). That it cannot end a hanging root command that ignores SIGTERM, 0.9 (6 runs; follows from the kernel's rule on signals to a namespace's first process). That it needs a sudoers change on the Remote Alpha host: Unknown, depends on that host's sudo policy.
