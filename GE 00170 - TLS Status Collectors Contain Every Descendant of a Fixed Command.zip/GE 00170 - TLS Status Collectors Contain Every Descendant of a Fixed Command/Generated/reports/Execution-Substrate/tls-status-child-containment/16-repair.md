# REPAIR: re-audit 14 finding A14-1 and observation O14-1 on PR #30

**A14-1 is fixed. The remote collector's design document (§8, in its rule and in its limits paragraph) and PLANS.md (P0v) now say that the fixed child's program can undo its own parent-death request. A changed binary that does so outlives a killed collector, as one process that the process limit still keeps from starting any other. The descendant documents contract pins both new sentences and refuses the old wording in each document. O14-1 is done too: the stand-in of the real collector-death test ignores TERM before it reports, so the case now requires the parent-death signal to be a KILL by behaviour. Audit 14's mutant Y09 (TERM instead of KILL) is now caught by that test as `ci` and as root, not only by the pin. Docs and tests only; the collectors are byte-identical to `4f55003`. New head `1861e23`, manifest `9cb8ec53…b122` against base `4c991ba`, the same 19 paths. Next: the auditor's diff check of `4f55003..1861e23`, then the merge queue.**

Written 2026-11-24 by the writer thread "Contain TLS status collector child processes". It builds on `13-repair.md`, `13a-validation.md`, `14-re-audit.md` (ACCEPT `4f55003` with A14-1) and `15-redteam-recheck.md` (ACCEPT `4f55003`, no finding).

## 1. Identity

| Item | Value |
|---|---|
| Previous head (re-audit 14, red-team re-check 15) | `4f55003b81580acec19f2cbe5bf1f6db4859afe1` |
| New head | `1861e23e8dc7ea4f66aa72566ccc28665e731035`, one commit on `4f55003`, fast-forward push |
| Tree | `9e5d7f67e1300d05a25aaf83fad647d4cf2bece6`; the tested copy's tree is the same (`16-evidence/validation/sync.txt`) |
| The commit | 3 files, +31 −17: `.docs/remote_alpha_operator_healthcheck_noninteractive_status.md`, `PLANS.md`, `scripts/remote_alpha_operator_healthcheck_tls_status_noninteractive_descendants_test.go`. Diff `16-evidence/diffs/a14-1861e23.diff`, SHA-256 `3f296341cab9f3ca905a2b0657cb434571c697b582ee41333a6b3d2b0cbde957` |
| Base | `trunk_dev` `4c991ba1c43ac135d9d94853696d14a21523a690`, unchanged |
| Recipe | `governed-execution.audit-patch-manifest.v2`, source SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca` (checked before the run) |
| Canonical manifest SHA-256 | `9cb8ec53add1096b775d2fda8064244e6d80c135f0e4bd0e793e9bc60b25b122` |
| Textual diff SHA-256 | `689ae6174f569218e783dad7974bb4ed774595436979e902d8b65b03d1493441` (it changes because the two documents are tracked files of the base) |
| File count | 19, the same paths as `git diff --name-only 4c991ba 1861e23`; every entry's SHA-256, size and mode match the tip's blobs (19 of 19) |
| Collectors | root `c6c2dc75…dd5e`, remote `db471490…ebdc8`, unchanged |

The flow is the same as in reports 13 and 13a: the recipe ran twice into a fresh 0700 directory and gave byte-identical output. Logs are in `16-evidence/provenance/`.

## 2. A14-1: the documents

The audit's wording was taken as given, with one change: PLANS.md lists the limit among its stated limits, in the same form as its other entries.

- **Design document §8, rule bullet:** "… so it can have no descendant, and a collector that is killed takes it along unless the program itself undoes that request."
- **Design document §8, limits paragraph,** after the `sudo -n` sentence: "The fixed child's program can undo its own parent-death request; a changed binary that does so outlives a killed collector, as one process that the process limit still keeps from starting any other."
- **PLANS.md P0v:** "… so that an unprivileged fixed child can start no process or thread and dies with a killed collector unless its program undoes that request itself." The stated limits gain: "a changed binary can undo its own parent-death request and then outlives a killed collector, as one process that the process limit still keeps from starting any other".
- **Pins** in `…DescendantDocumentsContract`:
  - The §8 section must contain both new sentences and must no longer contain "takes it along.".
  - The PLANS section must contain both new phrases and must no longer contain "dies with a killed collector.".
  - With the old wording put back, the test fails for each document (`old-wording-design.txt`, `old-wording-plans.txt`).

No other document makes this claim for the remote collector. The other "killed collector" sentences in `remote_supported_host_alpha.md`, `remote_alpha_access_contract.md` and PLANS.md are about the root collector's anchor, whose ptrace limit is already stated (re-audit 14, section 9).

## 3. O14-1: the collector-death case requires KILL by behaviour

The real collector-death test used the shared `standin()`, which a TERM also ends. So a parent-death signal of TERM (audit 14's Y09) passed the test and was caught only by the text pin. The test now builds its own stand-in. It ignores TERM before it writes its byte to the FIFO, so no TERM can come before that. Only a KILL ends it, and its loop is otherwise the same. The control case (a setup that does nothing) is unchanged: the fixed child outlives the collector until the probe releases it. The comment above the test says this, and it adds the changed binary that undoes the request to the stated limits.

## 4. Validation (cloud container, kernel 6.18.44, Python 3.13.18, Go 1.26.5; `16-evidence/validation/`)

- Test binary built; `go vet ./scripts/` for linux/amd64 and darwin/arm64 clean; `gofmt -l scripts/` printed nothing.
- Remote collector family (`TestRemoteAlphaOperatorHealthcheckTLSStatusNoninteractive(Descendant|RemoteCollector)`): as `ci` 13 pass; as root 12 pass and 1 skip (`…RealProcessLimit`, which skips itself where the limit does not bind).
- `…DescendantRealCollectorDeath` with `-test.count=10`: 10 of 10 pass as `ci`, and 10 of 10 as root.
- **Y09** (the fixed child's parent-death signal is TERM): caught by `RealCollectorDeath` and `DocumentsContract`, as `ci` and as root. The failing case is "a killed collector takes its fixed child with it", with `(True, False, b'')`: the stand-in was still there after the collector's death.
- Root package `.` and `internal/testutil` (the documents tests): pass. The `scripts` tests that match `Doc|Contract|Plans|PLANS`: pass.
- Box probes: the throwaway dump of report 13 still applies at `1861e23`. Only the remote collector-death probe changed: its SHA-256 is now `d0a03105…cd62`; the other nine are unchanged (`probe-sums-1861e23.txt`). Run like the rehearsal, it passes 2 of 2 on the repair and fails its first case on `eed4c9b`, as before (`rehearsal-remote-collector-death.txt`).

I did not rerun the whole packages or the mutants of report 13. This commit touches no collector and no test outside the remote descendant file. In that file it changes only `DocumentsContract` and the collector-death stand-in, and both ran above.

## 5. Brief

`13-mac-and-box-brief.md` is updated for head `1861e23` (tree `9e5d7f6`) and the new probe sum, with a status line. The run stays on hold until the diff check and the queue allow it.

## 6. Not done

- trunk_dev `6ce0034` is not merged. Per the coordinator, the PR syncs only when it is its turn in the merge queue (#31, #34, #38, #44, #45, #35, then #30). The sync then also redoes the provenance and the brief's head.
- The PR #35 coupling (root step PATH and package) is unchanged from report 13: whichever lands second adjusts it. In the current queue that is #30.

## 7. Files

- Repository: commit `1861e23` (section 1).
- Project folder:
  - this report;
  - `16-evidence/` with `provenance/`, `diffs/` and `validation/`, and `SHA256SUMS.txt`;
  - the updated `13-mac-and-box-brief.md`.
