# AUDIT 09: PR #30 repair `0b8b9c0`, narrow re-audit of audit 07's findings

**Verdict: ACCEPT `0b8b9c0`.** The repair does what report 08 says, and nothing else changed. T7-2 and T7-3 are closed. T7-1 is closed for a fixed child that ended normally.

**On the question asked (keep the failure-path hold as a stated limit, or fix it now): fix it now, before the red-team.** It is not a compromise. The fix is two lines in the collector, the same kind of change as the order change the coordinator approved at 17:43Z, and the process-group logic stays untouched. It does **not** need audit 07's option (b). A tested diff is attached (section 4).

| Finding | Severity | What | Asked |
|---|---|---|---|
| T9-1 | Low | The rest of T7-1. On every failure path after the spawn (time limit, interruption, output overflow, any later fault), the cleanup still runs before the namespace ends. There, a descendant that left the group and keeps an ended child unreaped in it holds the invocation until the descendant ends by itself. Measured: held for the full 20 s in all four variants I tried | Fix now with `proposed-fix-09.diff`: release the namespace before the cleanup on every path after the spawn. Then a narrow re-audit of that change and the red-team |
| T9-2 | Nit | The three documents, the PR body and report 08 justify the failure-path order with "the fixed child may still run". That is not always true: in the time-limit case where a descendant holds the fixed child's output open, the fixed child has already ended and the hold happens anyway | Goes away with T9-1's fix. If the limit stays instead, reword it |

STATUS line and next steps are at the end.

## 1. What was audited

| Item | Value |
|---|---|
| PR | [#30](https://github.com/evo-agi/Execution-Substrate/pull/30), draft, base `trunk_dev` |
| Head | `0b8b9c034f1b65c938e24e7edc6f07f66b9dab94` on `claude/project-thread-wbmulu`, tree `1b6457746bc6aac57a60cf6819f97a6ce78fad94`; parent `e3dce37` (audited in 07) |
| Base | `trunk_dev` `036d50724b499b020c5149c55ad902cfcb1482c0` = merge base; `origin/trunk_dev` was `036d507` at open and `8ba1edb` at close (section 2) |
| Writer report | `08-repair.md`, sha256 `5a2907653faf0abba0dee08384f254fea0fc4be8a32d3c6c968ad7c1bad75332` |
| Repair diff `e3dce37..0b8b9c0` | 7 files, +273/−47: collector +7, namespace tests +152/−26, descendant tests +51/−2, one stand-in line, three documents (+62/−18) |
| Recipe | `governed-execution.audit-patch-manifest.v2`, source sha256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca`, checked before every run |
| Scope | Narrow: the repair diff, the three findings, and the coordinator's question about the failure-path limit. Not repeated: the whole-PR review of 07 |

## 2. Provenance

Recipe run twice per pass in `/opt/audit/prov-repo` under umask 022, reset `--mixed` to the merge base with upstream `origin/trunk_dev` (scripts/prov31.sh, which also checks that `036d507` and `e3dce37` are ancestors of the head).

| | Open (18:50Z) | Close (20:05Z) |
|---|---|---|
| Canonical manifest sha256 | `bdcec349e996375fadb3e2fe0b22d00fca9a88cceeaf4c491eb38574d26ecffe` | `bdcec349…cffe`, the same |
| Textual diff sha256 | `824d6d174e91bc3e2407a4bf13fd446117a3590679bdb5a72749ec277e48e3d2` | `824d6d17…e3d2`, the same |
| File count | 19 | 19 |
| Two runs byte-identical | yes | yes |
| Same bytes as the writer's `08-evidence/manifest-v2.json` | yes (`cmp`) | yes (`cmp`) |
| Staged tree after `git add -A` | `1b645774…` = the commit's tree | the same |
| Merge base | `036d507` = `origin/trunk_dev` | `036d507`; **`trunk_dev` itself moved to `8ba1edb`** (PR #26, 4 test files in `es/admission/`) |

`trunk_dev` moved during the audit. PR #26 and PR #30 share no file, and a trial merge of `0b8b9c0` with `8ba1edb` is clean (tree `b6acc0ee…`). The branch must still be brought up to date before merge (the ruleset requires it), and CI then runs again; that update is the writer's, with a fresh manifest.

## 3. The repair, finding by finding

### T7-1, normal completion: closed

The collector now calls `namespace.release()` right after the read loop and right before `own_child_until_proved(proc)`, on the normal path only. I read the change against the loop condition. The loop ends only when the selector is empty (stdout and stderr at end of input, stdin and the trust-anchor pipe written) **and** `leader_terminal(proc)` holds, so the release can never kill a fixed child that is still running on this path. The fixed child stays the collector's unreaped child (WNOWAIT), so its PID and PGID stay reserved while the namespace dies. `release()` is idempotent, `close()` calls it again, and a failed release is reported by `close()`, which then sends the anchor its KILL at once (writer's Sequence and FixedCommand cases).

My hold fixture from 07 (`hold2.py`, now with failure-path modes), as root, real namespace, 20 s limit per run:

| Mode | e3dce37 (07) | 0b8b9c0 |
|---|---|---|
| `zombie`: descendant setsid, keeps an ended child unreaped in the group, fixed child ends normally | held 20 s | **returned in 0.33 s**, `(0, b'fixed', b'')`, nothing unproved |
| `qalive`: the same, the child alive until the group KILL | held 20 s | **0.33 s**, same result |
| `reaps` (control: the descendant reaps its child) | 0.34 s | 0.33 s |

Evidence: `probes/hold-0b8b9c0.txt`.

### T7-1, failure paths: still open by design (T9-1 below)

| Mode (CHILD_TIMEOUT 1.5 s) | 0b8b9c0 | With the two-line fix (`probes/optC.diff`) |
|---|---|---|
| `zombie-to`: as `zombie`, the fixed child keeps running, so the time limit fires | **held 20 s** | `child_timeout` in 1.54 s, nothing unproved |
| `qalive-to`: as `qalive`, the fixed child keeps running | **held 20 s** | `child_timeout` in 1.54 s |
| `zombie-held`: the fixed child ends, the descendant keeps its stdout open | **held 20 s** | `child_timeout` in 1.54 s |
| `zombie-over`: the fixed child overflows its output limit and keeps running | **held 20 s** | `child_output_overflow` in 0.33 s |

While held, the tree is exactly the T7-1 shape: the fixed child is the collector's zombie (reserved), the escaped descendant lives in its own session, and its unreaped child is a zombie in the fixed child's group (`probes/hold-0b8b9c0.txt`). This matches the documented limit. `zombie-held` is the case behind T9-2.

### T7-2: closed

New tests: the anchor-process test requires the anchor to still be waiting after 50 poll periods (1 s) without the end of its input, and a real test as root (`slow`) runs a fixed command that writes its output after 1 s and must return it. Mutant A19 (anchor ends with status 0 after 0.3 s) is now caught, by AnchorProcess as `ci` and as root and by RealDescendants as root. A later timer (A19b, 2.5 s) is not; see O9-1.

### T7-3: closed

The model's `close()` now ends the grandchild when the hold pipe's write end closes (as the real grandchild does), and two new model cases require the kill before `close(hold_write)` and, after a failed probe, the close first and a reap without a signal. The real-kernel test runs the real probe through a recording wrapper of the real backend and requires that the kill comes before `close(hold_write)` and that the grandchild's wait status is SIGKILL. The ordering check is deterministic (a recorded sequence), not a race. I checked that the model change does not weaken an older case: "a grandchild that cannot be killed" still ends with `not_drained`. Mutant B20 is now caught, by Probe and RealKernel as `ci`.

## 4. The coordinator's question: keep the failure-path limit, or fix it now

### What the limit is

On a failure path after the spawn, the cleanup owner runs while the namespace is still open. A descendant of the fixed child that leaves the group (`setsid`), ignores TERM, and keeps a child of its own in the fixed child's group without reaping it, holds `terminate_child`'s unbounded loop until the descendant ends by itself. The invocation holds with the status lock.

### Why accepting it would not be a correctness defect

- It fails closed: no result, no released lock while a process of the command lives.
- It is reachable only by a fixed command that forks, leaves its group, and keeps an unreaped child behind, so only by a changed or hostile `openssl` (or something it loads) running as root. Such code can do much worse than hold a status call.
- An operator who kills the collector ends everything: the control pipe closes with the collector, and the kernel empties the namespace.
- The documents state the limit, apart from the wording point T9-2.

### Why I still recommend fixing it now

1. **The fix is small and does not reopen D4.** Report 08 says that removing the limit "would mean ending the namespace inside the unbounded part of `terminate_child` (audit option b)". That is not so. Releasing the namespace before the cleanup owner on the failure paths too, exactly as 0b8b9c0 already does on the normal path, removes the hold. `terminate_child`, `own_child_until_proved`, the hold, the reap and the absence scan stay byte-identical. The collector change is two `namespace.release()` lines (plus comments).
2. **The only behaviour it gives up carries no value.** A fixed child that still runs at a failure is killed by the kernel's KILL instead of TERM, a grace period, then KILL. On those paths the command is already incomplete and its output is discarded; the fixed child's exit status is never read there (`result` is set only on the normal path). The collector runs only `openssl x509`, `openssl pkey` and `openssl verify`, filters from stdin to stdout that write no file, so there is nothing for a TERM to let them finish (my reading of the collector's argv; I did not check OpenSSL's source for a TERM handler).
3. **It is the project's standard.** "Proper solutions win", and no lasting edge without a machine trigger. Kept, this limit is a permanent edge in root code. With the fix, the rule becomes one sentence: on every path after the spawn, the namespace ends before the cleanup.
4. **The red-team should see the final shape.** It follows this re-audit; changing the release order after it would need another round.

### The tested fix (`fix09/proposed-fix-09.diff`, sha256 `876d5894586e813c678f134c9c61136c5361f5f7ba38d0de24b1348fe33c1efe`)

Applies to `0b8b9c0` with `git apply`. 5 files:

- **Collector:** `namespace.release()` before each of the two failure-path calls of `own_child_until_proved(proc)` (the inner `except` and the outer `except` after a spawn), with comments. The normal-path comment now says the order holds on every path.
- **FixedCommand:** the two failure-path cases (overflow; a fixed child still running at its time limit) now require the whole order `open, spawn, restore, release, cleanup, close`; the time-limit case also requires that the fixed child had **not** ended at the release (`at_release == [False]`), so the test proves that a running child is released into the kernel's KILL on purpose.
- **DocumentsContract:** in the fixed command body, every call of `own_child_until_proved(` must directly follow a `namespace.release()` line, and there must be exactly 3 of each, so a new cleanup call has to be placed the same way. New phrases: "on every path after the spawn the collector closes the control pipe before the cleanup owner runs", "without a TERM first", and the list of failure paths; the phrases "the fixed child may still run" and "holds the invocation until the descendant ends by itself" must be gone.
- **RealDescendants (root):** two new fixture modes and cases with `CHILD_TIMEOUT = 1.0`: `zombie-run` (the T7-1 descendant, and the fixed child keeps running, so the time limit fires while it runs) and `zombie-out` (the descendant keeps the fixed child's stdout open, so the time limit fires after the fixed child ended). Each must raise `child_timeout` in less than 15 s with no "lapsed" report and nothing left.
- **Documents:** PLANS.md, host doc step 6, access contract: one order for every path, the reason, the lost TERM stated; the limit bullet and the limit clauses removed.

Results (as `ci` for the root-collector selection, every ChildNamespace test as root):

| Run | Result |
|---|---|
| Fix applied | As root, 8 of the 9 ChildNamespace tests passed in the first run (RealDescendants 5.5 s); the ninth, DocumentsContract, is static and failed only on my phrase's capital letter (see below), and passes after the correction. As `ci`, the selection has only the 7 baseline failures besides that one |
| The fix's tests and docs with the **unfixed** collector of 0b8b9c0 | FixedCommand fails (order), DocumentsContract fails ("a cleanup owner call does not directly follow a release"), and RealDescendants fails: both new cases returned only after **15.04 s and 15.03 s**, with "lapsed", that is when the descendant ended by itself |
| My mutant C2 (the same two lines on 0b8b9c0 with 0b8b9c0's tests) | Only FixedCommand and DocumentsContract fail, the two tests that pin today's order. Every real test as root passes |

The fix runs overlapped the first two mutant runs (C1, C2); I ran them under `nice 19`, and no timing bound came near its limit: load can only lengthen a run, the upper bounds are 15 s and more, and the passing real tests of the fix took at most 5.5 s.

One correction during the run: my first draft of the DocumentsContract phrase began with a lower-case "a"; the documents start the sentence with "A". I dropped the article, re-ran DocumentsContract in both trees, and the diff above is the corrected one (`fix09/*-docs-rerun.txt`). Everything else ran once.

If the fix goes in, report 08's PR body text on the limit ("In the root collector, when a command may still be running ...") should be removed too.

## 5. Mutants on 0b8b9c0

Each mutant on a fresh clone of `0b8b9c0` (scripts/m31.sh, mutate31.py): the root-collector selection as `ci` and every ChildNamespace test as root (A, C), or the remote-collector selection as `ci` (B). Baseline failures of this container: 7 (A selection) and 11 (B selection), the same names as at `e3dce37`; they are left out below.

| Mutant | Change | Caught by |
|---|---|---|
| A04 | release right after the spawn | FixedCommand, DocumentsContract; as root RealDescendants, RealCollectorDeath |
| A05 | fixed child spawned at home | FixedCommand, DocumentsContract; as root RealDescendants, RealCollectorDeath |
| A08 | ECHILD on the anchor counts as a clean end | AnchorWait |
| A10 | probe skips "anchor not terminal while the member is unreaped" | Probe |
| A11 | namespace part of the probe runs first | DocumentsContract |
| A13 | anchor forked before `unshare` | Sequence, Probe; as root RealKernel, RealDescendants, RealCollectorDeath |
| A15 | `child_namespace_unproved` maps elsewhere | FixedCommand, DocumentsContract |
| **A19** | anchor ends with status 0 after 0.3 s | **now caught** (survived in 07): AnchorProcess, as `ci` and as root; RealDescendants as root |
| A23 | `namespace.open()` outside the cleanup owner | FixedCommand, DocumentsContract |
| B01 | a live child counts as proof | Drain, Probe, RealKernel, RunCommand, DocumentsContract |
| B06 | kill round sends TERM | Drain, Probe, RealKernel |
| B11 | flag checked after the spawn | RunCommand, RealProbeRefusesAChild, DocumentsContract |
| B12 | a failed probe ignored by main | RunCommand, DocumentsContract |
| B14 | handle poll for a reused PID | Drain |
| **B20** | probe closes the hold pipe before the drain | **now caught** (survived in 07): Probe, RealKernel |
| B23 | children-list bound off by one | Drain |
| B24 | drain deadline renewed per round | Drain, Probe, RunCommand |
| C1 (new) | release moved after the cleanup (old order) | FixedCommand, DocumentsContract; as root RealDescendants (the two hold cases waited until the 15 s lapse) |
| C2 (new) | release also before the failure-path cleanups (= the proposed fix) | only FixedCommand and DocumentsContract, which pin today's order; every real test passes |
| C3 (new) | a failed release is not remembered | Sequence, AnchorWait, Probe |
| C4 (new) | `release()` closes nothing | Sequence, AnchorWait, Probe; as root RealKernel, RealDescendants, RealCollectorDeath |
| A19b (new) | anchor ends with status 0 after 2.5 s | **survives**, see O9-1 |
| OLD | `036d507`'s collectors under `0b8b9c0`'s tests | root collector: 8 more failures as `ci`, all 9 ChildNamespace tests fail as root; remote collector: 6 more failures |

All 17 of my mutants from 07 are now caught, among them A19 and B20. Of the 5 new ones, C1, C3 and C4 are caught; C2 is the change I recommend; A19b survives.

**O9-1 (observation, no change asked).** The new tests bound an anchor that ends early only up to about 1 s, the length of their longest command. An anchor that ended by itself later would kill a longer command, which would then return `(-9, b'', b'')` as an ordinary result. That needs a code change to the anchor (the DocumentsContract pins four of its lines, not the absence of another exit), and a really killed anchor (status other than 0) is already reported by `close()`. If wanted, pinning the anchor function's whole text in the DocumentsContract would close this class without a slow test.

## 6. Validation

Cloud container: kernel 6.18.44, Go 1.26.5 (`GOTOOLCHAIN=local`), Python 3.13, test user `ci` (UID 1500) with an emptied environment.

| Check | Result |
|---|---|
| `go vet .` (root package), linux/amd64 and darwin/arm64 | clean |
| `gofmt -l` on the 3 changed Go files | clean |
| Python parse of the root collector | clean |
| Root package at `0b8b9c0` as `ci` vs my `e3dce37` run (07) | 2,272 results, **no verdict changed**, no name added or lost (the repair adds cases inside existing tests). Totals 2,034 pass, 3 skip, 235 fail at both; the 235 failures are this container's (no ssh, uuidgen or bindfs), the same as at `036d507` |
| Root package at `0b8b9c0` vs `036d507` | 2,256 shared, no verdict changed; the 16 new tests: 13 pass, the 3 PID-namespace real tests skip as `ci` (EPERM) |
| Every ChildNamespace test as root (9) | 9 pass (base run of the mutant harness) |
| Remote-collector selection as `ci` | only the 11 baseline failures; every descendant test passes |
| CI root step, emulated as root (`rootstep30.py`: the step's own code, `go` commands as `ci`) | 3 of 3 pass |
| CI on GitHub for `0b8b9c0` | run 45234732069 success (18:06 to 18:38Z), head_sha `0b8b9c0`; root step 3 of 3 on the runner (`ci/check-run-45234732069.txt`) |
| The proposed fix (`fix09`): `go vet .` linux/amd64 and darwin/arm64, `gofmt -l` on its test file | clean |

## 7. What this audit did not cover

- The box and the Mac (not reachable from here). The box items of 07 stand: Python ≥ 3.12 and `unshare` allowed for the root collector as really started; the R2 probe as the SSH user; `sudo -n` pseudo-terminal; `pidfd_answers.py`. The writer's `08-mac-and-box-brief.md` covers them; I did not review that brief.
- The full-module suite (07 did it for e3dce37). The repair touches only the files listed in section 1; I ran the root package.
- A second look at the parts of PR #30 that the repair did not touch.

## 8. Confidence

- The repair is correct and does only what 08 says: 0.95 (code reading, hold probes, root package, 22 mutants, CI).
- T7-2 and T7-3 are closed: 0.95 (A19 and B20 caught; the model change checked against the older cases).
- The failure-path hold is real and matches the documented limit: 0.95 (four variants held for 20 s; the writer's text and mine agree on the mechanism).
- The two-line fix removes it without side effects worth keeping: 0.9 (four variants return at once; every real test passes with it; C2 shows only the order-pinning tests object; the lost TERM is reasoned from the code, where a failed command's status is never read). The kernel mechanism (`zap_pid_ns_processes`, a dying first process autoreaps) was shown by behaviour here, not re-read in the kernel source.

## 9. Next steps

1. Coordinator: decide T9-1. My recommendation: fix now with `proposed-fix-09.diff` (the writer may restyle it), then a narrow re-audit of that change, then the red-team.
2. Writer, either way: bring the branch up to date with `trunk_dev` `8ba1edb` before merge; CI runs again.
3. The box and Mac run stays after the red-team, on the final code (coordinator's plan of 18:45Z).

## Evidence

`09-audit-evidence/` (SHA256SUMS inside):

- `provenance-open/`, `provenance-close/`: both manifest passes.
- `probes/`: `hold-0b8b9c0.txt`, `hold-optC.txt`, `optC.diff` (the two-line prototype).
- `fix09/`: `proposed-fix-09.diff` and its runs (`fix09*.log`, `*-A-root.txt`, `*-docs-rerun.txt`, `fix09-vet.txt`).
- `mutants/`: one log per mutant, root-test output for A and C mutants.
- `validation/`: `a31-steps.log`, `root-step.log`, `compare31.txt`, `pr31-root.summary.txt`, vet and gofmt logs.
- `ci/check-run-45234732069.txt`.
- `scripts/`: `prov31.sh`, `hold2.py`, `hold2.sh`, `runall.sh`, `tree.py`, `m31.sh`, `mall31.sh`, `mutate31.py`, `apply.py` (writes the proposed fix), `fixrun.sh`, `a31.sh`, `compare31.py`, `rootstep30.py`, `cirun.sh`, `sync.sh`, `sigdfl.py`, `summ.py`.

STATUS: READY
