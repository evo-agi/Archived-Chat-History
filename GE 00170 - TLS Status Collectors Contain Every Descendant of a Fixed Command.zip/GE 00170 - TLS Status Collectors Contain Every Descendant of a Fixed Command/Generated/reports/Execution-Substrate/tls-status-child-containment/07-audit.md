# AUDIT: PR #30, child containment for both Remote Alpha TLS status collectors

**Verdict: ACCEPT `e3dce37` for correctness, with three Low findings. Both containments do what the contract says on this kernel, and CI passed on GitHub, including the new root step. T7-1 needs the coordinator's decision: a hold the root collector already had before this PR, which the new namespace could end. T7-2 and T7-3 are test gaps to close in this PR: two of my 17 mutants survive. The box run, the Mac run and the separate red-team are still required before merge.**

| Finding | Severity | What | Asked |
|---|---|---|---|
| T7-1 | Low | Root collector: a descendant that leaves the fixed child's group but keeps an unreaped child in it holds the invocation for as long as that descendant lives. Pre-existing; the namespace could release it at once | Coordinator decides: option (a) below, prototyped and working, or a stated limit |
| T7-2 | Low, tests | No test notices an anchor that ends by itself with status 0 while the command still runs (mutant A19). The code is right; the tests do not pin it | Add a real test with a command that outlives several anchor polls |
| T7-3 | Low, tests | No test notices an R2 probe that lets its grandchild end by itself instead of killing it (mutant B20). The code is right; the tests do not pin it | Make the probe tests require the kill while the hold is still open |

CI on PR #30: check run "build, vet and test" succeeded at 17:21Z (workflow run 45219890036, head `e3dce37`). The new step ran on the GitHub runner and printed `tests as root passed: 3 of execution-substrate`.

Written 2026-11-23 by the audit thread "Audit TLS collector child containment" (read-only; nothing pushed, no comment on GitHub). Opened 16:46Z, closed 17:45Z. At close, `trunk_dev` was still `036d507` and the branch tip still `e3dce37`.

## 1. What was audited

| Item | Value |
|---|---|
| PR | [#30](https://github.com/evo-agi/Execution-Substrate/pull/30), draft, base `trunk_dev` |
| Head | `e3dce375eda8208a6dfcd8d3ea754d4ab11436ec` on `claude/project-thread-wbmulu`, tree `4d6163075c35f64cd747e0db3b89e893c91debe5`, one commit |
| Base | `trunk_dev` `036d50724b499b020c5149c55ad902cfcb1482c0` (merge base = `origin/trunk_dev` at open and close) |
| Writer report | `06-implementation.md`, sha256 `9dd58ed39a5d6ea074c5ea655c1fb5a123f1d2ab7312558d26ac0c1c41c8ffaf` |
| Designs read | `02-handoff.md` (decisions D1 to D5), `03-handoff-update.md`, `04-remote-collector-design.md` (R2), `05-root-side-runner.md` |
| Recipe | `governed-execution.audit-patch-manifest.v2`, source sha256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca`, checked before every run |

## 2. Provenance

I ran the recipe myself in a separate clone, twice at open and twice at close, with HEAD reset to the merge base, the upstream set to `origin/trunk_dev`, and umask 022 (`07-audit-evidence/scripts/prov30.sh`).

| | Open (16:48Z) | Close (17:41Z) |
|---|---|---|
| Canonical manifest sha256 | `17adc312188df31ca579907dc62292f14cf50f11f7504c94ef71273cae1d90c9` | `17adc312…90c9`, the same |
| Textual diff sha256 | `b58c54631b5ad1488b04dd1485554933d1085b3dcda8ca60eb3c735302a9ce31` | `b58c5463…ce31`, the same |
| File count | 19 | 19 |
| Two runs byte-identical | yes | yes |
| Same bytes as the writer's `06-evidence/manifest-v2.json` | yes (`cmp`) | yes (`cmp`) |
| Staged tree after `git add -A` | `4d616307…` = the commit's tree | `4d616307…`, the same |

The staged path set equals the 19 paths of `git diff --name-only 036d507 e3dce37`.

## 3. Validation (cloud container: kernel 6.18.44, Go 1.26.5, Python 3.13, test user `ci` UID 1500)

| Check | Result |
|---|---|
| `go build ./...` and `go vet ./...`, linux/amd64, linux/arm64, darwin/arm64 | all clean |
| `gofmt -l` on the 8 changed Go files | clean |
| Python parse of both collectors, `go_test_as_root.py`, the self-test | clean |
| `go_test_gate_selftest.py` (pinned toolchain, as `ci`) | 132 of 132 |
| CI list check (each listed test defined exactly once) | OK: 16 entries, 7 `skips-itself` lines, 4 packages |
| CI root step (`go_test_as_root.py`), see 3.1 | 3 of 3 pass as root |
| Full module suite at `e3dce37` vs `036d507`, both as `ci`, same container | 5,478 shared results, **no verdict changed**. 16 new tests: 13 pass, the 3 PID-namespace real tests skip (EPERM as `ci`) and pass as root |
| Every ChildNamespace test as root (9) | 9 pass |
| The remote collector's real tests (unprivileged) | pass as `ci` |
| CI on GitHub for `e3dce37` | success (run 45219890036, 16:44 to 17:21Z); root step 3 of 3 (`ci/check-run-45219890036.txt`) |

The root package fails 235 results at both commits for the same reason as in my earlier audits (this container has no `ssh`, `uuidgen` or `bindfs`); none of them changed. The two listed `reliablesubmit` tests fail at both commits, as listed.

### 3.1 The CI root step

The `ci` user has no sudo here, so I ran the step's own code (`main()` of `go_test_as_root.py` at `e3dce37`) as root with two changes, both in `07-audit-evidence/scripts/rootstep30.py`: every `go` command and the `-test.list` query ran as `ci`, and the scratch directory was handed to `ci`. The elevated command itself ran unchanged: `sudo -n -- /usr/bin/env -i PATH=/usr/bin:/bin <binary> -test.run ^(…)$ -test.v -test.count=1 -test.timeout=10m`. Result: `tests as root passed: 3 of execution-substrate` (`validation/root-step.log`).

I read the step and its self-checks line by line. It runs only the `skips-itself` lines of the root package, refuses a list without such a line, refuses a subtest line, checks that the binary holds every listed test before sudo, requires exactly one PASS verdict per listed test and none for any other top-level test, and requires status 0. The self-test pins that the step is the last command of the job and that the only other `sudo` is the pinned bindfs install. On `ubuntu-24.04` hosted runners the job user already has passwordless sudo, so the step widens what the workflow uses, not what the runner allows. It is still the privilege widening that D3 asked to be stated, and the PR states it.

## 4. Review: root collector (`scripts/internal/remote_alpha_es_tls_status.py`)

I read every changed line and the unchanged cleanup it relies on (`own_child_until_proved`, `terminate_child`, `waitid_terminal`).

What holds, with the kernel facts checked:

- `unshare(CLONE_NEWPID)` acts on the calling thread only; the collector has one thread and only three fork sites besides `Popen` (the first probe, the anchor, the probe member).
- The anchor is forked first and so is the namespace's first process; `Popen` forks the fixed child second, and `restore()` runs in a `finally` right after. A fork into a namespace whose first process is gone fails with ENOMEM (the writer's `RealKernel` test shows it, and it passed in my runs as root).
- The control pipe's write end is held only by the collector: `os.pipe()` is close-on-exec, `Popen` uses `close_fds=True`, and the anchor and probe member close every inherited descriptor and check it. So the anchor ends with status 0 only when the collector closes its end or dies.
- The kernel does not let the anchor become waitable until every other process of the namespace is reaped, including the fixed child, which is the collector's child. The collector reaps the fixed child before `close()` on every reachable path, because `own_child_until_proved` returns only after the reap.
- The fixed child sees parent ID 0, so `kill(getppid(), …)` hits its own group, never the collector (probe `failpaths`, mode `signal`).
- Failures map as documented: a missing `os.unshare` or a refused namespace means no spawn; an unproved reset, pipe close, anchor end or reap is `child_namespace_unproved` → `openssl_child_unproved`; a failed second probe part is `process_capability_unproved`.

My own real-kernel probes as root (`07-audit-evidence/probes/`), each with a descendant that leaves the group with `setsid` and ignores TERM and HUP:

| Path | With the namespace | Without it (control) |
|---|---|---|
| Fixed child times out | `child_timeout`, every process gone at return, no child left | descendant survives |
| Fixed child exits, descendant holds stdout until the timeout | `child_timeout`, every process gone | descendant survives |
| Output overflow | `child_output_overflow`, every process gone | descendant survives |
| Killed collector (writer's real test) | fixed child and descendant die with it | both survive |

The writer's three notes:

1. `ChildNamespace.close()` retries forever when `waitpid` on the anchor keeps raising something other than ECHILD. By the documented errors, `waitpid` with a valid PID and these fixed options can only fail with ECHILD (handled) or EINTR (retried by Python), so this is the documented hold and not reachable in practice. Agreed.
2. The `subprocess` module never sees a PID that the R2 drain reaped directly: confirmed by reading. The drain reaps the fixed child only through its handle while its return code is unset, so the handle is never put on `subprocess._active`, and there is one `Popen` per command.
3. The probe's unbounded `waitpid(middle, 0)`: the middle child only forks, writes a few bytes and exits. Agreed.

### T7-1 (Low): an unreaped child left in the fixed child's group by a descendant that left it holds the root collector

**What happens.** The fixed child F starts P. P starts Q, then leaves F's group with `setsid`, ignores TERM, and does not reap Q. Q stays in F's group: it ends, or the group KILL ends it, and it stays a zombie because its parent P is alive. F completes normally. The unchanged cleanup owner then waits until F's group holds nothing but F (`terminate_child`, `scripts/internal/remote_alpha_es_tls_status.py:1064`, a loop without a time limit). Q's zombie stays in the group for as long as P lives, so the loop never ends. The namespace would kill P at once, but by design the collector closes it only after the cleanup returns (step 6 of the rule). The anchor cannot help: it reaps orphans, and Q is not an orphan.

**Evidence** (`probes/hold-results.txt`, `probes/hold-release.txt`, real namespace, as root):

- mode `zombie` (Q ends at once) and mode `qalive` (Q lives, the group KILL ends it): both held for the whole 20 s limit. The process tree at that point: F zombie (leader, unreaped), Q zombie in F's group, P alive outside it.
- control mode `reaps` (P reaps Q): returns `(0, b'fixed', b'')` in 0.34 s.
- the same `zombie` case with an 80 s limit: returned success after 60.04 s, exactly when P's 60 s sleep ended. A P that does not end holds forever, with the status lock retained.
- `036d507`'s collector holds in the same case, and there P survives the killed collector. So this PR does not introduce the hold or make it worse, and after a killed collector the namespace now ends P and Q.

**Why it matters, and why Low.** Nothing escapes and nothing false is published: the failure is a hold. It needs a fixed command that starts processes, which `openssl` does not, so it needs a changed host binary, the same condition as everything this rule covers. But the rule's own text says the namespace makes a descendant that leaves the group harmless, and the docs list only "a process that cannot die" as a reason for a hold. Here every process can die. Step 2 of the rule explains why the anchor must reap orphans, for the same scan, but it does not cover a zombie whose parent is still alive.

**Options for the coordinator** (D4 keeps the process-group logic untouched):

- (a) On the normal-completion path the fixed child has already ended. Closing the control pipe there, before `own_child_until_proved`, would let the kernel kill P; Q is then reparented to the ending anchor and reaped, the group scan finds only F, and the cleanup finishes. This changes the order in `_run_fixed_in_namespace`, not the group logic, and keeps TERM first on the failure paths, where the fixed child may still run. On those paths the same hold stays possible.
- (b) Release the namespace before the unbounded part of `terminate_child` on every path. That covers all paths, but it touches the group logic, which D4 rules out.
- (c) Keep the code and add this case to the stated limits in the three documents.

I prototyped (a) in a scratch copy (`probes/optA/option-a.diff`: three lines before the call of `own_child_until_proved` on the normal-completion path). With it, `zombie`, `qalive` and `reaps` all return `(0, b'fixed', b'')` in 0.33 s (`probes/optA/hold-option-a.txt`). Every real-kernel case of the writer's tests still passes as root. Only cases that use the shared stand-in or the deterministic model fail, because neither has a `release` method or expects the new order (`probes/optA/childnamespace-tests-option-a.txt`). A real fix would extend both.

My recommendation is (a), with one sentence in the limits for the failure paths, or (b) if the coordinator reopens D4. Either way the PR should gain a real test for the case: `scripts/hold.py` is a ready fixture.

### T7-2 (Low, tests): nothing pins that the anchor holds the namespace for the whole command

Mutant A19 makes the anchor end by itself with status 0 after 0.3 s, whatever the control pipe says. Every test passes, unprivileged and as root. The consequence is a silent wrong result: a fixed command that takes 1 s comes back as `(-9, b'', b'')`, a normal result with nothing unproved, because the kernel killed it when the anchor ended, and `close()` then accepts the anchor's status 0 (`probes/slow-A19.txt`; the unmutated collector returns `(0, b'fixed', b'')`). The real anchor ends only on end of input, so the code is right; the tests just never hold a namespace open longer than a few anchor polls. The writer's M22 (anchor ends at once) is caught because it ends before anything happens.

Asked: a real test as root in which the fixed command runs well past the poll period (for example 1 s) and must return its own output, and an anchor-process case that checks the anchor is still waiting after such a pause before the control pipe closes.

### Observations (no change asked)

- O7-1: `close()` assumes the fixed child is already reaped. If it ever were not, the anchor could not become waitable and `close()` would hold. The only path I found, by reading CPython's `subprocess`, is an exception inside `Popen` after its fork (for example `MemoryError` while it reads the exec-error pipe); that is a hold, consistent with the doctrine, and not a containment gap.
- O7-2: the anchor waits with `select()`, which refuses descriptor numbers of 1024 and above. The anchor would then end with status 1 and the command would be incomplete (fail closed). The collector holds far fewer descriptors.

## 5. Review: remote collector (`…_noninteractive_remote.py`, option R2)

I read every changed line and the unchanged lifecycle around it.

- `main` runs the probe after argument parsing and before `collect_status`, so a failed probe emits `remote_status_unavailable` before any status input or command. `run_command` refuses before any spawn while the flag is unset (an over-long input is refused first, as documented).
- The drain proves absence only through `waitid(P_ALL, WEXITED|WNOHANG|WNOWAIT)` raising ECHILD. All children of the collector are `Popen` children or adopted orphans, and the kernel sets the exit signal of an adopted orphan to SIGCHLD, so `waitid` without `__WALL` sees every one of them.
- Every PID it kills comes from a fresh children list and is an unreaped child, so the PID is reserved under the signal. That rests on SIGCHLD not being ignored: with SIGCHLD ignored, the kernel reaps children by itself. I checked that the probe catches that case: `waitpid(middle, 0)` then fails with ECHILD and the probe reports `probe_failed`, so no command runs.
- An adopted descendant cannot reach any reaper but the collector: orphans go to the nearest living subreaper among their ancestors, and every such ancestor is itself a descendant. A descendant in its own PID namespace dies with that namespace's first process, which the drain kills.
- The bound is real: 64 reaps per round, then a kill round, 2 s in all; an unproved drain is `runtime_failed` whatever the command returned, and clears the flag. Missing `prctl` or `/proc/self/task/<tid>/children` fails the probe (fail closed).
- A root descendant of the `sudo -n` path survives a SIGKILL from the unprivileged collector and outlives it. This is the documented limit; the bound turns it into a reported failure.

No finding in the code.

### T7-3 (Low, tests): nothing pins that the R2 probe kills its grandchild

Mutant B20 closes the probe's hold pipe before the drain, so the grandchild ends by itself and the drain only reaps it. Every test passes. The contract (§8) says the drain must kill and reap a grandchild that never ends by itself, and that is what the probe is for: proving on the host that the collector can kill an adopted descendant. The real code keeps the hold pipe open until after the drain, so it is right. The impact of a regression would be limited, because the drain after each command would still fail closed at its bound. But the probe would then prove less than the contract says.

Asked: the deterministic probe test should require that the grandchild is killed while the hold pipe is still open (the order of `kill` and `close(hold_w)` in the backend's record), and the real probe test should check the same, for example through a wrapped backend.

## 6. Contract documents

I checked each claim in the four changed documents and PLANS.md against the code: the noninteractive status contract (§8 bounds, the bounded slice rule and its limits; §9 sudo limit; §14 validation), `remote_supported_host_alpha.md` (steps 1 to 7, probe part two, limits), `remote_alpha_access_contract.md`, `capability_probing.md` (stand-ins and guards), and the two PLANS.md refinements. They match the code, with one gap: T7-1 (the step 2 reasoning and the limits list). The bounds in the docs equal the constants, and the docs-contract tests pin them.

## 7. Tests

- **New tests against the old collectors** (both collectors replaced by `036d507`'s bytes, all else at `e3dce37`; `mutants/OLD.log`):
  - Root collector, unprivileged: 8 tests fail that pass at the head: the 6 new deterministic ChildNamespace tests, `FixedCapabilityProbe` and `LocalBoundaryKnowsTheCallGraph`. As root, all 9 ChildNamespace tests fail.
  - Remote collector, unprivileged: 6 of the 7 new tests fail, including both real ones. The seventh, `DescendantStandInIsWhole`, guards test text and rightly passes.
  - The real tests also carry their own controls: the same fixture without the containment must leave the descendant alive, and it does.
- **Writer's mutants**: I read both harnesses (`06-evidence/*-mutants.py.txt`): each mutant replaces one exact text that must occur once, and the kill lists name the expected tests. I did not re-run them; my own mutants below cover other changes.
- **My own mutants** (`07-audit-evidence/scripts/mutate30.py`, none of them a copy of the writer's 48). A mutant counts as caught when a test fails that passes on the unmutated head in the same container (`mutants/summary.txt`):

| Mutant | Change | Caught by |
|---|---|---|
| A04 | release the namespace right after the spawn | real Descendants and CollectorDeath as root, FixedCommand, and many local fixtures (the stand-in has no `release`) |
| A05 | spawn the fixed child back home (restore before `Popen`) | FixedCommand, DocumentsContract; real Descendants and CollectorDeath as root |
| A08 | ECHILD on the anchor counts as a clean end | AnchorWait |
| A10 | probe skips "the anchor is not terminal while the member is unreaped" | Probe |
| A11 | namespace part of the probe runs before the first part | FixedCapabilityProbe, DocumentsContract |
| A13 | anchor forked before `unshare` (fixed child becomes the first process) | Sequence, Probe; real Kernel, Descendants, CollectorDeath as root |
| A15 | `child_namespace_unproved` maps to another public reason | FixedCommand, DocumentsContract |
| A19 | anchor ends with status 0 after 0.3 s | **survives** (T7-2) |
| A23 | `namespace.open()` outside the cleanup owner's `try` | FixedCommand, DocumentsContract |
| B01 | a live child (wait reports none ended) counts as proof | Drain, Probe, RunCommand, RealKernel, DocumentsContract |
| B06 | the kill round sends TERM | Drain, Probe, RealKernel |
| B11 | flag checked after the spawn instead of before | RunCommand, RealProbeRefusesAChild, DocumentsContract |
| B12 | `main` ignores a failed probe | RunCommand, DocumentsContract |
| B14 | a reused PID of the reaped fixed child is polled through the old handle | Drain |
| B20 | probe closes the hold pipe before the drain | **survives** (T7-3) |
| B23 | children list bound off by one (`>=`) | Drain |
| B24 | drain deadline renewed every round | Drain, Probe, RunCommand |

- **Guards**: the root-collector fixture guard now treats `ChildNamespace` and `validate_child_namespace` as a pair (both or neither), with a pin for each name and a floor of 36 scripts using the stand-in. The remote guard allows only the one shared stand-in to replace the flag or the drain, and nothing to replace the probe. Both guards pass and their self-cases cover the spellings I would try.

The stand-ins mean that the many existing local fixtures no longer touch the namespace or the drain. The real behaviour is covered by the 3 real namespace tests (as root, in CI's root step) and the 2 real R2 tests (unprivileged, in CI's Test step), each with a control case that shows the fixture fails without the containment.

## 8. What needs the box or the Mac (not available to me)

Box (Remote Alpha host), before merge:

1. The root collector's whole capability probe passes there as it is really started: Python 3.12 or later (`os.unshare`, `os.setns`), `/proc/self/ns/pid_for_children`, and `unshare(CLONE_NEWPID)` allowed in that context (root, no `RestrictNamespaces=`, seccomp or capability limit from a service unit). Otherwise the collector fails closed on every run.
2. The R2 probe passes as the SSH user in the real launch shape: no child at start, `prctl(PR_SET_CHILD_SUBREAPER)`, `/proc/self/task/<tid>/children` readable, SIGCHLD not ignored.
3. Whether `sudo -n` uses a pseudo-terminal there. Without a terminal, `use_pty` has no effect; this container's sudoers sets `use_pty`.
4. `pidfd_answers.py`, as planned.

Mac: macOS is the development platform only. The real tests should skip there (no `os.unshare`; no `prctl` in libc). `go vet` for darwin/arm64 is clean here. A Mac run of the root package would confirm the skips.

## 9. Envelope

- Effect status: `READ_ONLY`. Nothing pushed, no GitHub comment, no PR change.
- Confidence:
  - The root collector contains every descendant of a fixed command on this kernel: 0.9.
  - R2 contains every own-user descendant and fails closed otherwise: 0.9.
  - T7-1 is real and pre-existing: 0.95 (reproduced, with controls).
  - Both behave the same on the Remote Alpha host: Unknown until the box run.
