# VALIDATION ADDENDUM 13a: PR #30, the runs that report 13 left running, and one test fix

**Everything that report 13 listed as still running has finished, and all of it supports the repair. One weakness in a test turned up and is fixed in a test-only commit. On the merged head, the root run of mutant N07 got past `AnchorProcess` and was caught only by the documents pin. The cause was that the test's check of the order "close, then report ready" was racy. Now the anchor's ready byte waits in a full pipe, so the order is decided without a race, and N07 is caught every time, as `ci` and as root. New head `4f55003`, manifest `2b9233cb…961b` against base `4c991ba`, same 19 paths. The collectors are byte-identical to `700b533` (and to `bb6e05a`). The red-team ran variant c of RT12-2 with its own harness, unchanged: the `eed4c9b` collector was held in 11 of 30 runs and the repaired one in 0 of 30. With the collector killed, the `eed4c9b` fixed child lived another 10.6 s, and the repaired one at most 263 ms. In the box rehearsal here, all ten real-kernel probes pass on the repair. Against `eed4c9b`, the probes for RT12-1, RT12-2, RT12-3 and O12-1 fail, as they should. trunk_dev has moved to `6ce0034` (#43 README, #42 es/app test ports). A trial merge is clean and touches no file of this PR, so it waits for the gate.**

Written 2026-11-24 by the writer thread "Contain TLS status collector child processes". Builds on `13-repair.md`. Guesses are marked "Guess:", inferences "Inference:".

## 1. Identity

| Item | Value |
|---|---|
| Previous head (report 13) | `700b533c8dee44e9b83fa4ccb15087a737aeb895` |
| New head | `4f55003b81580acec19f2cbe5bf1f6db4859afe1`, one commit on `700b533`, fast-forward push |
| Tree | `9cbfdff64f7d8ff08ae8f8488f3a0ef03418eaf8` (the tested copy's tree is the same, `13-evidence/validation-4f55003/sync.txt`) |
| The commit | test-only: `scripts/remote_alpha_es_service_tls_status_child_namespace_test.go`, +27 −7; diff `13-evidence/diffs/anchor-order-4f55003.diff`, SHA-256 `5014f247888422e73df747d463956b081ec75540dfcef3771299ea497d494bd3` |
| Base | `trunk_dev` `4c991ba1c43ac135d9d94853696d14a21523a690` (unchanged; section 6) |
| Recipe | `governed-execution.audit-patch-manifest.v2`, source SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca` (checked before the run) |
| Canonical manifest SHA-256 | `2b9233cbe3c27943c34c3e65ec68035520a134e01def9072e4b31030e876961b` |
| Textual diff SHA-256 | `af20695eded45cf7271b9373e74eecf932499fbbf5e9e837d1eda036bdea52c5`, the same as report 13's: the changed file is new to the base, so under the flow it is untracked, and only its manifest entry changes (now `241f4a16…7b9d`, 112913 bytes) |
| File count | 19, the same paths as `git diff --name-only 4c991ba 4f55003`; each entry's SHA-256, size and mode match the tip's blobs (19 of 19) |
| Collectors | root `c6c2dc75…dd5e`, remote `db471490…ebdc8`, unchanged since `bb6e05a` |

The flow is the same as in report 13: reset to the base, the upstream pinned to `origin/trunk_dev`, two byte-identical runs into a 0700 directory, then back to the tip with the upstream restored. The recipe diffs against `HEAD` and only records the upstream's name, so the trunk_dev move in section 6 does not touch this manifest. Logs are in `13-evidence/provenance-4f55003/`.

## 2. The finding: AnchorProcess's order check was racy

**What showed it.** I reran the 27 mutants of report 13 on the merged tree `700b533`. All 27 were caught both ways, but N07 (the anchor writes its ready byte before it closes what it inherited) was caught as root only by `DocumentsContract` (`13-evidence/validation-4c991ba/mut13-merged.txt`). On the `0aa4a2b` tree, `AnchorProcess` had caught it both ways, so this was chance, not a change in code.

**Cause.** The test read the ready byte and then listed the anchor's descriptors. An anchor that reports first and closes right after can finish closing between the probe's read and its list. Then the list is clean, and the end of input on the inherited pipe comes too.

**Fix (test-only).** The probe fills the ready pipe to capacity before it forks the anchor (64 KiB here). The anchor's one-byte write then blocks until the probe reads. The probe waits for the end of input on a pipe whose write end only the anchor inherited. It drains the filler and the byte, checks that the filler came back whole, and only then lists the descriptors. A correct anchor has closed everything before its write blocks, so the end of input comes first. An anchor that reports first still holds the write end while its byte waits, so the 20 s bound ends the wait and the case fails. The bound only ends a failing case. The list is taken after the byte, so a correct anchor has finished closing by then. The subset check allows the ready pipe to be already closed. The case label is unchanged, and the doc comment says how the order is decided.

**Results** (`13-evidence/validation-4f55003/`):

- `AnchorProcess` with `-test.count=30`: 30 of 30 pass as `ci`, 30 of 30 as root.
- N07: caught by `AnchorProcess` as `ci` and as root, in addition to `DocumentsContract`. Failure detail: `(False, 65536, 65537, b'r', [0, 1, 2, 3, 6, 14])`. The inherited end was still open while the byte waited, and right after the byte the anchor still held the inherited descriptors.
- M13b, N06, N19 (the other mutants that `AnchorProcess` catches): still caught by it, both ways (`anchor-mutants.txt`).
- The root collector's family (`TestRemoteAlphaESServiceTLSStatus(ChildNamespace|FixedCapabilityProbe|LocalBoundary)`): as `ci` 13 pass and 5 skip (the five `skips-itself` tests); as root 18 pass.
- `go vet ./scripts/` for linux/amd64 and darwin/arm64: clean. `gofmt -l scripts/`: nothing.
- No other test changed, so I did not rerun the whole packages. Section 3 has the packages on `700b533`. CI on `4f55003` is run 45309449104; it was still running when I wrote this.

## 3. Merged head 700b533: the runs that were still going

These ran on an otherwise idle container. A container restart around 01:09Z interrupted them. The packages step had finished before it; the rest resumed after it (`final13c.sh`). The restart changed the kernel build from `6.18.44-fc-v726` to `6.18.44-fc-v819`. Both are 6.18.44. All logs are in `13-evidence/validation-4c991ba/`.

- **Packages** as `ci` (idle run): the same result as the quick run in report 13. 498 pass (root 159, `scripts` 333, `testutil` 6). The 8 failures are the 8 environment-only `scripts` entries, and the 5 skips are the five `skips-itself` lines (`packages-idle-as-ci.json.gz`).
- **Gate self-test** 132 of 132. **Root step**: "tests as root passed: 5 of execution-substrate/scripts". **vet**: clean for both targets.
- **Families as root**: 21 pass, 1 skip (`…DescendantRealProcessLimit`, which skips itself where the limit does not bind, as for root) (`families-root.txt`).
- **Mutants of report 13**: 27 of 27 caught as `ci` and as root (`mut13-merged.txt`). N07 is covered in section 2.
- **Report 10's two** (`mut10-merged.txt`):
  - RELEASE-BEFORE-TERMINAL: caught as `ci` by `FixedCommand` and `DocumentsContract`, and as root also by RealDescendants, RealCollectorDeath, RealSiblings and RealDeafAnchor.
  - B20: caught both ways by the remote `Probe` and `RealKernel`.
- **CI** run 45301976440 on `700b533`: green (report 13).

## 4. Variant c of RT12-2, with the red-team's harness unchanged

This is the red-team's own harness (`rt_storm.py`, `run_storm.sh`, `run_storm_kill.sh`, `storm` built from its `storm.c`; SHA-256s in `13-evidence/variant-c/redteam-harness.sha256`), run as root against each collector. Part A is the T7-1 shape (zombie) plus sleepers and relay chains. The stand-in ends by itself after 5 s, and a run counts as held when `run_fixed` returns only after that lapse.

| Sleepers, chains | `eed4c9b`: held | `eed4c9b`: seconds | repair: held | repair: seconds |
|---|---|---|---|---|
| 0, 0 | 0 of 5 | 0.007–0.017 | 0 of 5 | 0.006–0.008 |
| 0, 4 | 0 of 5 | 0.007–0.019 | 0 of 5 | 0.008–0.022 |
| 2000, 4 | 0 of 5 | 0.235–1.33 | 0 of 5 | 0.173–0.205 |
| 4000, 4 | **5 of 5** | 5.23–5.88 | 0 of 5 | 0.359–0.47 |
| 8000, 1 | **4 of 5** | 2.97–5.25 | 0 of 5 | 1.43–2.26 |
| 8000, 4 | **2 of 5** | 1.96–5.24 | 0 of 5 | 1.00–2.28 |
| All | **11 of 30** | | **0 of 30** | |

Every run of both collectors returned `(0, b'fixed', b'')` with nothing raised and no process left after the return.

The repaired collector's 1 to 2.3 s with 8000 sleepers is not a hold: it never waits for the stand-in's lapse. Inference: it is the kernel tearing down about 8000 processes of the namespace after the anchor's KILL, so it grows with the number of processes, not with any time of theirs.

Part B kills the collector with SIGKILL 1.5 s into a command whose fixed child stays for 12 s. The table shows how long the fixed child kept running after the collector's death:

| Sleepers, chains | `eed4c9b` | repair |
|---|---|---|
| 0, 0 | 3 ms | 2 ms |
| 8000, 1 | 196 ms | 263 ms |
| 8000, 4 | **10607 ms** (about the rest of its 12 s; the anchor was busy reaping and never saw the end of its input) | 234 ms |

No process of either run was left at the end (`grid-eed4c9b.txt`, `grid-repair.txt`). The first attempt of this grid called `run_storm.sh` directly. That file has mode 0644, so each run printed nothing and the parse failed. That was my harness error, not a result (`first-attempt-harness-error-excerpt.txt`). `drive.sh` now calls the script through `/bin/bash`.

The box brief's own variant c driver (`pr30_storm.py`, section 5) agrees: at 4000 sleepers and 4 chains, `eed4c9b` was held 5 of 5 (5.17–5.33 s) and the repair 0 of 5 (0.37–0.48 s). With the collector killed, the `eed4c9b` fixed child ran on for 10574 ms and the repair's for 144 ms.

## 5. Box rehearsal in this container

`rehearse13.sh` stages the box run's inputs into `/home/ci/rehearse13` and runs them the way the brief will:

- the new collectors, which are the same at `700b533` and `4f55003`;
- the `eed4c9b` collectors;
- the ten real-kernel tests' Python probes, dumped from the tests at `700b533`. The `4f55003` commit changed only `AnchorProcess`, which is not one of them, so the probes are those of the final head too;
- `pr30_box_probe.py` and `pr30_storm.py`.

The namespace probes ran as root with an emptied environment, and the remote probes ran as `ci`. Staged SHA-256s are in `13-evidence/rehearsal/staged.sha256`.

| Probe | Repair | `eed4c9b` | What fails on `eed4c9b` |
|---|---|---|---|
| namespace RealKernel | 10 of 10 | 10 of 10 | nothing (the kernel facts and the capability probe did not change) |
| namespace RealDescendants | 14 of 14 | 12 of 14 | the two "without the namespace" controls. The probe's stand-in has `end()`, and the old collector calls `release()`, so this is an interface failure, not behaviour |
| namespace RealCollectorDeath | 4 of 4 | 4 of 4 | nothing. Inference: with an intact control pipe, the old anchor already ended when its pipe closed |
| namespace RealSiblings | 5 of 5 | 2 of 5 | RT12-1: twice held for the 20 s bound, and the collector kept a child |
| namespace RealDeafAnchor | 5 of 5 | 1 of 5 | RT12-2: held about 8 s, and a killed collector left the namespace alive |
| remote RealKernel | 10 of 10 | 10 of 10 | nothing (the drain did not change) |
| remote ProbeRefusesAChild | 2 of 2 | 2 of 2 | nothing |
| remote RealCrowd | 4 of 4 | 4 of 4 | nothing (its contract is the drain's: a reported failure with the limit off) |
| remote RealProcessLimit | 3 of 3 | 1 of 3 | RT12-3: without the limit nothing refuses the fixed child's fork or thread, and both cases end as runtime failures (125) instead |
| remote RealCollectorDeath | 2 of 2 | 1 of 2 | O12-1: the fixed child outlives a killed collector |

The box probe's other parts:

- **Root part:** the capability probe (both parts) is accepted. The real `openssl version` runs in its own namespace. The stand-in modes setsid, zombie, zombie-run and slow leave no process after the return; zombie-run is `Incomplete('child_timeout')` after 1.016 s.
- **r2 part (as `ci`):** under `RLIMIT_NPROC (0, 0)`, the fixed child's fork gets EAGAIN. `sudo -n /usr/bin/id -u` and `sudo -n /usr/bin/stat …/etc/hostname` both succeed under the limit.
- **Facts here:** no Yama (`ptrace_scope` not present), `pid_max` 32768, 4 CPUs. The box will differ, and the brief records them there.
- **Leftovers:** the leftover check printed 3 lines both times. They are the rehearsal's own shell chain (the launching shell, its `bash -c`, and `rehearse13.sh`), not a probe's process. The brief's check will leave out its own chain.

## 6. trunk_dev moved to 6ce0034

trunk_dev gained `523648c` (#43, README) and `6ce0034` (#42, es/app test ports). They change 4 files (`README.md` and three under `es/app/`), none of them in this PR. `git merge-tree` merges `4f55003` with `6ce0034` cleanly. I did not merge, so the re-audit and the red-team re-check keep base `4c991ba` and an unchanged PR diff. The required check needs an up-to-date branch, so the merge happens at the gate, as for PR #38.

## 7. For the re-audit and the red-team re-check

Report 13's scope plus one test-only commit `700b533..4f55003` (section 2, diff SHA-256 `5014f247…4bd3`). The product code is the same as in report 13. The Mac and box brief for head `4f55003` follows in this folder as `13-mac-and-box-brief.md`, and it stays on hold until both accept.

## 8. Files

Repository: commit `4f55003`, one file (section 1).

Project folder `13-evidence/`, new:

- `diffs/anchor-order-4f55003.diff` and `diffs/commit-message-4f55003.txt`.
- `provenance-4f55003/`: both manifest runs and their output.
- `validation-4f55003/`: sync, build, `AnchorProcess` 30 times each way, the family each way, vet, the four anchor mutants, and the scripts.
- `validation-4c991ba/`:
  - `packages-idle-as-ci.json.gz`
  - `families-root.txt`
  - `mut13-merged.txt`
  - `mut10-merged.txt`
  - `final13c.sh` and `final13c-steps.txt`
- `variant-c/`: `drive.sh`, both grids, the harness SHA-256s, and the first attempt's error excerpt.
- `rehearsal/`: `rehearse13.sh`, its step log, the staged SHA-256s, the outputs of each part, `pr30_box_probe.py` and `pr30_storm.py`.

`SHA256SUMS.txt` is regenerated over the whole folder.
