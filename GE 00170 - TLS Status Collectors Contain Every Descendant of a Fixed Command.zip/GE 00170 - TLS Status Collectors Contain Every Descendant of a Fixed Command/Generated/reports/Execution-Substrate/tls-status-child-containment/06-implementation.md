# IMPLEMENTATION: child containment for both Remote Alpha TLS status collectors

**Draft PR [#30](https://github.com/evo-agi/Execution-Substrate/pull/30) is open against `trunk_dev`. The ES service TLS status collector runs each fixed OpenSSL command in a PID namespace of its own (decisions D1 to D5). The noninteractive remote collector uses option R2: it becomes a child subreaper and drains its descendants after every command. The root-side runner for the `sudo -n` path is not included (report 05). Next: fresh audit and red-team, the box run, and the Mac run.**

Written 2026-11-23 by the writer thread "Contain TLS status collector child processes". Earlier reports in this folder: 01 to 05.

## 1. Identity

| Item | Value |
|---|---|
| Repository | `evo-agi/Execution-Substrate` |
| Base | `trunk_dev` `036d50724b499b020c5149c55ad902cfcb1482c0` (PR #25 merged after 792f17c; the work was moved onto it before the commit, and only the `WORKFLOW_SHA256` line conflicted) |
| Topic branch | `claude/project-thread-wbmulu` |
| Topic commit | `e3dce375eda8208a6dfcd8d3ea754d4ab11436ec` (one commit) |
| Tree | `4d6163075c35f64cd747e0db3b89e893c91debe5` |
| Recipe | `governed-execution.audit-patch-manifest.v2`, source SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca` (checked before the run) |
| Textual diff SHA-256 | `b58c54631b5ad1488b04dd1485554933d1085b3dcda8ca60eb3c735302a9ce31` |
| Canonical manifest SHA-256 | `17adc312188df31ca579907dc62292f14cf50f11f7504c94ef71273cae1d90c9` |
| File count | 19 |

The manifest was taken twice with HEAD at the base, the upstream set to `origin/trunk_dev`, and nothing staged. Both runs gave the same bytes. After `git add -A`, the staged path set equals the manifest path set. The complete canonical manifest is in `06-evidence/manifest-v2.json`.

## 2. What changed

**ES service TLS status collector** (`scripts/internal/remote_alpha_es_tls_status.py`, runs as root). The decided design is D1 to D5 of the coordinator's 02:56Z message.

- Before each fixed OpenSSL command, the collector checks `/proc/self/ns/pid_for_children` and calls `unshare(CLONE_NEWPID)`. It then forks one fixed anchor as the first process of the new namespace.
- The fixed child is spawned exactly as before, as the second process. Right after the spawn, the collector returns to its own namespace with `setns` and checks that this worked.
- The cleanup owner, the group disposition, the hold, the reap and the absence scan are unchanged. After them, the collector closes the anchor's control pipe and waits for the anchor alone. The kernel kills every process still in the namespace.
- Unproved steps map through `child_namespace_unproved` to the existing `openssl_child_unproved`.
- The capability probe gained a namespace part.

**Noninteractive remote TLS status collector** (`scripts/internal/remote_alpha_operator_healthcheck_tls_status_noninteractive_remote.py`, runs as the SSH user):

- `main` runs `validate_descendant_capability()` before `collect_status()`. The probe requires that the collector has no child yet. It makes the collector a child subreaper with `prctl`, then starts a probe child that starts a grandchild and exits. The grandchild must show up as the collector's child, and the drain must then end it. Any failure emits the existing `remote_status_unavailable` document.
- `run_command` works in three steps:
  - It refuses before any spawn unless the capability flag is set.
  - It runs `supervise_fixed_child`, which is the previous body unchanged except that it records the child's process handle.
  - In a `finally`, it calls `drain_descendants(proc)`.
- The drain:
  - Only `waitid(P_ALL, WNOHANG|WNOWAIT)` raising ECHILD counts as proof that no descendant is left.
  - The fixed child is reaped only through its own process handle.
  - Each kill round comes after at most 64 reaps, and the whole drain is bounded at 2 s.
  - An unproved drain makes the command `runtime_failed` and clears the flag, so every later command is refused.

**Tests:**

- Deterministic models for both containments, which run on every host.
- Real-kernel tests:
  - The PID namespace tests need root. They skip themselves otherwise, and the new CI step runs them as root.
  - The subreaper tests run as any user on Linux. They skip only when the attempt to become a subreaper is refused.
- Guards:
  - Root collector: a fixture replaces the namespace and its probe part together or not at all.
  - Remote collector: only the shared stand-in may replace the flag or the drain, and nothing may replace the probe.
- Docs contract tests.

The three existing remote-collector tests that call `run_command` directly now use the shared stand-in. It proves that the test process has no child left after each command.

**CI.** A new step, "Listed root-package tests pass as root", runs the three `skips-itself` tests through `sudo -n` and fails unless each one passes. This widens privilege, and the PR says so. The only other use of sudo in the job is the bindfs installation, which trunk_dev already had. The self-check now allows exactly that one bindfs command.

**Docs:** PLANS.md, the noninteractive status contract (§8 bounds and rule, §9 sudo limit, §14), the Remote Alpha host overview, the access contract, and capability_probing.md.

## 3. Validation (cloud container only: kernel 6.18.44, Ubuntu 24.04 userland, Go 1.26.5, test user `ci` with UID 1500 and GID 1600)

| Check | Result |
|---|---|
| Whole root package as `ci`, `go test -count=1 .` | 480 pass. The 8 failures and 3 skips are exactly the root-package lines of `environment-only-tests.txt`. One first-run failure of `TestTrackedGeneratedArtifactHygiene` came from a `__pycache__` that my `py_compile` check left in the scratch copy. I removed it and the test passed on a re-run. |
| `go_test_gate_selftest.py` as `ci` with the pinned toolchain | 132 of 132. Run as root with the container's default PATH, 46 cases failed because a synthetic module resolved go1.24.7. That is an environment artifact and is not in CI. |
| `go_test_as_root.py` (the new CI step) as `ci` through sudo | 3 of 3 pass |
| `go vet ./...`, linux/amd64 and darwin/arm64 | clean |
| Root collector mutants (`06-evidence/root-collector-mutants.*`) | 26 of 26 caught, unprivileged and as root (run on 792f17c with collector and test bytes identical to the head) |
| Remote collector mutants (`06-evidence/remote-collector-mutants.*`) | 22 of 22 caught, unprivileged |
| R2 smoke test through `sudo -n` as an unprivileged user | A root descendant leads to `runtime_failed` after the 2 s bound. The flag is cleared and the next command is refused, as designed. |

Not run: the Remote Alpha host, macOS, and the GitHub runner. CI on PR #30 will show the runner.

## 4. Notes for the audit and red-team

1. The root collector's containment code was written by the earlier writer in 06325a2, before its tests existed. I reviewed it in this tranche and strengthened the behaviour tests until all 26 mutants were caught. I found no defect.
   - One point to look at: `ChildNamespace.close()` keeps retrying when `waitpid` on the anchor keeps raising an error other than ECHILD. That is the documented hold, which has no time limit, but it also applies to an error that is not a living anchor.
2. Two R2 facts rest on reasoning, not measurement:
   - With the collector as subreaper, the `subprocess` module never sees a process ID that the drain reaped directly. Every Popen child is reaped through its own handle before the next spawn, and after an unproved drain no further spawn happens.
   - The probe's `waitpid(middle, 0)` blocks without a bound. The probe child only forks, writes a few bytes to a pipe and exits.
3. Stated limits, also written in §8 and §9 of the contract:
   - A root descendant of the `sudo -n` path is detected but not ended.
   - A relay that leaves the group is chased with bounded per-process kills.
   - A process that a host service starts on a descendant's behalf is not a descendant.

## 5. Not done

- Box run on the Remote Alpha host: `pidfd_answers.py`, the R2 probe as the SSH user, and whether `sudo -n` uses a pseudo-terminal there. Required before merge. It needs David's go ahead on the Mac.
- Mac run.
- Fresh audit and red-team: required before merge. The coordinator arranges them.
- The local facade still uses `killpg` only. Out of scope.
- ES-6 drift test: a test-only PR after this one merges.

## 6. Envelope

- Effect status: `PR_OPEN_DRAFT` | `PUSHED claude/project-thread-wbmulu e3dce37`.
- Confidence:
  - The root collector contains every descendant of a fixed command on this kernel: 0.9 (real tests as root, mutants).
  - R2 contains every own-user descendant: 0.9 (real unprivileged tests, prototype, mutants).
  - Both behave the same on the Remote Alpha host: Unknown until the box run.
