# REPAIR: red-team 12 findings RT12-1, RT12-2 and RT12-3 on PR #30, and the update with trunk_dev 4c991ba

**All three Low findings are repaired, and observation O12-1 with them. The root collector now ends each fixed command's PID namespace itself, with one KILL to its anchor, before the process-group cleanup, and it reaps every child that the fixed command made of the collector with `CLONE_PARENT`, until one list of its children holds none. The anchor asks for a parent-death signal before it reports ready, so a killed collector takes the namespace with it whatever happens to the control pipe or the anchor. The noninteractive remote collector's fixed child gets a parent-death signal and a process limit of zero, so an unprivileged fixed child can start no process or thread at all. For root, and for the root command of the fixed `sudo -n` path, the limit does not bind; I stated that limit in the documents instead of hardening the drain (section 5). trunk_dev is merged twice: `0aa4a2b` as asked, and then `4c991ba`, because #39 landed meanwhile and made the PR unmergeable; that merge moves this PR's two new test files into `scripts/` and points the root step at that package (section 7). New head `700b533`, manifest `2c850673…eaa0` against base `4c991ba`, 19 files. Next: a narrow re-audit and the red-team's re-check; then the one Mac and box run (brief to follow in this folder).**

Written 2026-11-23/24 by the writer thread "Contain TLS status collector child processes". Earlier reports in this folder: 01 to 12. Guesses are marked "Guess:", inferences "Inference:".

**Update (2026-11-24 ~02:15Z):** the runs listed as still running in section 8 are done, see `13a-validation.md`. One test-only commit followed: head `4f55003`, manifest `2b9233cb…961b`, same 19 paths; the collectors are unchanged.

## 1. Identity

| Item | Value |
|---|---|
| Repository | `evo-agi/Execution-Substrate`, draft PR [#30](https://github.com/evo-agi/Execution-Substrate/pull/30) |
| Base | `trunk_dev` `4c991ba1c43ac135d9d94853696d14a21523a690` (was `76c030f`; trunk_dev gained #29 `fdfa3bc`, #36 `400ff7f`, #33 `0aa4a2b`, #41 `725c97a`, #37 `42db339` and #39 `4c991ba`) |
| Topic branch | `claude/project-thread-wbmulu` |
| Previous head (audit 11, red-team 12) | `eed4c9b41b37c0e6bf9e33e3ac2b314ca3ef89ea` |
| New head | `700b533c8dee44e9b83fa4ccb15087a737aeb895`, three commits on top of `eed4c9b`, fast-forward push: `f7a1170` (merge of `0aa4a2b`), `bb6e05a` (the repair, 11 files, +1382 −297), `700b533` (merge of `4c991ba`) |
| Tree | `004d04662a5ef0c4820c6d01e0e7e47b2bc62e0e` |
| Recipe | `governed-execution.audit-patch-manifest.v2`, source SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca` (checked before the run) |
| Textual diff SHA-256 | `af20695eded45cf7271b9373e74eecf932499fbbf5e9e837d1eda036bdea52c5` |
| Canonical manifest SHA-256 | `2c85067375440e845458ed290896361cada57efef9d67cc5e7a73417fe6eeaa0` |
| File count | 19 (3 untracked under the flow: `.github/ci/go_test_as_root.py` and the two new test files in `scripts/`) |

Flow: commit, record the tip; `git reset --mixed 4c991ba`; upstream pinned to `origin/trunk_dev` (which was `4c991ba` after a fresh fetch); the recipe run twice into a fresh 0700 directory, byte-identical; `git reset --mixed` back to the tip and the upstream restored; every entry's SHA-256, size and mode checked against the tip's blobs (19 of 19, and the same 19 paths as `git diff --name-only 4c991ba 700b533`). Logs in `13-evidence/provenance/`. The repair commit's own diff is `13-evidence/diffs/repair-bb6e05a.diff` (SHA-256 `30f69545…146a`), for a narrow look at the repair alone.

## 2. RT12-1: strays of the collector are reaped (root collector)

A process that the fixed child makes with `clone3` and `CLONE_PARENT` is in the namespace, and its parent is the collector. Before the repair nothing reaped it, and its zombie held either the group cleanup (stray in the fixed child's group) or the wait for the anchor (stray outside it), both without a bound.

- `ChildNamespace.end(fixed_child)` replaces the three `release()` calls before the cleanup owner. After the release and the anchor's KILL (section 3), it waits without a time limit until the fixed child is terminal (`waitid` with `WNOWAIT`, so the fixed child stays reserved for the cleanup owner), and only then lists the collector's children (`/proc/self/task/<tid>/children`, new helper `own_children`). Every child outside the collector's own PID namespace (new helper `pid_namespace`, compared with the namespace that `open()` recorded) that is neither the anchor nor the fixed child is a stray. A stray is reaped with `waitpid(pid, WNOHANG)` once it has ended, and never signalled; the kernel kills it with the namespace. `end()` returns only when one list holds no stray.
- Why one empty list is final. Only the fixed child and a stray can make a child of the collector inside the namespace (`CLONE_PARENT` gives the caller's own parent; the anchor is refused `CLONE_PARENT` as the first process of its namespace). The list is read after the fixed child was seen terminal. The kernel reads the children list one entry at a time under `tasklist_lock`, so the read is not one snapshot, but entries of the collector's children are removed only when the collector reaps them (it is single-threaded and reaps only after the read), and new children are appended at the tail, so a read sees every child that existed when it began. A read that finds no stray therefore began at a moment when no stray existed and the fixed child was terminal, and none can appear later. A stray inherits its exit signal from its caller's thread group leader (`CLONE_PARENT` copies it), which is SIGCHLD for the fixed child and so for every stray, so a plain `waitpid` sees it.
- The red-team prototype hooked the reaping into the group cleanup's two waits (`resolved_with_leader_reserved`, `prove_group_absent`). I kept the group logic untouched (decision D4) and reap before the cleanup instead: after `end()`, no stray of the collector is left, so the cleanup finds the fixed child alone.
- `close()` also reaps strays in its wait for the anchor (skipping only the anchor). That covers the path without `end()`: an exception inside `Popen` after its fork leaves a child of the collector in the namespace (observation O7-1 of audit 07), which would otherwise hold the anchor.
- The capability probe now also proves the method: after the anchor's end, the probe member must be listed among the collector's children with a PID namespace other than the collector's.

## 3. RT12-2: the namespace ends by KILL, and with a killed collector (root collector)

The release before the cleanup was a request: a root process of the namespace could open a second write end of the control pipe through `/proc/<collector>/fd`, or stop the anchor with `ptrace`, and any process could keep the anchor busy reaping orphans. A killed collector then left everything alive.

- `end()` closes the control pipe and then sends the anchor one SIGKILL. The anchor is the collector's unreaped child, so its PID is still reserved. A failed KILL is unproved, and `end()` then returns without waiting (`close()` reports it). This makes the end independent of the pipe and of the anchor's state: a stopped or busy process still dies of SIGKILL.
- The anchor's first step is `prctl(PR_SET_PDEATHSIG, SIGKILL)`; a failure ends it with status 1. Then it closes what it inherited (now keeping the control pipe's read end and the write end of a new ready pipe), writes one byte `r` to the ready pipe, and closes it. `open()` reads that byte before it returns, so before any spawn; a missing or wrong byte is `child_namespace_unproved`, which means no spawn. This closes the window that the red-team named: between the anchor's fork and its `prctl`, a death of the collector would have left the anchor depending on the pipe again. `getppid()` inside the anchor cannot serve as that proof, because inside the new namespace it is 0.
- When the collector dies, its file table closes before the kernel sends the parent-death signals, so the anchor may still see the end of input first and exit 0; either way it ends. The real collector-death test therefore accepts the anchor ending with status 0 or by SIGKILL.
- The probe keeps the plain release, because it tests that the kernel ends the namespace when the anchor ends by itself.
- The comments and documents now say that a fixed child that still runs at a failure is killed by the kernel before the cleanup owner runs, without the grace period of TERM before KILL. Since `end()` waits for the fixed child to be terminal, the race that report 10 described (the cleanup's TERM against the kernel's kill) no longer exists.

What is left (stated in the documents): a root process of the namespace that may trace the anchor could inject a `prctl` that undoes its parent-death signal; then a killed collector leaves that namespace alive. While the collector lives, its KILL ends the anchor regardless. The red-team's design option (an unprivileged fixed child for the root collector) would remove this at the cause; it is not in this PR (section 9).

## 4. RT12-3 and O12-1: the remote collector's fixed child

`supervise_fixed_child` passes `preexec_fn=fixed_child_setup(os.getpid())`. Between fork and exec the fixed child:

1. asks for `prctl(PR_SET_PDEATHSIG, SIGKILL)` (the `prctl` symbol is resolved before the fork);
2. proves `os.getppid()` is still the collector, so the collector cannot have died before step 1;
3. sets `RLIMIT_NPROC` to `(0, 0)` (`FIXED_CHILD_PROCESS_LIMIT = 0`; tests of the drain set `None`).

The kernel then refuses an unprivileged fixed child every new process and thread (EAGAIN), so chains, herds and relays cannot start, and a killed collector takes the fixed child with it (O12-1). A failure of the setup raises `SubprocessError` in the collector, which returns `returncode=125, runtime_failed=True`; the drain still runs. The collector's own limit is unchanged. The fixed `openssl`, `sha256sum` and `stat` commands start no process (section 8 of the design document already said so), so the limit costs them nothing.

## 5. The root and `sudo -n` cases: stated, not hardened

Root is not bound by `RLIMIT_NPROC` (the kernel exempts `INIT_USER` and `CAP_SYS_RESOURCE`), and the exec of a set-user-ID program such as `sudo` clears the parent-death request. So for every command when the SSH target is root, and for the root command of the fixed `sudo -n` path, the drain is the only containment, and the red-team's chain, herd and backlog shapes still beat it. In every red-team run of those shapes the command was a runtime failure with the flag cleared, never a success with a process alive, and that contract holds and is now tested.

I chose to state this in the documents rather than harden the drain, because a root process can defeat any per-process drain anyway (it can raise its own limits, signal the collector, or start processes through host services), and an unprivileged collector cannot end a root descendant of `sudo -n` at all, which the documents already stated. Hardening the drain against waiting shapes (whole-tree kills per round, an unbounded children list) would add host-wide signalling of processes that are not the collector's children, which reopens the PID-reuse question that the drain was designed to avoid. Inference: the honest bound for root is the reported failure. If the coordinator prefers hardening, that is a separate change.

Documents: `.docs/remote_alpha_operator_healthcheck_noninteractive_status.md` §8 (a new bound line, a rule bullet for the setup, the limits paragraph rewritten; the red-team's quoted sentence "each round only shrinks what is left … a relay that stays ahead" is gone and pinned absent), §9 (neither the limit nor the parent-death request binds the `sudo -n` path), `PLANS.md` P0v paragraph, and `capability_probing.md` (the new skip rule of the process-limit test).

## 6. Tests

Root collector (`scripts/remote_alpha_es_service_tls_status_child_namespace_test.go` since the merge of `4c991ba`):

- The deterministic model gains the ready pipe (`read`), the collector's children list and PID namespaces, a fixed child, waves of strays (a wave appears while a list is being read, as when a living stray makes the next one) and children at home. Sequence, AnchorWait and Probe follow the new order; Sequence has three new refusals (a failed ready pipe, no ready byte, a failed read of it); Probe has two new refusals (member not listed, member listed at home).
- New deterministic test `…ChildNamespaceEnd`, 13 cases: the order release, KILL, terminal, list; the fixed child left unreaped for the owner; strays reaped wave by wave until a list holds none; a late stray; a child at home never waited for or signalled; the list only after the fixed child is terminal; a failed list, a failed wait, a failed KILL and a failed release; and `close()` reaping a child that a failed spawn left.
- FixedCommand: the recorder has `end(fixed_child)` and no `release`, so a bare release would fail; it checks that `end` gets the spawned child's PID.
- AnchorProcess (any user, no namespace): the anchor's descriptor list when the ready byte arrives holds only the standard streams, the control pipe and the ready pipe; the ready pipe then reaches end of input; and an anchor whose parent ends is killed by SIGKILL while another process still holds its control pipe open.
- RealCollectorDeath accepts the anchor ending by end of input or by its parent-death signal.
- The red-team's RealSiblings and RealDeafAnchor are adopted (diff SHA-256 `c3e9d2cf…724c` checked), with comments that state the rule, and RealSiblings tightened: the command must return `(0, "fixed")` and leave no orphan, not just return. Both are `skips-itself` lines; the comment says five tests now run as root.
- DocumentsContract: the anchor's code is pinned whole again (parent-death request, then closing, then the ready byte); the namespace class sends exactly two signals, both a KILL to the anchor; `open()` reads the ready byte; each of the three cleanup owner calls directly follows `namespace.end(proc.pid)`, and the body has no bare `namespace.release()`; new phrases pinned in the three documents.
- The local stand-in `remoteAlphaESStatusLocalChildNamespace` (in `scripts/remote_alpha_es_service_tls_status_test.go`) has `end` instead of `release`.

Remote collector (`scripts/remote_alpha_operator_healthcheck_tls_status_noninteractive_descendants_test.go`):

- RealKernel sets `FIXED_CHILD_PROCESS_LIMIT = None`: its descendants stand for root or `sudo -n` descendants, where only the drain contains them.
- RealCrowd (the red-team's test, adapted): with the limit off, a chain of 80 and a herd of 120 (read bound 256 bytes) must each be a runtime failure without output that clears the flag and refuses the next command; their processes end on a release file and the capability is proved again. The red-team's version expected "gone", which only the limit gives; that half moved to RealProcessLimit. Determinism: the drain's pauses alone (0.5 ms doubling to 50 ms) cap it at about 46 rounds in 2 s however fast the host, and each round hands it one link.
- RealProcessLimit (new): decides by an attempt in a child whether `RLIMIT_NPROC (0, 0)` binds this user and skips itself only on the answer that a fork still worked (root). Then: a fixed child's first fork fails with EAGAIN and nothing is left; a thread is refused; the collector's own limit is unchanged. It is not a `skips-itself` line, because it passes on the runner, which is not root. Its chain is bounded and released, after a first draft with an unbounded chain left about 1,200 processes of the test user behind when I ran it against the old collector (I ended them with one `kill -9 -1` as that user; nothing else was affected).
- RealCollectorDeath (new, any user): a killed collector takes its fixed child with it within 10 s; the control, with a setup that does nothing, shows the fixed child outliving the collector.
- RunCommand: a setup that fails (a limit that `setrlimit` refuses) means the command does not run and is a drained runtime failure.
- DocumentsContract: the new bound line, setup bullet and limits; the setup's order (parent-death request, parent proof, limit); `preexec_fn` passed exactly once.

## 7. The merge of trunk_dev 4c991ba (#39)

#39 moved the Remote Alpha script tests from the root into `scripts/` (package `scripts_test`), with a guard in `internal/testutil` that keeps the root to its docs tests and requires every command that a `scripts` test starts to run at the repository root. The merge had no textual conflict, but this PR's two new test files would have stayed at the root, where they no longer compile against the moved helpers. The merge commit therefore also does what #39 asks of tests it could not see (29 lines added, 28 removed beyond the textual merge; `13-evidence/diffs/merge-resolution-700b533.diff`, SHA-256 `5503f341…a3c`):

- `remote_alpha_es_service_tls_status_child_namespace_test.go` and `remote_alpha_operator_healthcheck_tls_status_noninteractive_descendants_test.go` move into `scripts/` as `package scripts_test`. The one command they start themselves (`runRemoteCollectorDescendantProbe`) gets `cmd.Dir = executionSubstrateRepoRoot`. The guard caught the missing line when I removed it again in a scratch copy (`13-evidence/checks/layout-guard-sees-the-moved-tests.txt`).
- The five `skips-itself` lines name `execution-substrate/scripts`, and the root step builds and runs that package. Its name was "Listed root-package tests pass as root"; it is now "Listed tests pass as root", because the tests are no longer in the root package. The gate self-test pins the new command and the workflow's new SHA-256.
- `capability_probing.md` called these tests "Root-package tests" in two sentences, one of them from trunk_dev (#39 left it); both now say "in `scripts/`", and the two section markers that tests use follow.

## 8. Validation (cloud container: kernel 6.18.44, Python 3.13.18, Go 1.26.5, 4 CPUs, `pid_max` 32768, no Yama, test user `ci` UID 1500)

Two trees were tested: the repair on the `0aa4a2b` base (tree `6a58d98`, commit `bb6e05a`), where everything below ran first, and the merged head `700b533` (tree `004d046`), where the packages, the gate self-test, the root step and vet ran again. Logs in `13-evidence/validation-0aa4a2b/` and `13-evidence/validation-4c991ba/`.

**Merged head `700b533`, as `ci`:**

- `go test -count=1 . ./scripts/ ./internal/testutil/`: 498 top-level tests pass (root 159, `scripts` 333, `testutil` 6). The 8 failures are the 8 `execution-substrate/scripts` entries of `environment-only-tests.txt` that fail here (the other 3, runtime security boundary checks, fail only on the runner); the 5 skips are exactly the five `skips-itself` lines.
- `go_test_gate_selftest.py`: 132 of 132.
- `go_test_as_root.py .github/ci/environment-only-tests.txt execution-substrate/scripts` (the CI step) as `ci` through sudo: "tests as root passed: 5 of execution-substrate/scripts".
- `go vet ./...` for linux/amd64 and darwin/arm64: clean.
- The #39 guards (`TestRootKeepsOnlyItsDocsTests`, `TestImportersNameRepositoryPathsFromTheRoot`) pass, and the second fails when the new `cmd.Dir` line is removed (section 7).

**Repair on the `0aa4a2b` base:**

- Root package as `ci`: 489 pass, 5 skips (the five `skips-itself` lines), 9 failures: the 8 known environment-only entries and `TestTrackedGeneratedArtifactHygiene`. That one was my harness, not the change: a check that I ran from the writer clone at 23:41 left `scripts/internal/__pycache__/remote_alpha_es_tls_status.cpython-313.pyc` there, ignored by `.gitignore`, and the sync script copies the working tree into the test clone with `git add -f`. The file is in no commit; I deleted it, and the test passes on the merged head. The tested tree minus that file is exactly the committed tree `6a58d98` (checked with a separate index).
- Gate self-test 132 of 132; root step 5 of 5; vet clean for both targets.
- Namespace and remote families as root: 21 pass, 1 skip (`…DescendantRealProcessLimit`, which skips itself where the limit does not bind, as for root).
- **Regression proof**, run by hand before the commit (its output went to the terminal only; the box rehearsal below records it again in files): against the `eed4c9b` collectors, RealSiblings (held for its 20 s bound), RealDeafAnchor, the remote RealProcessLimit and the remote RealCollectorDeath fail; RealCrowd passes on both, as its contract (a reported failure with the limit off) is the drain's, which did not change.

**Mutants of this repair, 27, each as `ci` and as root on the `0aa4a2b` tree: 27 of 27 caught both ways** (`13-evidence/validation-0aa4a2b/mut13.txt`, definitions in `mut13-apply.py`). Columns: tests that caught it as `ci`; tests that caught it only as root.

| Mutant | Caught as `ci` by | Also as root |
|---|---|---|
| `M13b-anchor-keeps-descriptors` | AnchorProcess, DocumentsContract | RealKernel, RealDescendants, RealCollectorDeath, RealSiblings, RealDeafAnchor |
| `M19b-anchor-pipe-end-kept` | Sequence, End, Probe | none |
| `N01-no-end-normal-path` | FixedCommand, DocumentsContract | RealDescendants, RealSiblings, RealDeafAnchor |
| `N02-release-not-end-normal-path` | FixedCommand, DocumentsContract, LocalBoundaryNeedsNoTargetFacility | RealDescendants, RealSiblings, RealDeafAnchor |
| `N03-no-end-inner-failure` | FixedCommand, DocumentsContract | RealDescendants |
| `N04-no-end-outer-failure` | FixedCommand, DocumentsContract | none |
| `N05-end-does-not-kill` | End, DocumentsContract | RealDeafAnchor |
| `N06-anchor-no-pdeathsig` | AnchorProcess, DocumentsContract | RealDeafAnchor |
| `N07-ready-before-close` | AnchorProcess, DocumentsContract | none |
| `N08-ready-not-awaited` | Sequence, Probe, DocumentsContract | RealKernel, RealDescendants, RealCollectorDeath, RealSiblings, RealDeafAnchor |
| `N09-ready-word-unchecked` | Sequence, DocumentsContract | none |
| `N10-end-reaps-no-stray` | End, DocumentsContract | RealSiblings |
| `N11-close-reaps-no-stray` | Sequence, End, Probe, DocumentsContract | none |
| `N12-settle-on-alive-count` | End | none |
| `N13-list-before-terminal` | End, DocumentsContract | none |
| `N14-home-children-waited` | End, DocumentsContract | none |
| `N15-strays-killed` | End, DocumentsContract | none |
| `N16-end-returns-before-terminal` | End, DocumentsContract | none |
| `N17-probe-no-list-check` | Probe | none |
| `N18-end-ignores-list-error` | End | none |
| `N19-anchor-timer` | AnchorProcess, DocumentsContract | RealDescendants |
| `R30-no-process-limit` | DocumentsContract, RealProcessLimit | none |
| `R31-no-pdeathsig` | DocumentsContract, RealCollectorDeath | none |
| `R32-no-preexec` | RunCommand, DocumentsContract, RealProcessLimit, RealCollectorDeath | none |
| `R33-no-parent-check` | DocumentsContract | none |
| `R34-setup-failure-not-runtime-failure` | RunCommand | none |
| `R35-limit-soft-only` | RunCommand, DocumentsContract, RealProcessLimit, RealCollectorDeath, RemoteCollectorHardBounds | none |

Notes: N12 (settle on a count of living strays instead of listed ones) and N18 (ignore a failed list) are caught only by the deterministic End test, since their real-kernel effect needs a stray that ends between two reads. R33 (no parent check after the parent-death request) is caught only by the pin of the setup's order: the window between the fork and the `prctl` cannot be hit on purpose. R30 as root is caught by the pin alone, since the process-limit test skips itself as root.

**Earlier mutants on the repaired collectors (0aa4a2b tree):** the root collector's 26 from audits 07 to 11: 24 of 24 that still apply caught as `ci` and as root; M13 and M19 no longer apply because the repair rewrote their text, and M13b and M19b above replace them. The remote collector's 22 from audits 07 to 11 (its probe and drain): 22 of 22 caught unprivileged (`earlier-remote-mutants.txt`). Report 10's RELEASE-BEFORE-TERMINAL and B20: caught both ways.

**`sudo -n` under the fixed child's limit** (`13-evidence/checks/sudo-under-process-limit.txt`, sudo 1.9.15p5): as `ci` with `RLIMIT_NPROC (0, 0)` set the way `fixed_child_setup` sets it, `sudo -n /usr/bin/id -u`, `sudo -n /usr/bin/stat …` and `sudo -n /bin/sh -c /usr/bin/id -u` all succeed (the root shell can still fork), while an unprivileged `/bin/sh -c /usr/bin/id -u` gets "Cannot fork". So the fixed sudo path keeps working under the limit here; the box can differ (its sudoers and PAM), which the brief checks.

**Still running when I wrote this** (they start one after another on an otherwise idle container, about two hours in all): on the merged head the packages and gate again, the families as root, the 27 mutants and report 10's two; variant c against the `eed4c9b` and the repaired root collector with the red-team's harness unchanged; and a rehearsal of the box run (the ten real-kernel tests' probes against the new and the `eed4c9b` collectors, the box probe's root and r2 parts, and the variant c driver of the brief). Results go to `13-evidence/` and to an addendum `13a-validation.md` in this folder; I will tell the coordinator if any of them fails.


## 9. Not done, and for the coordinator

- Box and Mac run: held until the re-audit and the red-team re-check accept. The brief will be revised for this head with the red-team's section 8 items (the two new root tests' shapes on the box kernel, `kernel.yama.ptrace_scope`, variant c with the box's `pid_max`, the SSH user's `ulimit -u`, PAM limits and `TasksMax`, whether the fixed `sudo -n` commands run under `RLIMIT_NPROC (0, 0)`, whether any SSH target is root, and a killed remote collector).
- Design option of report 12 (an unprivileged fixed child for the root collector): not done; it changes the privilege model of decision D4. Inference: it would remove the remaining "root is still root" cases of RT12-1 and RT12-2 at their cause.
- PR #35 coupling, updated for #39: whichever lands second adjusts the root step: its PATH to `/usr/sbin:/usr/bin:/sbin:/bin`, two expectations in `go_test_gate_selftest.py`, and the package of #35's root-only tests (the step runs the listed tests of one package, now `execution-substrate/scripts`). Guess: once #35 takes #39, its root-only tests live in `scripts/` too, so one package still suffices.
- O12-2 (a held root collector ignores the latched signal), O12-4 (two parser exceptions caught by `main`): not changed; only a process that truly cannot die now reaches the unbounded waits.

## 10. Files

Repository, repair commit `bb6e05a` (11 files): `scripts/internal/remote_alpha_es_tls_status.py`, `scripts/internal/remote_alpha_operator_healthcheck_tls_status_noninteractive_remote.py`, `remote_alpha_es_service_tls_status_child_namespace_test.go`, `remote_alpha_es_service_tls_status_test.go`, `remote_alpha_operator_healthcheck_tls_status_noninteractive_descendants_test.go`, `.github/ci/environment-only-tests.txt`, `PLANS.md`, `.docs/system_overview/remote_supported_host_alpha.md`, `.docs/system_overview/remote_alpha_access_contract.md`, `.docs/remote_alpha_operator_healthcheck_noninteractive_status.md`, `.docs/system_overview/capability_probing.md`.

Repository, merge commit `700b533` beyond the textual merge (7 files): the two test files moved into `scripts/`, `scripts/remote_alpha_es_service_tls_status_local_boundary_test.go` (one section marker), `.github/ci/environment-only-tests.txt`, `.github/ci/go_test_gate_selftest.py`, `.github/workflows/go.yml`, `.docs/system_overview/capability_probing.md`.

Project folder `reports/Execution-Substrate/tls-status-child-containment/`: this report; `13-evidence/` with `environment.txt`, `provenance/` (both manifest runs and their output), `diffs/` (the repair commit's diff, the merge resolution, the three commit messages), `validation-0aa4a2b/` and `validation-4c991ba/` (summaries, gzipped `go test -json` streams, self-test, root step, vet, families, mutant tables and the mutant definitions), `checks/` (sudo under the limit, the layout guard), and `SHA256SUMS.txt`.
