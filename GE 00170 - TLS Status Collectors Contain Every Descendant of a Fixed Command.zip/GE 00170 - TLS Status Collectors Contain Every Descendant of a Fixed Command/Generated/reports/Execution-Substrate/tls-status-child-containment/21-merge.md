# MERGE: PR #30 into trunk_dev as 2c6847a

**PR #30 is merged into trunk_dev as `2c6847a3df0cb4f31068e5e7fb067d07b67c1eb3`, a squash at 2026-11-24 12:39Z on the coordinator's merge turn. The merge commit's tree `0eb58fbc6fe00c28bcbd030d6c989f5bc7ee6c14` is the tree of the checked head `f76db77`, and its parent is `230954d`. It changes the same 20 files, +4882 −34. Next for this work: the box run P30, which gates the first TLS status check from a commit that contains this merge.**

Written by the writer thread "Contain TLS status collector child processes".

## Gate

| Check | Result |
|---|---|
| Head equals the checked commit | PR head `f76db77d2cf59666e36318fb3b3c25f1cd824ffc`, merged with `expectedHeadSha` set to it. Diff check 20 (`20-diff-check.md`) accepted `f76db77`; sync check 19 accepted `cd36797`; diff check 17 accepted `1861e23`; re-audit 14 and red-team re-check 15 accepted the code at `4f55003` |
| Up to date | Base `trunk_dev` `230954d867dd29b60865965dce3d7d0a19bcdf16` is an ancestor of the head. GitHub showed `mergeable_state: clean` |
| Manifest | v2 `66ec78d154042e79efed33179a31878d2369c51d3303f93d7e8ceca921f519f8`, 20 files against `230954d`. The auditor matched it byte for byte at open and close of check 20 |
| CI | Run 45388336474 on `f76db77` passed. That includes the root step: 9 of 9 on the runner, with #35's four firewall tests and the bridge isolation count of exactly 15 |
| Post-merge bytes | `git rev-parse 2c6847a^{tree}` = `0eb58fb…` = `f76db77^{tree}`. `git diff --stat 230954d 2c6847a`: 20 files changed, 4882 insertions, 34 deletions |
| Draft state | The PR was marked ready just before the merge. Its description lists what was required before the merge and what comes after it |
| Codex review | Codex reviewed `f76db77` when the PR was marked ready (12:38Z). It finished at 12:41Z with no findings (PR comment 7131725679) |

## Decisions on the way (2026-11-24)

- **10:15Z:** merge turn. Then at 10:20Z: hold, because the box and Mac runs were not waived.
- **11:03Z:** merge turn again.
  - 11:10Z: the box and Mac runs move after the merge. Every problem they can find fails closed, and merging puts nothing on the box.
  - 11:13Z: they become P30, their own box turn. P30 gates the first TLS status check from a commit with #30 (`p30-gate-moved-from-es-upgrade-plan.md`).
- **11:54Z:** #35's bridge isolation fix stays in #30. Only #30's root step can run it.

## After the merge

- **P30.** The box and Mac run, on the coordinator's box turn. First, revise `13-mac-and-box-brief.md` for `2c6847a`: the commit and tree in A2 and A3, the remote collector's sum `432366fa…6273`, and the probe sums in A7 if a test changed. Until P30 passes, nobody runs a TLS status check on the box from a checkout that contains `2c6847a`.
- **ES-6 drift test** for the collectors' supervision functions: a test-only PR.
- **The local facade** (`scripts/remote_alpha_operator_healthcheck_tls_status_noninteractive.py`) still uses `killpg` only. Out of scope here.
