# P30: PR #30 box and Mac run (its own box turn)

**P30 gates the first TLS status check on the Remote Alpha box from a commit that contains PR #30. Until P30 has passed for that commit, nobody runs a TLS status check on the box from such a checkout. That covers the operator routes `remote_alpha_operator.sh recovery-session es-service-tls-status` and `es-governance-tls-status`, and the noninteractive healthcheck. The coordinator decided at 11:13Z that it is its own turn in the box queue. It does not depend on the ES box upgrade, which neither installs nor runs the collectors.**

Written 2026-11-24 by the PR #30 writer thread ("Contain TLS status collector child processes"). The coordinator first moved this run from before PR #30's merge to a precondition of the ES box upgrade (11:10Z). The upgrade's writer then pointed out that the upgrade never puts the collectors on the box, so the coordinator made it a separate gate (11:13Z). This file replaces section 4a of `es-box-upgrade/02-plan.md`, and that plan now points here.

**Why it gates use and not the merge.**

- **How the code reaches the box.** Both collectors reach the box only when an operator runs a TLS status check from a checkout that contains them. The operator script stages the root collector into a fresh `/tmp` folder on each run (`scripts/remote_alpha_operator.sh`, "Stages only scripts/internal/remote_alpha_es_tls_status.py"). The noninteractive facade sends the remote collector on standard input. Merging into trunk_dev puts nothing on the box.
- **What a problem would look like.** Every problem this run can find shows as an explicit failure of the TLS status check: `runtime_failed`, or `openssl_child_unproved`, which is reported as unavailable. None gives a wrong status, and none lets more descendants escape than the code before PR #30 did. The ptrace and root-target facts are stated limits already.

**What it checks.** On the box:

- the root collector's whole capability probe and a real
  `openssl version` in its own PID namespace, as root through `sudo -n`;
- the noninteractive remote collector in its real launch shape, as the
  SSH user, including the fixed `sudo -n` commands under the fixed
  child's `RLIMIT_NPROC` of `(0, 0)` with the box's sudo, sudoers and
  PAM;
- the ten real-kernel tests' probes, against the new collectors and
  against those of `eed4c9b`;
- `pidfd_answers.py`;
- as facts:
  - `kernel.yama.ptrace_scope`, `pid_max` and `TasksMax`;
  - PAM limits;
  - whether the SSH user is root;
  - whether `sudo -n` uses a pseudo-terminal.

On the Mac: the collectors' tests pass, and the real-kernel tests skip
with their stated reasons.

**Exact commands.** The source is the brief
`reports/Execution-Substrate/tls-status-child-containment/13-mac-and-box-brief.md`.
Before the run, its writer revises it for the commit to be used: the
trunk_dev commit that PR #30 merged as, or a later one. The revision changes three things:

- the commit and tree in A2 and A3;
- the remote collector's SHA-256 in B3b, which is
  `432366fad4572aa115fac1e341146bdf7ca40674d2573f3397d8bc9898986273`
  at PR #30's head `cd36797`; the root collector stays
  `c6c2dc75f3d214027a73392cf84cdbee64227d3628d8bcfb3e2c2dddb774dd5e`
  unless a later commit changes it;
- the probe sums in A7, if a test changed.

One Remote Control session on the Mac runs it, using the brief's exact
text. The steps are:

- **Part A (Mac):** A1 to A7, the clone, tests, vet, gofmt and probe dump.
- **B3 (box):** staging into one `mktemp -d /tmp/pr30-box.XXXXXX` folder
  `$D`, with `pr30_box_probe.py` (SHA-256 `cf6dcade…eb75`) and
  `pidfd_answers.py` (`f22289dd…8dad`).
- **Part C (Mac):** cleanup.

The box commands that decide the result are below. `BOX` stands for
`ssh -T -o BatchMode=yes -o ConnectTimeout=15 [test box name withheld]`.

```
B1  BOX 'hostname; uname -r; nproc; /usr/bin/python3 --version; /usr/bin/openssl version; id -un; id -u; sudo -n true && echo "sudo -n: ok"; sudo -n -V | head -1; systemctl is-active es ags nomad vault spire-agent spire-server docker'
    BOX 'echo "ptrace_scope=$(cat /proc/sys/kernel/yama/ptrace_scope 2>&1)"; echo "pid_max=$(cat /proc/sys/kernel/pid_max)"; echo "ulimit -u=$(ulimit -u)"; grep "Max processes" /proc/self/limits; systemctl show -p TasksMax -p TasksCurrent "user-$(id -u).slice"; grep -H pam_limits /etc/pam.d/sshd /etc/pam.d/sudo /etc/pam.d/common-session 2>&1'
B2  BOX 'sudo -n /usr/bin/tty </dev/null; echo "tty_exit=$?"'
B4  ssh -T -o BatchMode=yes -o ConnectTimeout=15 -o RequestTTY=no [test box name withheld] "exec /usr/bin/python3 -I -S -B - r2 '$D'" < "$T/pr30_box_probe.py"; echo "exit $?"
B5  BOX "sudo -n LC_ALL=C /usr/bin/python3 -I -B '$D/pr30_box_probe.py' root '$D'"; echo "exit $?"
B5b for n in RealKernel RealDescendants RealCollectorDeath RealSiblings RealDeafAnchor; do for v in new old; do BOX "sudo -n LC_ALL=C /usr/bin/python3 -I -B '$D/pr30_box_probe.py' probe TestRemoteAlphaESServiceTLSStatusChildNamespace$n $v '$D'"; echo "exit $?"; done; done
B5c for n in RealKernel RealProbeRefusesAChild RealCrowd RealProcessLimit RealCollectorDeath; do for v in new old; do BOX "/usr/bin/python3 -I -B '$D/pr30_box_probe.py' probe TestRemoteAlphaOperatorHealthcheckTLSStatusNoninteractiveDescendant$n $v '$D'"; echo "exit $?"; done; done
B6  BOX "/usr/bin/python3 -I -B '$D/pidfd_answers.py'"; BOX "sudo -n /usr/bin/python3 -I -B '$D/pidfd_answers.py'"
B7  BOX "ps -eo pid,ppid,user,stat,args | grep -F '$D' | grep -v grep"; BOX "sudo -n rm -rf '$D'; ls -ld '$D' 2>&1; systemctl is-active es ags nomad vault spire-agent spire-server docker"
```

**Pass criteria.** P30 passes only when every item holds:

1. **Mac, A4 to A7.**
   - A4 exits 0 with no failed test. The only skips are the five
     `…ChildNamespaceReal…` tests, `…ChildNamespaceAnchorProcess` and the
     five `…NoninteractiveDescendantReal…` tests.
   - A5 and A6 print nothing.
   - A7 exits 0, with the ten probe sums of the revised brief.
2. **Staging.** Every SHA-256 in B3 and B3b matches the revised brief.
3. **B4, as the login user.**
   - `"process limit of the fixed child": 0`.
   - `"r2 descendant probe"` gives `"verdict": "accepted"` with
     `"flag": true`.
   - The command that tries to start a descendant gives:
     - `"returncode": 0`;
     - `"stdout": "EAGAIN"`, or `"forked"` if the login user is root;
     - `"runtime_failed": false`;
     - `"process left after return": false`.
   - Both `sudo -n` commands under the limit give `"returncode": 0` and
     `"runtime_failed": false`, with `"stdout": "0"` and
     `"stdout": "644:0:0:regular file"`.
4. **B5, as root.**
   - `"root capability probe (both parts)"` gives
     `"verdict": "accepted"`.
   - The real `openssl version` returns 0.
   - Modes `setsid`, `zombie` and `slow` each give
     `"result": "(0, b'fixed', b'')"` with
     `"process left after return": false`.
   - Mode `zombie-run` gives `"raised": "Incomplete('child_timeout')"`
     with `"process left after return": false`.
   - `"root end"` gives `"unproved": false`.
5. **B5b and B5c, with `new`.** Every line has `"capability": true`,
   exit 0, `"failed cases": []` and no timeout. The one exception is
   `…RealProcessLimit` when the login user is root: it may print
   `"capability": false` with a reason, because the limit does not bind
   root. The `old` lines are comparison only.
6. **B7.** No process line, the folder is gone, and the services are as
   in B1.

B1 and B2 facts, the B6 answers, the `"root facts"` line and the
optional B6d are information. They are recorded and are not pass or
fail.

**On failure.** No TLS status check from a commit that contains PR #30
runs on the box. The finding goes to the coordinator. The fix is a PR with its
own audit, and P30 then runs again for the commit that holds the fix.

**Record.** The results go to
`tls-status-child-containment/NN-box-run.md`, and the coordinator hands
out the box turn. The Remote Control session needs David's Mac online.
David's approval of bundled box runs (2026-11-24 04:23Z) covers the run.

