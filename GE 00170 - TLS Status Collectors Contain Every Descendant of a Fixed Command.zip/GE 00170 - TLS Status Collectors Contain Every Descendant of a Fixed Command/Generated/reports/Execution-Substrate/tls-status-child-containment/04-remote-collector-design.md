# DECISION NEEDED: containment for the noninteractive remote TLS status collector

**Ask to the coordinator: choose how the second collector contains its fixed children. I recommend option R2: the collector becomes a child subreaper, and after every fixed command it kills and reaps every process it adopted until the kernel answers that it has no child left (`waitpid` gives ECHILD); if that answer does not come within a bound, the command counts as failed. R2 needs no privilege and no host change, and in the prototype it ended every escaping descendant that ran as the collector's own user (0 escapes in 182 runs, against 175 escapes in 178 runs of the current code). Its limit: a descendant that runs as root through `sudo -n` can be detected but not ended by an unprivileged collector, so R2 turns that case from a silent escape into a reported failure. Option R1 (option C plus a user namespace) cannot run the `sudo -n` path at all (measured) and needs a host that allows unprivileged user namespaces with capabilities, which stock Ubuntu 24.04 restricts (inference, to be checked on the host).**

Written 2026-11-23 by the writer thread "Contain TLS status collector child processes", step 4 of `03-handoff-update.md` section 3. Nothing of this is implemented in the repository. The root collector's containment (option C, decisions D1 to D5) is not affected by this decision and continues.

## 1. What was measured on the current code

Collector: `scripts/internal/remote_alpha_operator_healthcheck_tls_status_noninteractive_remote.py` at `trunk_dev` `792f17c`, unchanged, run as an unprivileged user, its real `run_command` called with a stand-in for a fixed command. Cloud container only (kernel 6.18.44, Ubuntu 24.04.5 userland, sudo 1.9.15p5). Evidence: `04-evidence/` (`README.md`, `SHA256SUMS.txt`, `out/summary.txt`).

Each stand-in starts one descendant that ignores SIGTERM. "Alive" is decided by a FIFO that every process of the descendant holds open, read 0.2 s after `run_command` returned, never by a scan.

| Case | Direct | Through `sudo -n` |
|---|---|---|
| Command ends normally; descendant stays in the group and closes stdout/stderr | 20 of 20 escape, result `0` | 10 of 10 escape |
| The same, descendant leaves the group (`setsid`) | 20 of 20 escape | 10 of 10 |
| The same with a Python fork relay, in the group / leaving it | 20 of 20 / 20 of 20 | 10 of 10 / 10 of 10 |
| The same with the C fork relay of `01-evidence` (group, `setsid`, `setpgid`) | 10 of 10 each | not run |
| Command ends at once, descendant keeps stdout open (10 s timeout path), in the group / leaving it | 5 of 5 / 5 of 5 escape, result `124` | 3 of 3 / 3 of 3 |
| Command itself ignores SIGTERM and runs on (timeout path), descendant in the group | **0 of 3 escape** (the group KILL reaches it) | 3 of 3 escape |
| The same, descendant leaving the group | 3 of 3 escape | 3 of 3 |

Two facts beyond `03-handoff-update.md` section 2:

- **The timeout path signals nothing when the direct child has already ended** (`resolve_child_lifecycle`, line 169: `if terminate_required and not child_has_exited(proc)`). A descendant that holds the pipes therefore survives the timeout too, in the group or not. Only the case "the direct child itself still runs at the deadline" sends the group signals.
- **Through `sudo -n`, the group KILL kills `sudo` but not the root command** (`04-evidence/out/sudo-signal.out`). `sudo` has the invoking user as its real user ID (`Uid: 1700 0 0 0`), so the unprivileged `killpg` is allowed and returns success, but the root command in the same group is skipped by the kernel. After the KILL, `sudo` was dead and the root command lived on with parent 1. `sudo` forwards SIGTERM, which the command may ignore; nothing can forward SIGKILL. In this container `sudo -n` did not use a pseudo-terminal (no terminal was attached), so the command stayed in `sudo`'s group.

## 2. Facts for a namespace-based option

Measured in the container as the unprivileged user (`04-evidence/out/userns-probe.out`):

- `unshare(CLONE_NEWPID)` alone: **EPERM**.
- `unshare(CLONE_NEWUSER | CLONE_NEWPID)`: works here. This container has no `kernel.apparmor_restrict_unprivileged_userns`.
- `sudo -n /usr/bin/true` from inside that namespace: **fails**, with and without mapping the user to root inside ("/usr/bin/sudo must be owned by uid 0 and have the setuid bit set", "unable to change to root gid"). The kernel ignores the set-user-ID bit of a file whose owner is not mapped into the namespace.

Not measured, inference: on stock Ubuntu 24.04 `kernel.apparmor_restrict_unprivileged_userns=1` lets an unprivileged process create a user namespace but denies it every capability inside, so `CLONE_NEWPID` in it would fail. To be checked on the Remote Alpha host in the box session (one `sysctl` and one attempt), not assumed.

## 3. Options

**R1. Option C with a user namespace** (`CLONE_NEWUSER | CLONE_NEWPID`, an anchor, per direct command).
- Gives the one-step kill and the kernel's proof of empty, for direct commands only.
- The `sudo -n` path cannot run inside (measured). It would stay uncontained, or the `sudo -n` path would have to go, which removes status on hosts where the operator user cannot read the key directly.
- Inference: fails its capability probe on a stock Ubuntu 24.04 host, so the route would be unavailable until the host is changed (sysctl or an AppArmor profile for the interpreter). That is a new host requirement for a read-only status route, against section 9's "No sudoers configuration is added or modified" spirit of no host setup.

**R2. Child subreaper and a drain after every command (recommended).**
- At the collector's start (its one validation boundary, before any status input is read), `prctl(PR_SET_CHILD_SUBREAPER)` through `ctypes`, then a behaviour probe: a probe child starts a grandchild and ends; the grandchild must arrive as the collector's child, be killed, be reaped, and then `waitpid(-1)` must answer ECHILD. A host where any of that fails gets the existing `remote_status_unavailable` document, with no fallback.
- After every fixed command, once the direct child is reaped as today: list the collector's own children (`/proc/self/task/*/children`), SIGKILL each, reap, and repeat until `waitpid(-1, WNOHANG)` raises ECHILD. That answer is the kernel's: no descendant is left, whatever its group, session or user. The PIDs signalled are the collector's own unreaped children, so a number cannot be reused under it. The list only drives the kills; it never proves anything.
- A bound (I would take the existing 1 s grace twice, to be fixed in the docs) ends the drain. Unproved means `CommandResult(runtime_failed=True)`, which the current code already maps to an unavailable check and `remote_status_unavailable`. No new failure vocabulary, no change to the internal protocol or the final route schema.
- Measured with a prototype (`04-evidence/src/proto_r2.py.txt`, not repository code), as the collector's own user: **0 escapes in 182 runs** across all eleven direct cases, the kernel's ECHILD every time, at most 13 kill rounds against the C relay. Through `sudo -n`: the root descendant was never proved gone (52 of 52) and could not be killed (EPERM), as expected. The prototype only reported; the real change makes those runs fail.
- What R2 does not give: the kill of a relay that leaves the group is a sequence of per-process kills, not one step. The kernel refuses a fork to a process with a pending SIGKILL, and an orphan comes to the collector as soon as its parent ends, so each round can only shrink what was there, but a fast relay can stay ahead for a while. The bound turns that into a reported failure, never into a success. It won every time here.
- It runs without root, so its real path can be tested in the unprivileged CI gate. macOS has no `prctl`; the collector only runs on Linux hosts, and the tests decide by attempt as the root collector's do.

**R3. Containment set up on the root side.** A fixed contained runner started through `sudo -n` would need a new sudoers entry or a general interpreter under sudo; section 9 forbids both. Not recommended.

**R4. Documentation and the ES-6 drift test only.** Leaves the measured escapes in place. Not recommended under the project's "no revisit later" rule.

## 4. What I recommend, and its limits for the contract

R2, with these limits stated in `.docs/remote_alpha_operator_healthcheck_noninteractive_status.md` (sections 8 and 9) and `PLANS.md`:

1. An unprivileged collector cannot end a root descendant of the `sudo -n` path. It detects it, reports the check unavailable, and the process outlives the collector. Inference: the fixed `openssl`, `sha256sum` and `stat` start no process, so this needs a changed binary on the host.
2. A process that a host service starts on a descendant's behalf (`systemd-run --user`, `at`) is no descendant. Same limit as option C.
3. The kill of a relay that leaves the group is a bounded chase with a kernel proof at its end, not one kill.

I would also fix the timeout path while there: with R2 the drain covers it, so no separate change is needed. I would keep the existing group signals unchanged, as D4 did for the root collector.

## 5. Two smaller questions

- **Q1. ES-6 drift test.** It pins the supervision functions of the collectors against each other or a list of intended differences. After this PR the two remote collectors differ by design (namespace against subreaper). I recommend it as a test-only PR right after this one merges, because it also covers a third script outside this PR; it needs no product review. Alternative: in this PR.
- **Q2. Local facade.** `scripts/remote_alpha_operator_healthcheck_tls_status_noninteractive.py` (operator machine, maybe macOS) also uses `killpg`. It stays out of scope and goes into the PR's "Not done" list, as `03-handoff-update.md` asks.

## 6. For the box session

Add to the Remote Alpha host run: `sysctl kernel.apparmor_restrict_unprivileged_userns`, one attempt of `unshare(CLONE_NEWUSER|CLONE_NEWPID)` as the SSH target user, the R2 capability probe as that user, and whether `sudo -n` for the operator user uses a pseudo-terminal there. These settle the inferences above.

## 7. Envelope

- Repository and base: `evo-agi/Execution-Substrate`, `trunk_dev` `792f17c`. Nothing pushed by this note; the root collector's work continues on `claude/project-thread-wbmulu` (not yet pushed).
- Validation: the measurements above, cloud container only. Not run: the Remote Alpha host, macOS, the GitHub runner.
- Confidence: that the current code lets every measured descendant escape except one case, 0.97 (measured). That R2 contains every own-user descendant on this kernel, 0.9 (prototype, 182 runs). That R1 fails on stock Ubuntu 24.04, 0.7 (inference until measured on the host).
- Effect status: `DECISION_NEEDED` | `NOTHING_PUSHED` | `NO_PR`
