# ES PR #30, diff check 17: 4f55003..1861e23 (A14-1 docs and pin, O14-1 stand-in)

```
Target:   evo-agi/Execution-Substrate, draft PR #30, branch claude/project-thread-wbmulu
Range:    4f55003b81580acec19f2cbe5bf1f6db4859afe1 .. 1861e23e8dc7ea4f66aa72566ccc28665e731035
          (one commit, tree 9e5d7f67e1300d05a25aaf83fad647d4cf2bece6)
Report:   16-repair.md (sha256 214a15f4…570f)
Posture:  auditor thread, read-only; nothing pushed, no PR comment. Cloud container
          (kernel 6.18.44, Go 1.26.5, unprivileged user ci UID 1500, and root).
Verdict:  ACCEPT 1861e23. A14-1 is closed and O14-1 is done; the collectors are
          byte-identical to 4f55003; no new finding.
```

## 1. Provenance

The recipe tool's sha256 was checked before each run (`c08597e2…a3ca`). With HEAD reset to
the merge base `4c991ba`, upstream `origin/trunk_dev`, two runs at open and two at close all
give:

- `manifest_sha256 = 9cb8ec53add1096b775d2fda8064244e6d80c135f0e4bd0e793e9bc60b25b122`, 19 files;
- `textual_diff_sha256 = 689ae6174f569218e783dad7974bb4ed774595436979e902d8b65b03d1493441`;
- staged tree `9e5d7f67…` = the head's tree; status after restore empty.

The four JSON files are byte-equal to each other and to the writer's
`16-evidence/provenance/manifest-v2-run1.json` and `run2.json` (`review/manifest-comparison.txt`).
The remote branch was still at `1861e23` at close.

## 2. What changed

`git diff 4f55003 1861e23` (sha256 `3f296341…e957`, the writer's figure): three files,
+31 −17. The design document and PLANS.md (A14-1), and the descendants test file (pins and
O14-1). The three collector programs are byte-identical at both heads: root
`c6c2dc75…dd5e`, remote `db471490…ebdc8`, wrapper `35dc9989…9150`
(`review/collector-hashes.txt`).

## 3. A14-1: the wording

- **Design document, section 8.** The rule bullet now reads "a collector that is killed takes
  it along unless the program itself undoes that request". The limits paragraph adds "The fixed
  child's program can undo its own parent-death request; a changed binary that does so outlives
  a killed collector, as one process that the process limit still keeps from starting any other."
- **PLANS.md P0v.** "dies with a killed collector unless its program undoes that request itself",
  and the same limit in the list of stated limits.

Both match what was measured in audit 14: a pdeathsig set in `preexec_fn` is advisory, and the
program that clears it is still bound by `RLIMIT_NPROC (0,0)`. Neither document still claims
the unconditional version.

**Info I17-1 (no change needed).** I re-checked the phrase "keeps from starting any other"
against one more route: a changed unprivileged binary could exec a set-user-ID `sudo` for a
command the host grants. `sudo` then runs as root, and root is not bound by the limit
(measured in red-team 12: `sudo -n` still ran under `RLIMIT_NPROC (0,0)`). Both documents
already state that route in the same list ("root is not bound by that limit, and the exec of
`sudo` clears the parent-death request"). It needs a changed binary at a root-owned path, so a
root-equivalent attacker, and it can only reach the granted root command. Read with the limits
next to it, the new sentence is accurate. I did not re-measure this route here, because the
container gives `ci` no sudo grant.

**Cosmetic.** One line of the design document (line 438, 115 characters) was not re-wrapped.
The document already had 13 lines over 80 characters, and Markdown renders it the same. No
change needed.

## 4. A14-1: the pin

`TestRemoteAlphaOperatorHealthcheckTLSStatusNoninteractiveDescendantDocumentsContract` now
requires both new phrases in each document and refuses the old endings ("takes it along." and
"dies with a killed collector."). Put back to its 4f55003 text, each document fails that case,
as ci and as root:

| Mutant | Fails (ci and root) | Reason |
|---|---|---|
| design document from 4f55003 | DocumentsContract | missing "and a collector that is killed takes it along unless the program itself undoes that request" |
| PLANS.md from 4f55003 | DocumentsContract | missing "dies with a killed collector unless its program undoes that request itself" |

## 5. O14-1: the stand-in ignores TERM

The `RealCollectorDeath` stand-in now sets `SIGTERM` to `SIG_IGN` before it writes its byte, so
only a KILL ends it. The test's comment says so, and it keeps the sudo path and the changed
binary as stated limits.

| Run | Result |
|---|---|
| `RealCollectorDeath` ×10 as ci | 10/10 pass |
| `RealCollectorDeath` ×10 as root | 10/10 pass |
| Y09 (the fixed child asks for SIGTERM, not SIGKILL) | fails as ci and root: `RealCollectorDeath` ("a killed collector takes its fixed child with it failed: (True, False, b'')", so the stand-in started and was still alive after 10 s) and the source pin in `DocumentsContract` |
| Y09 with the 4f55003 test file (control) | `RealCollectorDeath` passes as ci and root; only the source pin catches it |
| 4f55003 test file on 1861e23 (control) | passes as ci and root |

So the new stand-in is what makes the behaviour catch Y09, as O14-1 asked. Before, only the
text pin caught it.

## 6. Regression runs at 1861e23

- `go vet ./scripts/` for linux/amd64 and darwin/arm64: exit 0. `gofmt -l scripts/`: empty.
- Descendant family as root: 9 pass, 1 skip. `RealProcessLimit` skips itself as root, because
  the limit does not bind uid 0, and it passes as ci in the package run.
- Packages `. ./scripts/ ./internal/testutil/` as ci: 2,056 pass, 5 skip, 235 fail. The verdicts
  are identical on all 2,296 names to audit 14's run of the same packages at `700b533`. The 235 are the
  container-only set (no `/usr/bin/ssh` and similar), which fail at every head here.
- The work tree was clean after all runs.

## 7. Against the current trunk_dev

trunk_dev has moved to `5b82a6e` since audit 14: #34 (SPIRE agent helper) landed, and it shares
two files with this PR, PLANS.md and `.docs/system_overview/remote_supported_host_alpha.md`.
A trial merge of `1861e23` with `5b82a6e` is textually clean (tree `2fbe3c2f…`, the same as
`git merge-tree`). On that merge, as ci, the same three packages give
identical verdicts on all 2,296 shared names, and #34's 43 new names pass (41) or skip
themselves (2, real SPIRE). #34 changes nothing under `.github/`, so the gate self-test's
workflow pin is unaffected. The writer still has to take `5b82a6e` at the gate
(`runs/trial-merge/`).

## 8. CI

Run 45312451832 ("build, vet and test") on `1861e23` was still running at 02:41Z. The run on
`4f55003` (45309449104) was cancelled when this commit was pushed, so 4f55003 never had a full
CI result; the run on `1861e23` is the one the gate needs.

## 9. Evidence

`17-diff-check-evidence/` (SHA256SUMS in that folder):
`provenance-open/`, `provenance-close/`, `review/` (diff, collector hashes, manifest
comparison), `runs/` (steps log, vet, gofmt, the ×10 runs, descendant family as root, package
run and comparison, each mutant's output, `trial-merge/`), `scripts/` (the run scripts and the
mutation tool).
