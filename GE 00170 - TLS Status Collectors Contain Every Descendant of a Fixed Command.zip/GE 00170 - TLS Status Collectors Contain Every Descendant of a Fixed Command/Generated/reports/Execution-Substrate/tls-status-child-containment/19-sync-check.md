# ES PR #30, sync check 19: 1861e23..cd36797 (merges of trunk_dev 8789662 and 230954d)

```
Target:   evo-agi/Execution-Substrate, draft PR #30, branch claude/project-thread-wbmulu
Range:    1861e23 (diff check 17, ACCEPT, CI green) .. cd367971fb1c7cb5095585173b623056bb9510cc
          e4c6434 = merge of trunk_dev 8789662; cd36797 = merge of trunk_dev 230954d (#45)
Report:   18-sync.md (writer)
Posture:  auditor thread, read-only; nothing pushed, no PR comment. Cloud container
          (kernel 6.18.44, Go 1.26.5, unprivileged user ci UID 1500, and root).
Verdict:  ACCEPT cd36797 as a sync. Both merges are git's own, the PR's content is
          unchanged, and nothing trunk_dev brought weakens the containment.
          NOT READY TO MERGE: CI is red (11:48Z). The root step now also runs #35's four
          firewall tests, and one of them, BridgeIsolation, counts 16 dropped frames instead of
          15 on the IPv6 runner (section 6). Fix #35's test first (test-only).
```

## 1. The two merges are git's own

- `e4c6434` has parents `1861e23` and `8789662`. `git merge-tree --write-tree 1861e23 8789662`
  gives `6f839ede…`, which is `e4c6434`'s tree.
- `cd36797` has parents `e4c6434` and `230954d`. `git merge-tree --write-tree e4c6434 230954d`
  gives `e84def5c…`, which is `cd36797`'s tree.
- Both `8789662` and `230954d` are on trunk_dev, and trunk_dev is at `230954d`, the new
  merge base.

So neither merge commit carries a hand edit or a conflict resolution (`review/merges.txt`).

## 2. Provenance

The recipe tool's sha256 was checked before each run (`c08597e2…a3ca`). With HEAD reset to
`230954d`, upstream `origin/trunk_dev`, two runs at open and two at close all give
`manifest_sha256 = 4147eb23222ca3013363ea54e8e5712a6efc0d0fe977e9f3ad32346d13311b91` (19 files)
and `textual_diff_sha256 = bb003736e947ec8adf224ef221c59e29b0626b445affbc6dbcdfe65e7e8348f1`.
The staged tree equals the head's tree, and the status after restore is empty. The four
JSON files are byte-equal to each other and to the writer's
`18-evidence/sync-230954d/provenance/manifest-v2-run1.json` and `run2.json`. The branch was
still at `cd36797` at close.

## 3. The PR's own content is unchanged

- The PR touches the same 19 paths as at `1861e23` (`review/patch-comparison.txt`).
- 12 of them are byte-identical to `1861e23`.
- In the 7 that trunk_dev also changed, the PR's own changed lines (`-U0`, the + and − lines
  only) are identical to its lines against `4c991ba`. The 7 are: the noninteractive status
  document, `remote_supported_host_alpha.md`, `environment-only-tests.txt`, PLANS.md, the
  remote collector, the local-boundary test and the noninteractive test.
- The range-diff of the six PR commits is "=" for all six.
- The root collector is byte-identical (`c6c2dc75…dd5e`). The remote collector's blob changed
  only by trunk_dev's own edit (next section): `db471490…` became `432366fa…6273`.

## 4. What trunk_dev changed that meets this PR

**The remote collector (#38).** #38 replaced the text parse of `openssl x509 -ext
subjectAltName` with a DER decoder, so one fixed command became `openssl x509 -in <cert>
-outform DER`. That command is called through `run_fixed`, like every other, and the
collector still has one process start, the `subprocess.Popen` in the PR's spawn path. So the
new command gets the same containment as the rest: the fixed-child setup (parent-death
request, parent check, `RLIMIT_NPROC (0,0)`) and the drain. `openssl x509` does not fork, so
the limit does not hurt it. #38's new runtime test,
`…NoninteractiveRuntimeKeepsEachIdentityClassification`, passes on the merged head once `ssh`
exists (section 5) (`review/collectors-and-process-starts.txt`).

**`environment-only-tests.txt` (#35, #12).** #35 added four `skips-itself` lines for
`execution-substrate/scripts`: three real-kernel firewall tests and one real-sshd test. This
PR's root step runs every `skips-itself` line of that package as root, so it now runs nine
tests instead of five. The firewall tests extend PATH with `/usr/sbin:/sbin` themselves, so
the step's `PATH=/usr/bin:/bin` is enough. But a missing `ip` or `nft` fails them, and a
missing `sshd` makes the sshd test skip itself, which the root step also counts as a failure.
The workflow installs only bindfs, so the root step depends on what the runner image already
has (`review/firewall-root-test-prerequisites.go.txt`, `review/workflow-installs-and-root-step.txt`).

**Docs and the two shared tests.** #38 edited the noninteractive status document and the
noninteractive test. #12 edited the local-boundary test. #31, #34, #35, #38 and #12 edited
PLANS.md, and #34, #35, #46, #49 and #50 edited `remote_supported_host_alpha.md`. All of these
edits are in other places than the PR's lines, and git merged them without a conflict. Both
families' documents contracts pass on the merged head
(`…ChildNamespaceDocumentsContract`, `…NoninteractiveDescendantDocumentsContract`).

**Other trunk_dev changes** (#44, #48, #45, and the code parts of the PRs above) touch none of
this PR's files. #49's ratchet counts by-name ownership changes in `.sh` files, and this PR
has none.

## 5. Runs at cd36797, compared with its base 230954d

| Run | Result |
|---|---|
| `go vet ./...` linux/amd64 and darwin/arm64 | exit 0 |
| `gofmt -l` on the PR's Go files | empty |
| `go_test_gate_selftest.py` | OK |
| `.`, `./scripts/`, `./internal/testutil/` as ci, head vs base | verdicts identical on all 2,773 shared names; the 22 new names are the PR's tests: 17 pass, 5 skip (the root-only namespace tests) |
| Same, head vs audit 17's trial merge of 1861e23 | verdicts identical on all 2,339 shared names |
| Both collector families as root | 21 pass, 1 skip (`RealProcessLimit`, which skips itself as root) |
| Both collector families as ci | 17 pass, 5 skip (root-only) |
| `RealCollectorDeath` ×5 as ci | 5/5 pass |
| CI root step, emulated (sudo replaced by root; go and `-test.list` as ci), container without `ip` and `sshd` | fails: the 5 namespace tests pass, the 3 firewall tests fail ("ip is missing"), the sshd test skips |
| Same after `apt-get install iproute2 openssh-server` (nft was already there) | **9 of 9 pass**; no network namespace left behind |
| `./scripts/` as ci after that install, head vs base | verdicts identical on all 2,159 shared names; 22 new names as above. The 12 tests that needed a local `ssh` now pass on both, #38's identity-classification test among them |

The container-only failures (241, then 193 once `ssh` exists) fail the same way at the base.
I reproduced the writer's root-step result both ways.

## 6. CI (result 11:48Z): red, on one #35 test that never ran in CI before

Run 45381241057 on `cd36797` failed in its last step, "Listed tests pass as root". Every
earlier step passed, including "Check the test gate", "Test" and "Listed tests still fail"
(17 of 17). The runner has `ip`, `nft` and `sshd`, so my guess about missing tools above was
wrong. Of the nine root tests, eight passed: the five PID-namespace tests, the real-sshd test,
`RealKernelTraffic` (its IPv6 subtests ran there) and `RealKernelApplyConfirmRollback`. One
failed (`ci/job-138400657450-tail.txt`):

```
remote_alpha_host_firewall_test.go:2301: the bridge counter must count the fifteen dropped frames, got 16
--- FAIL: TestRemoteAlphaHostFirewallRealKernelBridgeIsolation (5.47s)
```

**What it is.** This is #35's test, not this PR's code. It passed here, where the kernel has no
IPv6 (`/proc/sys/net/ipv6` is missing, and the IPv6 subtests skip). The bridge table's one
rule, `counter name "container_to_container" drop`, counts every frame from one bridge port to
another, and the test requires exactly its own 15 probe frames. My reading, not measured: on a
kernel with IPv6, the containers' `eth0` send their own IPv6 frames after link-up (duplicate
address detection, router solicitations, MLD reports, some of them repeated seconds later).
The bridge floods them to the other port, the rule drops and counts them, and the count goes
over 15. That depends on timing, so a re-run may pass by luck. The firewall's behaviour is
correct: those frames should be dropped.

**Why it shows now.** trunk_dev has no root step, so on trunk_dev this test only skips. This PR's
root step runs every `skips-itself` line of `execution-substrate/scripts` as root. That is the
coupling, and it is working as intended: it found a test that fails on an IPv6 host. Any root
run of #35's tests on such a host, for example on the box, would most likely show the same.

**The proper fix** is test-only: give the lab containers no IPv6 traffic of their own, for
example by setting `net.ipv6.conf.{all,default}.disable_ipv6=1` in the `c1` and `c2` namespaces
before their links come up, and keep the exact count. The probe's IPv6 frame is a raw frame and
does not need the IPv6 stack (it arrived here with no IPv6 at all). It is not a fix to loosen
the count to "at least 15", re-run CI until it is green, or drop #35's lines from the root step.

**Where the fix goes** is the coordinator's call. I recommend a small test-only PR on trunk_dev
from #35's line, audited and gated, which PR #30 then takes with one more sync: the test is
#35's, and the box needs it too. The fix could also go inside PR #30, which would add a
twentieth file outside the PR's scope. Either way I can diff-check it.

## 7. Not in scope

The writer's section 5 argues that the box and Mac runs should come after the merge. That is
the coordinator's call, not part of a sync check. I note only that its premise matches what
audits 14 and 17 measured: every failure those runs could find shows as `runtime_failed` or
`openssl_child_unproved`, never as a false success.

## 8. Evidence

`19-sync-check-evidence/` (SHA256SUMS in that folder): `ci/` (the CI job excerpt), `provenance-open/`, `provenance-close/`,
`review/` (merge re-creation, patch comparison, trunk_dev's collector diff, process starts,
the firewall prerequisites, the workflow's installs), `runs/without-tools/`, `runs/with-tools/`
(including the package versions installed), `scripts/`.
