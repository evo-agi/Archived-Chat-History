# Mac and box run brief: PR #30 at eed4c9b, child containment of both TLS status collectors

Prepared 2026-11-23 by the writer thread "Contain TLS status collector child processes". This replaces `08-mac-and-box-brief.md` (head `0b8b9c0`): new head, base, tree and collector sums, and one more stand-in case (T9-1). One Remote Control session on David's Mac does both runs that must pass before PR #30 merges: the Mac test run and the Remote Alpha box run (audit 07, section 8). One "go ahead" from David in this thread covers both.

**In plain words.** The session clones the pull request into one new temporary folder on the Mac and runs the collectors' tests there. Then it logs in to the box with the existing `[test box name withheld]` login, copies the two collectors from that clone and two small check scripts into one new folder under `/tmp` on the box, and runs them: once as the login user and once as root through `sudo -n`, the same way the operator routes start the collectors. The checks start and end only their own short-lived processes. They touch no service, install nothing, and change no file outside that folder. At the end both temporary folders are removed. It takes about 20 to 25 minutes.

**What it settles (audit 07, section 8):**

1. The root collector's whole capability probe passes on the box as it is really started (root through `sudo`, Python 3.12, `/proc/self/ns/pid_for_children`, `unshare(CLONE_NEWPID)` allowed), and one real `openssl version` and four stand-in commands run in their own PID namespace there. Two stand-ins are the T7-1 and T9-1 cases: the first must return at once and the second at its one-second time limit, neither after its 30 seconds.
2. The R2 probe of the noninteractive remote collector passes as the SSH user in its real launch shape (`ssh -T` and `exec /usr/bin/python3 -I -S -B -`), and the drain ends a descendant that ignores TERM.
3. Whether `sudo -n` uses a pseudo-terminal there.
4. `pidfd_answers.py`, planned since PR #22, as the login user and as root.
5. On the Mac: the collectors' tests at the PR head pass, and the real-kernel tests skip with their stated reasons.

**Expected, from the cloud container** (kernel 6.18, Python 3.13; not yet seen on the box or the Mac):

- Box, root part: `"verdict": "accepted"`; `openssl version` returns 0; modes `setsid`, `zombie` and `slow` each give `"result": "(0, b'fixed', b'')"`, `"process left after return": false`, no `"lapsed"` report, and `zombie` takes well under a second (here 0.05 s); `slow` takes about one second; mode `zombie-run` gives `"result": "None"`, `"raised": "Incomplete('child_timeout')"`, reports `fixed`, `held` and `escaped` but no `lapsed`, `"process left after return": false`, and takes about one second (here 1.02 s; with the collector of `0b8b9c0` it took 30.09 s and reported `lapsed`); `"root end"` with `"unproved": false`.
- Box, R2 part: `"sigchld": "0"` (default handling), `"verdict": "accepted"`, the fixed command returns 0 with `"stdout": "ok"`, `"runtime_failed": false`, `"process left after return": false`.
- Box, `sudo -n /usr/bin/tty`: `not a tty` with exit 1 (no pseudo-terminal without a terminal), whatever `use_pty` says.
- Mac: exit 0. These tests skip with a reason: the three `…ChildNamespaceReal…` tests and `…ChildNamespaceAnchorProcess`, and the two `…NoninteractiveDescendantReal…` tests. Python 3.9 on the Mac has no `os.unshare`, and macOS has no `prctl` or `/proc`.

---

## Instructions for the Mac session (paste as is)

Run a test check of one Execution-Substrate commit on this Mac and a check on the Remote Alpha box (ssh alias [test box name withheld]), and report the complete output. Pull request 30 makes both Remote Alpha TLS status collectors contain every process that a fixed helper command starts: the root collector runs each command in a PID namespace of its own, and the noninteractive remote collector becomes a child subreaper and drains its descendants.

Rules on the Mac:
- Create exactly one new folder: T=$(mktemp -d /Users/ds/Repositories/Playground/es-pr30-run.XXXXXX) and print it. Then: touch "$T/start-marker".
- Keep /Users/ds/Repositories/Playground as your working directory for the whole run. Never cd into "$T" or below it, not even briefly. Use git -C "$T/es" or a subshell such as ( cd "$T/es" && … ). (If the folder ever becomes the working directory, removing it at the end is refused.)
- Do not change, stage, commit or delete anything in any existing folder. You may read the origin URL of the existing clone with: git -C "/Users/ds/Repositories/Execution Substrate" remote get-url origin. Run no other command in that folder.
- Do not run sudo on the Mac. No git push. No installs and no downloads other than the git clone and fetch.
- For every go and gofmt command set:
    export GOTOOLCHAIN=go1.26.5 GOPROXY=off GOFLAGS=-mod=readonly GOCACHE="$T/gocache"
  Outside the clone go version may print go1.26.1; that is expected. Inside the clone it must print go1.26.5. If it does not, skip part A, report, and go on with part B.
- If a go command fails because a module is missing, report the exact error; do not download.
- If a test fails, do not fix any code. Record the output and go on.
- Shell variables may not survive from one of your commands to the next. After you print T (and later D), use their literal values wherever the steps say "$T" or "$D".

Rules on the box:
- Reach it only with: ssh -T -o BatchMode=yes -o ConnectTimeout=15 [test box name withheld] '<command>'. Below this is written BOX '<command>'; BOX is shorthand, so type the full ssh command each time. Do not open an interactive shell.
- Create exactly one folder there (step B3), write only inside it, and remove it in step B7.
- Use sudo on the box only in the exact commands below. Do not start, stop, restart or reconfigure any service. Do not install anything, do not reboot, do not touch Vault, Nomad, Docker or any file outside that folder.
- If an ssh command fails with "No route to host" or a timeout, run: route -n get [home network address withheld]; ping -c 2 [home network address withheld]; nc -vz -w 5 [home network address withheld] 22. Then wait five minutes and try the same command once more. If it still fails, skip the rest of part B (but still do B7 if a box folder was created), report the diagnostics, and go on with part C.

Part A, on the Mac:
A1. Print: sw_vers, uname -m, whoami, and the value of TMPDIR (printf '%s\n' "${TMPDIR-unset}"). Clone:
      git clone "$(git -C "/Users/ds/Repositories/Execution Substrate" remote get-url origin)" "$T/es"
A2. git -C "$T/es" fetch origin trunk_dev claude/project-thread-wbmulu
    Print git -C "$T/es" rev-parse origin/claude/project-thread-wbmulu origin/trunk_dev
    (expected eed4c9b41b37c0e6bf9e33e3ac2b314ca3ef89ea and 76c030fa7872dd22dda731591878ef284c01bd9b; if either differs, say so and still test eed4c9b).
A3. git -C "$T/es" checkout --detach eed4c9b41b37c0e6bf9e33e3ac2b314ca3ef89ea
    Confirm git -C "$T/es" rev-parse HEAD 'HEAD^{tree}' (expected tree c97fc0acf9465ad78e73a3a0cd08c1395d9a8c67).
    Inside the clone print: go version, and go env GOVERSION GOROOT GOTOOLCHAIN GOPROXY GOCACHE.
A4. R='^(TestRemoteAlphaESServiceTLSStatus.*|TestRemoteAlphaOperatorHealthcheckTLSStatusNoninteractive.*|.*Doc.*)$'
    K='^(TestRemoteAlphaESServiceTLSStatusFailureWitnessBootstrapOwnedTerminal|TestRemoteAlphaESServiceTLSStatusRootLoadedStageCustody|TestRemoteAlphaESServiceTLSStatusStageFIFOSubstitution)$'
    ( cd "$T/es" && go test -count=1 -v -timeout 30m -run "$R" -skip "$K" . ) > "$T/head-root.log" 2>&1; echo "exit $?"
    Report: the exit status; the last 3 lines; the number of lines matching each of '^ *--- PASS', '^ *--- SKIP' and '^ *--- FAIL'; every '--- SKIP' line with the two lines after it (grep -E -A2 '^ *--- SKIP'); every line containing 'panic:' or 'the same test as root'; and for each failed test its complete output from its "=== RUN" line through its "--- FAIL" line and the indented lines after it.
A5. ( cd "$T/es" && go vet ./... ); echo "exit $?"    (expected: no output, exit 0)
A6. ( cd "$T/es" && "$(go env GOROOT)/bin/gofmt" -l $(git diff --name-only 76c030fa7872dd22dda731591878ef284c01bd9b HEAD -- '*.go') ); echo "exit $?"    (expected: no output)

Part B, on the box:
B1. Baseline, read only:
      BOX 'hostname; uname -r; /usr/bin/python3 --version; /usr/bin/openssl version; id -un; sudo -n true && echo "sudo -n: ok"; sudo -n -V | head -1; systemctl is-active es ags nomad vault spire-agent spire-server docker'
B2. Whether sudo -n uses a pseudo-terminal, read only:
      BOX 'sudo -n -l 2>&1 | sed -n "/Matching Defaults/,/^\$/p"; sudo -n /usr/bin/tty </dev/null; echo "tty_exit=$?"; sudo -n /usr/bin/tty; echo "tty_exit=$?"'
B3. Stage. Write the two scripts at the end of these instructions into "$T/pr30_box_probe.py" and "$T/pidfd_answers.py", each with exactly the text between its BEGIN and END marker lines (not the marker lines themselves); a quoted heredoc such as cat > "$T/pr30_box_probe.py" <<'PR30_EOF' keeps the text unchanged. Check:
      shasum -a 256 "$T/pr30_box_probe.py" "$T/pidfd_answers.py"
    expected 2fdb0d7c2bb7c7f22f7351fb032f782e879e51d5e152be5da9c6c42ad7fba2e2 and f22289dd4d93fe55fdd13429af0ca623d79f2e3ee2657ca45ab398af17b38dad. If either differs, rewrite it once; if it still differs, skip the rest of part B and report both sums.
    Then create the box folder and print it:
      D=$(BOX 'mktemp -d /tmp/pr30-box.XXXXXX'); printf '%s\n' "$D"
    It must match ^/tmp/pr30-box\.[A-Za-z0-9]{6}$; if not, stop part B.
    Copy four files:
      for f in "$T/es/scripts/internal/remote_alpha_es_tls_status.py" "$T/es/scripts/internal/remote_alpha_operator_healthcheck_tls_status_noninteractive_remote.py" "$T/pr30_box_probe.py" "$T/pidfd_answers.py"; do ssh -T -o BatchMode=yes -o ConnectTimeout=15 [test box name withheld] "cat > '$D/$(basename "$f")'" < "$f"; done
      BOX "sha256sum '$D'/*.py"
    Expected sums: b5a1344f1f0de75c13b7b1d2d54b27cc71630e7cd4b495408b7943f72771d474 remote_alpha_es_tls_status.py, 33e5f4d5bcfab7c5524703d14e9c97ec6e3f47d29fc18c0431ed6efaa16aa4c8 remote_alpha_operator_healthcheck_tls_status_noninteractive_remote.py, and the two above. If any differs, go to B7.
B4. The noninteractive remote collector's probe as the login user, in its real launch shape (the script goes on standard input):
      ssh -T -o BatchMode=yes -o ConnectTimeout=15 -o RequestTTY=no [test box name withheld] "exec /usr/bin/python3 -I -S -B - r2 '$D'" < "$T/pr30_box_probe.py"; echo "exit $?"
B5. The root collector as root through sudo, as the operator route starts it:
      BOX "sudo -n LC_ALL=C /usr/bin/python3 -I -B '$D/pr30_box_probe.py' root '$D'"; echo "exit $?"
B6. pidfd answers, as the login user and as root:
      BOX "/usr/bin/python3 -I -B '$D/pidfd_answers.py'"; echo "exit $?"
      BOX "sudo -n /usr/bin/python3 -I -B '$D/pidfd_answers.py'"; echo "exit $?"
B7. Leftovers and cleanup on the box (run this whenever a box folder was created):
      BOX "ps -eo pid,ppid,user,stat,args | grep -E 'pr30-box|fixed-openssl|pidfd_answers' | grep -v grep; sudo -n rm -rf '$D'; ls -ld '$D' 2>&1; systemctl is-active es ags nomad vault spire-agent spire-server docker"
    Expected: no process line, "No such file or directory" for the folder, and the same service states as in B1.

Part C, on the Mac:
C1. ps -axo pid,ppid,stat,command | grep -E '\.test|remote_alpha_es_tls_status|es-pr30-run' | grep -v grep    (expected: no output)
C2. git -C "$T/es" status --porcelain    (expected: empty)
C3. find /Users/ds/go/pkg/mod -newer "$T/start-marker" -print | head -5    (expected: no output)
C4. rm -rf "$T", then confirm "$T" is gone and /Users/ds/Repositories/Playground still exists. If the removal is refused, do not retry; say so and give David the one-line command.

Report back: the environment lines, the commit and tree hashes, the go version lines; for A4 to A6 the items asked above; for B1 to B7 the complete output of every command, with every JSON line verbatim and every exit status. Say plainly what passed and what failed. Do not summarize a failure away.

----- BEGIN pr30_box_probe.py -----
# PR #30 box probe: child containment of both Remote Alpha TLS status collectors.
# It loads the two collectors from DIR, as staged from the pull request head,
# and writes only below DIR. It starts and ends its own processes only.
#
#   root DIR  as root through sudo -n: facts, the root collector's whole
#             capability probe, one real "openssl version" through run_fixed,
#             and four stand-in fixed commands (an escaped descendant, an
#             escaped descendant that keeps an ended child unreaped in the
#             group, the same descendant while the fixed command still runs
#             at a time limit of one second, and a command that runs for one
#             second).
#   r2 DIR    as the SSH user, started as `exec /usr/bin/python3 -I -S -B - r2 DIR`
#             with this file on standard input: facts, the noninteractive
#             remote collector's descendant probe, and one fixed command whose
#             escaped descendant ignores TERM.
import importlib.util, json, os, signal, sys, time

def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module

def status_fields(*names):
    found = {}
    with open("/proc/self/status") as handle:
        for line in handle:
            key, _, value = line.partition(":")
            if key in names:
                found[key] = value.strip()
    return found

def proc_value(path):
    try:
        with open(path) as handle:
            return handle.read().strip()
    except OSError as exc:
        return "unreadable: " + type(exc).__name__

def watch(path):
    os.mkfifo(path, 0o600)
    return os.open(path, os.O_RDONLY | os.O_NONBLOCK)

def drain(reader):
    # Everything written so far, and whether a writer is still there.
    data = b""
    while True:
        try:
            chunk = os.read(reader, 65536)
        except BlockingIOError:
            return data, True
        if chunk == b"":
            return data, False
        data += chunk

def say(report):
    print(json.dumps(report, sort_keys=True), flush=True)

FIXED_CHILD = r'''#!/usr/bin/python3 -I
import os, signal, sys, time
mode, fifo, release = sys.argv[1:4]
out = os.open(fifo, os.O_WRONLY)
os.write(out, b"fixed\n")
def stay():
    end = time.monotonic() + 30
    while time.monotonic() < end and not os.path.exists(release):
        time.sleep(0.02)
if mode == "slow":
    time.sleep(1.0); sys.stdout.write("fixed"); sys.stdout.flush(); sys.exit(0)
ready_r, ready_w = os.pipe()
if os.fork() == 0:
    for fd in (0, 1, 2, ready_r):
        os.close(fd)
    if mode in ("zombie", "zombie-run"):
        held = os.fork()
        if held == 0:
            os.write(out, b"held\n"); os._exit(0)
        os.waitid(os.P_PID, held, os.WEXITED | os.WNOWAIT)
    os.setsid()
    signal.signal(signal.SIGTERM, signal.SIG_IGN); signal.signal(signal.SIGHUP, signal.SIG_IGN)
    os.write(out, b"escaped\n"); os.write(ready_w, b"r"); os.close(ready_w)
    stay()
    if not os.path.exists(release):
        os.write(out, b"lapsed\n")
    os._exit(0)
os.close(ready_w); os.read(ready_r, 1)
if mode == "zombie-run":
    stay()
sys.stdout.write("fixed"); sys.stdout.flush()
'''

def root_part(base):
    work = os.path.join(base, "root-work")
    os.mkdir(work, 0o700)
    say({"part": "root facts", "uid": os.getuid(), "euid": os.geteuid(), "python": sys.version.split()[0],
         "os.unshare": hasattr(os, "unshare"), "os.setns": hasattr(os, "setns"),
         "pid_for_children": os.path.exists("/proc/self/ns/pid_for_children"),
         "status": status_fields("NoNewPrivs", "Seccomp", "CapEff", "Threads"),
         "user.max_pid_namespaces": proc_value("/proc/sys/user/max_pid_namespaces"),
         "kernel.apparmor_restrict_unprivileged_userns": proc_value("/proc/sys/kernel/apparmor_restrict_unprivileged_userns")})
    module = load(os.path.join(base, "remote_alpha_es_tls_status.py"), "pr30_root_collector")
    try:
        module.validate_process_capability()
        verdict = "accepted"
    except BaseException as exc:
        verdict = "refused: %r" % (exc,)
    say({"part": "root capability probe (both parts)", "verdict": verdict,
         "unproved": bool(module.WITNESS_DISPOSITION_UNPROVED)})
    if verdict != "accepted":
        return
    module.PROCESS_CAPABILITY_READY = True
    try:
        result = module.run_fixed((module.OPENSSL, "version"))
        say({"part": "real openssl version in its own PID namespace", "returncode": result[0],
             "stdout": result[1].decode("ascii", "replace").strip(), "stderr_bytes": len(result[2])})
    except BaseException as exc:
        say({"part": "real openssl version in its own PID namespace", "raised": repr(exc)})
    child = os.path.join(work, "fixed-openssl")
    with open(child, "w") as handle:
        handle.write(FIXED_CHILD)
    os.chmod(child, 0o700)
    fixed, module.OPENSSL = module.OPENSSL, child
    limit = module.CHILD_TIMEOUT
    for mode in ("setsid", "zombie", "zombie-run", "slow"):
        module.CHILD_TIMEOUT = 1.0 if mode == "zombie-run" else limit
        fifo = os.path.join(work, "events-" + mode)
        release = os.path.join(work, "release-" + mode)
        reader = watch(fifo)
        started = time.monotonic()
        try:
            result = module.run_fixed((module.OPENSSL, mode, fifo, release)); raised = None
        except BaseException as exc:
            result = None; raised = repr(exc)
        took = round(time.monotonic() - started, 3)
        data, alive = drain(reader)
        if alive:
            open(release, "w").close()
            time.sleep(1.0)
        os.close(reader)
        say({"part": "stand-in fixed command, mode " + mode, "result": repr(result), "raised": raised,
             "seconds": took, "reports": data.decode().split(), "process left after return": alive})
    module.OPENSSL, module.CHILD_TIMEOUT = fixed, limit
    say({"part": "root end", "unproved": bool(module.WITNESS_DISPOSITION_UNPROVED)})

def r2_part(base):
    work = os.path.join(base, "r2-work")
    os.mkdir(work, 0o700)
    module = load(os.path.join(base, "remote_alpha_operator_healthcheck_tls_status_noninteractive_remote.py"),
                  "pr30_remote_collector")
    tid = os.listdir("/proc/self/task")
    say({"part": "r2 facts", "uid": os.getuid(), "python": sys.version.split()[0],
         "sigchld": str(signal.getsignal(signal.SIGCHLD)),
         "children file": proc_value("/proc/self/task/%s/children" % tid[0]) if len(tid) == 1 else tid,
         "status": status_fields("NoNewPrivs", "Seccomp", "Threads")})
    try:
        module.validate_descendant_capability()
        verdict = "accepted"
    except BaseException as exc:
        verdict = "refused: %r" % (exc,)
    say({"part": "r2 descendant probe", "verdict": verdict, "flag": module.DESCENDANT_CAPABILITY_READY})
    if verdict != "accepted":
        return
    fifo = os.path.join(work, "events")
    reader = watch(fifo)
    body = ("import os,signal,time\nw=os.open(%r,os.O_WRONLY);os.write(w,b'x')\n"
            "signal.signal(signal.SIGTERM,signal.SIG_IGN)\n"
            "if os.fork()==0:\n    os.setsid();os.close(1);os.close(2);time.sleep(30);os._exit(0)\n"
            "print('ok')\n" % fifo)
    result = module.run_command(("/usr/bin/python3", "-I", "-c", body))
    time.sleep(0.2)
    data, alive = drain(reader)
    os.close(reader)
    say({"part": "r2 fixed command with an escaped descendant that ignores TERM",
         "returncode": result.returncode, "stdout": result.stdout.decode("ascii", "replace").strip(),
         "runtime_failed": result.runtime_failed, "bytes from stand-ins": len(data),
         "process left after return": alive, "flag": module.DESCENDANT_CAPABILITY_READY})

if __name__ == "__main__":
    part, base = sys.argv[1], sys.argv[2]
    {"root": root_part, "r2": r2_part}[part](base)
----- END pr30_box_probe.py -----

----- BEGIN pidfd_answers.py -----
# What does pidfd_open(pid, 0) answer on this kernel for each kind of number?
import errno, os, signal, threading, time, subprocess, sys
def ans(pid):
    try:
        fd = os.pidfd_open(pid, 0)
    except OSError as exc:
        return errno.errorcode.get(exc.errno, exc.errno)
    os.close(fd); return "opened"
def sig0(fn, n):
    try: fn(n, 0); return "answers signal 0"
    except OSError as exc: return errno.errorcode[exc.errno]
print("kernel", os.uname().release, "python", sys.version.split()[0])
pid = os.fork()
if pid == 0:
    time.sleep(30); os._exit(0)
print("live child:", ans(pid))
os.kill(pid, signal.SIGKILL); os.waitid(os.P_PID, pid, os.WEXITED | os.WNOWAIT)
print("zombie child (terminal, not reaped):", ans(pid))
os.waitpid(pid, 0)
print("reaped child, number unused:", ans(pid))
# reaped group leader whose group still has a member
leader = os.fork()
if leader == 0:
    os.setpgid(0, 0)
    if os.fork() == 0:
        time.sleep(30); os._exit(0)
    time.sleep(30); os._exit(0)
time.sleep(0.3); os.kill(leader, signal.SIGKILL); os.waitpid(leader, 0)
print("reaped leader, group still has a member (group %s):" % sig0(os.killpg, leader), ans(leader))
os.killpg(leader, signal.SIGKILL); time.sleep(0.1)
# reaped session leader whose session still has a member in another group
r, w = os.pipe()
sl = os.fork()
if sl == 0:
    os.setsid()
    m = os.fork()
    if m == 0:
        os.setpgid(0, 0); time.sleep(30); os._exit(0)
    os.write(w, str(m).encode()); time.sleep(30); os._exit(0)
time.sleep(0.3); member = int(os.read(r, 20)); os.kill(sl, signal.SIGKILL); os.waitpid(sl, 0)
print("reaped session leader, session still has a member (member's sid %d, leader was %d):" % (os.getsid(member), sl), ans(sl))
os.kill(member, signal.SIGKILL)
# a live non-leader thread's TID
tid = []; ev = threading.Event(); stop = threading.Event()
t = threading.Thread(target=lambda: (tid.append(threading.get_native_id()), ev.set(), stop.wait()))
t.start(); ev.wait()
print("TID of a live non-leader thread of this process:", ans(tid[0]))
stop.set(); t.join()
# leader thread exited, another thread lives
code = "import os,threading,time,sys\nt=threading.Thread(target=lambda: time.sleep(5))\nt.start()\nsys.stdout.write('x');sys.stdout.flush()\nimport ctypes\nctypes.CDLL(None).syscall(60,0)\n"
p = subprocess.Popen([sys.executable, "-I", "-c", code], stdout=subprocess.PIPE)
p.stdout.read(1); time.sleep(0.3)
state = open("/proc/%d/stat" % p.pid, "rb").read().rsplit(b")", 1)[1].split()[0]
print("leader thread exited, another thread lives (stat state %s):" % state.decode(), ans(p.pid))
p.kill(); p.wait()
for n in (4194305, 2**31 - 1):
    print("number", n, "(above pid_max):", ans(n))
----- END pidfd_answers.py -----
