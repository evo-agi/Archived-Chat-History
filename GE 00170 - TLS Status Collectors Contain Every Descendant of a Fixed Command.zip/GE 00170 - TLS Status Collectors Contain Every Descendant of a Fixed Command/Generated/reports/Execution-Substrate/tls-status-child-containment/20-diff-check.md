# ES PR #30, diff check 20: cd36797..f76db77 (IPv6 off in the firewall lab's containers)

```
Target:   evo-agi/Execution-Substrate, draft PR #30, branch claude/project-thread-wbmulu
Range:    cd36797 (sync check 19, ACCEPT as a sync; CI red on #35's BridgeIsolation)
          .. f76db77d2cf59666e36318fb3b3c25f1cd824ffc (one test-only commit, tree 0eb58fbc…)
Evidence: writer's 18-evidence/fix-f76db77/
Posture:  auditor thread, read-only; nothing pushed, no PR comment. Cloud container
          (kernel 6.18.44 without IPv6, Go 1.26.5, user ci UID 1500, and root).
Verdict:  ACCEPT f76db77. The fix removes the containers' own IPv6 frames and keeps the
          exact count of 15. CI is green, and on the IPv6 runner BridgeIsolation passed with
          that count. No new finding. Ready for the gate.
```

## 1. Provenance and scope

- `f76db77`'s parent is `cd36797`. The diff is one file, `scripts/remote_alpha_host_firewall_test.go`,
  with 13 added lines. Its sha256 is `28007ff3…3305`, the writer's figure.
- With HEAD reset to `230954d`, upstream `origin/trunk_dev`, two runs at open and two at close all
  give `manifest_sha256 = 66ec78d154042e79efed33179a31878d2369c51d3303f93d7e8ceca921f519f8`
  (20 files) and `textual_diff_sha256 = d7395f73…bff2`. They are byte-equal to the writer's
  `fix-f76db77/provenance/manifest-v2-run1.json` and `run2.json`. The recipe hash was checked
  before each run.
- The 20 files are the 19 accepted at `cd36797` plus the firewall test file. Nothing else
  changed: both collectors, the workflow, the root step and `environment-only-tests.txt` are as
  in sync check 19.

## 2. The fix against the failure

The failure (sync check 19, section 6): on the IPv6 runner the bridge counter
`container_to_container` read 16, not the probe's 15. That rule drops and counts every frame
forwarded from one docker0 port to another.

The fix, in `newHostFirewallLab`, when the kernel has IPv6 (`l.ipv6`, from `/proc/sys/net/ipv6`):
`sysctl -qw net.ipv6.conf.all.disable_ipv6=1` and `…default…` inside the `c1` and `c2`
namespaces. I checked:

- **Order.** It runs after the namespaces exist and before each container's `eth0` is created
  in it (`ip link add eth0 netns <c> type veth …`). A new interface takes the namespace's
  `default` values, so the containers' `eth0` never has IPv6. With no IPv6 address there is no
  duplicate address detection, no router solicitation and no MLD report from the containers.
- **Only the containers.** The box, LAN and WAN namespaces keep IPv6. Frames that the box's own
  bridge ports or docker0 send are not forwarded between ports, so the forward hook never sees
  them. So the containers were the only source of extra counted frames, and the fix removes
  exactly that source. That follows from how the bridge forward hook works; I did not measure it.
- **No check loses its meaning.** All 25 lab checks that start in a container use IPv4
  addresses. Every IPv6 check starts in `lan` or `box`. No check now passes only because a
  container lacks IPv6.
- **The layer-2 probe still tests the bridge rule.** It sends from `c1` and receives in `c2` on
  `AF_PACKET` raw sockets bound to `eth0` (`ETH_P_ALL`). That path does not use the IPv6 stack,
  and it delivered the probe's IPv6 frames in this container, which has no IPv6 at all. So the
  probe still sends 3 IPv6 frames that the bridge table has to drop. Without the firewall it must
  still see `ipv4=3 ipv6=3 tagged=6 arp=3`.
- **The exact count stays.** The `!= "15"` check is unchanged, and #35's four `skips-itself`
  lines are all still in the root step.

The fix is the one I proposed in sync check 19, and it is test-only.

## 3. Runs at f76db77 (container without IPv6, iproute2 and openssh-server installed)

| Run | Result |
|---|---|
| `go vet ./scripts/` linux/amd64 and darwin/arm64 | exit 0 |
| `gofmt -l` on the changed file | empty |
| CI root step, emulated | 9 of 9 pass |
| `RealKernelBridgeIsolation` ×5 as root | 5/5 pass |
| `./scripts/` as ci, vs `cd36797` with the same tools | verdicts identical on all 2,181 names |
| Network namespaces left after the runs | none |

The new branch runs only when the kernel has IPv6, and this container has none, so these runs
show only that nothing else changed. The fix itself can only be proved on an IPv6 host, and CI
is that host.

## 4. CI on f76db77

Run 45388336474 on `f76db77` (11:53:38Z to 12:35:15Z) is green in every step: "Check the test gate",
"Test", "Listed tests still fail", and "Listed tests pass as root" with **9 of 9**
(`ci/job-138425070433-root-step.txt`). The runner has IPv6, since `RealKernelTraffic` ran both
IPv6 subtests. `RealKernelBridgeIsolation` passed, so its counter read exactly 15: the test fails
on any other value, and on `cd36797` that same runner type read 16.

This is one passing run. What makes the result deterministic rather than lucky is the mechanism
in section 2: with IPv6 off before `eth0` exists, the containers send no IPv6 frame at all, so
no timing can add one. The five PID-namespace tests passed again on the runner.

## 5. Evidence

`20-diff-check-evidence/` (SHA256SUMS in that folder): `provenance-open/`, `provenance-close/`,
`review/` (the diff, and `fix-review.txt` with the setup order, the 25 container checks, the
probe's socket and the bridge rule), `runs/`, `ci/`, `scripts/`.
