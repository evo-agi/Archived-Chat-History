# ES PR #30 red-team (12): TLS status collector child containment

| Item | Value |
| --- | --- |
| Repository / PR | `evo-agi/Execution-Substrate`, draft PR [#30](https://github.com/evo-agi/Execution-Substrate/pull/30), branch `claude/project-thread-wbmulu` |
| Target head | `eed4c9b41b37c0e6bf9e33e3ac2b314ca3ef89ea`, tree `c97fc0acf9465ad78e73a3a0cd08c1395d9a8c67` (branch tip on GitHub at the start and at the close) |
| Base | `trunk_dev` `76c030fa7872dd22dda731591878ef284c01bd9b` (merge base). `trunk_dev` was `fdfa3bc` at the start and is `0aa4a2b5d8e93a10f65b3bb724b286ee79a0aa7e` at the close; a trial merge of the close state is clean and touches none of the PR's files |
| Role | Red-team thread, separate from the writer and from the auditor. Read-only toward the repo: nothing pushed, no PR edit, no comment |
| Window | 2026-11-23, 21:37Z to about 23:15Z |
| Where it ran | One cloud container, as root and as an unprivileged user `ci`. Kernel 6.18.44, 4 CPUs, Python 3.13.18, OpenSSL 3.0.13, sudo 1.9.15p5, Go 1.26.5. Nothing ran on the Linux box or on any other machine |
| Evidence | `12-redteam-evidence/` next to this file (`SHA256SUMS.txt` lists every file) |

## Verdict

**The containment never gave a false result, but it can be held for good and it can leave processes behind. Three Low findings. Each has a failing regression test and a prototype fix that makes the test pass.**

In everything I ran, no command returned success while a process of that command was still alive, and no malformed output was accepted through a hang or a crash. That is the property that protects the status result, and it held.

The two things the brief asked me to check both fail. A path can hang the caller: findings 1 and 2. A path can leave a process behind: findings 2 and 3.

| ID | Severity | Type | Summary | Status |
| --- | --- | --- | --- | --- |
| RT12-1 | Low | Bug, and the documents state the opposite | Root collector. A fixed child can make a process that is a child of the collector itself (`clone` with `CLONE_PARENT`). Nobody reaps it. The collector then waits for good; TERM, INT, HUP and QUIT do not end it, only KILL does. Needs no root power. 5 of 5 runs | Failing test and prototype fix attached. Recommended in this PR |
| RT12-2 | Low | Bug, and the documents state the opposite. Two of three variants are inside the stated limit "root is still root", the third is not | Root collector. The namespace ends only when the anchor notices that its control pipe closed. A process in the namespace can keep the anchor from noticing: hold the pipe open, stop the anchor, or keep it busy with fork alone. Then the fix for T9-1 is switched off, and a killed collector leaves its fixed child and all descendants alive | Failing test (two deterministic variants) and prototype fix attached. Recommended in this PR |
| RT12-3 | Low | Bug. The stated limit covers only "a relay that stays ahead" | Remote collector. The drain is beaten by descendants that only wait: a chain of 60 processes (every run), or a herd of 14,000 (every run, none killed). A fork relay behind a backlog beats it in 9 or 10 of 10 runs. The run is always reported as failed, never as passed, but the processes outlive the collector | Failing test and prototype fix attached. Recommended in this PR |

Severity is by the scale the audits used for T7-1 and T9-1: every finding needs a changed binary at the fixed OpenSSL path on the host, and none yields a false result.

---

## 1. Plain-language summary for David

The collectors start small helper programs (OpenSSL). PR 30 makes sure that when a helper misbehaves, for example by starting hidden background programs, everything it started is gone before the collector goes on. I played the misbehaving helper.

The good news: I could not make a collector report "all fine" while something of the helper was still running, and I could not make it accept garbage.

I found three ways in which the cleanup itself fails.

1. **The collector can be frozen for good.** A helper can start a program that looks like a direct child of the collector. The collector does not know about it and never cleans it up, and then waits for ever. Ctrl-C does not help. Only a hard kill does. This needs no special rights.
2. **The off switch asks politely.** The collector ends the helper's sealed room by telling a small guard process "you can go now". The helper can keep the guard from hearing that. Then an old stall comes back, and if the collector is killed, the helper and everything it started keep running. One way to do this needs nothing more than starting many processes.
3. **The second collector's sweep can be outnumbered.** The collector that runs without root sweeps up leftovers in rounds, for two seconds. Sixty idle processes in a row are enough to outlast it. It notices and reports a failure, which is right, but the processes stay.

For all three I wrote tests that fail on today's PR, and small trial fixes that make them pass. None of the fixes is a compromise. I recommend adding them to PR 30 before it merges, followed by a short re-audit.

All of this needs someone who can already replace `/usr/bin/openssl` on the host, which itself needs root there. That is why the findings are Low.

---

## 2. Target and provenance

Verified before any attack and again at the close (provenance §5.3, tool `governed_execution_audit_patch_manifest_v2.py`, SHA-256 `c08597e2…e1a3ca` verified before each run):

| Check | Start (21:38Z) | Close (22:54Z) |
| --- | --- | --- |
| Branch tip on GitHub | `eed4c9b41b37c0e6bf9e33e3ac2b314ca3ef89ea` | same |
| Tree | `c97fc0acf9465ad78e73a3a0cd08c1395d9a8c67` | same |
| v2 manifest, two runs each time | `ab6da82106b7387a2dce1b3d0f041d3f5bfbf02c889401682ec648a333f9019d`, both runs identical | same, both runs identical |
| Textual diff | `e556b9e28b8e4cd4b475016181452af14e487a494144a6cbb6e2845218b17a25`, 19 files | same |
| Against the writer's `10-evidence/manifest-v2.json` | byte-identical | byte-identical |

The two files under attack:

- `scripts/internal/remote_alpha_es_tls_status.py`, SHA-256 `b5a1344f1f0de75c13b7b1d2d54b27cc71630e7cd4b495408b7943f72771d474` (the root collector).
- `scripts/internal/remote_alpha_operator_healthcheck_tls_status_noninteractive_remote.py`, SHA-256 `33e5f4d5bcfab7c5524703d14e9c97ec6e3f47d29fc18c0431ed6efaa16aa4c8` (the remote collector).

Every run used these exact bytes, loaded from a clone that stayed clean (`git status` empty at the close). The regression tests and the prototypes live in separate copies.

## 3. Threat model and method

The attacker is the fixed child: a changed binary at the fixed OpenSSL path. For the root collector it runs as root inside its own PID namespace. For the remote collector it runs as the SSH user. I also attacked from the outside with signals to the collector, and with malformed output.

Each attack replaced the fixed command by a stand-in and called the collector's own `run_fixed` or `run_command`, with the real capability probes. Every process of a stand-in keeps a FIFO open for writing, so "nothing is left" is read from the kernel as end of input, the same way the PR's own tests do it.

What I read first: reports 01 to 11 of this folder, the two collectors, both containment test files, and the three documents that state the limits.

Fact about the attack surface: neither collector opens a network connection. Every OpenSSL command reads standard input, `/dev/fd/N`, or a fixed file (no `s_client`, no socket). So the item "a slow or hostile TLS peer" in the brief has no target here.

## 4. Findings

### RT12-1 (Low): a child that the collector never asked for holds it for good

**What happens.** The fixed child calls `clone3` with `CLONE_PARENT`. The new process is inside the namespace, but its parent is the fixed child's parent: the collector. The anchor reaps only orphans of the namespace, and the collector waits only for the fixed child and the anchor. When the namespace ends, the kernel kills that process, its zombie stays, and the kernel does not let the anchor become terminal while a process of the namespace is unreaped. `CLONE_PARENT` is refused only to the first process of a namespace, not to the second.

**Where it holds.**

- Sibling inside the fixed child's group: `terminate_child`, the loop at lines 1064 to 1066. The group never becomes "only the leader".
- Sibling that left the group with `setsid`: `ChildNamespace.close()`, the loop at lines 1281 to 1300. The anchor never becomes waitable.

Neither loop has a bound, and neither looks at the latched signal.

**Measured** (`logs/sibling-eed4c9b.txt`, `logs/sibling-latched-eed4c9b.txt`): 5 of 5 runs held, with limits of 20 s and 45 s. The stand-in's own lifetime does not matter, because the holder is a zombie. With the collector's own signal handlers installed, as `main` installs them, the collector was "still running after SIGTERM". Only SIGKILL ended it.

**Against the documents.** `remote_supported_host_alpha.md` lists what can still hold the invocation: "A process that cannot die … keeps the anchor from becoming terminal." Here every process can die and has died. The same document says the anchor waits for "an unreaped direct child of the collector"; that sentence is true, and it is the mechanism.

**Related.** Observation O7-1 of audit 07 (an exception inside `Popen` after the fork leaves an unreaped child of the collector in the namespace) is the same hold by another route. The fix below closes both.

**Regression test.** `TestRemoteAlphaESServiceTLSStatusChildNamespaceRealSiblings`, 5 cases. At `eed4c9b` both collectors are still running after 20 s and the probe kills them.

### RT12-2 (Low): the release is a request, and the anchor can be made deaf to it

**What happens.** Since the T9-1 fix, the collector closes the control pipe before the cleanup. That ends the namespace only if the anchor then reads the end of input and exits. Until `close()`, nothing else ends it, and `close()` runs after the unbounded cleanup. If the collector is dead, nothing else ever ends it.

Three ways to keep the anchor from acting, all measured:

| Variant | Needs | How |
| --- | --- | --- |
| a. Hold the pipe | root (any process in the namespace is root) | One `open()` of `/proc/<collector>/fd/N` gives a second write end of the control pipe. The anchor never sees the end of input |
| b. Stop the anchor | root, and a kernel that allows ptrace | `PTRACE_SEIZE` and `PTRACE_INTERRUPT` on process 1 of the namespace |
| c. Keep it busy | fork only | The anchor reaps in `while os.waitpid(-1, os.WNOHANG)[0] > 0` before it looks at the pipe's answer. A few thousand orphans make each reap slow, and a fork relay supplies ended children faster than the anchor reaps them. The loop does not end |

**Effect 1: the T9-1 stall is back.** With the T7-1 shape (a descendant outside the group keeps an ended child unreaped inside it), the command returns only when the descendant ends by itself, and then reports success with nothing unproved.

| Variant | Without the T7-1 shape | With it (descendant ends by itself after 12 s, or 5 s for c) |
| --- | --- | --- |
| a | 1.11 s (the grace period, then `close()` kills the anchor) | 12.05 s |
| b | 1.11 s | 12.06 s |
| c, no sleepers, 0 or 4 chains | | 0 of 10 runs held (0.005 to 0.018 s) |
| c, 2,000 sleepers, 4 chains | | 2 of 5 held |
| c, 4,000 sleepers, 4 chains | | 4 of 5 held |
| c, 8,000 sleepers, 1 chain | | 2 of 5 held |
| c, 8,000 sleepers, 4 chains | | 4 of 5 held |

Variant c is a race. It held in 12 of 20 runs with sleepers. Runs that were not held still took 0.2 to 3.1 s instead of 0.006 s.

**Effect 2: a killed collector leaves everything alive.** The collector was killed with SIGKILL 1.5 s into a command whose fixed child stays.

| Case | Fixed child after the collector's death |
| --- | --- |
| Control, no trick | gone after 7 ms |
| a and b | still alive 3 s later, until the descendant let go (`logs/collector-death-eed4c9b.txt`) |
| c, 8,000 sleepers, 1 chain | still running after 7.1 s; ended after 10.4 s, which is the stand-in's own lifetime |
| c, 8,000 sleepers, 4 chains | the same: 10.4 s |

**Effect 3: a reader of the collector's output waits too.** The anchor keeps the collector's standard streams. With variant a or b, a process that reads the killed collector's standard output through a pipe saw the end of input after 6.67 s, when the descendant let go, against 1 ms in the control (`logs/anchor-keeps-stdout-eed4c9b.txt`). The real route uses a terminal; whether the operator's SSH session returns there is a box item (section 8).

**Against the documents.** `remote_supported_host_alpha.md` says "so a killed collector takes its fixed child and every descendant in the namespace with it". Variants a and b fall under the stated limit "root is still root". Variant c uses no root power, so it does not.

**Regression test.** `TestRemoteAlphaESServiceTLSStatusChildNamespaceRealDeafAnchor`, 5 cases, with variants a and b, which are deterministic. At `eed4c9b` the two in-process cases return after 8.05 s with "lapsed" reported, and after both killed collectors the processes are still alive when the 10 s are over. Variant c has no regression test: it is a race and needs thousands of processes. The fix is the same for all three, and I ran variant c against the prototype by hand (section 7).

### RT12-3 (Low): descendants that only wait outlast the remote collector's drain

**What happens.** `drain_descendants` kills the collector's own children once per round, reaps at most 64 ended children per round, pauses up to 50 ms between rounds, stops after 2 s, and reads at most 65,536 bytes of a children list; a round that cannot read the list kills nothing. Each of these numbers can be used.

| Shape | Why it works | Measured as user `ci` |
| --- | --- | --- |
| Chain: every process is the parent of the next, all wait | Only the first link is the collector's child. Each kill hands over one more link, so the drain needs one round per link, and 2 s hold about 45 rounds | Depth 45: success after 2.03 s. Depth 60: failed, 13 left alive. Depth 100: 53 left. Depth 200: 153 left. Every run |
| Herd: many children that wait | Above about 10,900 children here the list is longer than one read, so no round kills anything | 14,000: failed, 14,000 left alive, 3 of 3. From 4,000 to 11,500 everything is killed but not reaped in time: a failure with nothing left alive |
| Relay behind a backlog: leave ended children, then relay | Reaping the backlog, 64 per round, uses up the rounds while the relay moves on | C relay, 10 runs each: 1,000 ended children with 4 chains: alive after return in 10. With 1 chain: 9. 200 with 4 chains: 9. Python relay, 1,000 with 4 chains: 8 |

In every one of these runs the command was reported as `runtime_failed` and the capability flag was cleared. No run returned success with a process alive. That part of the contract holds.

**Against the documents.** `remote_alpha_operator_healthcheck_noninteractive_status.md` §8 says: "the kernel refuses a fork to a process with a pending SIGKILL, so each round only shrinks what is left, and the bound turns a relay that stays ahead into a reported failure." A chain and a herd are not relays and are not ahead of anything; they wait. And with a backlog, a round does not shrink what is left. The PR's own real test passes because its relay sleeps 5 ms per generation, for 40 generations.

**Side effect on a good host.** A chain costs time even when the drain wins: depth 30 took 1.26 s. Not a finding.

**Regression test.** `TestRemoteAlphaOperatorHealthcheckTLSStatusNoninteractiveDescendantRealCrowd`, 3 cases: a chain of 80, and a herd of 120 with the read bound set to 256 bytes for the test, so that it stays cheap. The real bound was measured with 14,000 processes. The relay has no regression test because it is a race.

## 5. Attacks that held

| Attack | Result |
| --- | --- |
| Double fork, `setsid`, `setpgid`, daemon, TERM ignored (the PR's own cases, rerun) | 16 of 16 existing containment tests pass as root at `eed4c9b` |
| Output floods on stdout and stderr; a flood by a descendant after the fixed child ended | Both collectors: `child_output_overflow` or overflow within 0.03 to 0.23 s, nothing left |
| Slow drip; output held open by a descendant; unread standard input of 1 MiB (root) or 64 KiB (remote); closed standard input | Timeout or success as designed, nothing left |
| Fixed child that ends within milliseconds of the timeout | 150 runs per collector. Only "returned" or "timed out", nothing left, nothing unproved |
| Descendants that end at random moments during the cleanup | Covered by the 300-command runs below |
| Leaks | 300 mixed hostile commands per collector in one process: 3 descriptors before and after, no child, no thread, no process left |
| HUP, INT, QUIT, TERM at a random moment of a fixed command (root collector, its own handlers installed) | 400 runs: 275 `child_interrupted`, 42 `interrupted`, 83 returned. Every run under 5 s, nothing left |
| SIGKILL, SIGALRM, SIGTERM (default action) to the collector at a random moment from its start to the middle of a command (root collector) | 140 runs: no process of the run alive 0.3 s later |
| PID reuse under the new signals | By reading: the anchor, the fixed child and every child the drain signals are unreaped children of the signalling process, so their numbers are reserved. I found no signal to a number that could have been released |
| A root descendant of the fixed `sudo -n` path (remote collector) | 3 of 3: detected, reported as `runtime_failed`, flag cleared, never passed. It outlives the collector, as the documents say |
| Malformed certificate output | 12,000 iterations, two seeds: one command per call answers with a mutated copy of real OpenSSL 3.0.13 output (bit flips, truncation, 60,000-byte runs of separators, control bytes, invalid UTF-8, extreme dates). No call took over 1 s. Outcomes: the typed grammar failure, or a parsed result. Two exception types escape the parsers and are caught by each collector's `main`, see O12-4 |
| A slow or hostile TLS peer | No target: neither collector opens a connection |

## 6. Observations

- **O12-1. The remote collector does not take its children with it.** It installs no signal handlers and does nothing on its own death. TERM or KILL to it leaves the fixed child and its descendants alive (`logs/r2-collector-death-eed4c9b.txt`). Older than this PR, and not among the stated limits. The prototype for RT12-3 removes the descendants. One more line in the same place (`PR_SET_PDEATHSIG` in the fixed child) would end the fixed child too. I did not prototype that line.
- **O12-2. A held root collector cannot be interrupted.** The two unbounded waits ignore the latched signal. The documents say the invocation holds; they do not say that Ctrl-C will not end it. After the fixes below, only a process that truly cannot die reaches these waits.
- **O12-3. A same-user descendant can signal the remote collector itself.** By design of an unprivileged collector; it ends the collection and yields no result. Stated here for completeness.
- **O12-4. Two exception types leave the parsers.** `OverflowError` from `parse_openssl_date` in the remote collector (`astimezone` is outside its `try`), 24 times in 12,000 iterations, and `UnicodeDecodeError` from the text decode in `cert_role` of the root collector. Both are caught by `main` and fail closed. Older than this PR. Report-only.
- **O12-5. The group cleanup's host-wide `/proc` scans are unchanged (decision D4).** I did not attack them again; PR 22's audits did.

## 7. Proposed fixes and their validation

Two diffs, both apply to `eed4c9b` with `git apply --check`:

- `regression-tests-12.diff`, SHA-256 in `SHA256SUMS.txt`: the three tests (13 cases) and two `skips-itself` lines in `.github/ci/environment-only-tests.txt` for the two root tests.
- `prototype-fixes-12.diff`: prototypes, marked `PROTOTYPE` in the code. They show that the tests can pass. They are not a finished repair.

| Finding | Prototype | In the code |
| --- | --- | --- |
| RT12-1 | The collector reaps every child of its own that is in another PID namespace and is neither the anchor nor the fixed child. It does so in both unbounded waits | `ChildNamespace.reap_strays`, called from the loop in `close()` and, through a small hook, from `resolved_with_leader_reserved` and `prove_group_absent` |
| RT12-2 | The collector ends the namespace itself: after closing the pipe it sends SIGKILL to the anchor, its own unreaped child. And the anchor asks the kernel to kill it when the collector dies (`PR_SET_PDEATHSIG`) | `ChildNamespace.end()` replaces the three releases of the fixed command. The probe keeps the plain release, because it tests the kernel |
| RT12-3 | The fixed child of an unprivileged collector gets `RLIMIT_NPROC` (0, 0) before exec. The kernel then refuses it every new process and thread | `_no_new_process` as `preexec_fn` |

**Results** (`test-runs/`):

| Run | Result |
| --- | --- |
| 01. Existing containment tests, root, `eed4c9b` | 16 of 16 pass |
| 02. Root collector tests with the new tests, root, `eed4c9b` | 9 existing pass. `RealSiblings` and `RealDeafAnchor` fail, for the reasons in section 4 |
| 03. Remote collector tests with the new test, user `ci`, `eed4c9b` | 7 existing pass. `RealCrowd` fails: both cases `runtime_failed` |
| 04. Root collector tests, root, prototype | `RealSiblings` passes in 0.40 s, `RealDeafAnchor` in 0.55 s. Four existing tests fail, see below |
| 05. Remote collector tests, user `ci`, prototype | `RealCrowd` passes in 0.16 s. One existing test fails, see below |

Also against the prototype, by hand:

- Variant c of RT12-2: 0 of 9 runs held, and after a killed collector the fixed child was gone within 2 to 20 ms, also with 8,000 sleepers and 4 chains (`logs/anchor-fork-capture-prototype.txt`). The runs take 0.4 to 4.5 s, which is the time the kernel needs to end and reap what the stand-in created.
- RT12-3: the relay matrix, 40 of 40 runs returned with nothing alive; the herd of 14,000 and every chain could not start.
- The reader of a killed collector's output saw the end of input after 1.5 ms.

**What the prototypes break, and why.** These are pins and stand-ins that a real repair has to update. None is a behaviour I did not intend.

- `ChildNamespaceFixedCommand` and the two controls of `RealDescendants`: their stand-in objects have no method `end`.
- `ChildNamespaceDocumentsContract`: it pins the anchor's code and the count of releases.
- `RealCollectorDeath`: it expects the anchor to end with status 0 after a killed collector. With the prototype the kernel kills it.
- `DescendantRealKernel` (remote): six of its cases start descendants, which the limit now refuses. The drain still needs tests, for a collector that runs as root and for the `sudo` path. The writer has to decide how those tests switch the limit off.

**What the prototypes do not settle.**

- RT12-2: between the anchor's fork and its `prctl` there is a window. If the collector spawns the fixed child and dies inside it, the anchor depends on the pipe again. A ready byte from the anchor before the spawn closes it.
- RT12-3: the limit does not bind root. Measured: as uid 0 the fork still works. So when the SSH target is root, and for descendants of the `sudo -n` path, the drain is still the only containment and the three shapes still beat it. Either the drain kills whole trees per round and survives a long list, or the documents state the limit for those two cases as it is.
- The fixed `sudo -n` path still worked under the limit here (`logs/r2-nproc-probe.txt`). Whether it does with the box's PAM settings is a box item.

**A design option beyond this PR, for the coordinator.** The root collector's fixed child gets every input on standard input or `/dev/fd`. Inference: it does not need root. Run as an unprivileged user with the same process limit, it could not fork, could not open root's pipes through `/proc`, and could not ptrace the anchor. That would remove RT12-1 and all variants of RT12-2 at the cause and shrink "root is still root" for this child. Not prototyped. Unknown: whether OpenSSL on the box reads anything at start that only root can read. This changes the privilege model that decision D4 fixed, so it is a design decision and not part of my recommendation for this PR.

## 8. What needs the Linux box (for the box brief)

Nothing in this report ran on the box. These items can only be answered there. Guesses are marked.

1. **RT12-1 and RT12-2 on the box's kernel**, as root through the real route: the new root tests, before and after the repair. Guess: Ubuntu 24.04 with kernel 6.8; `clone3` with `CLONE_PARENT` and the `/proc` reopen behave the same.
2. **`kernel.yama.ptrace_scope`** on the box. This container has no Yama. With scope 3 the kernel refuses variant b, and the test's ptrace case then holds for a different reason; the test reports which.
3. **Variant c on the box.** The race depends on the CPU count and on `kernel.pid_max` (guess: 4,194,304 there, against 32,768 here). More room for sleepers makes it more reliable, not less.
4. **Whether the operator's `ssh -tt` session returns** when a killed collector leaves an anchor that holds the terminal (effect 3 of RT12-2). Inference: with a terminal, sshd ends the session when the command ends. Unmeasured.
5. **RT12-3 as the real SSH user**: the new test, before and after. And for the limit: `ulimit -u` of the SSH session, PAM limits, the user slice's `TasksMax`, and whether the fixed `sudo -n` commands still run under `RLIMIT_NPROC` (0, 0) with the box's sudo and sudoers.
6. **Whether any SSH target user is root.** There the limit does not bind.
7. **How fast the box's first process reaps.** This container's first process takes up to about 3.5 s to reap adopted zombies, which only affects how long ended processes stay listed after a killed collector. Guess: systemd reaps at once.

## 9. Coverage I could not get

- The Linux box, the Mac, the real operator route (`recovery-session … --interactive-tty`), real `sudo` with a terminal, and real TLS material. Everything ran with stand-ins in one container.
- Variant c of RT12-2 and the relay of RT12-3 are races. Their rates are from 4 CPUs and `pid_max` 32,768 and will differ elsewhere.
- I did not attack the unchanged group cleanup (host-wide `/proc` scans, PGID reuse after the reap) again.
- I did not run the whole root package or the whole repository test suite. I ran the two containment families: 16 tests at `eed4c9b` as root, and the 26 tests of the remote family (25 existing and the new one) as `ci`, with and without the prototype (`test-runs/06` and `07`). Eight of the 26 fail in this container at `eed4c9b` and with the prototype alike. All eight end with the wrapper's "local prerequisite failed": the wrapper requires `/usr/bin/ssh` (line 353 of `scripts/remote_alpha_operator_healthcheck_tls_status_noninteractive.py`), and this container has no SSH client. The only verdicts the prototype changed are the two in section 7.
- The CI gate self-test (`go_test_gate_selftest.py`) fails 46 of 132 of its own tests in this container at `eed4c9b` and with the regression diff alike, the same 46. I could not verify the two new `skips-itself` lines on the CI runner.
- The fuzzing of the parsers replaced the commands; it did not run OpenSSL on malformed certificates.
- macOS: the real tests skip there. Not run.
- Subagents: none used.

## 10. Recommendation

1. **Repair RT12-1, RT12-2 and RT12-3 in this PR, before merge.** None of the three is a compromise, and the changes are small. Take `regression-tests-12.diff` as it is or adapt it; the prototypes are a starting point.
2. For RT12-3, decide the root and `sudo` cases explicitly: harden the drain, or state the limit.
3. Correct the three sentences of the documents quoted in section 4.
4. Then a narrow re-audit of the repair, and a short re-check by this thread of the three findings and of variant c.
5. Add section 8 to the box brief.
6. The design option in section 7 is the coordinator's call.

The PR is not ready to merge at `eed4c9b`.

## 11. Confidence

- **High** that RT12-1 is real and deterministic: 5 of 5 by hand, 2 of 2 in the test, the mechanism is kernel behaviour I measured, and the prototype removes it.
- **High** for variants a and b of RT12-2 and for the chain and herd of RT12-3: deterministic, repeated, and removed by the prototypes.
- **Medium** for the rates of the two races. That they exist is certain; how often they win depends on the host.
- **Medium** that I found every hold. I attacked the two unbounded waits from the directions I could think of; the group cleanup itself I left alone.
- **High** that no attacked path gives a false success.

## 12. Effects and sensitive material

- Repository: nothing pushed, no branch created, no PR edit, no GitHub comment.
- Project files: this report and `12-redteam-evidence/` created. No other project file changed.
- Machines: only this thread's container. A test user `ci` and a sudoers drop-in for it exist only there. Several runs used up the container's process numbers for a few seconds; they ended by themselves.
- No live service, no third party, no real key or certificate. The test certificates were made in the container and are not in the evidence. The evidence was scanned for secrets and personal data: none.

## 13. Evidence index

`12-redteam-evidence/`:

| Path | Content |
| --- | --- |
| `regression-tests-12.diff` | The three failing tests, for the writer |
| `prototype-fixes-12.diff` | The prototype fixes |
| `test-runs/01` to `05` | The five `go test` runs of section 7 |
| `test-runs/06`, `07` | The whole remote family as `ci`, at `eed4c9b` with the new test and with the prototype (section 9) |
| `logs/sibling-*.txt` | RT12-1 |
| `logs/anchor-eof-*.txt`, `logs/collector-death-eed4c9b.txt`, `logs/anchor-fork-capture-*.txt`, `logs/anchor-keeps-stdout-eed4c9b.txt` | RT12-2. The file `anchor-eof-eed4c9b.txt` carries a note: two of its results came from a faulty fixture and are superseded |
| `logs/r2-chain-*.txt`, `logs/r2-herd-*.txt`, `logs/r2-relay-*.txt`, `logs/r2-pyrelay-*.txt`, `logs/r2-nproc-probe.txt` | RT12-3 and the limit |
| `logs/root-*.txt`, `logs/r2-streams-race-leak-eed4c9b.txt`, `logs/r2-sudo-root-relay-eed4c9b.txt`, `logs/r2-collector-death-eed4c9b.txt`, `logs/parsers-fuzz-eed4c9b.txt` | Section 5 and the observations |
| `tools/root/`, `tools/remote/`, `tools/parsers/` | Every stand-in and harness, as run |
| `provenance/` | The opening and closing manifests and the tool's output |
| `environment.txt` | The container |
| `SHA256SUMS.txt` | SHA-256 of every file above |
