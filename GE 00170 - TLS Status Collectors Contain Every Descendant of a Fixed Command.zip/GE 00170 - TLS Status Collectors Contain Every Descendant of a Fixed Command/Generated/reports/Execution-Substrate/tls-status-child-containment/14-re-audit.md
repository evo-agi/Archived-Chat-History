# RE-AUDIT 14: PR #30 at `4f55003` (red-team 12 repair, the #39 update, and one test fix)

**Verdict: ACCEPT `4f55003`, with one Low documentation finding (A14-1) to fix in this PR before merge.**

- RT12-1, RT12-2 and RT12-3 are fixed, and O12-1 with them. Every hold and stray shape I tried returns; the same shapes hold `eed4c9b`.
- The #39 sync is correct and complete.
- The writer's test-only commit `4f55003` makes the anchor-order check deterministic (section 6).
- The writer's section 5 (documenting rather than hardening the drain for root and `sudo -n`) is an acceptable boundary, not a compromise (section 7).
- A14-1: the remote collector's documents say a killed collector takes the fixed child with it. A changed binary can undo that request itself, and the stated limits do not say so. The fix is two documents and one pin.

The red-team re-check can start on `4f55003` now; A14-1's fix then needs only a diff check. The collectors are byte-identical at `700b533` and `4f55003`, so every behaviour result below holds for both. Most runs were on `700b533`, and the runs on `4f55003` are named.

## 1. Identity and provenance

| Item | Value |
|---|---|
| Head | `4f55003b81580acec19f2cbe5bf1f6db4859afe1`, tree `9cbfdff64f7d8ff08ae8f8488f3a0ef03418eaf8`. Commits on top of `eed4c9b`: `f7a1170` (merge of `0aa4a2b`), `bb6e05a` (the repair), `700b533` (merge of `4c991ba`; tree `004d0466…`), `4f55003` (test-only, one file, +27 −7, diff sha256 `5014f247…4bd3` = the writer's `anchor-order-4f55003.diff`). `git diff 700b533 4f55003 -- scripts/internal/` is empty |
| Base | `trunk_dev` `4c991ba1c43ac135d9d94853696d14a21523a690` = merge base. trunk_dev has since moved to `6ce0034` (#43 README, #42 es/app test ports). None of its 4 changed files is in this PR. The recipe diffs against `HEAD` and only records the upstream's name, so the move does not touch the manifest. A trial merge `git merge-tree --write-tree 4f55003 6ce0034` is clean (tree `b3eb58ef…`). The branch must be brought up to date at the gate |
| Writer reports | `13-repair.md`, sha256 `4fda097fc31dd1a2bc5b5c39e85c656db17b74a676dee3150492d766e43e7211`; `13a-validation.md`, sha256 `e7a40024bd49b13f4126842737a6381bad9bad2bfa926b26b09a2b6bc19a44d3` |
| Manifest of `4f55003` (recipe sha `c08597e2…a3ca`, checked before each run) | `2b9233cbe3c27943c34c3e65ec68035520a134e01def9072e4b31030e876961b`, textual diff `af20695e…52c5`, 19 files. Taken twice at open and twice at close; byte-identical each time and the same bytes as the writer's `13-evidence/provenance-4f55003/manifest-v2-run1.json` and `-run2.json`. Staged tree = the commit's tree; the repository is clean afterwards |
| Manifest of `700b533` | `2c85067375440e845458ed290896361cada57efef9d67cc5e7a73417fe6eeaa0`, the same bytes as the writer's `13-evidence/provenance/` runs |
| Merges | `f7a1170` and `700b533` each re-created with `git merge-tree --write-tree`. `f7a1170` = the plain merge (tree `d931daea…`). `700b533` differs from the plain merge (tree `0d817f55…`) by exactly the 7 files, +29 −28, of `13-evidence/diffs/merge-resolution-700b533.diff` (byte-identical, sha256 `5503f341…9a3c`) |
| Repair diff | `git diff bb6e05a^ bb6e05a` = the writer's `repair-bb6e05a.diff` (sha256 `30f69545…146a`) |
| CI | run 45301976440 on `700b533`: "build, vet and test" success. Run 45309449104 on `4f55003`: still running at 02:22Z (started 02:02Z) |

## 2. RT12-1: strays of the collector (root collector)

**Code.** `ChildNamespace.end(fixed_child)` replaces all three `release()` calls before the cleanup owner. `_reap_strays` reads `/proc/self/task/*/children`, skips the anchor, the fixed child and every child in the collector's own PID namespace, and reaps the rest with `waitpid(pid, WNOHANG)`, never with a signal. `end()` waits until the fixed child is terminal (`waitid` with `WNOWAIT`) and then until one list holds no stray. `close()` reaps strays in its loop too, keeping only the anchor; that covers O7-1. The group logic is untouched (decision D4).

**The "one empty list is final" argument holds.** I checked each step against the kernel source. Each step below is my reading of that source (inference); the real-kernel tests and my probes agree with it.

- **Only a child of the collector can make a child of the collector.** `CLONE_PARENT` gives the caller's parent. The anchor is refused `CLONE_PARENT`, because it is the first process of its namespace. A process in the namespace cannot `setns` into the collector's namespace, which is an ancestor, so no stray appears at home.
- **The read is complete for this reader.** The kernel walks the children list one entry at a time and can skip entries that are removed during the walk. Here entries leave the list only when the collector reaps them. The collector is single-threaded: it starts no thread, and SIGCHLD is not ignored. Its one `waitpid(-1)` runs in the anchor process, not in the collector. It reaps only after the whole read. New children are appended at the tail.
- **A plain `waitpid` sees every stray.** A `CLONE_PARENT` child takes its exit signal from the caller's group leader, and that chain starts at the fixed child, which `Popen` forked with SIGCHLD.
- **`pid_namespace()` works on a zombie.** The capability probe now proves it on the running kernel: the ended probe member must be listed, with a namespace other than home.

**Behaviour.** My own stray shapes (`probes/sib3.txt`), as root with the real namespace, every stray made with `clone3` and `CLONE_PARENT`:

| Shape | `eed4c9b` | `700b533` |
|---|---|---|
| relay: each stray makes the next one, then ends | held 15 s | `(0, b'fixed', b'')` in 0.34 s |
| herd: 300 strays that ignore TERM, half of them in a new session | held 15 s | same, 0.45 s |
| nested: the stray is the first process of a nested PID namespace, with 20 sleepers inside | held 15 s | same, 0.34 s |
| relay, with the fixed child still running at the time limit | | `child_timeout` in 1.54 s |
| herd, with the fixed child still running at the time limit | | `child_timeout` in 1.60 s |

Each run on `700b533` left no child of the collector and no process of the command, with nothing unproved. The red-team's RealSiblings passes as root (0.39 s), and against the `eed4c9b` collector it holds for its 40 s bound (section 8).

## 3. RT12-2: the namespace ends by KILL, and with a killed collector (root collector)

**Code.** `end()` closes the pipe, then sends the anchor one SIGKILL. The anchor is the collector's unreaped child, so its PID is reserved. A stopped, traced or busy anchor still dies of SIGKILL, and so does a process that holds a second write end of the pipe. The anchor's first step is `prctl(PR_SET_PDEATHSIG, SIGKILL)`. Then it closes what it inherited and writes the ready byte. `open()` closes its own copies of the control read end and the ready write end before it reads, so a failed anchor gives end of input and no hang. A missing or wrong byte means no spawn. A parent-death SIGKILL reaches the first process of a namespace. By my reading of the kernel, it forces the signal when the sender is in an ancestor namespace. RealDeafAnchor proves this on the running kernel: with the pipe held, a killed collector's namespace still ends. `close()` accepts a KILL status only when the collector sent the KILL itself.

**Behaviour.**

- The seven hold modes of audit 09 (`probes/hold-700b533.txt`) give the same results as at `eed4c9b`. The normal path returns `(0, b'fixed', b'')` in 0.33 to 0.34 s. `zombie-to`, `qalive-to` and `zombie-held` give `child_timeout` in 1.53 to 1.54 s. `zombie-over` gives `child_output_overflow` in 0.32 s. Nothing was left.
- RealDeafAnchor and RealCollectorDeath pass as root. Against the `eed4c9b` collector, RealDeafAnchor fails.
- I did not rerun variant c (the busy anchor) by hand. The KILL does not depend on the anchor's loop, and the red-team's re-check covers variant c.

**Stated residual.** A root process of the namespace that may trace the anchor can inject a `prctl` that undoes the anchor's parent-death signal. The documents state this under "root is still root". It cannot be closed while the fixed child runs as root. The red-team's design option (an unprivileged fixed child) would close it; that is a design decision outside this PR.

## 4. RT12-3 and O12-1: the remote collector's fixed child

**Code.** `preexec_fn=fixed_child_setup(os.getpid())` runs three steps in order:

1. `prctl(PR_SET_PDEATHSIG, SIGKILL)`, with the symbol resolved before the fork;
2. a check that `getppid()` is still the collector;
3. `RLIMIT_NPROC (0, 0)`.

An exception in `preexec_fn` reaches the collector as `SubprocessError` (`_posixsubprocess` reports it with errno 0, never as `OSError`). The collector maps it to `runtime_failed`, and the drain still runs. The capability probe forks its children directly, without the setup, as it must: it needs a grandchild. The fixed commands are `openssl`, `sha256sum` and `stat`, directly or through the `sudo -n` allowlist; none starts a process.

**Behaviour** (`probes/pdz.txt`, as `ci`, collector killed with SIGKILL 1 s into the command):

| Fixed child | `eed4c9b` | `700b533` |
|---|---|---|
| sleeps | alive after the collector's death | killed with it |
| tries one fork | fork worked; alive | fork refused, EAGAIN; killed with it |
| unshares a user namespace, then forks | | unshare works, fork refused (EAGAIN): a new user namespace does not escape the limit |
| first undoes its own parent-death request with `prctl(PR_SET_PDEATHSIG, 0)`, then sleeps | alive | **alive**, as one process that cannot fork (A14-1) |

RealProcessLimit, RealCollectorDeath and RealCrowd pass as `ci`. RealProcessLimit skips itself as root, as stated. Against the `eed4c9b` remote collector, RealProcessLimit, RealCollectorDeath, RunCommand and DocumentsContract fail. RealCrowd passes there, as the writer says: its contract, a reported failure with the limit off, belongs to the unchanged drain.

**`sudo -n` under the limit.** The writer's check (`13-evidence/checks/sudo-under-process-limit.txt`, sudo 1.9.15p5) shows that the sudo path and its root command still work under `(0, 0)`, while an unprivileged shell cannot fork. I did not repeat it: my standing rule is not to grant `ci` sudo here. Inference: sudo runs with euid 0 after its exec, which the kernel exempts. The box brief already checks this against the box's sudoers and PAM.

## 5. The #39 sync

The 29 added and 28 removed lines are exactly what #39's rules require of the two test files that #39 could not see:

- Both files move into `scripts/` as `package scripts_test`.
- The five `skips-itself` lines name `execution-substrate/scripts`.
- The root step builds that package and is renamed "Listed tests pass as root".
- The gate self-test pins the new command, and the workflow's SHA-256 `fa3d88b7…9d29` matches `go.yml` byte for byte.
- `capability_probing.md` and the two section markers that tests read follow the new wording.
- `runRemoteCollectorDescendantProbe` gains `cmd.Dir = executionSubstrateRepoRoot`. Without that line, `TestImportersNameRepositoryPathsFromTheRoot` fails and names the line (checked in a copy, `validation-700b533/layout-guard-without-dir.txt`).

Checks:

- Gate self-test as `ci`: 132 of 132.
- CI root step emulated as root, with package `execution-substrate/scripts`: "tests as root passed: 5 of execution-substrate/scripts".
- `go vet ./...` for linux/amd64 and darwin/arm64: clean.
- `gofmt -l` on the 8 changed Go files: clean.

## 6. The test-only commit `4f55003`

The writer found that `AnchorProcess` checked the order "close what was inherited, then report ready" with a race. The probe read the ready byte, then listed the anchor's descriptors. An anchor that reported first and closed right after could pass. The fix fills the ready pipe before the anchor starts, so the anchor's one-byte write blocks until the probe reads.

The probe then works in this order:

1. It waits for end of input on a pipe whose write end only the anchor still holds.
2. It drains the filler and the byte, and checks that the filler came back whole.
3. Only then does it list the anchor's descriptors.

I read the diff (`git diff 700b533 4f55003`), and it is sound. A correct anchor closes before its write blocks, so the end of input comes first. An anchor that reports first still holds the write end while its byte waits, so the 20 s bound ends the wait and the case fails. The write end is blocking in the anchor, because the probe sets it back to blocking before the fork. The old checks of the descriptor list and of the anchor being alive stay, now after the byte. The change only strengthens the test, and no other file changed.

Runs on `4f55003` (`validation-4f55003/`):

| Check | Result |
|---|---|
| `AnchorProcess` with `-test.count=30` | 30 of 30 pass as `ci`, 30 of 30 as root |
| The writer's N07 (the anchor reports ready before it closes what it inherited), applied to `4f55003`, `AnchorProcess` with `-test.count=5` | fails 5 of 5 as `ci` and 5 of 5 as root, each time on the order case: `(False, 65536, 65537, b'r', …)`, which means the inherited end was still open while the byte waited |
| Root-collector selection as `ci` | only the 7 baseline failures |
| Every ChildNamespace test as root | 12 of 12 pass |
| CI root step emulated as root | "tests as root passed: 5 of execution-substrate/scripts" |
| `go vet ./scripts/` for linux/amd64 and darwin/arm64; `gofmt -l scripts/` | clean |

## 7. The writer's section 5: an acceptable boundary, not a compromise

The question is whether the drain should be hardened for the two cases where neither the process limit nor the parent-death signal binds: a root SSH target, which section 9 allows, and the root command of the fixed `sudo -n` path. My answer is no, for four reasons.

1. **Every case needs an attacker who already holds root.** A waiting shape (a chain of 45 or more, a herd of about 11,000, or a backlog relay) has to be built on purpose. Neither the fixed commands nor `sudo` builds one. So it needs a changed binary at a root-owned fixed path. Under the `sudo -n` path the collector itself runs that binary as root through the fixed grant. Such an attacker can start processes through host services, write a unit or a cron entry, or kill the collector. Any drain hardening therefore yields nothing an attacker in this class cannot get another way. The process limit and the parent-death signal are worth having for the unprivileged case, because they do bind there, apart from A14-1.
2. **The guarantee that can hold against root does hold.** The result is never success while a descendant lives: the command is a runtime failure and the flag is cleared. RealCrowd (a chain of 80 and a herd of 120 with the limit off) tests exactly that, and all of the red-team's runs agree.
3. **For `sudo -n`, nothing short of a root-side runner could end a root descendant.** Audit 05 rejected that runner, because it needs a host sudo grant for a general process launcher. That decision stands.
4. **Hardening would cost safety for no gain.** Whole-tree kills per round would signal processes that are not the collector's children. With a root collector, a wrong kill reaches any process on the host. The writer says this reopens the PID-reuse question. Strictly, pidfds could answer that question. But that is a sizeable new mechanism, built for an attacker it cannot stop. A PID namespace for a root target, as the root collector uses, raises the bar only to "use a host service", which the root collector's documents already concede.

The documents state the limit precisely, apart from A14-1:

- the bound line;
- root and set-user-ID exec;
- the three waiting shapes by name;
- "no command returns success while a descendant still lives";
- §9's "neither the process limit nor the parent-death request binds it".

The red-team's quoted sentence is gone, and it is pinned absent. I see no "revisit later" here: the open question for the box, whether any SSH target is root, changes no decision.

## 8. Tests and mutants

| Check | Result |
|---|---|
| `go test -count=1 . ./scripts/ ./internal/testutil/` as `ci` | Root 343 results pass, testutil 6, scripts 1,707 pass, 5 skip (the five `skips-itself` lines), 235 fail. Compared by test name with my `eed4c9b` run (#39 moved packages): 2,278 shared names, **no verdict changed**. 16 new names pass, plus RealSiblings and RealDeafAnchor, which skip as `ci`. The 235 failures are this container's (no SSH client and others): the same names as at `eed4c9b`. The writer's container fails only 8 |
| Both families as root (ChildNamespace, NoninteractiveDescendant) | 21 pass, 1 skip (RealProcessLimit, as stated); the writer's result |
| Both families as `ci` | 17 pass, 5 skip (the real namespace tests, each with the reason "the kernel refuses a new PID namespace to this process: EPERM") |
| Root-collector and remote-collector selections as `ci` (mutant baseline) | only the 7 and 11 baseline failures, the same names as in audit 11 |

**Regression proof** (new tests against the `eed4c9b` collectors):

- Root collector, as root: RealSiblings is held for its 40 s bound and fails. RealDeafAnchor, RealDescendants, End, Sequence, Probe, FixedCommand, AnchorProcess and DocumentsContract fail too; many of these failures come from the stand-in, which now has `end` and no `release`. RealKernel and RealCollectorDeath pass; the latter accepts an anchor that ends by end of input.
- Remote collector: RealCollectorDeath, RealProcessLimit, RunCommand and DocumentsContract fail; RealCrowd passes.

**My mutants** (each in a fresh clone of `700b533`; root collector: its selection as `ci` plus every ChildNamespace test as root; remote collector: its selection as `ci` plus the descendant family as root):

| Mutant | Change | Caught as `ci` by | Also as root by |
|---|---|---|---|
| X01 | strays waited for with a blocking `waitpid` | End, DocumentsContract | none |
| X02 | the anchor writes its ready byte before its parent-death request | DocumentsContract (anchor pin) | none |
| X05 | `end()` does not keep the fixed child, so it reaps it | End, DocumentsContract | RealDescendants (held to its 120 s bound), RealSiblings (40 s) |
| X06 | `close()` keeps nothing, so it reaps the anchor as a stray | Sequence, AnchorWait, End, Probe, DocumentsContract | all five real namespace tests |
| X08 | anchor's parent-death signal is TERM | AnchorProcess, DocumentsContract | RealDeafAnchor (20.6 s) |
| X13 | `end()` sends the anchor TERM | End, DocumentsContract | RealDeafAnchor (16.6 s) |
| X21 | `close()` leaves the ready pipe open | Sequence, Probe | none |
| X26 | `end()` returns after one list, strays or not | End, DocumentsContract | RealSiblings (20.3 s) |
| X27 | `open()` reads the ready byte before closing its own pipe ends | Sequence, Probe, DocumentsContract | none |
| X29 | `end()` lists without waiting for the fixed child (= the writer's N16) | End, DocumentsContract | none |
| Y03 | process limit set before the parent check | DocumentsContract (order pin) | none |
| Y09 | the remote fixed child's parent-death signal is TERM | DocumentsContract (pin) | none |
| Y28 | setup failure reported as "unavailable" (127) (= the writer's R34) | RunCommand | none |
| Y30 | process limit 1 instead of 0 | DocumentsContract (pin) | none |

14 of 14 caught.

- Y30 is behaviourally equivalent. The fixed child counts against its own limit, so 1 refuses a fork just like 0. The pin keeps the exact value.
- X02 and Y03 each change a window between fork and `prctl` that no test can hit on purpose; the writer's R33 is the same case. The pins catch them.
- Y09 is different, see O14-1.

I read the writer's 27 mutant definitions (`mut13-apply.py`). They are real changes of the repaired lines, and `mut13.txt` reports each one caught as `ci` and as root. I did not rerun them. My X29 is the writer's N16 and my Y28 is the writer's R34; I ran both anyway.

## 9. Finding

### A14-1 (Low, documentation): a changed binary can undo the remote fixed child's parent-death request

`.docs/remote_alpha_operator_healthcheck_noninteractive_status.md` §8 says the kernel refuses an unprivileged fixed child every new process and thread, "so it can have no descendant, and a collector that is killed takes it along". `PLANS.md` (P0v paragraph) says the same: "so that an unprivileged fixed child can start no process or thread and dies with a killed collector".

The first half holds. The second half holds only for a program that leaves the request alone. The request is set before the exec, in the fixed child, so the program that runs afterwards can undo it with one `prctl(PR_SET_PDEATHSIG, 0)`. Measured at `700b533`: such a child is alive 1 s after the collector was killed (`probes/pdz.txt`). The same document's limits paragraph says "these rules matter only for a changed binary on the host", and that is exactly the case where this sentence does not hold. The stated limits name root and the set-user-ID exec, but not this.

Effect: one process of the SSH user, which still cannot start any other, outlives a killed collector. No false result follows, and the drain on a living collector is unaffected. It is not fixable in code without breaking the sudo path. A seccomp filter would need `no_new_privs`, which disables the set-user-ID `sudo`.

The root collector does not have this gap: its parent-death request sits in the anchor's fixed code, and undoing it needs `ptrace`, which its documents state.

Fix in this PR, documentation only:

- In §8, replace "and a collector that is killed takes it along" with "and a collector that is killed takes it along unless the program itself undoes that request".
- Add one sentence to the limits paragraph: "The fixed child's program can undo its own parent-death request; a changed binary that does so outlives a killed collector, as one process that the process limit still keeps from starting any other."
- Change PLANS.md P0v to match.
- Pin the new limit sentence in the descendant DocumentsContract.

### O14-1 (observation, optional): RealCollectorDeath could require KILL by behaviour

Y09 (the remote fixed child's parent-death signal is TERM instead of KILL) is caught only by the text pin. The test's stand-in dies of TERM as well. A stand-in that ignores TERM would make the test itself require KILL, as the anchor's RealDeafAnchor does for X08. The pin already holds the line, so this is optional. It would cost one line in the stand-in.

## 10. Not covered

- The box and the Mac.
- Variant c of RT12-2 by hand; the red-team re-check covers it.
- The full module suite.
- Repeating the writer's sudo check (section 4).
- The writer's variant c grid and box rehearsal (`13a-validation.md` sections 4 and 5). I read them; they agree with my results, and the red-team re-check repeats variant c.

## Evidence

`14-re-audit-evidence/` (SHA256SUMS inside):

- `provenance-700b533-open/`, `provenance-4f55003-open/` and `provenance-4f55003-close/`
- `review/`:
  - `merge-check.txt`: the merge re-creations, the diff hashes, and the trunk_dev overlap and trial merge
  - `merge-resolution-700b533.diff`
  - `test-commit-4f55003.diff`
- `probes/`: `sib3.txt`, `hold-700b533.txt`, `pdz.txt`
- `validation-700b533/`:
  - steps log, root step, gate self-test, vet, gofmt, and the layout guard check
  - package summary, table and JSON, the comparison with my `eed4c9b` run, and that baseline table
  - both family runs
- `validation-4f55003/`: steps log, sync, `AnchorProcess` 30 times each way, N07 both ways, the root family, root step, vet, gofmt
- `mutants/`: the logs, the root-run outputs, `summary.tsv`, and the `go test -json` streams (tar)
- `scripts/`: the provenance, validation and mutant runners, `mutate33.py`, and the probes

STATUS: READY
