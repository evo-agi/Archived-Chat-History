# REPAIR: audit 07 findings on PR #30 (T7-1, T7-2, T7-3)

**All three Low findings of audit 07 are fixed in one new commit, `0b8b9c0`, pushed on top of `e3dce37` as a fast-forward. T7-1 follows the coordinator's decision (option a): when the fixed child has ended and its output is complete, the root collector ends the namespace before the cleanup owner runs. A new real test reproduces the T7-1 hold, and it fails on the old order. T7-2 and T7-3 gained tests, and the auditor's surviving mutants A19 and B20 are now caught. Next: a narrow re-audit of `e3dce37..0b8b9c0` by the same auditor (provenance covers the whole base-to-tip range), then the red-team, and one Mac and box run that David approves with a single "go ahead" (brief: `08-mac-and-box-brief.md`).**

Written 2026-11-23 by the writer thread "Contain TLS status collector child processes". Earlier reports in this folder: 01 to 07.

## 1. Identity

| Item | Value |
|---|---|
| Repository | `evo-agi/Execution-Substrate`, draft PR [#30](https://github.com/evo-agi/Execution-Substrate/pull/30) |
| Base | `trunk_dev` `036d50724b499b020c5149c55ad902cfcb1482c0` (unchanged since report 06) |
| Topic branch | `claude/project-thread-wbmulu` |
| Previous head (audited in 07) | `e3dce375eda8208a6dfcd8d3ea754d4ab11436ec` |
| New head | `0b8b9c034f1b65c938e24e7edc6f07f66b9dab94` (one commit on top, fast-forward push) |
| Tree | `1b6457746bc6aac57a60cf6819f97a6ce78fad94` |
| Recipe | `governed-execution.audit-patch-manifest.v2`, source SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca` (checked before the run) |
| Textual diff SHA-256 | `824d6d174e91bc3e2407a4bf13fd446117a3590679bdb5a72749ec277e48e3d2` |
| Canonical manifest SHA-256 | `bdcec349e996375fadb3e2fe0b22d00fca9a88cceeaf4c491eb38574d26ecffe` |
| File count | 19 (the same path set as `e3dce37`) |

Repair flow of the protocol: TIP recorded, `git reset --mixed` to the base, upstream pinned to `origin/trunk_dev`, the manifest taken twice to a fresh 0700 directory (byte-identical), `git reset --mixed` back to TIP, then add, commit and push. After the commit, `git diff --name-only BASE HEAD` equals the manifest path set, every committed blob matches the manifest's SHA-256 and size, and `git status --porcelain` is empty. The complete manifest is in `08-evidence/manifest-v2.json`.

## 2. What changed in `e3dce37..0b8b9c0` (7 files)

**Root collector** (`scripts/internal/remote_alpha_es_tls_status.py`, 7 lines). On the normal-completion path of `_run_fixed_in_namespace`, `namespace.release()` now runs right before `own_child_until_proved(proc)`. At that point the read loop has ended, which needs both an empty selector (stdout and stderr at end of input, stdin and the trust-anchor pipe written) and `leader_terminal(proc)`. Nothing else changed:

- The failure paths (timeout, interruption, output overflow, any exception after the spawn) still run the cleanup first and end the namespace in `close()`.
- The process-group logic (`terminate_child`, `own_child_until_proved`, the hold, the reap and the absence scan) is unchanged.
- `close()` calls `release()` again, which does nothing once the pipe is closed. A failed release sets `release_failed` and `unproved`, so `close()` kills the anchor at once and the command is incomplete through `child_namespace_unproved`. This was already the behaviour of `close()`.

What this changes in behaviour, on the normal path only: a process that outlived the fixed child is killed by the kernel when the anchor ends, without a TERM first. The fixed child is already terminal and its output is complete, so the result cannot change. The fixed child's own status is read after the cleanup's reap, as before.

**Decision D4, amended.** D4 keeps the process-group logic untouched, and it still does. What changes is the order of step 6 of the rule: the documented sentence "Only after they return does the collector close the control pipe" now holds only for the paths where the fixed child may still run. Reason: a descendant that left the group can keep a child of its own in the fixed child's group and leave it unreaped. Once that child has ended, its zombie is no orphan, so the anchor cannot reap it, and no group signal can end it. The unchanged cleanup then waits until the descendant ends by itself, which may be never. With the pipe closed first, the kernel kills the descendant, the zombie goes to the anchor, which reaps it, and the cleanup finds the fixed child alone. The three documents (`PLANS.md`, `.docs/system_overview/remote_supported_host_alpha.md` step 6, `.docs/system_overview/remote_alpha_access_contract.md`) now state the new order, the reason, and the remaining limit.

**Remaining limit, stated in all three documents.** On a path where the fixed child may still run, the cleanup still runs before the namespace ends, so the same hold stays possible there. Removing it would mean ending the namespace inside the unbounded part of `terminate_child` (audit option b), which changes the group logic and so reopens D4. This is the coordinator's decision of 17:43Z, not a shortcut taken here.

**Tests:**

- `remote_alpha_es_service_tls_status_child_namespace_test.go`:
  - FixedCommand: the recorder has `release`. The good path must be open, spawn, restore, release, cleanup, close. The release must come only after the fixed child is terminal (checked with `waitid_terminal` inside `release`). The overflow path and a new timeout path (a fixed child that is still running) must clean up before anything is released. A failed release leaves the result to the end of the namespace.
  - Sequence (deterministic backend): a release before `close()` closes the control pipe once, and `close()` then only waits for the anchor. A failed release before `close()` is unproved, and `close()` kills the anchor at once.
  - AnchorProcess (T7-2): after fifty poll periods (1 s) without the end of its input, the anchor must still be waiting.
  - RealDescendants (root): new fixture modes. In `zombie` and `qalive` the descendant starts a child in the fixed child's group, leaves the group with `setsid`, ignores TERM and HUP, and does not reap that child. It would end by itself only after 15 s, and only then would it report `lapsed`. The command must return with `(0, b'fixed', b'')`, nothing left, no `lapsed`, and in less than 15 s. Mode `slow` (T7-2) writes its output after one second and must return it. A new control shows that without the namespace the same `zombie` case holds the cleanup until the descendant ends by itself.
  - DocumentsContract: new phrases for the order, the reason and the limit in the three documents. The source must hold `namespace.release()` exactly once in the fixed-command body, directly before the cleanup owner on the normal path.
- `remote_alpha_es_service_tls_status_test.go`: the shared stand-in has `release` (returns True and does nothing).
- `remote_alpha_operator_healthcheck_tls_status_noninteractive_descendants_test.go` (T7-3):
  - The model's grandchild now ends by itself when the probe closes the hold pipe's write end, as the real one does.
  - Probe: the kill of the grandchild must come before `close(hold_write)`. After a failed probe the hold pipe closes first, and the grandchild is reaped without a signal (the code's own comment says so).
  - RealKernel: the real probe runs once more through a recording wrapper of the real kernel operations. The grandchild must be killed while the hold pipe is still open, and its reaped status must be SIGKILL.

## 3. Validation (cloud container: kernel 6.18.44, Python 3.13, Go 1.26.5, test user `ci` with UID 1500)

| Check | Result |
|---|---|
| New mutants (`08-evidence/new-mutants.*`), unprivileged and as root | **OLD-ORDER** (release removed, so the old order): caught by FixedCommand and DocumentsContract, and as root by RealDescendants, where both new hold cases returned only after 15.06 s, exactly when the descendant ended by itself. **RELEASE-BEFORE-TERMINAL** (release before the read loop): caught by FixedCommand and DocumentsContract, and as root by RealDescendants (`(-9, b'', b'')`) and RealCollectorDeath. **A19** (auditor's, anchor ends after 0.3 s): caught by AnchorProcess unprivileged and as root, and by the `slow` case as root (`(-9, b'', b'')`). **B20** (auditor's, probe closes the hold pipe before the drain): caught by Probe and RealKernel, unprivileged. |
| Earlier mutants, re-run on the new head (harnesses of report 06, collector bytes of `0b8b9c0`) | Root collector 26 of 26 caught, unprivileged and as root; M06 and M14 by the test timeout (`08-evidence/earlier-root-mutants-rerun.txt`). Remote collector 22 of 22 caught, unprivileged (`08-evidence/earlier-remote-mutants-rerun.txt`). |
| Whole root package as `ci`, `go test -count=1 .`, on the final tree `1b64577` | 480 pass, 8 fail, 3 skip; the same sets as at `e3dce37` (see the correction below; `08-evidence/whole-package-summary.txt`) |
| Docs, contract and namespace tests on the final tree (after two wording edits in the docs) | 144 pass, 3 skip (the three `skips-itself` tests), none fail |
| `go_test_gate_selftest.py` as `ci` | 132 of 132 (`08-evidence/gate-selftest.txt`) |
| `go_test_as_root.py` (the CI root step) as `ci` through sudo | 3 of 3 pass (`08-evidence/root-step.txt`) |
| `go vet ./...`, linux/amd64 and darwin/arm64 | clean |
| Box probe script (`08-evidence/pr30_box_probe.py.txt`), tried here | root part: probe accepted, `openssl version` returns 0 in its own namespace, `setsid` 0.03 s, `zombie` 0.04 s, `slow` 1.02 s, each `(0, b'fixed', b'')` with nothing left; R2 part as `ci` in the real launch shape: probe accepted, drain left nothing |

| GitHub CI on `0b8b9c0` | "build, vet and test" succeeded, run [45234732069](https://github.com/evo-agi/Execution-Substrate/actions/runs/45234732069), including the root step |

Not run: the Remote Alpha host and macOS (section 5).

**Correction to report 06 and the PR text.** They said the 8 failures and 3 skips "are exactly the root-package lines of `environment-only-tests.txt`". Precisely: the 8 failures are 8 of the 11 root-package entries of that file. The other 3 entries, the `TestRemoteAlphaRuntimeSecurityBoundary…` checks, fail only on the runner and pass in this container. The 3 skips are the file's 3 `skips-itself` lines. The result is the same at `e3dce37` and at `0b8b9c0`.

## 4. For the narrow re-audit

Target: `e3dce37..0b8b9c0`, with provenance over `036d507..0b8b9c0` (manifest above). Points worth a look:

1. The release on the normal path comes after `leader_terminal(proc)` and an empty selector. The fixed child is the collector's unreaped child (WNOWAIT), so its PID and PGID stay reserved while the namespace dies. The group signals of the unchanged cleanup cannot reach anything outside the namespace, because no process can join the fixed child's session or group from outside it.
2. While the anchor ends, it reaps its own children and the orphans the kernel gives it. The anchor itself becomes terminal only after the cleanup has reaped the fixed child; `close()` then reaps it. The real tests and the auditor's prototype show this. The kernel text is `zap_pid_ns_processes`, not re-read here.
3. A release that fails on the normal path is reported only by `close()`. The cleanup still runs fully before it.
4. The failure-path hold is a stated limit (section 2). The decision on it is the coordinator's.
5. Observations O7-1 and O7-2 of audit 07 are unchanged by this commit.

## 5. Mac and box run

`08-mac-and-box-brief.md` holds the full instructions for one Remote Control session on David's Mac. It runs the collectors' tests at `0b8b9c0` on the Mac. Then, through `ssh [test box name withheld]`, it runs on the box:

- the root collector's whole capability probe, as root through `sudo -n`, the way the operator route starts it;
- one real `openssl version` and three stand-in fixed commands in their own PID namespace, one of them the T7-1 case;
- the R2 probe and one drain, as the SSH user in the real launch shape;
- the `sudo -n` pseudo-terminal check;
- `pidfd_answers.py`, as the SSH user and as root.

It touches no service and removes both temporary folders. David starts it by writing "go ahead" in this thread. About 20 to 25 minutes.

## 6. Envelope

- Effect status: `PUSHED claude/project-thread-wbmulu 0b8b9c0` (fast-forward, no force) | `PR_OPEN_DRAFT`.
- Confidence:
  - The new order removes the T7-1 hold on the normal path: 0.95 (real test with control, old-order mutant held until the descendant's own end).
  - Nothing else changed in behaviour except the missing TERM for processes that outlive a completed fixed child: 0.9 (code reading, full package, mutants).
  - Both collectors behave the same on the Remote Alpha host: Unknown until the box run.
