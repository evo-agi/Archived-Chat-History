**Diff check of PR #49's repair (c342535): the code is accepted.** All three findings from my audit are fixed.
- The Vault reset now goes through a descriptor that follows no links. My reproduction is refused before anything moves.
- The migration no longer makes a folder writable for the Vault account when it could only read it.
- My four tests are in unchanged, plus two from the writer.

Two small gaps are left, both in tests only:
- Nothing checks the reset's owner check at the moment of the move.
- Nothing checks that the reset tells the operator where the old data went when a race hits it.

I sent the writer the two exact additions, which I ran. If they go in unchanged, I only need to confirm the bytes match.

The manifest matched the writer's, and the merge with the current trunk_dev is clean. CI passed on the previous head and was still running on c342535.

STATUS: PR #49 code ACCEPT; two test-only additions pending. Read-only, nothing pushed.
