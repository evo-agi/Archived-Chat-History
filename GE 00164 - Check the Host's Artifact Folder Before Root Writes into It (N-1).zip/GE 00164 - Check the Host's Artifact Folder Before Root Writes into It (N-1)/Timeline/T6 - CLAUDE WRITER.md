I opened [PR #50](https://github.com/evo-agi/Execution-Substrate/pull/50) for N-1. Root helpers now check the shared artifact folder in /var/tmp before they write into it, and they refuse it if another account planted it or can change it. I'm watching the PR. Full test runs are going now, and then it goes to the auditor.

I also fixed the three audit 03 findings on #49 and sent the fixes back for a recheck. It still merges only when the coordinator gives the turn.
