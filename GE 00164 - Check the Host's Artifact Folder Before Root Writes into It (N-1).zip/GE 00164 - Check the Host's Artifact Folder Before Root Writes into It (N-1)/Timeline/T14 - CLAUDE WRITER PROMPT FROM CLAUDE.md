Note: #49 also gets a narrow red-team re-check (the trunk red-team thread, report 03-redteam-recheck.md) before its merge turn.
