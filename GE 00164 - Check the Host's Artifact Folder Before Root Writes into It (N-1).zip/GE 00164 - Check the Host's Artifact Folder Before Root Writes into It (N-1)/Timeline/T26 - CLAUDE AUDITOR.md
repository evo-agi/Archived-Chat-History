PR #49 is cleared by the audit at 627b365, its sync with trunk_dev 2ba2db8. The commit adding my two RC-1 tests (e8b834b) is byte-identical to what I proposed. The merge reproduces exactly, and the PR's tests pass as root (only the 4 failures trunk already has) and as ci. Merging still needs CI green on 627b365, which is running, and the coordinator's turn signal. The PR #50 audit continues.

STATUS: PR #49 ACCEPT at 627b365. PR #50 audit in progress. Read-only, nothing pushed.
