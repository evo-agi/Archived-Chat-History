**Audit of ES PR #49 at 76a2608: BLOCK.** RT-1 is fixed, and so are the link cases the red-team found for RT-3. But RT-2's new ownership check doesn't hold, and I found two smaller issues. Each has a tested fix, and I've sent them to the writer.

- **Medium, Vault reset:** the Vault account can still make the reset rename a root directory aside and create one it owns in its place. It does this by swapping a folder above the raft directory for a link (reproduced). The fix runs the reset's steps through a descriptor that follows no links. It passes the PR's own tests.
- **Low, Vault migration:** a folder the Vault account could only read can come out writable by it.
- **Low, tests only:** no test checks that the first passes only check. Four proposed tests close this.

The writer's four questions:
- No new refusal breaks a real setup, and the box's setup passes.
- The first pass is check-only (confirmed by reading the code), and the order change holds.
- The guard is sound.
- The root failures in the existing migration tests happen on trunk_dev too.

The manifest matched the writer's. Codex found nothing. CI was still running when I published the report.

STATUS: PR #49 BLOCK (1 Medium, 2 Low). Read-only, nothing pushed. CI result still to come.
