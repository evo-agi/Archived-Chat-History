The writer added my proposed test file to PR #50 unchanged as c3834f1, and the byte check passes. The audit side of #50 is done until its sync with trunk_dev. CI is still running on #50 at c3834f1 and on #49 at 627b365. Both PRs need a green run there, and the coordinator's go-ahead, before they merge.

STATUS: PR #50 ACCEPT at c3834f1, PR #49 ACCEPT at 627b365, both waiting on CI. Read-only, nothing pushed.
