# ES PR #49: fixes for whole-trunk red-team RT-1, RT-2 and RT-3 (audit, report 03)

```
Target:    evo-agi/Execution-Substrate PR #49, head 76a260886688c91d99862127cd3a525bbebdb8c3,
           base trunk_dev 5d6ad513add57a3bd69e8956c32090e343d4f82d (one commit, 7 files)
Asked by:  the PR's writer thread, 2026-11-24 06:12Z
Posture:   independent auditor thread; read-only on the repo; nothing pushed, no PR comment;
           nothing run on the Linux box. Everything ran in one cloud container, as real root
           with throwaway accounts (rtvault 996:995, nobody 65534) and as the unprivileged
           account ci (1500:1600).
Verdict:   BLOCK. 1 Medium, 2 Low (one of them test-only). RT-1 is fixed. RT-3 is fixed
           against the links the red-team described. RT-2's link race is fixed, but the new
           ownership check doesn't hold: the Vault account can still make the reset rename and
           recreate a root directory (reproduced). Each finding comes with a tested fix.
```

Labels: **Ran** (I executed it and saw the result), **Read** (from code or a report),
**Inference**, **Unknown**.

## 1. Findings

| ID | Severity | Where | What |
|---|---|---|---|
| A03-1 | **Medium** | `scripts/remote_alpha_reset_disposable_vault.sh` `require_vault_owned_raft_dir`, `replace_raft_directory` | Every step acts on the raft path by name, and every directory in that path is followed. The Vault account picks the raft path and owns the folders below `/opt/vault`. After the ownership check passes, it swaps a folder above the raft directory for a link. Root then renames a root directory aside and creates a Vault-owned one in its place. Ran. |
| A03-2 | Low | `scripts/internal/remote_alpha_migrate_vault_service_user.sh` `dedicated_directory_problem` | The "dedicated to Vault" rule accepts a directory owned by the Vault **group** for targets the apply hands to the Vault **user**: log and audit parents, and storage. A `root:vault 0750` directory, which the Vault account can only read, comes out `vault:vault 0750`, so the account can now write it. Ran. |
| A03-3 | Low (tests only) | `scripts/remote_alpha_root_service_paths_test.go` | No test can tell whether the first pass only checks. Four mutants survive: RT-1 without its check-only walk, and RT-3 with the check pass changing the config or TLS parent, the storage directories or the log parent. The existing assertions can't see either. Ran. |

### A03-1 (Medium): the reset still follows a link the Vault account plants above the raft directory

**Code (Read).** `require_vault_owned_raft_dir` checks the raft path with `sudo test -L`,
`sudo test -d` and `sudo stat -c %U`, before the confirmation. `replace_raft_directory` then runs
`sudo mv -T -- "${VAULT_RAFT_PATH}" "${backup_path}"`, `sudo mkdir -m 0700 --
"${VAULT_RAFT_PATH}"`, `sudo chown -h -- …` and a final `sudo test -L / -d`. `mv -T`, `mkdir`
and `chown -h` handle only the **last** part of the path. Every directory above it is resolved
again on each command, and a link there is followed.

**Why the Vault account can do it.** It chooses the raft path: the reset reads it from `vault.hcl`,
in `/etc/vault.d`, and on the box that directory is `vault:vault 755` (Read: inventory of
2026-11-23 in `infra-security-audit/`). The writer's report notes it stays that way until the
migration's apply runs. The account also owns everything below `/opt/vault`. So it can point the
raft path at `/opt/vault/x/<name>`, where `x` and `<name>` are its own directories, and the
ownership check passes. While the operator reads the confirmation prompt, the still-running Vault
swaps `x` for a link to a root directory that holds an entry called `<name>`. A surviving process
isn't needed: the swap happens before the stop, so the `pgrep` check can't see it.

**Reproduction (Ran, `probes/rt2_intermediate_swap.sh.txt` → `probes/rt2-intermediate-swap-76a2608.out`).**
The probe sources the PR's script with a stand-in `sudo` and `systemctl`, as the PR's own tests do. It uses a real
`rtvault` account and real root, a raft path `…/opt/vault/x/system`, and a victim `…/etc/systemd/system` (root:root 755):

```
pre-confirmation checks: passed
replace_raft_directory exit: 0
after:
rtvault:rtvault 700 …/etc/systemd/system
root:root 755 …/etc/systemd/system.remote-alpha-reset-backup-TEST
```

The final link check passes, because the new directory is real and only the path above it
went through a link. Inference: on the box, a raft path ending in `system` gives the Vault
account a new, empty `/etc/systemd/system` it owns, and moves the real one aside. Unit files it
writes there run as root at the next daemon reload. A path ending in `bin` does the same to
`/usr/local/bin`. The confirmation prompt prints the raft path, so an attentive operator could
notice `/opt/vault/x/system`.

**Severity.** Medium, the same as RT-2: it needs a compromised Vault account and an operator who
runs the rare interactive reset. It isn't a regression, because trunk had no ownership check at
all and the account could name `/usr/local/bin` directly. But the PR states this as closed: the
script comment ("moving and recreating it then gives that account nothing it did not own
before"), the writer's report (section "Beyond", item 3), and the P0m stop conditions in the docs.
Those claims don't hold.

**Second gap in the same lines (Ran, `probes/rt2-hardlink-note.out`).** `chown -h` doesn't follow
a symbolic link, but a hard link is the file itself. If the account replaces root's new empty
directory with a hard link to a root file between the `mkdir` and the `chown -h`, root gives that
file to vault. Only `fs.protected_hardlinks = 1` stops the account from making that link. That is
the Ubuntu default (here: 1, and the vault account got `Operation not permitted`), but the box's
value is Unknown.

**Fix (tested; `proposed/rt2-proposed.diff`, sha256 7188e096…6025, 81 lines).** Do the move and
the recreation in one `sudo python3 -I` step that works through the raft directory's parent:
- reach the parent from `/` one directory at a time, with `O_DIRECTORY|O_NOFOLLOW`, refusing any link;
- check the raft entry with `fstatat(AT_SYMLINK_NOFOLLOW)`: a directory of the Vault uid;
- `renameat` it to the backup name;
- `mkdirat` the new directory (an existing name is refused);
- open it with `O_NOFOLLOW` and require that root owns it and that it is empty;
- then `fchown` and `fchmod` 0700.

This is the same pattern RT-1 and RT-3 use in this PR, and it also closes the hard-link gap.

Results with the proposal:
- the swap probe is refused before anything moves: `…/opt/vault/x is not a directory or is a symbolic link; nothing was moved` (`proposed/rt2-intermediate-swap-with-proposal.out`);
- the PR's race test passes (17 of 20 plants), and so do its 4 refusal cases, as root and as ci;
- the only failure is `TestRemoteAlphaResetDisposableVaultStaticSafety`, which pins the old literal `mv -T`, `mkdir` and `chown -h` lines and needs updating with the change.

The source guard's RT-2 rule becomes "no by-name owner change in the reset". The docs' P0m line,
which still describes `mv -T`, `mkdir` and `chown -h`, needs the same update.

**Regression test (`proposed/proposed_rt2_link_above_raft_test.go.txt`).** It builds the
reproduction above, with the victim holding a unit file, and requires a refusal with the victim
directory and its file unchanged. It fails on 76a2608 as root and as ci, because the victim is
moved aside and recreated empty. It passes with the proposal both ways. It doesn't skip as an
ordinary user, so CI's skip gate is unaffected.

Smaller points for the same change:
- Run `pgrep` through `sudo`. A `/proc` mounted with `hidepid` would hide other users' processes from the operator.
- A vault-uid process can also start after the check (cron, `at`, or a lingering user manager). With the descriptor step that no longer matters, so the `pgrep` check stays as defence in depth only. Inference.

### A03-2 (Low): a directory the Vault account can only read can become writable by it

`dedicated_directory_problem` accepts a directory when `uid == vault uid` **or**
`gid == vault gid`. That is right for config and TLS parents, which the apply makes
`root:vault 0750`: the account gains nothing. Log and audit parents, the storage directory, and
the storage parent fallback are different, because the apply makes them `vault:vault`. A
`root:vault 0750` directory, which the account can read but not change, then becomes one it can
write.

**Ran (`probes/rt3-group-only-dir-76a2608.out`):** the PR's own fixture as root (vault account
65534). The config names `log_file` in a `0:65534 0750` directory that holds a root-written file:

```
directory before: 0:65534 750
directory after:  65534:65534 750
apply err=<nil> ok=true
```

The rule's purpose is that the account can only point root at directories it already controls.
This case breaks that. **Impact:** Unknown on the box. It matters only if a `root:vault`
directory holds something root or another service trusts, and only before `/etc/vault.d` is
locked. A directory the account can't change today should not be handed to it.

**Fix (tested candidate; `proposed/rt3-writable-candidate.diff`, sha256 dd09614a…6cdbf, 92
lines).** Add a "becomes writable by Vault" flag to the rule, set for log and audit parents and
for storage (own directory and parent fallback), in both the plan and the apply. For those, accept
only a directory the Vault user owns, or one the Vault group owns with group write. The candidate
passes:
- the regression test below;
- every RT-3 test as root;
- the whole migration set (28 tests) as ci with a second group (`proposed/rt3-candidate-*.log`).

The box's known layout is unaffected: `/opt/vault/raft` belongs to the Vault user, and the log
and audit settings are Unknown. **Regression test (`proposed/proposed_rt3_group_only_dir_test.go.txt`):**
it fails on 76a2608 as root. As an ordinary user it only logs, because no unprivileged account can
build a directory it can read but not write. It does not skip, so CI's gate is unaffected.

### A03-3 (Low, tests only): nothing shows that the first pass only checks

The design promise is "a refused tree or plan is left unchanged" (RT-1 docs invariant, RT-3
summary text). The writer asked me to check that the first pass stays check-only (point 2).
**By reading it does:**
- every `fchown`, `fchmod` and `mkdir` in the RT-1 walk and the RT-3 helpers runs only on the change pass (owner `None`, or `if apply:`);
- RT-1's root and blob `fchmod` come only after both walks.

But no test fails when that breaks:
- **A1** removes RT-1's check walk. The refusal fixtures are already owned by the service account, and modes are set only after the walks, so nothing changes visibly.
- **C1b, C1c, C1d** make the RT-3 check pass change the config and TLS parents, the storage directories or the log parent. The planted-link test checks only the victim, the foreign directory, the drop-in and the restart.
- The guard test only looks for the literal text `for apply in (False, True):`.

**Proposed tests (each fails on its mutants and passes on 76a2608, as root and as ci with a
second group):**
- `proposed/proposed_rt1_first_walk_test.go.txt`: a first run on a tree the running user owns, with a named pipe sorted after `sha256/`. After the refusal every owner must be unchanged. It kills A1.
- `proposed/proposed_rt3_check_pass_test.go.txt`: storage files start with another owner, and the audit directory, the last target, is a link. After a refusal that says "no path was changed", every earlier target path must be unchanged. It kills C1b, C1c and C1d (`proposed/rt3-check-pass-test-vs-mutants.txt`).

As an ordinary user, both tests hand owners to a second supplementary group, the way the SPIRE
helper test from audit 17 does. GitHub's runner account has several groups. Inference: if an
account has only one group, the tests check only the refusal and log that, without skipping.

## 2. The writer's four questions

**(1) Does the "dedicated to Vault" rule refuse a real layout it shouldn't?** It refuses no real
layout I can find. The one hole goes the other way (A03-2).
- **Box (Read, inventory 2026-11-23):**
  - `/etc/vault.d` is vault:vault 755 and `vault.hcl` root:vault 640;
  - `/opt/vault` is vault:vault 755, and `/opt/vault/raft` and `/opt/vault/tls` are vault:vault 700;
  - this passes: config and TLS parents become root:vault 0750, and storage stays vault-owned and becomes 0750, as before.
- **HashiCorp package defaults** (`/etc/vault.d`, `/opt/vault/data` and `/opt/vault/tls`, all vault-owned) pass.
- **Refused, and rightly** (the old apply would have re-owned a shared directory):
  - a log file in `/var/log`;
  - a TLS file in `/etc/ssl/certs` or `/etc/ssl/private`, or in the ES TLS directory;
  - a log file next to the config;
  - a TLS file inside the storage tree.
- **Refused, with friction only:**
  - a config or TLS directory an admin locked to `root:root`; the message gives the one-line fix (`chgrp vault`);
  - a storage directory to be created under a shared parent such as `/opt`.

**(2) Is the first pass check-only, and does the order change hold?** By reading, yes (see A03-3);
the gap is in the tests. The path changes run before `run_install_dropin`, and mutant C2, which
reverses the order, is killed by the drop-in check. A refusal in the first pass leaves the unit
as it was. There is no path rollback. The apply records stat observations in
`snapshot-manifest.json`, and the second-pass message points the operator there.

**(3) Is the source guard sound?** It is sound for what it covers.
- The counts work in both directions: a rise fails, and so does a fall without the table changing.
- The strict checks on the three fixed steps kill A4 (the `st_nlink != 1` text) and B4 (`chown` without `-h`).

Its limits, none of which blocks this PR (Info):
- It counts only `chown`, `chmod` and `install -d`, and only in `.sh` files, which includes their inline Python.
- It doesn't count `setfacl`. `remote_alpha_operator.sh` runs 7 `setfacl -m` lines as root by name on the SPIRE socket path and the config path. Today they grant ACLs to `$(id -un)`, the operator, who already has sudo, so they cross no boundary.
- It doesn't count `chgrp` (no uses today) or by-name `mv`, which is the RT-2 class.
- It doesn't scan standalone `.py` files under `scripts/`. Today only a test file there calls `chmod`.

A ratchet also lets a new by-name line replace a removed one at the same count. That is accepted
by design: the table and its comment make the reviewer look.

**(4) Do the existing migration tests fail as root on trunk_dev too?** Yes (Ran). The same 4
tests fail with the same messages on 5d6ad51 and on 76a2608:
- `…CheckOnlyWritesBlockedArtifactWhenNoninteractiveRootUnavailable`
- `…CheckOnlyIsDefaultAndNonMutating`
- `…ApplyRepresentsPostApplyContractFailureHonestly`
- `…ApplyCreatesBackupRollbackAndHonestSkippedSmoke`

As ci, all of them pass on both trees.

## 3. Checks

**Fixes against the red-team (Read and Ran).**

- **RT-1** matches the red-team's tested fix shape.
  - The preflight still pins the paths: `storage.root_dir = /var/lib/execution-substrate/ars/blobs` and `index_file = …/ars/index.json`, so the new direct-child rule holds.
  - The ARS blob layout `sha256/xx/yy` is 4 levels deep, well inside 16.
  - ARS never makes links or special files (Read: `ars/store/filesystem.go` uses temp files plus rename, and `PLANS.md` says the same), so the new refusals don't hit a healthy tree.
- **RT-2.** `mv -T` removes the old "move into a planted directory" case. `mkdir` plus the final check catch the red-team's planted link: 15 to 17 of 20 trials planted, and the victim never changed. A03-1 is what remains.
- **RT-3.**
  - `open_directory_path` walks from `/` with `O_NOFOLLOW` on every part, so a link anywhere in a path is refused at apply time, not only at plan time.
  - `open_regular_file` refuses links, `nlink > 1` and FIFOs. `O_NONBLOCK` means a swapped-in FIFO can't hang the apply.
  - Storage entries that vanish are skipped, which suits a running Vault.
  - The account is reloaded and conflicts are checked again before any change.
  - The backup holds only stat observations, not copies, so reading through a planted name in `create_backup` leaks nothing.

**Manifest (Ran).** `governed_execution_audit_patch_manifest_v2.py` (sha256 c08597e2…a3ca), with
`git reset --mixed origin/trunk_dev` and upstream pinned to `origin/trunk_dev`, run twice under
umask 022: **f4085ffebd349e719090b35e6ed066a85f548968e9c4b195ab2f5bd5a6c4d7e9**, 7 files,
textual diff 3eab76d9…ae1a. Both runs are byte-identical and equal the writer's file. (A first
pair of runs, before I pinned the upstream, differed only in the `upstream` field.)

**Tests (Ran; `tests/`).** Selection: every RT-1, RT-2 and RT-3 test, the two guards, and the
existing ARS hardening, reset and migration tests.

| Run | 76a2608 | 5d6ad51 |
|---|---|---|
| root | 66 pass, 4 fail (the shared 4 above) | 27 pass, 4 fail (same 4) |
| ci (unprivileged) | 70 pass | 31 pass |

**Mutants (Ran; `mutants/`; 32 mutants, each run as root and as ci).** 22 are killed both ways.
The 10 that survive both ways:

| Mutant | Why it survives |
|---|---|
| A1, C1b, C1c, C1d | The gap in A03-3. The proposed tests kill all four. |
| A9 (no direct-child check) | Equivalent: the preflight pins both paths. |
| B5 (no final link check) | Can't be reached: after a successful `mkdir` only a later swap could trip it, and the race can't land one. It becomes moot with A03-1's descriptor step. |
| C12, C13, C14 | The apply-time storage owner rule, the shared-directory list and the conflict re-check. The plan already blocks all three, so only a forged preflight could reach them, and that file's folder is the writer's N-1. Optional: one forged-preflight case each. |

**CI.** The run started 06:11:40Z (`build, vet and test`) and was still in progress when I wrote
this. The result goes in my thread reply. **Codex:** a code review completed on 76a2608 at
06:13:40Z with no findings.

## 4. Observations (no change needed for this PR)

- **O-1.** The RT-1 walks stop on an ARS temp file that vanishes mid-walk, because ARS keeps running during the step. This isn't new: the old `chown -R` failed the same way. It fails closed, and the operator reruns.
- **O-2.** The writer's N-1, root artifacts in world-writable `/var/tmp`, is real in shape. On the box the folder is `ds:ds 0750` (Read: inventory INF-22), so only `ds`, who has sudo anyway, can write there. That supports the writer's guess that the box blocks it, though by `ds` rather than root ownership. Tracking it as its own issue is right.
- **O-3.** The RT-1 parent check looks only at the state root's direct parent. The directories above it (`/var/lib`, `/var`) are system directories that only root can write, and the path is pinned, so this is fine.

## 5. Evidence

`03-audit-evidence/` (hashes in `SHA256SUMS`):
- `manifest/`: both runs.
- `tests/`: root and unprivileged logs on both trees, and the runners.
- `mutants/`: `mutants.py.txt`, `run_mutants.sh.txt`, `results-49-on-76a2608.txt`.
- `probes/`: the RT-2 swap and hard-link probes, and the RT-3 read-only directory probe, with their outputs.
- `proposed/`:
  - `rt2-proposed.diff` with its writer script and results;
  - `rt3-writable-candidate.diff` with its writer script and results;
  - four proposed tests (`*.go.txt`) with their logs on 76a2608, on the proposals and on the mutants.

The probe paths are throwaway rigs, and no real secrets appear.
