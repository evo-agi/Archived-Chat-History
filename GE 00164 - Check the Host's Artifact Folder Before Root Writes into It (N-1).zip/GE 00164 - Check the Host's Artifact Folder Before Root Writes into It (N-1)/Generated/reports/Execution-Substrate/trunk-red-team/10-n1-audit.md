# ES PR #50: audit of the artifact folder check (N-1) at 0330c5a (report 10)

```
Target:    evo-agi/Execution-Substrate PR #50, head 0330c5a590fb625bf38e21ee9c5f92e8f5e48414
           (3 commits on trunk_dev a60c216; trunk_dev is now 2ba2db8)
Asked by:  the PR's writer thread, 2026-11-24 07:35Z (report 07-n1-implementation.md)
Posture:   independent auditor thread. Read-only: nothing pushed, no PR comment, Codex
           threads left for the writer, nothing on the Linux box. Real root; the attacker is
           a real second account (nobody, uid 65534); unprivileged runs as ci (uid 1500) with
           two groups. Every run used a private, empty /var/tmp.
Verdict:   ACCEPT the code. The check is sound. Every root write into the folder that I
           traced, and the reset's one read, runs it first. Probes with a real second account
           found no way through, including a 200-round race. Two test gaps remain (Low, tests
           only): most call sites, and two of the check's rules, are pinned by no test. A
           proposed test file passes on 0330c5a and catches every surviving mutant. Applied
           unchanged, it needs only a byte-for-byte check.
```

Labels: **Ran** (I executed it and saw the result), **Read**, **Inference**.

## 1. The check (Read)

`remote_alpha_prepare_output_dir DIR` is a `python3 -I` step.

- **The walk.**
  - It starts from `/` and goes through every part of `DIR` with
    `O_PATH|O_DIRECTORY|O_NOFOLLOW` and `openat`, so a link anywhere on the path is refused.
  - A missing part is created with `mkdirat(0o755)` through the parent's descriptor and then
    opened again with `O_NOFOLLOW`. If another account wins that race with a folder or a
    link, the open or the owner check that follows refuses it.
  - `..` is refused, and the path is never normalized.
  - Relative paths are joined to `getcwd()`, which has no links, and walked the same way.
- **Trust.** The trusted owners are root, the effective user and a numeric `SUDO_UID`.
  `sudo` always sets `SUDO_UID` itself, so only the person who ran sudo can choose it.
- **Modes.**
  - A folder that its group or others can write is refused.
  - The exception is a folder above `DIR` that root owns and that is sticky (`/var/tmp`, `/tmp`).
  - `DIR` itself is never accepted when its group or others can write it.
  - A named-user ACL entry with write permission shows in the group bits (the ACL mask), so
    it is refused too. That point is Read only: `setfacl` is not installed in this container.
- **Why the result holds after the check returns** (Inference from the rules above).
  - Every folder on the path can be changed only by a trusted account.
  - In a root-owned sticky folder, another account cannot rename or remove a trusted entry.
  - So no other account can swap a name between the check and the write that follows.
- **What it does not cover:** entries that were already in `DIR` before it became private.
  See I10-1.

## 2. Every write and read into the folder (Read)

| Script | What root writes (or reads) there | Check before it |
|---|---|---|
| ARS, AGS and EGS hardening | summary | summary folder at start and again just before the write |
| ES config/TLS prep | summary; backups (apply) | summary folder at start; backup root unless check-only |
| ES binary deployment, host side | summary; backups (apply) | summary folder at start; backup root in apply |
| ES service TLS renew; operator healthcheck TLS renew | summary; backups (execute_renew) | summary folder at start; backup root in execute_renew, and again in `create_backup` before `mktemp -d` |
| Vault service-user migration | summary; preflight read and write; backups (apply) | summary folder at start and before `mv`; in apply, the preflight folder and the backup root. This closes the forged-preflight route behind audit 03's C12 to C14. |
| runtime image check; Vault workload-auth check | summary | summary folder at start and before `install` or `mv` |
| Vault workload-auth bootstrap | summary | summary folder, under `umask 077` |
| runtime identity summary | summary | output folder, unless dry run |
| Vault reset | reads the workload-auth summary (it can name the Vault address) | summary folder before the read |
| ES config/TLS staging and ES binary staging (Mac side) | `rm -rf` and `install` of the staging tree; root runs the staged wrapper | the staging tree's parent, checked through sudo before any other sudo step. Cleanup removes the staging tree only through a folder that passes. The `/tmp` upload and artifact folders are made fresh with `mkdir -m 0700` and no `-p`. |
| operator summary-path preparation | `sudo chown -h` of the folder and the summary file | the folder, checked as the SSH user before sudo; a summary path that is a link is refused |

Other places I checked:
- No other script under `scripts/` names `/var/tmp`.
- Every remote batch that runs sudo on the staging tree runs after the batch that checked and
  installed it, in the same run (`…_main` order).
- The copies test fails when a script names the folder but carries no copy and sends no
  definition.

## 3. Probes (Ran; `probes/`)

Each probe ran in its own mount namespace with an empty tmpfs on `/var/tmp`. The attacker is
uid 65534, driven with `setpriv`. In this container `fs.protected_symlinks=0`, which is the
worst case.

| Probe | Result |
|---|---|
| P1a: the attacker creates the folder 0777 and plants a link to a root file in it; the runtime identity helper runs as root with `SUDO_UID=1500` | refused ("belongs to uid 65534"); the root file is unchanged |
| P1b: the same with an attacker-owned 0755 folder | refused, unchanged |
| P1c: the folder name is a link to a root directory | refused ("is not a directory or is a symbolic link"), unchanged |
| P1d: the attacker owns a folder above the summary path | refused at that folder |
| P1e: no attacker | root creates the folder `root:root 0700` and writes |
| P5: the box layout, a folder owned by ci (standing in for ds) with mode 0750 | refused without `SUDO_UID`; passes with `SUDO_UID=1500` |
| P5b: the same folder with mode 0770 | refused ("can be written by its group or others") |
| P2: a race over 200 rounds. Root removes the folder each round; the attacker plants a 0777 folder with an inner link, or a link, in a tight loop. | 199 refused, 1 written into root's own folder, 0 other. The root file never changed. |
| P7: `remote_alpha_prepare_output_dir_as_root` through real `sudo -n` | a planted folder is refused; a clean run creates `root:root 0755`. The function survives the `declare -f` round trip with its heredoc. |

## 4. Tests, CI and merges

**Manifest (Ran).**
- v2 tool c08597e2…a3ca, `git reset --mixed a60c216`, upstream `origin/trunk_dev`, two runs:
  **6ff204509e0ce4bc0952c2803c363f807340121c565c34f50b238d557f2bd836**.
- Textual diff c97bf977…693c, 21 files; byte-identical to the writer's JSON.
- `git diff a60c216 0330c5a` matches the writer's `pr50-a60c216-0330c5a.diff`.
- `07-evidence/SHA256SUMS` verifies.

**Full `scripts` package, head against base (Ran; `tests/`).** Counts include subtests.

| Run | 0330c5a | a60c216 | New failures |
|---|---|---|---|
| root | 1750 pass, 248 fail, 7 skip | 1739 pass, 248 fail, 7 skip | none |
| ci with two groups | 1751 pass, 250 fail, 4 skip | 1742 pass, 250 fail, 2 skip | none |

The 2 new skips as ci are the two tests that need root or `sudo -n`, which ci lacks here.

**CI (Read).** The run on 0330c5a (45347555517) passed, 07:23:19Z to 07:58:21Z. The gate
fails on any self-skip that is not listed, and this PR lists none, so the sudo tests ran
there.

**Merges (Ran).**
- `git merge-tree` of 0330c5a with trunk_dev 2ba2db8 is clean (tree dbd505a6).
- 0330c5a with #49's dfd765d is clean (tree 916481e2).
- The three-way tree (trunk_dev 2ba2db8 + #49 e8b834b, which is #49's synced tree c56187d4,
  + 0330c5a) is 5a441ed7. On it the full `scripts` package gives: no new failures against 0330c5a, as root and as ci with two groups (root 1796 pass, 257 fail, 7 skip; ci 1799 pass, 250 fail, 4 skip; the failing tests are the same ones as on 0330c5a, and the new passes are #49's and #48's tests).

## 5. Mutants (Ran; `mutants/`)

There were 22 mutants.
- **Core mutants (N)** change the definition and all 13 copies the same way, so the copies
  test stays quiet. Each ran the whole `scripts` package.
- **Call-site mutants (R)** keep the call but make it check `/`. Each ran every test in the
  test files that name the mutated script, plus the output folder tests.
- Root runs are compared with a root baseline on an exported tree. Three tests fail on any
  tree without `.git`, so they are not counted as kills.

| Mutant | ci (two groups) | root | Note |
|---|---|---|---|
| N1 a root-owned folder that others can write counts without the sticky bit | killed (copies test) | killed | |
| N2 the artifact folder itself may be root's and sticky (`/tmp`) | **survived** | killed | A10-2 |
| N3 `SUDO_UID` not trusted | survived here, killed in CI | killed | The owner test needs root or `sudo -n`; CI has sudo |
| N4 the running user not trusted | killed | survived | Equivalent as root: the running user is root |
| N8 group write ignored | **survived** | **survived** | A10-2 |
| N9 owner checked only for the artifact folder | survived here, killed in CI | killed | as N3 |
| R1 ES binary staging checks `/` (4 calls) | **survived** | | A10-1 |
| R3 operator: a summary path that is a link not refused | **survived** | | A10-1 |
| R4 reset, R5 migration preflight folder, R6 and R7 ES binary host backup and summary, R8 bootstrap, R11 runtime image, R12 workload-auth check, R13 ARS hardening, R14 ES config/TLS prep, R15 and R16 the TLS renew helpers, R17 migration summary and backups | **survived** (all 12) | | A10-1 |
| R18 runtime identity summary | killed | | through the `..` test |
| R19 ES config/TLS staging | killed | | through its planted folder test |

The writer's 6 mutants, the two Codex regressions among them, are in `07-evidence/`. I did not
rerun them.

## 6. Findings (Low, tests only)

**A10-1. Most call sites are pinned by no test.** The copies test proves only that each copy is
called somewhere. Behaviour tests exist for three routes: the runtime identity summary, ES
config/TLS staging and the operator's planted-folder case. A call that checks another folder
would pass every other test: 14 of 16 call-site mutants survive. That includes the ES binary
staging route, where root runs `rm -rf` and `install`, and the migration's preflight folder,
which is what closes the forged-preflight route. A regression would bring N-1 back for that
helper.

**A10-2. Two rules of the check are untested in CI.**
- N8: group write alone is never tested. The tests use 0777 folders. Making the box folder
  `ds:ds 0770` would let any member of group `ds` plant links.
- N2: refusing a root-owned sticky folder as the artifact folder itself is tested only as
  root. A summary path such as `/tmp/summary.json` depends on that rule.

**Additions.** One new file, `scripts/remote_alpha_output_dir_call_sites_test.go`, package
`scripts_test`, 233 lines, gofmt clean, sha256 `bb9755ec7ed21e0e319eee296256984a6457f9984b44f1a3d430eb5f32e7b1be`. It is in
`10-evidence-auditor/proposed/`. It holds five tests:
- `TestRemoteAlphaOutputDirRefusesGroupWritableFolders`: folders at 0770 and 0775, as the
  artifact folder and above it. Catches N8.
- `TestRemoteAlphaOutputDirRefusesASharedStickyFolderAsTheArtifactFolder`: `/tmp` and
  `/var/tmp` themselves, whichever is root's 1777. No sudo needed. Catches N2.
- `TestRemoteAlphaOutputDirCallsCheckTheFoldersTheyWrite`: pins, per script, the exact
  folder each call checks and how many calls there are. It fails on an unpinned call or an
  unpinned copy or sender. Catches R4 to R17.
- `TestRemoteAlphaESBinaryDeploymentStageRefusesPlantedArtifactFolder`: the ES binary
  staging route against a planted link. Nothing is installed or removed, the checker does not
  run, and the folder behind the link is unchanged. Catches R1.
- `TestRemoteAlphaOperatorPrepareSummaryPathRefusesASummaryLink`: a summary file that is a
  link to a read-only file gives `summary_path_symlink`, no `chown` or `chmod`, and the file
  is unchanged. Catches R3.

Ran (`proposed/10-additions-vs-mutants.txt`):

| Tree | Result |
|---|---|
| 0330c5a + file, root | the 5 new tests pass |
| 0330c5a + file, ci with two groups | the 5 new tests pass |
| + N2 | FAIL: `…RefusesASharedStickyFolderAsTheArtifactFolder` |
| + N8 | FAIL: `…RefusesGroupWritableFolders` |
| + R1 | FAIL: `…ESBinaryDeploymentStageRefusesPlantedArtifactFolder` and the pin test |
| + R3 | FAIL: `…PrepareSummaryPathRefusesASummaryLink` |
| + R4 to R8, R11 to R17 (12 mutants) | FAIL: `…CallsCheckTheFoldersTheyWrite` |
| + R18, R19 (already killed) | FAIL: the pin test as well |

Every mutant run here is ci with two groups, which is what CI sees.

## 7. Codex threads (Read)

- **`abspath` dropped `link/..`.** Confirmed fixed: `..` is refused and the path is no
  longer normalized. Tested directly and through the runtime identity helper (`…RefusesDotDotComponents`).
- **The `O_RDONLY` walk refused a root-private folder.** Confirmed fixed: `O_PATH` reads
  the owner and mode without read permission. Tested at 0000 and 0300, and through the
  operator's hand-over.

Both threads are still open on GitHub. The writer can resolve them; I do not write to GitHub.

## 8. Info (no change needed)

- **I10-1. Entries already in the folder.** The check makes the folder and the path above it
  safe from now on. It does not inspect entries made while the folder might have been open
  to others. Nothing suggests the box folder ever was (audit 03 saw `ds:ds 750`). For a later
  box turn, I suggest one more read-only row for `box-checks.md`:
  `sudo find /var/tmp/execution-substrate-remote-alpha -mindepth 1 \( ! -user root ! -user ds -o -type l -o -perm /022 \) -ls`.
  Expect no output; anything listed should be looked at before root helpers run.
- **I10-2. Trusting `SUDO_UID` means trusting ds.** The hardening helpers count passwordless
  sudo for ds as a warning, so a process running as ds without the password could plant into
  the ds-owned folder for the next sudo run. Such a process can already capture the password
  or change what ds runs, including the helpers ds uploads. So this opens no new path.
- **I10-3.** The cleanup steps run the check, which creates the folder (`root:root 0755`)
  if it is missing. This is harmless.
- **I10-4.** The `/tmp` upload folder names can be guessed. Another account can plant one and
  make the staging step fail. That is a refusal only, as intended.
- **I10-5.** Report 07 gives the manifest tool sha as `c08597e2…a1ca`. It is
  `c08597e2…a3ca`; the full value checks.
- **I10-6.** The protections are needed whatever the kernel setting. With stock Ubuntu's
  `fs.protected_symlinks=1`, a link placed directly at `/var/tmp/<name>` would already not be
  followed by root. A planted directory with links inside it would be, and the check
  refuses both.

## 9. Evidence

`10-evidence-auditor/` (hashes in `SHA256SUMS`):
- `manifest/`: both runs.
- `tests/`: full-package JSON for head and base, root and ci; the root baseline on an
  exported tree; the three-way trial merge; the runner (`suite.sh`) and comparison scripts.
- `probes/`: `n1_probes.sh` and its output.
- `mutants/`: `mutants50.py.txt`, the runners and the results.
- `proposed/`: the test file, the runner, and the results against the mutants.
