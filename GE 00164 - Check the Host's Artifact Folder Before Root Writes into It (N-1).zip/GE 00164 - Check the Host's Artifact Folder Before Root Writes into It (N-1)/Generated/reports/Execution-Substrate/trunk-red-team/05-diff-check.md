# ES PR #49 repair: diff check of 76a2608..c342535 (report 05)

```
Target:    evo-agi/Execution-Substrate PR #49, head c342535d9a3394589daf4cdae5a8740057cf0224
           (one commit on 76a2608), merge base 5d6ad51; trunk_dev now a60c216 (PR 12)
Asked by:  the PR's writer thread, 2026-11-24 07:02Z (repair for audit 03, report 04-repair.md)
Posture:   independent auditor thread; read-only; nothing pushed, no PR comment; nothing on
           the Linux box. Real root with throwaway accounts, and the unprivileged account ci
           with one and with two groups.
Verdict:   ACCEPT the code. All three audit 03 findings are fixed. Two small test gaps
           remain (Low, tests only). The exact two additions are in 05-evidence-auditor; they pass on
           c342535 and catch the gaps. Applied unchanged, they need only a byte-for-byte
           diff check, no new review.
```

Labels: **Ran** (I executed it and saw the result), **Read**, **Inference**.

## 1. The audit 03 findings

| ID | Status | What I checked |
|---|---|---|
| A03-1 Medium (reset follows a link above the raft directory) | **Fixed** | My diff is applied, with one change: exits are split, so failures after the move exit 3 (inside `recreate()`) and failures before it exit 2. `pgrep` now runs through `sudo`. The static test, the guard's RT-2 rule and the P0m docs line are updated, and the reset's by-name allowance is gone. Ran: my swap probe on c342535 is refused before anything moves (`…/opt/vault/x is not a directory or is a symbolic link … nothing was moved`), and the root directory stays `root:root 755`. |
| A03-2 Low (a folder vault can only read becomes vault-writable) | **Fixed** | `writable_mode` applies to log and audit parents (plan and apply), to an existing storage directory, and to a storage parent that stands in for a storage directory that isn't dedicated (plan and apply). Creating a missing storage directory inside a dedicated parent is still allowed. I agree with that, because the parent itself doesn't change and the new directory is root's and empty until it is handed over. My test passes on c342535 as root, and so does the writer's `…StorageInAReadOnlyVaultDirectory`, both subtests. |
| A03-3 Low (no test shows the first pass only checks) | **Fixed** | My four tests are in the file byte for byte (compared function by function). The writer added `…RefusesALinkAboveTheRaftDirectoryToAVaultFolder`, and was right to: my link-above test hit the owner check first, so it couldn't catch a walk without `O_NOFOLLOW`. This one does (mutant R1, below). |

**Reading the new reset step (Read).**
- The walk from `/` uses `O_DIRECTORY|O_NOFOLLOW` on every part.
- `fstatat(AT_SYMLINK_NOFOLLOW)` plus a uid check runs before the `renameat`, and every failure up to and including the rename exits 2 ("nothing was moved"). That is true: either the rename hasn't happened, or it failed.
- `recreate()` covers `mkdirat`, the `O_NOFOLLOW` open, the root-owned-and-empty check, and `fchown`/`fchmod`. Any exception there becomes exit 3, which bash reports as "the old data is in <backup>".

Info only, no change needed: a Ctrl-C that lands exactly while `os.rename` runs raises `KeyboardInterrupt` after the rename but outside `recreate()`'s `try`. Python then exits 1, and bash would say "nothing was moved". The window is one system call, and Vault stays stopped either way. Ignoring SIGINT, SIGHUP and SIGTERM for the short Python step would close it.

## 2. New: two small test gaps (Low, tests only)

| ID | Mutant that survives | Gap | Addition |
|---|---|---|---|
| A05-1 | R2: the uid check in the Python step removed | No test calls the step on a raft directory of another owner. Only the by-name check before the confirmation is tested, and the P0m line documents this exact refusal ("or the raft directory is no longer the Vault service user's"). | New subtest `raft directory of another owner when the move starts` in `…RefusesUnsafeRaftStates`. It requires the refusal, the raft directory unchanged and no backup. |
| A05-2 | R5: the planted-name path exits 2 instead of 3 | On the race path the old directory has already moved. A regression to exit 2 would make bash tell the operator "nothing was moved" while the raft path is empty. The race test checks only Python's own message, which is the same either way. | In the race test's planted branch, require `was not recreated after the move; the old data is in <backup>` and forbid `nothing was moved`. |

Both additions are in `05-evidence-auditor/proposed/05-test-additions.diff` (sha256
37b2693a…b8b9c, 40 lines, gofmt clean). The script that writes them is `apply_05_test_additions.py.txt`.

Ran (`proposed/05-additions-vs-mutants.txt`):

| Tree | root | ci, two groups |
|---|---|---|
| c342535 + additions | pass | pass |
| + mutant R2 | FAIL (`moved a raft directory of another owner`) | FAIL |
| + mutant R5 | FAIL (`did not report that the old raft directory moved`) | FAIL |

## 3. Checks

**Manifest (Ran).** v2 tool c08597e2…a3ca, `git reset --mixed 5d6ad51`, upstream pinned to
`origin/trunk_dev`, two runs under umask 022:
- **manifest cc3a46bb5a2e9e4722fcffa7f8f0db74e73654c8bc5a56536c91570f82b30a8b**;
- textual diff 8f797838…857c;
- 7 files;
- byte-identical to the writer's JSON.

The ARS script is unchanged since 76a2608 (sha 121f5004…).

**Tests (Ran; `tests/`).** Selection: every RT-1, RT-2 and RT-3 test, the guards, and the
existing ARS, reset and migration tests.

| Run on c342535 | Result |
|---|---|
| root | 74 pass, 4 fail (the same 4 migration tests that fail as root on trunk_dev, as in audit 03) |
| ci, two groups | 76 pass |
| ci, one group | 76 pass |

The race tests ran under load from the parallel mutant runs:
- reset: planted in 11 and 9 of 20 trials;
- migration: refused in 18 of 20;
- the victim never changed.

**Trial merge with trunk_dev a60c216 (Ran).** `git merge-tree` is clean (tree 7c9ef93b…).
PR 12 changes no `.sh` under `scripts/`, so the guard's counts are unaffected. As root on the
merged tree, the guards, the reset and ARS tests and every new migration test pass (72 verdicts).

**Mutants (Ran; `mutants/`).** 39 mutants, each run as root and as ci with two groups.

- **Reused from audit 03** (24 of the A and C mutants still apply). 21 are killed, including the four A03-3 survivors: A1, C1b, C1c and C1d are now killed both ways. Survivors:
  - A9: equivalent, the preflight pins the paths;
  - C13 and C14: apply-time re-checks behind the plan, reachable only through a forged preflight.
- **New**, for the reset's descriptor step (R) and the vault-writable rule (W):

| Mutant | root | ci | Note |
|---|---|---|---|
| R1 walk without `O_NOFOLLOW` | killed | killed | by the writer's new test |
| R2 no uid check in the step | survived | survived | A05-1 |
| R3 no "root's and empty" check on the new directory | survived | survived | Equivalent: only a race can reach it, and then root would hand vault a directory vault itself made |
| R4 `pgrep` without `sudo` | killed | killed | static test |
| R5 planted name exits 2 | survived | survived | A05-2 |
| R6 no `fchmod 0700` | survived | survived | Equivalent: `mkdir(0o700)` under root's umask already gives 0700 |
| R7 no `pgrep` check | killed | killed | |
| W1 writable rule removed | killed | survived | The tests that see it need root to build the folder. CI runs unprivileged, so it can't catch this; my audit and root runs can. |
| W2 a just-created storage directory checked too | killed | survived | same |
| W5 plan storage check lenient | killed | survived | same |
| W3, W4, W6 one layer lenient (apply write parent, plan write parent, apply storage) | survived | survived | Covered by the other layer: the plan and the apply each enforce the rule, and removing the rule from both (W1) is killed |
| C11b apply re-check off | killed | killed | forged-preflight case |
| C12b apply storage rule off | survived | survived | Behind the plan, like C13 and C14 |

**CI (Read).**
- 76a2608: `build, vet and test` passed (06:11:40Z to 06:43:57Z, run 45338619072).
- c342535: started 06:58:11Z and was still running when this report was written; the result goes in the thread reply.
- Codex has reviewed only 76a2608, with no findings.

## 4. Info carried over

- The reset's refusal hint `List them with: pgrep -a -u …` lacks `sudo`, so under a `hidepid` `/proc` it would list nothing. It is cosmetic.
- The source guard's scope is unchanged from audit 03: `setfacl`, `chgrp`, by-name `mv` and standalone `.py` files are not counted.
- The writer's N-1 (`/var/tmp` artifacts) is still separate work.

## 5. Evidence

`05-evidence-auditor/` (hashes in `SHA256SUMS`):
- `manifest/`: both runs.
- `tests/`: root, ci with two groups and ci with one group on c342535; root on the trial merge.
- `probes/`: the swap probe on c342535.
- `mutants/`: `mutants05.py.txt`, the runners, both result files.
- `proposed/`: `05-test-additions.diff`, its writer script, the runner, and the results and logs against R2 and R5.
