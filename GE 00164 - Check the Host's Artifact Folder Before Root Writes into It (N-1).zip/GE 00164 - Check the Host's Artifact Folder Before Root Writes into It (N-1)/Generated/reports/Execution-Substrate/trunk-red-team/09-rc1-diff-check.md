# ES PR #49 RC-1 follow-up: diff check of e41d8ea..dfd765d (report 09)

```
Target:    evo-agi/Execution-Substrate PR #49, head dfd765d6fab4f6a11858001c499ca5ce4d5467fb
           (one commit on e41d8ea, which diff check 05 and the byte check accepted), merge base 5d6ad51
Asked by:  the PR's writer thread, 2026-11-24 07:42Z (report 08-rc1-followup.md)
Posture:   independent auditor thread. Read-only: nothing pushed, no PR comment, nothing on
           the Linux box. Real root, and the unprivileged account ci with two groups.
Verdict:   ACCEPT the code. The fix closes RC-1 as the red-team described it. Two small test
           gaps remain (Low, tests only). Each would let a regression make the migration
           refuse its own output. Two test additions that catch them are in
           09-evidence-auditor. Applied unchanged, they need only a byte-for-byte check.
```

Labels: **Ran** (I executed it and saw the result), **Read**, **Inference**.

## 1. What changed (Read)

The diff touches 3 files:
- `remote_alpha_migrate_vault_service_user.sh` (+81 −12);
- the root paths test file (+132);
- one paragraph of the overview doc.

There is no change outside the migration.

- **`vault_runs_as_service_user`** reads `effective_user`. This is the unit's configured
  `User=` from `systemctl show` (`root(default)` when unset). The Vault account cannot change
  it, because unit files and drop-ins are root's.
- **Plan:** in that state, `plan_file_access` blocks a config or TLS file that vault cannot
  read now.
- **Apply:** `apply_path_changes` reads `systemctl show` again. This matters because an
  apply that reuses an existing preflight does not rerun the plan, so the recorded user
  could be stale. If `systemctl show` fails, the apply refuses.
  - `change_read_file` checks the opened descriptor (`fstat`) before `fchown`, so the check
    and the change see the same file.
  - `own_storage_tree` refuses a directory or regular file that vault does not own.
  - A storage directory that the step just created is exempt (`keep_foreign and not created`).
  - Both refusals also run in the first pass, which only checks, so a refusal means "no path
    was changed".
- **While the unit runs as root,** nothing changes. Path changes still run before the
  drop-in is installed, so a first migration always runs in the root state.

## 2. Checks

**Diff and manifest (Ran).**
- `git diff e41d8ea dfd765d` has sha256 `6c8861d2…925f`, the same as the writer's file.
- Manifest v2 (tool c08597e2…a3ca), run as `git reset --mixed 5d6ad51` with upstream
  `origin/trunk_dev`, two runs under umask 022:
  - **manifest 87b91b15596b014fcddf172344ba905f16ec49111f789896479497a37854da15**;
  - textual diff bf714d16…98aa;
  - 7 files;
  - byte-identical to the writer's JSON.
- The writer's `08-evidence/SHA256SUMS` verifies.

**Tests (Ran; `tests/`).** Selection: the ARS hardening, reset and migration tests, the
by-name guard and the red-team fixed steps. Every run below used an empty private `/var/tmp`.

| Run | Result |
|---|---|
| root, dfd765d | 25 pass, 4 fail. The 4 are the known migration tests that also fail as root on trunk_dev, with the same lines (604, 409, 488, 684). `…KeepsFilesVaultCannotReadFromVault` passes, all 3 subtests. |
| ci with two groups, dfd765d | 29 pass. The new test logs "only root can…" and returns, like the other root-only tests in that file. |
| root, trial merge with trunk_dev 2ba2db8 (#48 is in) | `git merge-tree` is clean (tree d820ae56). The same 25 pass and 4 known failures. The by-name guard still passes, although #48 changes four `.sh` files under `scripts/`. |

**Mutants (Ran, as root; `mutants/`).**

| Mutant | Result | Note |
|---|---|---|
| D4: apply readability check off | killed | TLS subtest |
| D7: storage file owner check off | killed | storage subtest |
| D6: `vault_can_read` loses its group clause | **survived** | A09-1 |
| D2: `created` exemption dropped | **survived** | A09-2 |
| D1: storage directory owner check off | survived | Equivalent in effect, see Info |
| D3: failed `systemctl show` at apply keeps the old behaviour instead of refusing | survived | Error path only, see Info |

The writer's four mutants (old script, apply guard off, plan guard off, guard always on)
cover the same ground as D4 and D7 from the other side. I did not rerun them.

## 3. Findings: two small test gaps (Low, tests only)

| ID | Mutant | Gap | Addition |
|---|---|---|---|
| A09-1 | D6 | No test runs the migration again once Vault runs as vault and its files are in the state the migration leaves them in. The first migration makes config and TLS files `root:vault 0640`, which vault can read only through its group. Without the group clause, every later run would refuse them as "not readable by vault now". The fixture's files belong to the Vault account, so the owner clause always applies in the current tests. | Subtest `a completed migration runs again`: first apply as root's unit, then the drop-in, then check-only must be ready and a second apply must pass. It also checks that config and a TLS file stay `0:vault 0640`. |
| A09-2 | D2 | The exemption for a storage directory the step just created is never exercised. Dropping it would make the apply refuse a missing storage directory once Vault runs as vault, because the new directory is root's. | Subtest `a missing storage directory is created`: drop-in in place, storage directory removed, apply must pass, and the new directory must be `vault:vault 0750`. |

Both subtests are in one new root-only function,
`TestRemoteAlphaVaultServiceUserMigrationKeepsWorkingOnceVaultRunsAsVault`. As another user
it logs and returns, as the writer's test does, so CI's skip gate is not involved.
- File: `09-evidence-auditor/proposed/09-test-additions.diff`.
- sha256 `80b8db65e1a02a476efc1ee7c00551f114621e9dbe881891a3dfc2e59e3d6eec`.
- 56 lines, gofmt clean; `git apply --check` is clean on dfd765d.

Ran (`proposed/09-additions-vs-mutants.txt`):

| Tree | Result |
|---|---|
| dfd765d + additions, root | pass (both subtests) |
| dfd765d + additions, ci with two groups | pass (logs and returns) |
| + mutant D6, root | FAIL: `a completed migration runs again` ("the fixture's plan is not ready") |
| + mutant D2, root | FAIL: `a missing storage directory is created` ("the apply refused to create a missing storage directory while Vault runs as vault") |

## 4. Info (no change needed)

- **D1 is equivalent in effect.** Moving a directory to another parent needs write
  permission on the directory itself, so vault cannot move a root-owned directory into
  storage from elsewhere. A root-owned directory already in storage that holds a root-owned
  file is refused anyway by the file check, in the first pass. What is left is an empty, or
  vault-only, root-owned directory becoming vault's, which gives vault nothing.
- **D3 is reachable only if `systemctl show` fails at apply** after it worked for the
  preflight. The Vault account cannot cause that. The refusal is the right behaviour, and
  only a test of that error path would pin it.
- **`vault_can_read` is approximate (Read; Inference about impact).**
  - **Missed refusals.** It ORs the owner, group and other clauses, while the kernel uses the
    first class that matches:
    - A file vault owns with no owner read bit counts as readable. Vault owns it, so it could
      chmod it anyway.
    - A file `root:vault 0604` counts as readable although vault, matched by the group class,
      cannot read it. The apply would then make it `root:vault 0640`. Only a file that every
      other account can already read is affected, and nothing in the scripts makes such a file.
  - **False refusals, which fail closed.** It ignores vault's supplementary groups and ACLs,
    so a file vault reads only through `ssl-cert` or an ACL would be refused on a rerun. The
    refusal message gives the fix. The box layout is not affected: config `root:vault 640`,
    TLS directory vault's.
  - If the line is touched again, this kernel-order form is a drop-in replacement. It gives
    the same results for every file in the current and proposed tests:
    `if uid == account["uid"]: return bool(mode & 0o400)`;
    `if gid == account["gid"]: return bool(mode & 0o040)`;
    `return bool(mode & 0o004)`.
- **CI (Read).**
  - The e41d8ea run (45346502402) was cancelled at 07:42:36Z when dfd765d was pushed. No
    #49 head after 76a2608 has a finished CI run yet.
  - The dfd765d run (45350047292) started at 07:42:39Z and was still running when this
    report was written.
  - The gate needs a green run on the head that merges.
- The new test is root-only, so CI (unprivileged) does not exercise it. This is the same
  standing limitation noted for W1, W2 and W5 in diff check 05: root runs by the auditor
  cover it.

## 5. Evidence

`09-evidence-auditor/` (hashes in `SHA256SUMS`):
- `manifest/`: both runs.
- `tests/`: root and ci on dfd765d, root on the trial merge, the runner, and a README with the selection.
- `mutants/`: `mutants10.py.txt`, the runner, the results and per-mutant summaries.
- `proposed/`: `09-test-additions.diff`, the added Go source, the runner, and the results against D6 and D2.
