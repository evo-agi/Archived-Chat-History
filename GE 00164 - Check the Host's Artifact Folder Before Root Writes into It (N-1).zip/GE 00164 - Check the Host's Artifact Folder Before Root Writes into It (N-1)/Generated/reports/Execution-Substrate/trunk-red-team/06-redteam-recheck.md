# ES PR #49: red-team re-check of the RT-1, RT-2 and RT-3 fixes (report 06)

```
Target:    evo-agi/Execution-Substrate PR #49, head e41d8eac1c6c609624f8a0ed029d6d2e81fc0b02
           (3 commits on base 5d6ad51; refs/pull/49/head re-checked at 2026-11-24 07:26Z)
Asked by:  the coordinator, 07:17Z. The note named this file 03-redteam-recheck.md, but 03
           is the audit, so this is the next free number, 06.
Posture:   the thread that wrote report 01; separate from the writer and the auditor;
           read-only on the repo; nothing pushed, no PR comment; nothing on the Linux box
           or any live service. One cloud container, real root, and every attacker a real
           process running as a second Unix account (uid 65534, or a real `ars` account).
Verdict:   NO BYPASS. RT-1 and RT-2 hold against everything I tried. RT-3 holds against
           links and races. One Low residual remains in RT-3 (RC-1, reproduced): it is
           far narrower than RT-3, does not block the merge, and has a small follow-up fix.
```

Labels: **Ran** (I executed it and saw the result), **Read**, **Inference**, **Unknown**.

## 1. Result per fix

| Fix | Result | What I tried |
|---|---|---|
| RT-1 ARS hardening | **Holds** | The original reproduction against the PR's unmodified script; 40 reruns against a real ARS-account process that keeps swapping five names for links. |
| RT-2 Vault reset (descriptor step) | **Holds** | 60 runs against a real Vault-account process that swaps the raft name and the backup name for links and deletes root's new directory; planted backup names; a Vault-owned directory in a root-owned parent. |
| RT-3 Vault migration | **Holds against links and races; one Low residual (RC-1)** | 25 applies against a real Vault-account process swapping eight names; a root-only file inside a Vault-owned directory. |

## 2. RT-1: holds

- **Original reproduction (Ran, `rt1-pr49-*.out`).** The report 01 rig (real `ars` account, real
  root, the PR's whole script, only `systemctl` stood in): the index link, the blobs link and
  the nested link are each refused and the root-only token stays `root:root 600`. A first
  run and a clean rerun still give `ars:ars` 750, 750 and 600.
- **Race (Ran, `probe-rt1-rt3.txt`).** A process running as the service account swapped
  `index.json`, a blob, two blob directories and `blobs` itself for links to a root file
  and a root directory, non-stop, across 40 reruns. 30 runs refused, 10 completed, and
  the victim file and directory never changed.
- **Read.** I looked for a name root still resolves by path. The only one is the state
  root's parent, which comes from root-owned config and must belong to root. Hard links
  are refused by the link count on the opened file, so that check does not depend on the
  kernel's hard-link protection.

Info, no change needed: the step creates a missing `blobs` directory before its check-only
walk, and it prints "stopped without changing it" for a refusal in the second walk too.
Both only show when the ARS account is already tampering.

## 3. RT-2: holds

- **Race (Ran, `probe-rt2.txt`).** 60 trials: 29 completed, 29 refused before the move, 2
  stopped after the move with the backup message. The victim directory, its program and
  its listing never changed.
- **Planted backup name (Ran).** A link to the victim: refused, "Not a directory", nothing
  moved. A directory with a file in it: refused. An empty directory: replaced by the
  move, which is harmless.
- **A Vault-owned directory in a root-owned parent (Ran, `rt2-vault-dir-in-root-parent.out`).**
  The Vault account can name `/etc/vault.d` or `/opt/vault` itself as the raft path, and the
  short refusal list lets those through. The step then moves that directory aside and
  creates an empty one. The account ends with what it owned before under a new name, plus
  an empty directory. It gains nothing; it only breaks its own service. Info.
- **Read.** After the move, root hands over only a directory it created itself, checked
  through its descriptor as root's and empty. The Vault account can delete or replace that
  name, and then the step stops with exit 3. I found no way to make the descriptor refer
  to anything the account did not already control.

Info, already in report 05: a signal that kills the Python step between the rename and the
recreation makes bash print "nothing was moved" (Inference: a dropped SSH session sends one). Ignoring
SIGINT, SIGHUP and SIGTERM in that step would close it.

## 4. RT-3: holds against links and races

- **Race (Ran, `probe-rt1-rt3.txt`).** 25 applies while a process running as the service
  account swapped the TLS key, the TLS directory, two storage entries, the storage
  directory, the log file, the audit directory and the config for links. 17 applies
  refused, 8 completed, and the victim file, the victim directory and the foreign
  directory never changed.
- **Read.** Each target is reached from `/` one name at a time without following links,
  the "dedicated to Vault" rule is applied to the opened directory, and a config or TLS
  directory is taken to root before its file is opened. I tried renaming a processed
  directory onto the storage name during the apply (possible, since the account owns the
  parent). It only returns the account's own files to it.

### RC-1 (Low, reproduced): a root-only file inside a Vault-owned directory becomes readable by the Vault account

**What.** The "dedicated to Vault" rule is about directories. Inside such a directory the
apply changes any regular file with one link, whoever owns it. So a file that root keeps
from the Vault account, but that sits in a directory the account owns, can be opened up
in two ways:

1. the account names it as a TLS file in the Vault config it can rewrite (on the box
   `/etc/vault.d` is `vault:vault 755`), and the apply makes it `root:vault 0640`;
2. the account moves it into the storage tree (it may rename entries in directories it
   owns), and the storage walk gives it to the account outright.

**Ran (`recheck_probe_test.go.txt`, `TestRecheckRT3RootOnlyFileInAVaultDirectory`).**

```
named as a TLS file:   before 0:0 0600, the account: Permission denied
                       after  0:65534 0640, the account reads "root keeps this from vault"
moved into storage:    before 0:0 0600, the account: Permission denied
                       after  65534:65534 0600, the account reads it
```

**Why Low.** It reaches only files already inside directories the Vault account owns.
The account can't bring a root-only file in from anywhere else (Read: that needs write
access to the file's directory). On the box the only known file of this kind is
`/etc/vault.d/vault.hcl.package-default` (`root:root 600`; Read: inventory. Inference: it
is the package's default config and holds no secret). Unknown: whether `/opt/vault/tls`
holds a root-only key; the inventory lists only certificates. Trunk let the account
reach any file on the host, so the PR is a large improvement and I would not hold it
for this.

**Suggested follow-up.** When the Vault unit already runs as the Vault user, every file
Vault needs is readable by that user already. In that state the apply can refuse a config
or TLS file the account cannot read today, and a storage entry it does not own. When the
unit still runs as root, no Vault-account process should exist and today's behaviour is
right. The probe above becomes the regression test once its log lines are assertions.

**Box check before the migration's apply is ever run there** (read-only, for a later box
turn): `sudo find /etc/vault.d /opt/vault ! -user vault -ls`. Anything listed besides
`vault.hcl` and `vault.hcl.package-default` deserves a look first.

## 5. Coverage this pass could not provide

- No systemd and no real Vault: the reset and the migration were driven through the PR's
  own fixtures, which source the scripts with stand-ins for `sudo`, `systemctl` and
  `pgrep`. The whole reset (terminal prompts, `vault operator init`) was not run.
- The PR's own new tests pass here as root (Ran, `pr-own-tests-root.txt`); I did not rerun
  the full suite or the auditor's mutants.
- The branch has not been synced with trunk_dev a60c216 yet. That sync should get the
  usual diff check; I did not re-check a merged tree.
- RT-4 (Nomad port holder) and the writer's N-1 (`/var/tmp` artifact folder) are not in
  this PR and stay open.

## 6. Evidence

`06-evidence/` (hashes in `SHA256SUMS`): `recheck_probe_test.go.txt` (the probes, scratch
only, never pushed), `probe-rt1-rt3.txt`, `probe-rt2.txt`, `rt1-pr49-*.out` (five cases),
`rt2-vault-dir-in-root-parent.out`, `pr-own-tests-root.txt`.
