# PR #12 after PR #31: Nomad's token on the private path (N-1), PR #31's guard test positions (N-2), with `trunk_dev` `6dbeaeb`

Status of this file: **REPAIR REPORT, NOT AUDITED.** It covers two merges and six commits after `99a6625` (PR #12's branch since the fast-forward in `34-pr12-fast-forward-99a6625.md`) on draft PR [#47](https://github.com/evo-agi/Execution-Substrate/pull/47) into PR #12's branch. The coordinator asked for this round once PR #31 had merged (03:14Z): take `trunk_dev`, apply N-1 and N-2, re-run the blob-read guard, then hand back for a combined diff check and a final red-team re-check. PR #38 landed at about 03:52Z, while the round ran, so the round takes it up too.

Written by the PR #13 writer thread on 2026-11-24 (UTC).

---

## 1. In plain words

1. **N-1: the private path now sends ES's Nomad token.** PR #31 made ES authenticate every Nomad request with its ACL client token, and its guard refuses a Nomad request path outside a builder that sets the token. PR #12's operational provider sent its three requests (register the job, read the job, read its evaluations) with no token. The provider now takes ES's token when it is built, from the same custody as the ordinary client's, cannot be built without a token in Nomad's canonical form, and sets it in the `X-Nomad-Token` header of every request, never in the URL.
2. **PR #31's guard now covers both Nomad clients.** Its tables name the token builders of each type. Its static half accepts the provider's one builder and refuses a provider request built by hand or off the provider's own receiver. Its builder check requires the provider's builder to set the header from the provider's token. New cases in its own self-tests cover the provider.
3. **The runtime check is in every handoff test.** The fake Nomad of the handoff tests now refuses any request without ES's token, as a Nomad with ACLs does. A new test checks the token, region and namespace on each of the three requests. Another shows a wrong token gets nothing registered, and another that the provider cannot be built without a canonical token.
4. **The rest of PR #31's change list for the provider is gated, not forgotten.** Grants and exclusive writing in the operational namespace, the access-control check before registration, what a refused registration means for the claim, and one Nomad identity in ES's configuration only matter once the provider is wired. It has no production caller, and a maintained gate fails on the first one and prints the prerequisites. That gate gains a seventh prerequisite, `CP-NOMAD-ACL`, in the owner contract and in the gate's list, pinned against each other.
5. **N-2: PR #31's guard test reads real positions.** It made three position reads that PR #12's position-read test refuses. They now go through `guardPosition`, as in the rest of the package.
6. **Re-check 33's Info note I33-3 is closed too.** A driver string that is not valid UTF-8 was kept by the rule; `encoding/json` would then write U+FFFD in its place. No caller can send one today. The rule now refuses it.
7. **`trunk_dev` is merged in twice:** `0842983` (PRs #43, #42, #34, #31) at the start, and `6dbeaeb` (PR #38) after it landed. Each merge had one conflict, in `PLANS.md`, with both entries kept. PR #38 changes no file of the private path and adds no path to PR #12's set.
8. **The path ceiling goes from 69 to 70 files:** PR #31's guard test is the one new path. An owner reconciliation paragraph names it and the five `trunk_dev` PRs, pinned like the earlier ones.
9. **No public behaviour changes.** The private path is unwired; the ordinary path is unchanged. No request contract or stored format changes.

## 2. Identity

| Item | Value |
| --- | --- |
| Repository | `evo-agi/Execution-Substrate` |
| Head | `f7bb1d67a1ef1d2882a2f04e2d8aa62e8457cb04`, tree `8408ab09c56ddaa41c9087c2105fff5c6ba6ae57` |
| Branch and PR | `claude/project-thread-ne9cwa-pr12-trunk-dev`, draft PR #47 into `codex/reliable-submit-operational-handoff-v1` |
| Base (PR #12's branch) | `99a66256be1b238d5bd5487a9926abe044f03028`, tree `11da794471b628481c1972f3663bc9f84cd9cc2f`, unchanged since the fast-forward |
| `trunk_dev` | `6dbeaebdce52b85e85abc8ea3aa2473a45abfcb4` (PR #38), the merge base of the head and `trunk_dev` |
| Commits | `a619076` merge of `trunk_dev` `0842983`; `72cf4d7` N-2; `0db37f1` N-1; `927b310` I33-3; `f3a2d19` documents, `CP-NOMAD-ACL`, 70 paths; `cd615c3` the authority-boundary test's prerequisite count (section 3.4); `8d3a365` merge of `trunk_dev` `6dbeaeb`; `f7bb1d6` names PR #38 in the reconciliation |
| Scope | 70 paths against `trunk_dev` (round 32's 69 plus `es/admission/nomad_request_guard_test.go`) |

Full commit ids: `a619076a96f54fb14f8f20e5a45fa14d1db337e8`, `72cf4d7f94c0a9c7ec3ce82d8f3b4c05d83759b1`, `0db37f120b25cacd2ea4cbe693354ec2835bcb7f`, `927b310e4a90ea8a145cf0ba6e100c6e171c551e`, `f3a2d1971c30aecadb65d25f451408b4d96e268d`, `cd615c3ab8b3d5a67ab8f620209120d8141ea524`, `8d3a3659057f063f0a0dd09d630edabd1459d391`, `f7bb1d67a1ef1d2882a2f04e2d8aa62e8457cb04`.

## 3. The change

### 3.1 N-1: the provider's token (`A/reliable_submit_operational_provider.go`, `A/reliable_submit_operational_handoff.go`)

- `operationalProvider` gains a `token` field. `newOperationalLoopbackProvider` takes the token as a fifth argument and refuses it unless `parseNomadTokenFileContent` reads it back unchanged: a canonical lower-case UUID, Nomad's SecretID form, with no line feed. So a provider cannot exist without a token.
- `prepareExchange`, the provider's only request builder, sets `X-Nomad-Token` from that field, once, on every request. The token never enters the URL. The transport follows no redirect (`RoundTrip`, not a client), so the token reaches only the pinned endpoint. The provider is a private value whose formatting is redacted (`privateExecutionValue`), so the token cannot be printed through it.
- The registration was prepared by the handoff's `liveSender.consume` calling `prepareExchange` with the literal `/v1/jobs`. A new provider method, `prepareRegister`, does that now, so every Nomad path literal is the path argument of a builder called on the provider's own receiver. `consume` still prepares before it takes the owner's lock, as before; nothing else in it moved. `net/http` is no longer imported by the handoff file.
- Where the token comes from in production is fixed by the owner contract (the same custody as the current submit client's, `nomad.token_file`), but no production code builds a provider yet. That stays behind the commissioning gate.

### 3.2 PR #31's guard (`A/nomad_request_guard_test.go`)

- `nomadTokenRequestBuilders` is now per type: `nomadClient` with `newJobRequest` and `get`, as before, and `operationalProvider` with `prepareExchange`. `nomadTokenHeaderSetters` names the builder of each type that makes the request and sets the header.
- The static half recognises methods of either type. A Nomad path literal is approved only as the leftmost operand of the path argument of a builder of the method's own type, called on that method's receiver. The access-control exemption stays with `nomadClient.verifyAccessControl` alone. A hand-built request is refused in any method of either type other than its header setter (and that one exemption).
- The builder check runs per type: the header setter must set `nomadTokenHeader` from the receiver's `token`, and every other builder of the type must build with the setter. The header-deletion check is unchanged.
- Self-tests: three accepted provider forms; six refused provider forms (a builder called off the receiver, from a free function, another type's builder name, a hand-built request, an access-control path in the provider, a path that is not leftmost). The old refused case "another client without the token" now names an unknown type, since the provider is a known client. Four lost-token cases cover the provider's builder (header not set, another value, another header, builder missing).
- The guard's opening comment names both clients and the runtime test of each, and says what a further client needs.

### 3.3 The runtime half (`A/reliable_submit_operational_provider_test.go`)

- The fake Nomad (`operationalReceiver`) records each request, with every value of its token header, and answers `403 Permission denied` to any request whose token header is not exactly ES's test token, before it looks at anything else. So every handoff test that passes through it shows the token was sent.
- `TestEveryOperationalNomadRequestCarriesTheTokenAndTheOperationalNamespace` drives one handoff that registers and observes, and checks the token (once, correct), the query (`region=global&namespace=es-operational-v1`) and that the token is not in the URL, on exactly the three requests.
- `TestOperationalProviderRefusesARequestWithoutTheToken` gives the provider another valid token: nothing is registered and the handoff is not accepted.
- `TestOperationalProviderNeedsANomadToken` builds the provider with the canonical token and fails to build it with seven others (empty, trailing line feed, upper case, short, not a UUID, surrounding space, a word).
- The three test constructions of the provider pass the test token. One of them is in the second red-team's regression file (`reliable_submit_operational_admission_redteam_test.go`), whose one call line gains the argument; nothing else in that file changes.
- PR #12's provider method inventory gains `prepareRegister` (one reference, from `liveSender.consume`), and `prepareExchange`'s references are now `prepareRegister` once and `observe` twice.

### 3.4 `CP-NOMAD-ACL` (owner contract §8, `A/reliable_submit_guardrails_test.go`)

The owner table and the gate's list gain, before `CP-PUBLIC-MAPPING`:

> `CP-NOMAD-ACL`: The provider's Nomad access under access control is settled: ES's token holds `submit-job` and `read-job` in the operational namespace and no other policy may write there, set up and checked by the Nomad ACL tool; registration runs the current submit path's access-control check over the provider's own pinned transport before `POST /v1/jobs`; what a 401 or 403 on registration means for the claim is selected; and the provider's endpoint and pin come from the same ES configuration as the current submit client's Nomad identity.

These are items 2 to 6 of PR #31's change list (`nomad-acl/01-implementation.md`, section 8). Today a 403 on registration leaves the claim ambiguous, which is safe but would strand it; that is why the meaning of a 401 or 403 is a prerequisite and not a silent default. The docs test pins the two lists against each other, with seven identifiers now, and two new mutants remove it from each side.

`TestOperationalHandoffOpaqueAuthorityBoundaries` also pins the list's length. I missed that pin in `f3a2d19`, because my targeted runs before the push selected tests by name and this one did not match. The first full run at `f3a2d19` failed it (6 expected, 7 found); `cd615c3` changes the 6 to 7 and nothing else. That run is kept in `runs/earlier-f3a2d19/`.

### 3.5 N-2 and I33-3

- `A/nomad_request_guard_test.go`: the three `fileSet.Position(…)` reads (lines 119, 218 and 230 at `0842983`) are now `guardPosition(fileSet, …)`.
- `A/service.go`: `nomadKeepsDriverString` first requires `utf8.ValidString`. Its unit test gains a stray byte, an encoded surrogate and an overlong encoding.

### 3.6 PR #38 (`8d3a365`, `f7bb1d6`)

PR #38 (one allowlist-prefix rule, a type-aware caller identity guard, DER-decoded operator identity) merged into `trunk_dev` as `6dbeaeb` at about 03:52Z. Its changes meet PR #12's set in five files, all documents or docs tests: `.docs/execution_lifecycle/contracts.md`, `.docs/system_overview/boundaries.md`, `.docs/system_overview/contracts.md`, `PLANS.md` and `docs_contract_test.go`. Only `PLANS.md` conflicted (both new top entries kept, PR #12's first). PR #12's path set against `trunk_dev` is the same 70 paths before and after. PR #38's new guard reads positions with `PositionFor(pos, false)`, which PR #12's position-read test accepts. Nothing under `es/admission/` changed between `cd615c3` and `f7bb1d6`.

`f7bb1d6` then adds `#38` to the list of `trunk_dev` PRs in the owner reconciliation paragraph, its pin and Missing mutant, and the `PLANS.md` entry.

### 3.7 Documents

- Owner contract: a paragraph after the POST paragraph of "Exchange limits and positive witness" states the token rule; the `CP-NOMAD-ACL` row; the reconciliation paragraph for 70 paths (the previous one now says "was 69 files").
- `PLANS.md`: a new top entry, the previous one now says "became 69 files", and the prerequisite list of the 2026-11-22 entry gains `CP-NOMAD-ACL`. `trunk_dev`'s own Nomad lock entry, which says the provider "is not yet covered", stays as written history; the new entry above it says what changed.
- `docs_contract_test.go`: pins for all of the above, six Missing mutants and four wrong-statement mutants for the new wording, and the two prerequisite-removal mutants.

## 4. Validation

All runs are on Linux, Go 1.26.5, in a clean clone run as user `ci` with an emptied environment (`scripts/val35.sh`), unless the line says otherwise. **Ran** means executed with the output seen.

| Check | Result at `f7bb1d6` |
| --- | --- |
| `go build` and `go vet`, linux/amd64, linux/arm64, darwin/arm64 | ok, all three (Ran) |
| `gofmt -l` | the same six files `trunk_dev` lists (`ags/sign/signer.go`, `ars/index/index.go`, `egs/sign/signer.go`, `es/runtimehelper/main.go`, `es/runtimehelper/privilege_linux.go`, `internal/observability/observability.go`), none of PR #12's (Ran) |
| Blob-read guard (`TestFetchVerifiedARSBlobIsTheOnlyARSBlobReadInES`, `TestESBinaryRepositoryPackageDirsSeesEveryLinkedRepositoryPackage`, `TestDependencyClientsDoNotFollowRedirects`) | 3 pass, 0 fail (Ran) |
| Root docs pins (`TestOperationalSubmitHandoffCurrentAdmissionV2*`, strings contract, ARS blob verification, runbook paths, link checks) | 10 pass, 0 fail (Ran) |
| `-race` on the Nomad, provider, job-bound, red-team and driver-string tests of `es/admission` | ok, 71.6 s (Ran) |
| `-race` on `OperationalLocatorShape` in `reliablesubmit` | ok (Ran) |
| `es/admission` whole package | 575 top-level tests pass, 14 skip, 0 fail (Ran) |
| Whole module against `trunk_dev` `6dbeaeb` run the same way | 7,497 results in both, **0 changed**. 2,174 new: 2,172 pass, 1 skip (`TestOperationalHandoffChildProcess`, a helper that only runs as a child), 1 fail (`TestOperationalHandoffSchema4BinaryRefusesSchema5`, which builds a probe binary and is on CI's list of environment-only tests, as in rounds 29 to 32). 0 gone. Top-level failures: 28 on `trunk_dev`, 29 at the head, the extra one being that probe test (Ran) |
| Whole module against round 32's head run (`99a6625`) | 9,268 results in both, **0 changed**. New: 385 pass, 12 skip (live tests from `trunk_dev`), 6 fail: `TestRemoteAlphaOperatorHealthcheckTLSStatusNoninteractiveRuntimeKeepsEachIdentityClassification` and its 5 subtests, new in PR #38. They fail on `trunk_dev` `6dbeaeb` alone too, the same way: the tool's preflight needs `/usr/bin/ssh`, which this container lacks; GitHub's runner has it. 43 gone, all randomly named subtests (Ran) |
| Earlier head `cd615c3` (before PR #38) against `trunk_dev` `0842983` | 7,404 in both, 0 changed; the same 2,174 new with the same one skip and one fail (Ran; `runs/earlier-cd615c3/`) |

The first full run at `f3a2d19` failed `TestOperationalHandoffOpaqueAuthorityBoundaries` (section 3.4) and nothing else new; it is kept in `runs/earlier-f3a2d19/`.

**Mutants** (`scripts/mutants35.py`, a clean clone of `cd615c3`; nothing under `es/admission/` differs at `f7bb1d6`). Each mutant changes one thing and runs the round's tests of its package. All 13 are caught, and both no-change baselines pass:

| Mutant | Caught by |
| --- | --- |
| T1 the provider sends no token | 3 tests, including the new three-request test and PR #31's builder check |
| T2 the token goes into the query instead of the header | 3 tests |
| T3 the provider is built without a token check | `TestOperationalProviderNeedsANomadToken` |
| T4 a token with a trailing line feed is accepted | `TestOperationalProviderNeedsANomadToken` |
| T5 the token header is sent twice | 2 tests |
| T6 another value is sent as the token | 3 tests |
| T7 registration prepared off the provider's receiver again | 2 tests, including PR #31's static half |
| U1 a driver string that is not UTF-8 is kept | the driver-string unit test |
| G1 the guard accepts a builder called on any value | the guard's bypass self-test |
| G2 the access-control exemption covers any type | the guard's bypass self-test |
| G3 the builder check accepts any token value | the guard's lost-token self-test |
| G4 the provider is dropped from the guard's builder table | 3 tests |
| C1 `CP-NOMAD-ACL` is dropped from the commissioning gate | 2 root docs tests |

T4 and G3 were first written so that the mutated code no longer compiled (an unused variable); I rewrote both to keep every variable used and re-ran them alone (`mutants/mutants35-cd615c3-t4-g3-rerun.log`).

**CI** on draft PR #47: run [45324371962](https://github.com/evo-agi/Execution-Substrate/actions/runs/45324371962) of `build, vet and test`, success on `f7bb1d6` (04:09Z to 04:45Z). The run on `cd615c3` was cancelled when `f7bb1d6` was pushed.

## 5. Provenance manifests

Recipe `governed-execution.audit-patch-manifest.v2`, source SHA-256 `c08597e2925a913890828459bf90b28e8e3abb8684d5ea65259c4c3744e1a3ca` (checked before each run), on a clean working tree at the pushed tip `f7bb1d6` (`scripts/prov35.sh`). Each manifest ran twice, byte-identical. In each, the path set equals `git add -A` staged against its reset target, and the staged tree equals the tip's tree `8408ab09c56ddaa41c9087c2105fff5c6ba6ae57`. Afterwards the working tree was clean and HEAD and the upstream were restored.

| Manifest | Reset target and upstream | Files | Textual diff SHA-256 | Manifest SHA-256 |
| --- | --- | --- | --- | --- |
| `trunk_dev`-relative (PR #12's whole change) | `6dbeaeb`, `origin/trunk_dev` | 70 | `36bf4a44b64bad48eeb8349aba6ae43ec5dc7c90cd6d135b6885806f9450c517` | `41ac8bad47ed08df678f48d2004edecf3c6262de4bb01a704e2938e9ddb8054b` |
| PR-relative (this draft against PR #12's branch) | `99a6625`, `origin/codex/reliable-submit-operational-handoff-v1` | 91 | `f0951aa2bd4ad1aa7a8a14a23fed31919b8acbfef17feeb417a81b28d4793e57` | `6d6dd5845c2eed959b2a8f9c84dfec9b085d4bf6841ffaddbadcce2029b0bea8` |

The PR-relative set is large because it includes everything `trunk_dev` gained since `4c991ba` (PRs #43, #42, #34, #31, #38).

Against round 32's `trunk_dev`-relative manifest (`73ed8c3c…`, 69 files): one path added, `es/admission/nomad_request_guard_test.go`; none removed; 17 changed. Eleven are this round's edits (`A/reliable_submit_operational_provider.go`, `A/reliable_submit_operational_handoff.go`, `A/service.go`, `A/reliable_submit_operational_provider_test.go`, `A/reliable_submit_operational_handoff_test.go`, `A/reliable_submit_operational_admission_redteam_test.go`, `A/reliable_submit_guardrails_test.go`, `A/nomad_request_strings_test.go`, the owner contract, `PLANS.md`, `docs_contract_test.go`). Six changed only through `trunk_dev`: `.docs/execution_lifecycle/contracts.md` (PRs #31 and #38), `.docs/execution_lifecycle/es_execution_admission_model.md`, `.docs/execution_lifecycle/implementation.md` and `A/workstream_c_guardrails_test.go` (PR #31), and `.docs/system_overview/boundaries.md` and `.docs/system_overview/contracts.md` (PR #38).

The manifests at `cd615c3`, before PR #38, are kept in `manifests/earlier-cd615c3/` (`trunk_dev`-relative `e451518f…`, 70 files; PR-relative `61b5dda1…`, 66 files). Between the two `trunk_dev`-relative manifests only the six files PR #38 and `f7bb1d6` touch differ.

## 6. For the combined diff check

- Merges: `commits/merge-check-a619076.txt` and `commits/merge-check-8d3a365.txt`. In each, git's own merge tree (`git merge-tree --write-tree`) differs from the merge commit only in `PLANS.md`, by the three conflict markers removed and one blank line between the two entries.
- The round's own changes are the six non-merge commits, as patches in `commits/`. `git diff a619076 cd615c3` (`commits/repair.diff`) is everything before PR #38: 12 files, +410/−102 (+384/−76 ignoring whitespace; the rest is gofmt's realignment of the guard's maps and of a test's comments). `f7bb1d6` adds 3 files, +5/−5.
- Questions worth checking:
  - whether the guard extension keeps PR #31's guarantees for `nomadClient` exactly (the accepted and refused cases of PR #31 all still run);
  - whether `prepareRegister` changes anything about when the POST is prepared relative to the owner's lock;
  - whether `CP-NOMAD-ACL` names everything in PR #31's change list that wiring needs, and whether it should instead be part of `CP-NATIVE`;
  - whether a real ACL Nomad answers a request with the right token but no grant in the namespace as the fake does (it does not matter today: the provider is unwired).

## 7. Evidence

`35-repair-evidence/` (and `35-repair-evidence.tar.gz`), with `SHA256SUMS`:

- `commits/`: the six commits as patches, both merges' summaries and merge-tree checks, the repair's diff;
- `mutants/`: `mutants35-cd615c3.log`;
- `runs/`: the head run at `f7bb1d6` with its comparisons, the `trunk_dev` `6dbeaeb` run, the earlier runs at `cd615c3` and `f3a2d19`, and the `trunk_dev` `0842983` run;
- `manifests/`: both manifests at the head, twice each;
- `scripts/`: `val35.sh`, `mutants35.py`, `prov35.sh`, `compare-moved.py`.

## 8. Not claimed and still open

- No audit of this round yet, and no red-team re-check. Nothing ran on macOS. Nothing ran against a real Nomad: the provider is unwired, so no live check applies to N-1 today; `box-live-checks.md` is unchanged.
- `CP-NOMAD-ACL`'s items are not done; they are gated. I wrote the change and my tests.
- `trunk_dev` moved on after the head: PR #44 merged as `c610e1d` at 04:44Z (one reliablesubmit test file, outside PR #12's paths). PR #12 takes it, and anything else that lands meanwhile, at its last `trunk_dev` sync before it merges, with a diff-only check of that sync.
- The live checks of `box-live-checks.md` have David's go and run in the coordinator's box order: Parts A and C after the Nomad lock's box run, Part B after PR #12 merges.

## 9. Effects

- Pushed `a619076` to `f3a2d19` to `claude/project-thread-ne9cwa-pr12-trunk-dev` at 03:34:58Z, a fast-forward of the branch from `99a6625`, which is PR #40's merged head; no force. Opened draft PR #47 into `codex/reliable-submit-operational-handoff-v1` at 03:35Z and subscribed to its activity.
- Pushed `cd615c3` at 03:49:44Z and `8d3a365` with `f7bb1d6` at 04:09:04Z, both fast-forwards, no force.
- PR #47's title and description updated to this report.
- `box-live-checks.md` (same folder): a Part C for the real Nomad's answer to the provider's requests, the run order, and David's go of 04:23Z.
- This report and `35-repair-evidence/`.
- Not changed: PR #12's branch (still `99a6625`), its description, `trunk_dev`, `main`. Nothing ran on the box or the Mac.
