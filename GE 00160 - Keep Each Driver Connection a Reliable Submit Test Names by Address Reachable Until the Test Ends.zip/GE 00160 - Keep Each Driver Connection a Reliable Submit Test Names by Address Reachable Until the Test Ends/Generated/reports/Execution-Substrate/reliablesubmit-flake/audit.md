# INDEPENDENT AUDIT REPORT: PR #44, the reliablesubmit connection-identity flake (`37ad684`)

This was a short, read-only audit, kept small because quota is tight. The auditor is the "Audit ES config field guard" thread. It ran on 2026-11-24 from 01:20Z to 01:55Z (UTC). The PR changes one test file, so no red-team was needed.

Verdict: **ACCEPT**, with no findings.

## 1. In plain words

1. **The cause is real, and I reproduced it.** The tests recorded only a driver connection's memory address. Once the pool closed that connection, nothing referenced it, so Go could free it and put the next connection at the same address.
   - I ran the writer's probe myself on the base (`4c991ba`). The new connection got the discarded connection's address in 2,999 of 3,000 rounds.
   - On the PR head the same probe got 0 of 3,000.
2. **The fix identifies connections robustly.** Each helper that records an address now also keeps the connection object reachable until the test ends. It does this through `t.Cleanup` with `runtime.KeepAlive`.
   - While an object is alive, no other object can have its address. So two recorded addresses are equal exactly when they are the same connection.
   - Every address comparison in the package goes through the two changed helpers, `d1DriverConnIdentity` and `d1LostBeginHook`. This covers all 6 tests that compare addresses, in 3 files. I found no other place that records an address.
3. **No assertion was weakened.** The diff only adds lines: an import, one retain call in each helper, and the new helper with its comments. No check changed.
   - The "must be a new connection" checks still fail if the pool really hands back the same connection, because that object is still alive and keeps its address.
   - The "must be the same connection" checks behave as before.
4. **It is stable.** I ran the 6 affected tests 218 times in a row, then 212 times on one CPU (`GOMAXPROCS=1`), then 10 rounds under the race detector. Everything passed and no data race was reported.
   - The first two runs stopped at go test's default 10-minute limit, which I had not raised. They did not stop on a failure.
5. **Nothing else changed.** The whole reliablesubmit package gives identical per-test results on base and head: 572 pass, 2 skip, 2 fail.
   - The 2 failures are the tests that need an old ES binary. They fail the same way on both trees.
6. **CI passed.** GitHub's required check passed on `37ad684`.

## 2. Target

| Item | Value |
| --- | --- |
| Pull request | `evo-agi/Execution-Substrate` #44, branch `claude/project-thread-ne9cwa-replay-conn-identity` into `trunk_dev` |
| Head | `37ad684be94893305ba09d427818c1ad32586e37`, tree `dfc7efc72a4de2fec27906ed9c66c176de171428`, one commit |
| Base | `trunk_dev` `4c991ba1c43ac135d9d94853696d14a21523a690`, merge base |
| Diff | `es/admission/internal/reliablesubmit/replay_key_use_sqlite_test.go`, +18/−0, SHA-256 `435e48be…6aa3` |
| Trunk now | `523648c`. The only change since the base is `README.md` (PR #43). `git merge-tree` with the head gives `8dbe98f3…` with no conflict. GitHub shows the branch as behind, so it must take the new trunk before it merges |
| Failure being fixed | `TestReplayOriginalKeyReadCleanup/commit_response_loss_model`, "uncertain driver connection reused", CI run 45293900583 |

## 3. Posture

Read-only on GitHub. I tested `git archive` exports of the exact commits, as user `ci` under `runuser … env -i`, with Go 1.26.5, `GOTOOLCHAIN=local` and `GOPROXY=off`.

I pinned identity by commit, tree and diff hash, and did not run the v2 manifest. I skipped it because no writer manifest was given for this PR and the audit was asked to stay small. The probe is the writer's scratch file, unchanged. I added it only to copies of the trees.

## 4. Review notes

- `d1RetainDriverConn(t, raw)` registers a cleanup that captures `raw`, which is the driver connection that `Raw` hands out.
  - The capture alone keeps the object reachable, because the closure sits in `t`'s cleanup list until the test ends. `KeepAlive` documents the intent.
  - `raw` is the same pointer whose address is recorded.
- The object is only kept: it is never called outside `Raw`. The comment saying so is accurate.
  - Keeping a closed `modernc.org/sqlite` connection object alive costs only memory for the test's lifetime. It does not change what the pool does.
- `d1LostBeginHook` calls `t.Cleanup` from inside the store's hook, during the test. `t.Cleanup` is safe from any goroutine while the test runs.
- Two distinct live objects can share an address only if they have zero size. The driver connection is a struct with fields, so that case does not apply.

## 5. Runs (`audit-evidence/`)

| Run | Tree | Result |
| --- | --- | --- |
| Writer's address-reuse probe, 3,000 rounds | base | reused 2,999 of 3,000, so the probe fails |
| Same probe | head | reused 0 of 3,000, passes |
| `go vet`, `gofmt` on the package | base, head | clean |
| Whole package, `-count=1` | base, head | 572 pass, 2 skip, 2 fail on each, identical per test |
| 6 affected tests, `-count=100` | head | 218 of 218 completed runs pass (36 rounds); stopped by the 10-minute default timeout |
| Same, `GOMAXPROCS=1`, `-count=50` | head | 212 of 212 completed runs pass; stopped by the same timeout |
| Same, `-race -count=10` | head | pass, 418 s, no data race |

The 6 tests are `TestReplayOriginalKeyReadCleanup`, `TestSQLitePooledClaimReadCleanup`, `TestPrivateReplaySharedObjectAllocation`, and the claim, grant and key-state `D1BeginResponseLossQuarantine` tests.

I could not make the original test fail on demand, and neither could the writer. The probe shows the mechanism directly: it reuses the address almost every time on the base and never on the head.

## 6. CI

GitHub's required check "build, vet and test" is run 45303252731 (job 138140733077) on head `37ad684`. It finished with **success**, from 01:12:23Z to 01:42:55Z. I read the result through the GitHub tool and did not rerun CI. Codex's automatic review of `37ad684` reported no findings.

## 7. Findings

None.

## 8. Effects

This audit made no commit, push, PR comment, review or merge. The only writes are this report and `audit-evidence/` in the project folder.

The PR is test-only, so under the project's merge policy it can merge without David's review. Two steps come first: the branch takes `trunk_dev` `523648c`, and the merge gate then passes on that new head.

Evidence is in `audit-evidence/`, with `SHA256SUMS`. It holds the probe logs and the probe used, the static logs, the package and repeat runs as gzipped JSON, the race log, the package comparison, refs and diff, and the runner scripts.

Final verdict: **ACCEPT** for head `37ad684be94893305ba09d427818c1ad32586e37`, base `4c991ba`.
