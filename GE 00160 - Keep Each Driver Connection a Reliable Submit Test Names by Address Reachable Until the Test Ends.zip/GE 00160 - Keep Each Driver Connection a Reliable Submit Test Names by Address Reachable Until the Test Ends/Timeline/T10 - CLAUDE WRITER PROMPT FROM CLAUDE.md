Merge freeze: merge nothing into trunk_dev (including #45) until PR #46 lands (CI on 06731ca, about 05:26Z). I'll lift it.
