PR 12's round after the Nomad lock is done and handed back for its final checks. The private path now sends ES's Nomad token, and the lock's guard covers it. The remaining Nomad setup for that path is now a hard prerequisite before it can be switched on. CI is green and no existing test result changed. The flake fix (PR #44) is merged into trunk_dev. Your box-run go is noted: my live Nomad checks will run when the coordinator gives me the box.

STATUS: WAITING (combined diff check and red-team re-check)
