I've fixed both problems the red-team's re-check found in [PR #40](https://github.com/evo-agi/Execution-Substrate/pull/40), and it's now with the auditor for a check of just the new changes. ES now refuses arguments and mount paths that Nomad would silently rewrite, and memory requests below Nomad's 10 MB minimum. The red-team's tests pass, and my deliberately broken versions of the new checks were all caught.

The flaky test on PR #34 had a real cause; [PR #44](https://github.com/evo-agi/Execution-Substrate/pull/44) fixes it, changing tests only.

The live Nomad checks are now one list and need your go.

STATUS: WAITING (audit, CI)
